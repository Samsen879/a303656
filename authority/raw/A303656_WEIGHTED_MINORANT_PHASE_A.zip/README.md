# A303656 Weighted-Minorant Phase A Bundle

## Verdict

`NO PROMOTABLE ROUTE — SPECULATIVE WATCH`

This bundle audits bounded support weights for the sums-of-two-squares component in OEIS A303656. It does not reprove the frozen positive-density theorem and does not claim almost-all representability.

## Required deliverables

- `EXECUTIVE_VERDICT.md` — decision and gate summary.
- `WEIGHT_CANDIDATES.md` — exact candidates, especially \(\nu_\tau=r_2/(4\tau)\).
- `CORRELATION_CROSSWALK.md` — theorem-by-theorem compatibility matrix.
- `WEIGHTED_TO_SUPPORT_GAP.md` — exact transference implication, boundaries, diagonal, collisions.
- `LITERATURE_AUDIT.md` — primary-source audit with theorem anchors.
- `NO_GO_RESULTS.md` — invalid shortcuts and counterchecks.
- `REPORT.md` — integrated research report.
- `PROMOTION_VERDICT.json` — machine-readable verdict.

## Reproducibility extras

- `SANITY_CHECKS.json`
- `scripts/sanity_checks.py`
- `SOURCE_LOCK.json`
- `PROVENANCE.md`
- `MANIFEST.json`
- `SHA256SUMS.txt`
- `scripts/build_deterministic_zip.py`
- `scripts/verify_bundle.py`
- `VERIFICATION.md`

## Reproduce the small checks

```bash
python3 scripts/sanity_checks.py \
  --limit 1000000 \
  --output /tmp/SANITY_CHECKS.rebuilt.json
cmp SANITY_CHECKS.json /tmp/SANITY_CHECKS.rebuilt.json
```

This is a candidate-weight sanity computation only. It performs no large \(T(n)\) search.

## Verify bundle integrity

```bash
python3 scripts/verify_bundle.py --root . --deep
```

## Build deterministic ZIP

From the parent directory:

```bash
python3 A303656_WEIGHTED_MINORANT_PHASE_A/scripts/build_deterministic_zip.py \
  --root A303656_WEIGHTED_MINORANT_PHASE_A \
  --output A303656_WEIGHTED_MINORANT_PHASE_A.zip
```

The builder sorts archive paths, uses timestamp `1980-01-01 00:00:00`, normalizes regular-file permissions to `0644`, and uses DEFLATE level 9.

## Status

OEIS A303656: UNRESOLVED.
