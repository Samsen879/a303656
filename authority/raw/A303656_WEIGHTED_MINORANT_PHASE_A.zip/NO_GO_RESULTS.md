# No-Go Results

每条 no-go 都是对一个常见 shortcut 的严格阻断；它们不是对未来所有 weighted routes 的不可能性定理。

## NG-1. Hooley \(\rho\) is not a nonnegative minorant

Hooley explicitly states that its damping factor \(t(n)\) is not always positive。Although \(\rho(n)=0\) off \(\mathcal S_2\)，neither \(\rho\ge0\) nor \(\rho\le C\mathbf1_{\mathcal S_2}\) holds。Hence Eq. (20) cannot be inserted as the requested \(\nu\)-covariance theorem。

## NG-2. Squaring, absolute value, and positive part do not inherit correlations

From an asymptotic for \(\sum\rho(n)\rho(n+h)\) one cannot infer one for

\[
\rho(n)^2\rho(n+h)^2,
\quad |\rho(n)||\rho(n+h)|,
\quad \rho_+(n)\rho_+(n+h).
\]

These are nonlinear observables requiring fourth/absolute-value/truncated moments。They are generally unbounded as well。

## NG-3. Raw \(r_2\)-weighted almost-all is not automatically support almost-all

There are three distinct statements：

1. large total \(r_2\)-weighted mass；
2. almost-all with respect to an \(r_2\)-weighted measure；
3. for almost every base \(n\), the shifted convolution \(\sum_s r_2(n-s)\) is positive。

Only (3), or a genuine concentration theorem implying (3), forces support coverage。Because \(r_2\) is unbounded and \(\sum r_2^2\asymp X\log X\)，(1)–(2) may concentrate on high-multiplicity integers。No conversion to counting measure is valid without an anti-concentration/tail argument。

## NG-4. Dividing a known \(r_2\) formula by \(\tau\) is invalid

The identity \(\nu_\tau=r_2/(4\tau)\) is pointwise, but

\[
\sum_{n\le X}\frac{r_2(n)r_2(n+h)}{\tau(n)\tau(n+h)}
\]

is not obtained by dividing an asymptotic for \(\sum r_2(n)r_2(n+h)\) by an average divisor factor。The denominators correlate with the numerators and with the shift。

## NG-5. Clipping destroys the divisor-sum algebra

Weights such as

\[
\min(1,r_2/B),\quad \min(1,|\rho|/B),\quad (L_z^-)_{+}
\]

can enforce nonnegativity/boundedness, but their products are nonlinear。No audited theorem transfers the original first/two-point formulas through clipping。Correct first mass also must be reproved。

## NG-6. Finite-level lower sieve is not exact support

Let

\[
L_z^-(n)=\sum_{d\mid(n,P_3(z))}\lambda_d^-.
\]

Rosser lower weights can give \(L_z^-\le\mathbf1_{(n,P_3(z))=1}\)，but \(L_z^-\) may be negative。After positive-part clipping, the result is at best supported on integers avoiding small inert primes。For an inert prime \(q>z\)，the integer \(n=q\notin\mathcal S_2\) can pass every small-prime test。Thus no strict support implication follows。

## NG-7. Selberg/enveloping sieve squares point in the wrong direction

\[
\left(\sum_{d\mid n}\lambda_d\right)^2\ge0
\]

is an outer majorant。It is generally positive on many non-\(\mathcal S_2\) integers。Multiplying by \(\mathbf1_{\mathcal S_2}\) restores the original hard indicator；multiplying by \(r_2\) restores an unbounded representation observable。

## NG-8. Dense model does not preserve support zeros

A dense model theorem controls selected averages between a sparse function and a bounded surrogate。It does not imply

\[
g(m)>0\Rightarrow m\in\mathcal S_2,
\]

nor that a zero of the original shifted support convolution corresponds to a zero of the model convolution。Therefore density-one coverage cannot be read from model density alone。

## NG-9. Pair lower/upper bounds do not yield covariance cancellation

Even matching-order bounds

\[
c_hX/\log X\le C_h(X)\le C_h'X/\log X
\]

permit covariance of order \(X/\log X\) for every pair。Summing over \(W_X^2\) pairs then remains of main scale, sufficient at best for a bounded second-moment ratio/positive density—not density one。

## NG-10. Fixed shift cannot be silently made growing

Constants written \(O_h,\gg_h\) may deteriorate arbitrarily with \(h\)。The present difference family grows and contains polylogarithmically many structured shifts。No diagonal argument authorizes choosing \(h=h(X)\) in a theorem proved after fixing \(h\)。

## NG-11. Fixed tuple cardinality is not \(K=(\log X)^2\)

Kimmel–Kuperberg/McGrath fix tuple size before the asymptotic。A theorem with constants depending exponentially or worse on fixed \(K\) cannot be substituted with \(K=W_X\to\infty\) without explicit uniformity。

## NG-12. Nonparallel linear-forms theorems exclude the target at hypothesis level

For \(n-s,n-t\)，the coefficient vectors of the nonconstant parts are identical。Loughran–Matthiesen Definition 3.9, MSTT Definition 9.1, and Green–Tao Definition 3.1 all impose independence/nonproportionality conditions that fail before error estimates are considered。

## NG-13. Bantle’s title is not an indicator asymptotic

Bantle Theorem I concerns \(r(n)r(n+1)\)。Theorem II is an indicator lower bound for shift 1。Citing “An asymptotic formula for B-twins” as an asymptotic for \(\mathbf1_{\mathcal S_2}(n)\mathbf1_{\mathcal S_2}(n+1)\) is factually wrong。

## NG-14. Average over all shifts does not automatically control this sparse family

A theorem averaging an error over every \(|h|\le H\) can still allow all exceptional \(h\) to lie in

\[
\{3^c+5^d-3^{c'}-5^{d'}\}.
\]

One needs a norm compatible with restriction to this family, a pointwise bound, or an independent proof that the structured multiset avoids the exceptional set。

## NG-15. Boundary replacement can create a main-scale error

\(C_{s,t}^\nu(X)\) uses \([X-s,2X-s]\)。Replacing all these by \([X,2X]\) costs boundary intervals of length comparable to \(s\)，which can be \(X/2\)。Only an explicitly uniform interval theorem or exact endpoint accounting is valid。

## NG-16. The elementary support-extraction lemma is not itself a promotion trigger

The implication

\[
\operatorname{Var}(V_X)=o(XM_X^2)
\Longrightarrow
\#\{V_X=0\}=o(X)
\]

is rigorous, but its hypothesis is the missing concentration theorem。It does not derive that theorem from available moments and therefore does not satisfy the substantive promotion gate。

## NG-17. A nonnegative model is not automatically an exact-support minorant

Grimmelt, Proposition 2.1, transfers a signed pointwise minorant through Fourier-close models and concludes a convolution lower bound outside an exceptional set。Its nonnegative object \(T_\nu^+\) is not required to satisfy

\[
T_\nu^+(m)>0\Longrightarrow m\in\mathcal S_2.
\]

Therefore model positivity cannot by itself certify a support hit。Applying the proposition here would require new pointwise minorization, Fourier-closeness, model-convolution positivity, and boundary-uniformity theorems; none is supplied by the abstract framework。

## NG-18. Absolute-value sieve correlations do not give signed covariance

Grimmelt–Teräväinen, Proposition 6.9, controls correlations of absolute values of specific pre-sieve weights in a binary Goldbach setup。Such an upper bound neither constructs a bounded exact-support weight for \(\mathcal S_2\) nor estimates

\[
C_{s,t}^{\nu_\tau}-A_s^{\nu_\tau}A_t^{\nu_\tau}/|I_X|
\]

with sign and aggregate little-o。Taking absolute values removes precisely the cancellation needed by the variance identity。
