#!/usr/bin/env python3
"""Verify hashes, schemas, required deliverables, and deep reproducibility."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile

REQUIRED = {
    'README.md',
    'EXECUTIVE_VERDICT.md',
    'WEIGHT_CANDIDATES.md',
    'CORRELATION_CROSSWALK.md',
    'WEIGHTED_TO_SUPPORT_GAP.md',
    'LITERATURE_AUDIT.md',
    'NO_GO_RESULTS.md',
    'REPORT.md',
    'PROMOTION_VERDICT.json',
    'SANITY_CHECKS.json',
    'SOURCE_LOCK.json',
    'PROVENANCE.md',
    'VERIFICATION.md',
    'MANIFEST.json',
    'SHA256SUMS.txt',
    'scripts/sanity_checks.py',
    'scripts/build_deterministic_zip.py',
    'scripts/verify_bundle.py',
}

MANIFEST_EXCLUDED = {'MANIFEST.json', 'SHA256SUMS.txt'}
SHA_EXCLUDED = {'SHA256SUMS.txt'}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def relative_files(root: Path) -> set[str]:
    return {
        p.relative_to(root).as_posix()
        for p in root.rglob('*')
        if p.is_file()
    }


def safe_relative(path: str) -> bool:
    p = PurePosixPath(path)
    return bool(path) and not p.is_absolute() and '..' not in p.parts and path == p.as_posix()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--deep', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()

    actual = relative_files(root)
    missing = sorted(REQUIRED - actual)
    if missing:
        raise SystemExit(f'missing required files: {missing}')

    # UTF-8/LF audit for all textual deliverables.
    for rel in sorted(actual):
        if Path(rel).suffix.lower() in {'.md', '.json', '.py', '.txt'}:
            data = (root / rel).read_bytes()
            if b'\r' in data:
                raise SystemExit(f'non-LF line ending or carriage return: {rel}')
            data.decode('utf-8')

    parsed = {}
    for name in ('PROMOTION_VERDICT.json', 'SANITY_CHECKS.json', 'SOURCE_LOCK.json', 'MANIFEST.json'):
        parsed[name] = json.loads((root / name).read_text(encoding='utf-8'))

    manifest = parsed['MANIFEST.json']
    if manifest.get('schema') != 'A303656_WEIGHTED_MINORANT_MANIFEST_V1':
        raise SystemExit('unexpected manifest schema')
    items = manifest.get('files')
    if not isinstance(items, list):
        raise SystemExit('manifest files is not a list')
    rels = [item.get('path') for item in items]
    if any(not isinstance(rel, str) or not safe_relative(rel) for rel in rels):
        raise SystemExit('unsafe manifest path')
    if len(rels) != len(set(rels)) or rels != sorted(rels):
        raise SystemExit('manifest paths must be unique and sorted')
    expected_manifest = actual - MANIFEST_EXCLUDED
    if set(rels) != expected_manifest:
        raise SystemExit(f'manifest file-set mismatch: missing={sorted(expected_manifest-set(rels))}, extra={sorted(set(rels)-expected_manifest)}')
    if manifest.get('file_count') != len(items):
        raise SystemExit('manifest file_count mismatch')
    for item in items:
        path = root / item['path']
        if path.stat().st_size != item['size_bytes']:
            raise SystemExit(f'size mismatch: {item["path"]}')
        if sha256(path) != item['sha256']:
            raise SystemExit(f'hash mismatch: {item["path"]}')

    lines = (root / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines()
    sha_map: dict[str, str] = {}
    for line in lines:
        try:
            digest, rel = line.split('  ', 1)
        except ValueError as exc:
            raise SystemExit(f'malformed SHA256SUMS line: {line!r}') from exc
        if not safe_relative(rel) or len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            raise SystemExit(f'malformed SHA256SUMS entry: {line!r}')
        if rel in sha_map:
            raise SystemExit(f'duplicate SHA256SUMS entry: {rel}')
        sha_map[rel] = digest
    expected_sha = actual - SHA_EXCLUDED
    if set(sha_map) != expected_sha:
        raise SystemExit(f'SHA256SUMS file-set mismatch: missing={sorted(expected_sha-set(sha_map))}, extra={sorted(set(sha_map)-expected_sha)}')
    for rel, digest in sha_map.items():
        if sha256(root / rel) != digest:
            raise SystemExit(f'SHA256SUMS mismatch: {rel}')

    verdict = parsed['PROMOTION_VERDICT.json']
    if verdict['verdict'] != 'NO PROMOTABLE ROUTE — SPECULATIVE WATCH':
        raise SystemExit('unexpected verdict')
    if verdict['oeis_status'] != 'UNRESOLVED' or verdict['promotion'] is not False:
        raise SystemExit('status invariant failed')
    if verdict['frozen_positive_density_reproved'] is not False:
        raise SystemExit('frozen theorem invariant failed')
    if verdict['unknown_indicator_covariance_assumed'] is not False:
        raise SystemExit('unknown covariance invariant failed')

    if args.deep:
        with tempfile.TemporaryDirectory() as td:
            rebuilt = Path(td) / 'SANITY_CHECKS.json'
            subprocess.run(
                [sys.executable, str(root / 'scripts/sanity_checks.py'), '--limit', '1000000', '--output', str(rebuilt)],
                check=True,
            )
            if rebuilt.read_bytes() != (root / 'SANITY_CHECKS.json').read_bytes():
                raise SystemExit('deep sanity rebuild differs')

    print('PASS')


if __name__ == '__main__':
    main()
