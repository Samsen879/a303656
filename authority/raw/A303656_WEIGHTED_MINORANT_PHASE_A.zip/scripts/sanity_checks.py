#!/usr/bin/env python3
"""Deterministic small-scale sanity checks for Phase A weighted-minorant audit.

This script does NOT search T(n).  It evaluates multiplicative candidate weights up to
N=1,000,000, verifies exact pointwise identities, records first/second moments, and
computes a few fixed structured-shift diagnostics.  The diagnostics are empirical only.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import numpy as np


def smallest_prime_factors(limit: int) -> np.ndarray:
    spf = np.zeros(limit + 1, dtype=np.int32)
    primes: list[int] = []
    for n in range(2, limit + 1):
        if spf[n] == 0:
            spf[n] = n
            primes.append(n)
        for p in primes:
            m = p * n
            if m > limit:
                break
            spf[m] = p
            if p == spf[n]:
                break
    return spf


def build_functions(limit: int) -> dict[str, np.ndarray]:
    spf = smallest_prime_factors(limit)
    exponent = np.zeros(limit + 1, dtype=np.uint8)
    core = np.ones(limit + 1, dtype=np.int32)
    tau = np.ones(limit + 1, dtype=np.int32)
    r2 = np.zeros(limit + 1, dtype=np.int32)
    r2[1] = 4
    penalty = np.ones(limit + 1, dtype=np.int64)
    nu0 = np.ones(limit + 1, dtype=np.bool_)
    nusf = np.ones(limit + 1, dtype=np.bool_)

    for n in range(2, limit + 1):
        p = int(spf[n])
        m = n // p
        if m % p == 0:
            e = int(exponent[m]) + 1
            c = int(core[m])
        else:
            e = 1
            c = m
        exponent[n] = e
        core[n] = c
        tau[n] = int(tau[c]) * (e + 1)

        if p == 2:
            r2[n] = int(r2[c])
            penalty[n] = int(penalty[c]) * (e + 1)
        elif p % 4 == 1:
            r2[n] = int(r2[c]) * (e + 1)
            penalty[n] = int(penalty[c])
        else:
            r2[n] = 0 if e % 2 else int(r2[c])
            penalty[n] = int(penalty[c]) * (e + 1)

        nu0[n] = bool(nu0[m]) and not (p % 4 == 3)
        nusf[n] = bool(nusf[c]) and e == 1 and not (p % 4 == 3)

    s2 = r2 > 0
    nu_tau = r2.astype(np.float64) / (4.0 * tau.astype(np.float64))

    # Exact integer verification of the local formula on support.
    supported = np.flatnonzero(s2)
    exact_lhs = r2[supported].astype(np.int64) * penalty[supported]
    exact_rhs = 4 * tau[supported].astype(np.int64)
    if not np.array_equal(exact_lhs, exact_rhs):
        bad = supported[np.flatnonzero(exact_lhs != exact_rhs)[:10]]
        raise AssertionError(f"nu_tau local identity failed at {bad.tolist()}")
    if np.any(r2[~s2] != 0):
        raise AssertionError("r2 support consistency failed")
    if np.any(nu_tau < 0.0) or np.any(nu_tau > s2.astype(np.float64) + 1e-15):
        raise AssertionError("0 <= nu_tau <= 1_{S2} failed")
    if np.any(nu0[1:] & ~s2[1:]):
        raise AssertionError("nu0 is not supported on S2")
    if np.any(nusf[1:] & ~s2[1:]):
        raise AssertionError("nusf is not supported on S2")

    return {
        "spf": spf,
        "tau": tau,
        "r2": r2,
        "penalty": penalty,
        "s2": s2,
        "nu_tau": nu_tau,
        "nu0": nu0,
        "nusf": nusf,
    }


def scaled_first_moment(values: np.ndarray, x: int) -> dict[str, float]:
    mass = float(np.sum(values[1 : x + 1], dtype=np.float64))
    return {
        "mass": mass,
        "mass_times_sqrt_log_over_X": mass * math.sqrt(math.log(x)) / x,
        "mean": mass / x,
    }


def effective_support(values: np.ndarray) -> float:
    s1 = float(np.sum(values, dtype=np.float64))
    s2 = float(np.dot(values.astype(np.float64), values.astype(np.float64)))
    return (s1 * s1 / s2) if s2 else 0.0


def top_mass_share(values: np.ndarray, fraction: float) -> float:
    positive = values[values > 0].astype(np.float64)
    if positive.size == 0:
        return 0.0
    k = max(1, int(math.ceil(fraction * positive.size)))
    if k >= positive.size:
        return 1.0
    top = np.partition(positive, positive.size - k)[-k:]
    return float(np.sum(top) / np.sum(positive))


def structured_shifts(max_c: int = 6, max_d: int = 6) -> list[int]:
    vals = sorted({3**c + 5**d for c in range(max_c + 1) for d in range(max_d + 1)})
    diffs = sorted({abs(a - b) for a in vals for b in vals if a != b})
    targets = [2, 8, 32, 80, 242, 624, 2400, 12500]
    selected: list[int] = []
    for target in targets:
        nearest = min(diffs, key=lambda h: (abs(h - target), h))
        if nearest not in selected:
            selected.append(nearest)
    return selected


def pair_diagnostic(values: np.ndarray, h: int, limit: int) -> dict[str, float | int]:
    left = values[1 : limit - h + 1].astype(np.float64)
    right = values[1 + h : limit + 1].astype(np.float64)
    length = int(left.size)
    pair_sum = float(np.dot(left, right))
    left_mean = float(np.mean(left))
    right_mean = float(np.mean(right))
    covariance_sum = pair_sum - length * left_mean * right_mean
    return {
        "h": h,
        "length": length,
        "pair_sum": pair_sum,
        "pair_sum_times_log_over_length": pair_sum * math.log(limit) / length,
        "covariance_sum": covariance_sum,
        "covariance_sum_times_log_over_length": covariance_sum * math.log(limit) / length,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=1_000_000)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.limit < 100:
        raise SystemExit("limit must be at least 100")

    f = build_functions(args.limit)
    checkpoints = [x for x in (10_000, 30_000, 100_000, 300_000, 1_000_000) if x <= args.limit]
    if checkpoints[-1] != args.limit:
        checkpoints.append(args.limit)

    named_values = {
        "indicator_S2": f["s2"].astype(np.float64),
        "nu_tau": f["nu_tau"],
        "nu0_no_inert_prime_divisor": f["nu0"].astype(np.float64),
        "nu_sf_split_squarefree": f["nusf"].astype(np.float64),
    }

    first_moments: dict[str, Any] = {}
    for x in checkpoints:
        first_moments[str(x)] = {
            name: scaled_first_moment(values, x) for name, values in named_values.items()
        }

    n = args.limit
    r2_values = f["r2"][1 : n + 1].astype(np.float64)
    nu_tau_values = f["nu_tau"][1 : n + 1]
    s2_count = int(np.count_nonzero(f["s2"][1 : n + 1]))
    representation_diagnostics = {
        "sum_r2": float(np.sum(r2_values)),
        "sum_r2_squared": float(np.dot(r2_values, r2_values)),
        "sum_r2_squared_over_X_log_X": float(np.dot(r2_values, r2_values) / (n * math.log(n))),
        "max_r2": int(np.max(f["r2"][1 : n + 1])),
        "argmax_r2_first": int(np.argmax(f["r2"][1 : n + 1]) + 1),
        "support_count_S2": s2_count,
        "effective_support_r2": effective_support(r2_values),
        "effective_support_r2_over_S2_count": effective_support(r2_values) / s2_count,
        "effective_support_nu_tau": effective_support(nu_tau_values),
        "effective_support_nu_tau_over_S2_count": effective_support(nu_tau_values) / s2_count,
        "top_0_1_percent_support_mass_share_r2": top_mass_share(r2_values, 0.001),
        "top_1_percent_support_mass_share_r2": top_mass_share(r2_values, 0.01),
        "top_0_1_percent_support_mass_share_nu_tau": top_mass_share(nu_tau_values, 0.001),
        "top_1_percent_support_mass_share_nu_tau": top_mass_share(nu_tau_values, 0.01),
        "max_nu_tau": float(np.max(nu_tau_values)),
    }

    shifts = [h for h in structured_shifts() if h < args.limit // 4]
    pair_diagnostics: dict[str, Any] = {}
    for name in ("indicator_S2", "nu_tau", "nu0_no_inert_prime_divisor", "nu_sf_split_squarefree"):
        values = named_values[name]
        pair_diagnostics[name] = [pair_diagnostic(values, h, n) for h in shifts]

    result = {
        "schema": "A303656_WEIGHTED_MINORANT_SANITY_CHECKS_V1",
        "purpose": "Small deterministic checks only; no T(n) search and no evidentiary promotion value.",
        "limit": n,
        "definitions": {
            "nu_tau": "r2(n)/(4*tau(n))",
            "nu0": "1 iff no prime q=3 mod 4 divides n",
            "nu_sf": "1 iff n is squarefree and every odd prime divisor is 1 mod 4",
        },
        "exact_assertions": {
            "nu_tau_nonnegative": True,
            "nu_tau_le_indicator_S2": True,
            "nu_tau_local_formula": "On S2, nu_tau=1/((v_2(n)+1)*prod_{q=3 mod 4}(v_q(n)+1)).",
            "nu0_supported_on_S2": True,
            "nu_sf_supported_on_S2": True,
            "verified_for_all_n_le_limit": True,
        },
        "first_moments": first_moments,
        "representation_diagnostics": representation_diagnostics,
        "structured_shift_pair_diagnostics": {
            "warning": "Empirical fixed-shift diagnostics; they do not establish asymptotics, uniformity, signed covariance cancellation, or almost-all coverage.",
            "shifts": shifts,
            "weights": pair_diagnostics,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
