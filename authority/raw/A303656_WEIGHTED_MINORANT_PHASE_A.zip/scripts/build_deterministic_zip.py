#!/usr/bin/env python3
"""Build a byte-deterministic ZIP from a bundle directory."""

from __future__ import annotations

import argparse
from pathlib import Path
import zipfile

FIXED_TIME = (1980, 1, 1, 0, 0, 0)


def build(root: Path, output: Path) -> None:
    root = root.resolve()
    output = output.resolve()
    files = sorted(
        p for p in root.rglob('*')
        if p.is_file() and p.resolve() != output
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_suffix(output.suffix + '.tmp')
    if tmp.exists():
        tmp.unlink()
    with zipfile.ZipFile(
        tmp,
        mode='w',
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
        strict_timestamps=True,
    ) as zf:
        for path in files:
            arcname = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(arcname, date_time=FIXED_TIME)
            info.create_system = 3
            info.external_attr = (0o100644 & 0xFFFF) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            info.flag_bits |= 0x800
            data = path.read_bytes()
            zf.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    tmp.replace(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    build(args.root, args.output)


if __name__ == '__main__':
    main()
