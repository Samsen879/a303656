# A303656 Weighted Minorant and Hooley–Rho Transference Trigger Hunt — Phase A

## 0. Status line

\[
\boxed{\texttt{NO PROMOTABLE ROUTE — SPECULATIVE WATCH}}
\]

**Project:** PAUSED.  
**OEIS A303656:** UNRESOLVED.  
**Frozen theorem:** positive density only; not reproved here.  
**Forbidden shortcut:** no unknown indicator covariance theorem is assumed.

## 1. Question audited

Can one replace the hard support indicator of sums of two squares by a nonnegative bounded minorant \(\nu\) that

1. vanishes off \(\mathcal S_2\)；
2. satisfies \(\nu\le C\mathbf1_{\mathcal S_2}\)；
3. has mass \(\gg X/\sqrt{\log X}\)；
4. admits sufficiently uniform shifted moments for differences of \(3^c+5^d\)；
5. transfers weighted concentration to density-one support coverage？

## 2. Main mathematical finding

The cleanest candidate is

\[
\boxed{\nu_\tau(m)=\frac{r_2(m)}{4\tau(m)}}.
\]

For \(m\in\mathcal S_2\),

\[
\nu_\tau(m)=
\frac{1}{(v_2(m)+1)\prod_{q\equiv3(4)}(v_q(m)+1)},
\]

and it is zero otherwise。Hence

\[
0\le\nu_\tau\le\mathbf1_{\mathcal S_2},
\qquad
\operatorname{supp}\nu_\tau=\mathcal S_2.
\]

At unramified primes, \(\nu_\tau(p)\) is the split-prime indicator for \(\mathbb Q(i)\), so it is a bounded nonnegative Frobenian multiplicative function of mean \(1/2\)。Loughran–Matthiesen, Lemma 2.8 therefore gives

\[
\sum_{m\le X}\nu_\tau(m)
=c_\tau X/\sqrt{\log X}
+O(X/(\log X)^{3/2}),
\quad c_\tau>0.
\]

This is an exact theorem-level pass for requirements 1–3。

Two simpler strict-subset alternatives, \(\nu_0\) (no inert prime divisor) and \(\nu_{sf}\) (split squarefree), also pass 1–3。Thus candidate construction is not the limiting step。

## 3. Exact weighted-to-support reduction

Let \(w_X(s)\) count exponent pairs with \(3^c+5^d=s\)，and

\[
V_X(n)=\sum_s w_X(s)\nu(n-s).
\]

On any exceptional \(n\) with no support representation, \(V_X(n)=0\)。If

\[
M_X=|I_X|^{-1}\sum_{n\in I_X}V_X(n)
\gg W_X/\sqrt{\log X}
\]

and

\[
\sum_{n\in I_X}(V_X(n)-M_X)^2
=o(XW_X^2/\log X),
\]

then Chebyshev on the zero set gives density one immediately。The variance expands exactly as

\[
\sum_{s,t}w_s w_t
\left(C_{s,t}^\nu-\frac{A_s^\nu A_t^\nu}{|I_X|}\right).
\]

For the bounded candidates, one-point Frobenian asymptotics are uniform over the actual dyadic endpoints \([X-s,2X-s]\)。The diagonal is negligible because \(\nu^2\le\nu\) and the frozen collision theorem gives \(\sum_s w_s^2=W_X+O(1)\)。All multiplicities are retained exactly。

The sole unresolved analytic term is the signed off-diagonal aggregate covariance。

## 4. Why Hooley–rho does not trigger

Hooley invented \(\rho_x=r_2t_x\) exactly because the standard indicator pair asymptotic was unavailable and raw \(r_2\) overweights highly factored numbers。But Hooley also explicitly says \(t_x\) is not always positive。Thus \(\rho_x\) has the desired support vanishing but fails nonnegativity and boundedness。

Its Eq. (20) is a two-point formula inside a specific dispersion setup。It is not an exact theorem for any of the bounded candidates, and nonlinear operations \(|\rho|,\rho_+,\rho^2\) do not inherit that formula。

## 5. What Kimmel–Kuperberg actually replace

Kimmel–Kuperberg explicitly note that standard indicator two-point estimates are not known。Their replacement is not a positive minorant：

- inner detector: signed Hooley \(\rho\)；
- outer measure: nonnegative GPY/Maynard-style weight \(w_n(\mathcal L)\)；
- conclusion: existence/positive density of fixed patterns via a quadratic contradiction。

Theorem 2 fixes tuple cardinality \(K\) before \(x\to\infty\)。It gives no density-one theorem for \(W_X\asymp(\log X)^2\) shifts attached to every base integer。

## 6. Sieve minorants and majorants

Rosser/beta sieve lower sums are signed pointwise。Clipping them to their positive part breaks the divisor-sum moment calculus and only certifies avoidance of small inert primes—not membership in \(\mathcal S_2\)。An unsieved inert prime gives a direct counterexample。

Selberg/enveloping sieve squares are nonnegative but are majorants, positive off the target support。Dense model methods preserve selected correlations, not the implication `positive model value => original support`。

Modern nonnegative-model frameworks were also audited rather than dismissed by terminology。Grimmelt, Proposition 2.1, converts a signed minorant into a convolution lower bound using a Fourier-close nonnegative surrogate, but that surrogate has no exact-support requirement。Grimmelt–Teräväinen, Definition 2.4 and Proposition 3.4, build a problem-specific approximation around Chen’s signed lower sieve；their Proposition 6.9 controls absolute values of those sieve weights, not signed covariance for \(\nu_\tau\)。No required approximation theorem is available in the present dyadic structured-shift geometry。

Therefore no audited sieve theorem gives all of support, sign, boundedness, mass, and parallel-shift moments。

## 7. Representation weights and the irreversible gap

Bantle’s Theorem I is a sharp caution：its asymptotic is for \(r(n)r(n+1)\)，whereas indicator information appears only as a fixed-shift lower bound in Theorem II。Cherubini–Fazzari similarly prove an indicator lower bound \(\gg_{K,h}X/\log X\) for fixed \(h\)，not a covariance asymptotic。

Raw \(r_2\) can support a valid implication only if one proves per-base convolution positivity/concentration。A large weighted total or an almost-all statement in the \(r_2\)-weighted measure is insufficient。High multiplicity is quantitatively visible in \(\sum r_2^2\asymp X\log X\)。The bounded damping \(\nu_\tau\) fixes mass concentration but creates a new shifted multiplicative correlation not supplied by representation formulas。

## 8. Linear-forms/transference mismatch

Loughran–Matthiesen Theorem 3.10, MSTT Definition 9.1, and Green–Tao Definition 3.1 require nonparallel/linearly independent affine directions。The target pair \(n-s,n-t\) has the same nonconstant part in both forms。Green–Tao Definition 3.2 explicitly introduces a separate correlation upper condition because this parallel case is outside the linear-forms condition。An upper envelope with bounded moments is not the signed little-o covariance needed here。

## 9. Boundary, diagonal, and multiplicity audit

- **Boundary:** retained through \(F(2X-s)-F(X-s)\), uniformly for \(s\le X/2\)。
- **Diagonal:** \(O(XW_X/\sqrt{\log X})=o(XW_X^2/\log X)\)。
- **Shift collisions:** retained through \(w_X(s)\); frozen theorem gives bounded multiplicity and \(\sum w_X(s)^2=W_X+O(1)\)。
- **Distinct-shift multiplicity:** no replacement by a set until weights are accounted for。
- **Growing shifts:** no fixed-\(h\) theorem is promoted without uniform constants。

## 10. Computation audit

A deterministic Python script evaluated candidates through \(10^6\)。It exact-checked local formulas and support inequalities and recorded first/second moment diagnostics for eight small structured shifts。It did **not** search for large \(T(n)\)，did not test the global conjecture, and has no promotion value。

At \(X=10^6\)，\(\nu_\tau\) mass is 130786.108255 and its scaled first moment is 0.486121788；maximum \(\nu_\tau=1\)。For comparison, maximum \(r_2=128\) and \(\sum r_2^2/(X\log X)=4.58361924\)。

## 11. Promotion gate assessment

| Gate | Result |
|---|---|
| Exact nonnegative support minorant | **PASS**: \(\nu_\tau\) |
| Pointwise bound | **PASS**: \(C=1\) |
| Correct mean | **PASS**: Loughran–Matthiesen Lemma 2.8 |
| Uniform moments on structured shifts | **FAIL / no theorem located** |
| Weighted concentration implies support almost-all | **FORMAL CONDITIONAL LEMMA ONLY** |
| Sole remaining lemma clearly weaker than indicator covariance | **NOT ESTABLISHED** |

The weighted covariance is different from indicator covariance, but signed covariance is not monotone under \(0\le\nu\le\mathbf1\)。No theorem proves it strictly easier。

## 12. Exact future watch trigger

Reopen the route only upon one of the following：

1. a theorem proving the aggregate covariance little-o for \(\nu_\tau\), \(\nu_0\), or another exact bounded support weight；
2. a uniform parallel-shift asymptotic with errors summable over the true weighted difference multiset and an averaged singular-factor theorem；
3. a direct lower-tail theorem \(\#\{n:V_X(n)=0\}=o(X)\) respecting dyadic boundaries；
4. a new transference lemma that derives counting-measure coverage from a genuinely weaker available weighted estimate, not from the desired concentration restated as a hypothesis。

## 13. Final conclusion

The phase produces a mathematically valid bounded full-support candidate and an exact gap reduction, but no literature theorem crosses the correlation barrier。Promotion would overstate current knowledge；complete termination would discard a clean future trigger。

\[
\boxed{\texttt{NO PROMOTABLE ROUTE — SPECULATIVE WATCH}}
\]

**OEIS A303656: UNRESOLVED.**
