# Weighted-to-Support Gap

## 1. Exact setup

令

\[
I_X=[X,2X]\cap\mathbb Z,
\qquad
\mathcal D_X=\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le X/2\}.
\]

对 shift value \(s\) 定义 multiplicity

\[
w_X(s)=\#\{(c,d)\in\mathcal D_X:3^c+5^d=s\},
\qquad
W_X=\sum_s w_X(s)=|\mathcal D_X|.
\]

冻结的 collision theorem 给出

\[
W_X\asymp(\log X)^2,
\quad
\max_s w_X(s)=O(1),
\quad
\sum_s w_X(s)^2=W_X+O(1).
\tag{1.1}
\]

对一个 weight \(\nu\)，零延拓到 \(m\le0\)，并定义

\[
V_X(n)=\sum_s w_X(s)\nu(n-s),
\qquad
M_X=\frac1{|I_X|}\sum_{n\in I_X}V_X(n).
\]

令 \(T_X(n)\) 是满足 \(n-(3^c+5^d)\in\mathcal S_2\) 的 exponent pairs 数；则 \(T_X(n)=0\) 表示所选 shift domain 中没有 support hit。

## 2. Rigorous support-extraction lemma

### Lemma 2.1

假设

\[
\nu(m)=0\quad(m\notin\mathcal S_2),
\tag{2.1}
\]

并且存在固定 \(c>0\) 使

\[
M_X\ge c\frac{W_X}{\sqrt{\log X}},
\tag{2.2}
\]

以及

\[
\sum_{n\in I_X}|V_X(n)-M_X|^2
=o\!\left(\frac{XW_X^2}{\log X}\right).
\tag{2.3}
\]

则

\[
\boxed{\#\{n\in I_X:T_X(n)=0\}=o(X).}
\]

#### Proof

若 \(T_X(n)=0\)，则每个 \(s\) with \(w_X(s)>0\) 都满足 \(n-s\notin\mathcal S_2\)。由 (2.1)，\(V_X(n)=0\)。记 exceptional set 为 \(E_X\)，则

\[
|E_X|M_X^2
=\sum_{n\in E_X}|V_X(n)-M_X|^2
\le\sum_{n\in I_X}|V_X(n)-M_X|^2.
\]

用 (2.2)–(2.3) 即得 \(|E_X|=o(X)\)。\(\square\)

### Remarks

- Nonnegativity 不是此 elementary implication 的逻辑最小条件；support vanishing 已足够。但本项目的 candidate gate 要求 nonnegative，\(\nu_\tau\) 满足。
- 若有 \(p>0\) 的 higher-moment estimate
  \[
  \sum_{n\in I_X}|V_X(n)-M_X|^p=o(XM_X^p),
  \]
  同一论证也成立。
- 这不是 promotion-level breakthrough：hypothesis (2.3) 正是尚未得到的 weighted concentration assertion。它没有从现有 pair estimates 推出 concentration，也没有证明 weighted covariance 比 indicator covariance 严格更弱。

## 3. Exact covariance identity

定义

\[
A_s^\nu(X)=\sum_{n\in I_X}\nu(n-s),
\qquad
C_{s,t}^\nu(X)=\sum_{n\in I_X}\nu(n-s)\nu(n-t).
\]

有限展开无误差地给出

\[
\boxed{
\sum_{n\in I_X}(V_X(n)-M_X)^2
=\sum_{s,t}w_X(s)w_X(t)
\left(
C_{s,t}^\nu(X)-
\frac{A_s^\nu(X)A_t^\nu(X)}{|I_X|}
\right).}
\tag{3.1}
\]

因此需要的 exact trigger 是

\[
\boxed{
\sum_{s,t}w_X(s)w_X(t)
\left(
C_{s,t}^\nu(X)-
\frac{A_s^\nu(X)A_t^\nu(X)}{|I_X|}
\right)
=o\!\left(\frac{XW_X^2}{\log X}\right).}
\tag{3.2}
\]

仅有 \(C_{s,t}^\nu\ll X/\log X\) 不够；variance 需要 main-term cancellation 的 sign information。

## 4. First moment and boundaries

对 \(\nu\in\{\nu_\tau,\nu_0,\nu_{\mathrm{sf}}\}\)，Loughran–Matthiesen, Lemma 2.8 给

\[
F_\nu(y)=\sum_{m\le y}\nu(m)
=c_\nu y/\sqrt{\log y}+O(y/(\log y)^{3/2}).
\]

对所有 \(0\le s\le X/2\)，

\[
A_s^\nu(X)=F_\nu(2X-s)-F_\nu(X-s)
=c_\nu\frac{X}{\sqrt{\log X}}
+O\!\left(\frac{X}{(\log X)^{3/2}}\right),
\tag{4.1}
\]

uniformly in \(s\)，因为两个 endpoints 都在 \([X/2,2X]\)。故

\[
M_X=(c_\nu+o(1))\frac{W_X}{\sqrt{\log X}}.
\]

这严格处理了 dyadic boundary；不需要把 shifted intervals 偷换成共同 interval。

## 5. Diagonal, collisions, and distinct shifts

若 \(0\le\nu\le1\)，则 \(\nu^2\le\nu\)。因此 diagonal contribution satisfies

\[
\sum_s w_X(s)^2
\left(C_{s,s}^\nu-\frac{(A_s^\nu)^2}{|I_X|}\right)
\le
\sum_s w_X(s)^2 A_s^\nu
\ll \frac{X}{\sqrt{\log X}}\sum_s w_X(s)^2.
\]

由 (1.1)，这为 \(O(XW_X/\sqrt{\log X})\)，相对于 target scale \(XW_X^2/\log X\) 的 ratio 是

\[
O\!\left(\frac{\sqrt{\log X}}{W_X}\right)
=O((\log X)^{-3/2}).
\]

故 diagonal negligible。Nontrivial collisions 由 \(w_X(s)\) 精确吸收；不能把 exponent pairs 假装成 distinct shifts，但 bounded multiplicity 使其不成为 blocker。

## 6. Off-diagonal blocker

将 \(m=n-s\) 后，\(C_{s,t}^\nu\) 是 shift \(h=s-t\) 的 correlation，但 summation interval 是

\[
[X-s,2X-s]\cap\mathbb Z,
\]

故 theorem 必须同时 uniform in \(h\)、absolute location、以及 endpoints。项目需要的是对真实 multiset 的 **aggregate signed error**；以下输入都不够：

1. 每个 fixed \(h\) 的 lower bound；
2. 每个 \(h\) 的 upper bound；
3. \(r_2\)-weighted asymptotic；
4. 对 Lebesgue-average/all \(h\le H\) 的 theorem，若不能控制这组 sparse structured differences；
5. 只对 fixed number of forms 的 theorem；
6. 只对 nonparallel finite-complexity forms 的 theorem。

## 7. Why boundedness does and does not solve concentration

若 \(0\le\nu\le C\mathbf1_{\mathcal S_2}\)，则 single-variable weighted mass 至少占用 \((\sum\nu)/C\) 个 support points；这排除了 raw \(r_2\) 的极端 mass concentration。

但对 \(V_X(n)\)，boundedness 只给

\[
0\le V_X(n)\le CW_X.
\]

它不排除 \(V_X\) 在少数 base points 上较大、其余多数 base points 为零。要把 positive-density 提升到 density one，仍需 (2.3)/(3.2) 或同等强度的 lower-tail theorem。

## 8. Promotion assessment

本文件证明了一个 exact support-extraction implication，并完整处理 boundary、diagonal 与 multiplicity；但该 lemma 的 concentration hypothesis 没有由 literature 中的 weighted estimates推出。因此它是 **gap formalization**，不是用户 promotion gate 所要求的 substantive weighted-to-support bridge。
