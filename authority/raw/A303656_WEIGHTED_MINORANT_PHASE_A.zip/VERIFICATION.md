# Verification Record

## Scope

This record covers the final Phase A research bundle. It certifies file integrity and reproducibility of the small candidate-weight checks; it does not certify OEIS A303656 itself and does not convert numerical evidence into a theorem.

## Authority-input checks

The three uploaded prior-stage archives were hashed directly. The resulting SHA256 values agree with `SOURCE_LOCK.json`:

- `A303656_GLOBAL_ROUTE_RESET(4).zip`: `b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13`
- `A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(1).zip`: `aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2`
- `analytic_bad_prime_phaseA(2).zip`: `9dd538f5d47a4d2327159b619af7db752f241421caef926207e623be6a8b1ec2`

The frozen positive-density bundle’s supplied verification had passed before this phase was drafted; its locked scientific-core hash is `8f7708954cb3e89f159bb01173b4160e1423bb7c7fc96d528b45a558a5de2220`.

## Source-file check

The locally audited PDF for Grimmelt, *Goldbach numbers in short intervals*, has SHA256 `3554d01f2b3f85514a0a7659cf9ff89c3e3b50d506c03a5e11d1532a40c4c1f9`, matching `SOURCE_LOCK.json`.

## Reproducibility checks

1. All JSON files parse as UTF-8.
2. Textual files contain LF line endings and no carriage returns.
3. `MANIFEST.json` covers every bundle file except itself and `SHA256SUMS.txt`, with sorted paths, sizes, and SHA256 values.
4. `SHA256SUMS.txt` covers every bundle file except itself, including `MANIFEST.json`.
5. `scripts/sanity_checks.py --limit 1000000` rebuilds `SANITY_CHECKS.json` byte-for-byte.
6. `scripts/verify_bundle.py --root . --deep` returns `PASS`.
7. The deterministic ZIP builder was run twice from the same verified directory; the two archives were byte-identical.
8. Every ZIP entry has timestamp `1980-01-01 00:00:00`, regular-file mode `0644`, UTF-8 path handling, sorted archive order, and DEFLATE compression.

The final archive hash is recorded in the external sidecar `A303656_WEIGHTED_MINORANT_PHASE_A.zip.sha256`, avoiding a self-referential hash inside the archive.

## Mathematical status invariant

- Verdict: `NO PROMOTABLE ROUTE — SPECULATIVE WATCH`.
- Positive-density theorem: frozen, not reproved.
- Unknown indicator covariance: not assumed.
- Large `T(n)` search: not performed.
- OEIS A303656: UNRESOLVED.
