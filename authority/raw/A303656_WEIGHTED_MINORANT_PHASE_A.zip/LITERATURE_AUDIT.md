# Literature Audit

## Audit protocol

- Cutoff / access date: **2026-07-18**。
- 只将 primary papers 中明确陈述的 theorem/lemma/equation 作为可用输入。
- 对每个结果核对：observable、sign、support、parameter order、shift geometry、uniformity、effectivity。
- arXiv appendix 中的 conjectural language 不计作 theorem。
- 搜索是 trigger-oriented，不声称穷尽全部文献；但所有被用来作决定的 claims 都锁定到 primary source。

## 1. Hooley’s \(\rho\)-function

**Source.** Christopher Hooley, *On the intervals between numbers that are sums of two squares*, Acta Mathematica 127 (1971), 279–297, DOI 10.1007/BF02392056.

### Exact audit

1. Introduction 明确比较 \(r(n)\) 与 indicator \(r_1(n)\)：\(r(n)\) 会强调 prime-factor-abundant integers；indicator pair asymptotic 被描述为类似 prime-pair problem 的困难。
2. Hooley 定义 \(\rho_x(n)=r(n)t_x(n)\)。原文明确说 \(t_x(n)\) “is not necessarily always positive”。
3. 因 \(r(n)=0\) off \(\mathcal S_2\)，\(\rho_x\) 仍 support-faithful。
4. Section 7 在 \(0<k<x\) 下推导 Eq. (20)，给 \(\sum_{n<x}\rho_x(n)\rho_x(n+k)\) 的 asymptotic form；detector 本身依赖 ambient \(x\)。
5. Eq. (20) 随后被嵌入对 \(0<k<h<x^{1/2}\) 的 dispersion sum，而不是声明为本项目所需的 arbitrary growing structured family theorem。

### Verdict

- **Sign:** fail。
- **Support:** pass。
- **Boundedness:** fail；包含 \(r(n)\)。
- **Uniformity:** no verified theorem matching all structured shifts, boundaries, and aggregate little-o。
- **Effectivity:** analytic error exists in the paper, but no project-ready uniform constant package for the present family。

Hooley \(\rho\) 是重要 detector，不是 nonnegative minorant。

## 2. Kimmel–Kuperberg’s weighted substitute

**Source.** Noam Kimmel and Vivian Kuperberg, *Positive density for consecutive runs of sums of two squares*, arXiv:2406.04174v2 (2025); Journal of the Institute of Mathematics of Jussieu publication.

### Exact theorem anchors

- **Theorem 1:** fixed odd squarefree modulus \(q\)，fixed reduced classes \(\tilde a_1,\tilde a_2\)，fixed tuple length \(M\)，positive density of prescribed concatenated residue patterns among consecutive sums of two squares。
- Section 2.1 explicitly states that two-point correlations for the standard indicator are not known and substitutes Hooley’s \(\rho\)。
- **Theorem 2:** for a fixed \(K\)-tuple \(\mathcal L(b)\) and fixed residue class, constructs nonnegative outer weights \(w_n(\mathcal L)\ge0\) and evaluates/bounds sums (17)–(22), including first and second moments involving \(\rho\)。

### Sign/support mechanism

Theorem 2 的 nonnegative object 是 outer sieve weight \(w_n\)，不是 \(\rho\)。Existence argument使用：若一个 bin 没有 \(\mathcal S_2\) element，则该 bin 所有 \(\rho\)-terms 都为零，从 quadratic inequality 得 contradiction。这个逻辑只要求 detector off-support vanishing，不把 \(\rho\) 变成 positive bounded minorant。

### Uniformity audit

- \(M,k,K,q\) 在 asymptotic 前 fixed。
- Tuple locations可随 \(x\) 位于 \(O(\sqrt{\log x})\) window，但 tuple cardinality \(K\) fixed。
- 本项目需要 \(W_X\asymp(\log X)^2\) 个 shifts 共同作用于每个 base \(n\)，以及 density-one lower-tail control。

### Verdict

No transference trigger。Theorem 1 是 positive-density pattern theorem；Theorem 2 是 fixed-configuration sieve moment theorem。二者均非 (R)。

## 3. McGrath

**Source.** Oliver McGrath, *A variation of the prime k-tuples conjecture with applications to quantum limits*, Mathematische Annalen 384 (2022), 1343–1407; arXiv:2008.11119.

### Exact anchors

- **Theorem 1.4:** starts from a fixed infinite admissible set \(H^*\), with every \(h_i\) divisible by 4; for each finite bin construction parameters are fixed before \(N\to\infty\)。
- **Proposition 5.2:** abstract second-moment implication for a nonnegative \(\rho_A\) supported on \(A\) and nonnegative outer weights \(w(n)\)。Its proof uses only that a bin with no \(A\)-element has sum zero。
- **Lemma 5.4:** \(r(n)r(n+h)\) in APs under coprimality, \(4\mid h\), fixed \(h>0\), and \(p\mid h\Rightarrow p\mid2q\)。
- **Lemma A.3:** more general \(0<h<N^{3/4}\) representation correlation, with an \(h\)-dependent local factor and power-saving error。
- **Lemma 5.5:** \(r(n)^2\) mean in APs。
- **Lemma 5.6:** auxiliary Hooley-weight sums; one displayed main term \(Z_{N,W}^{(2)}\) is negative; \(o(1)=O(D_0^{-1})\)。
- Section 6: \(k,H\) fixed and Landau constants may depend on fixed \(k\)。

### Verdict

McGrath supplies the algebra behind fixed sieve constructions, not a nonnegative bounded support weight. Representation correlations cannot be divided by \(\tau(n)\tau(n+h)\) without a new theorem。

## 4. Bantle — false-trigger disambiguation

**Source.** G. Bantle, *An asymptotic formula for B-twins*, Acta Arithmetica 47(4) (1986), 297–312.

The title is easy to overread. Page 297 defines \(r(n)\) as representation count and \(r_1(n)\) as indicator, then states that a similar asymptotic for \(r_1(n)r_1(n+1)\) is not known。

- **Theorem I:** for \(\lambda\) composed only of primes \(1\pmod4\), gives an asymptotic for a congruence-restricted sum of **\(r(n)r(n+1)\)**, with an explicit main term and error。
- **Theorem II:** gives
  \[
  \sum_{x-y<n\le x}r_1(n)r_1(n+1)\gg y/\log x,
  \qquad y\ge x^{2/3+\varepsilon}.
  \]

Thus indicator information is a fixed-shift lower bound, not an asymptotic/covariance。The paper does not contradict later statements that standard indicator two-point asymptotics are unavailable。

## 5. Cherubini–Fazzari

**Source.** Giacomo Cherubini and Alessandro Fazzari, *Hyperbolic angles from Heegner points*, arXiv:2206.08282.

- **Theorem 1.5:** for an imaginary quadratic class-number-one field \(K\) and fixed \(h\in\mathbb Z\)，
  \[
  \sum_{n\le x}b_K(n)b_K(n+h)\gg_{K,h}x/\log x.
  \]
- **Proposition 3.1:** establishes the sieve lower bound used in the proof, again with \(K,h\)-dependent constant。

This is exact support indicator and the correct lower-order scale, but only lower bound, fixed \(h\), no signed main-term cancellation, no growing family uniformity。

## 6. Frobenian multiplicative functions

**Source.** Daniel Loughran and Lilian Matthiesen, *Frobenian multiplicative functions and rational points in fibrations*, arXiv:1904.12845; Memoirs of the European Mathematical Society (2023).

### One-point theorem

- **Definition 2.6:** prime restriction Frobenian; \(|\rho(n)|\ll_\varepsilon n^\varepsilon\); \(|\rho(p^k)|\le H^k\)。
- **Definition 2.7:** Frobenian for every \(\varepsilon\)。
- **Lemma 2.8:**
  \[
  \sum_{n\le x}\rho(n)=c_\rho x(\log x)^{m(\rho)-1}
  +O(x(\log x)^{m(\rho)-2}),
  \]
  with Euler product for \(c_\rho\)，and \(c_\rho>0\) if \(\rho\) is real, nonnegative and \(m(\rho)\ne0\)。

This exactly certifies the first moments of \(\nu_\tau,\nu_0,\nu_{sf}\)。

### Linear-forms theorem

- **Definition 3.9:** finite complexity requires every pair of nonconstant linear parts to be linearly independent over \(\mathbb Q\)。
- **Theorem 3.10:** fixed collection of nonnegative Frobenian functions and fixed finite-complexity system over a fixed convex body。

For \(\varphi_1(n)=n-s\), \(\varphi_2(n)=n-t\)，both nonconstant parts are exactly \(n\)，hence rational multiples。The theorem is inapplicable before any question of growing \(r\) or effectivity arises。

## 7. Green–Tao and enveloping sieve

**Source.** Ben Green and Terence Tao, *The primes contain arbitrarily long arithmetic progressions*, Annals of Mathematics 167 (2008), 481–547; arXiv:math/0404188.

- **Definition 3.1:** linear forms condition excludes rationally proportional coefficient tuples。
- **Definition 3.2:** correlation condition is added precisely because shifts \(x+h_j\) have identical linear components; it supplies an upper envelope \(\tau(h_i-h_j)\) with moment bounds, not a signed covariance asymptotic。
- **Theorem 3.5:** relative Szemerédi for fixed \(k,\delta\)，a global pattern-count theorem。
- **Proposition 8.1:** dense-model decomposition on a large set; it does not preserve exact arithmetic support implication。
- **Definition 9.3 / Lemma 9.4:** the square of a truncated divisor sum is a nonnegative majorant for primes。

A dense model \(g\) may be bounded by 1 and statistically close in selected tests while being positive off the original support。Therefore `dense model` is not a weighted-to-support theorem for zero sets of every shifted convolution。

## 8. Nonnegative models for signed sieve minorants

### 8.1 Grimmelt’s circle-method bridge

**Source.** Lasse Grimmelt, *Goldbach numbers in short intervals*, arXiv:1910.05187v2 (2022).

**Proposition 2.1 (Circle Method)** starts with

\[
a,T_\nu^+:[X]\to\mathbb R_{\ge0},\qquad b,\omega,\nu,T_\nu:[X]\to\mathbb R,
\]

pointwise minorization \(\nu\le b\), \(\omega\le a\), and two local Fourier-closeness estimates (17)–(18). Outside an explicitly bounded exceptional set it concludes

\[
a*b(n)\ge \omega*T_\nu(n)+O(\kappa).
\]

This is a genuine and useful nonnegative-model transference statement, but the roles are crucial: \(T_\nu^+\) is a Fourier-close nonnegative surrogate, not a pointwise minorant of \(b\), and no hypothesis says that \(T_\nu^+(m)>0\) forces membership in the target support. To specialize it here one would still need a signed pointwise minorant \(\nu\le\mathbf1_{\mathcal S_2}\), a nonnegative model with both closeness estimates in the true dyadic/structured-shift geometry, and a positive model convolution. Hooley’s \(\rho\) is not such a pointwise minorant because its positive values are unbounded. No audited theorem supplies this package for \(\mathcal S_2\).

### 8.2 Grimmelt–Teräväinen’s Chen-prime model

**Source.** Lasse Grimmelt and Joni Teräväinen, *The exceptional set in Goldbach’s problem with two Chen primes*, arXiv:2508.16400v1 (2025).

- **Theorem 1.1:** a power-saving exceptional-set theorem for sums of two Chen primes; the authors state that the exponent and implied constant are effective in principle.
- **Definition 2.4:** defines an additive approximation relation through convolution tests outside a power-saving exceptional set, not pointwise support equality.
- **Proposition 3.4:** constructs Chen’s lower-bound sieve with pre-sieves; the underlying minorant can take negative values.
- **Proposition 6.9:** gives an upper bound for correlations of **absolute values of sieve weights** in that specific setup.
- **Theorem 7.9** and **Propositions 7.10–7.11:** replace primes by a Cramér-type model within the paper’s parameter hierarchy.

This demonstrates that a task-specific signed-minorant-to-nonnegative-model mechanism can prove an exceptional-set theorem. It does **not** provide a reusable exact-support minorant for sums of two squares, nor does Proposition 6.9 give signed covariance cancellation for \(\nu_\tau(n)\nu_\tau(n+h)\). Treating “nonnegative model” as synonymous with “nonnegative support minorant” would reverse the logical role of the model.

## 9. Rosser / beta sieve

**Source.** Henryk Iwaniec, *Rosser’s sieve*, Acta Arithmetica 36 (1980), 171–202.

- **Theorem 1:** gives upper and lower sieve bounds with functions \(F(s),f(s)\) and remainder terms。
- Section 3, **(3.2)** imposes \(\mu(d)\sigma_d\le0\) for an upper bound; **(3.3)** imposes \(\mu(d)\sigma_d\ge0\) for a lower bound；**(3.4)–(3.5)** are the resulting upper/lower estimates；**(3.6)** gives Rosser’s natural truncated choice。

The lower divisor sum is not pointwise nonnegative。Taking its positive part is nonlinear and can be positive for numbers with an unsieved large inert prime; it no longer has an exact support theorem。Selberg squares reverse the issue: they are nonnegative but majorize a sifted indicator and are positive off \(\mathcal S_2\)。

## 10. MSTT higher uniformity

**Source.** Kaisa Matomäki, Xuancheng Shao, Terence Tao and Joni Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, Forum of Mathematics, Pi 11 (2023), e29; arXiv:2204.03754.

- **Definition 9.1:** pseudorandom systems require relevant coefficient vectors to be pairwise linearly independent/nonparallel。
- **Proposition A.3:** extends stated results to the representation function \(r_2\) and a Type-I approximant。
- **Appendix A.4:** titled “Potential result for the indicator function of the sums of two squares”; the text uses conjectural language such as “seems likely” and “we conjecture”。

Appendix A.4 is a research watch, not an admissible theorem。

## 11. 2026 watch items

Parkkonen–Paulin, *On the multiplicative pair correlations of sums of two squares*, arXiv:2602.13058, **Theorems 1.1 and 4.1**, studies pair correlations of logarithms of norm-form values under multiplicative scaling。It does not supply additive shifted support covariance for \(n,n+h\)。

Croot–Mao–Pohoata–Sheffer–Yip, *A combinatorial large sieve for Sidon sets, distances, and norm forms*, arXiv:2606.17487v2, **Theorems 1.9–1.11** and weighted **Theorem 4.1**, develops upper bounds for bounded algebraic multiplicities using local weights and entropy-enhanced sieving。This is an upper-bound/global-multiplicity mechanism, not a nonnegative exact-support minorant, shifted lower-tail theorem, or signed covariance estimate。

## 12. Literature verdict

The exact positive candidate \(\nu_\tau\) is new to this route audit as a clean synthesis, but the audited literature provides only:

- first moment for it；
- representation-weighted or signed-detector correlations；
- fixed-shift support lower bounds；
- nonparallel linear-form theorems；
- outer majorants/existence sieves；
- nonnegative surrogate models whose positivity is only convolutional/approximate and not support-faithful。

No primary theorem meets all of nonnegative + exact support + correct mass + growing parallel shift signed concentration。
