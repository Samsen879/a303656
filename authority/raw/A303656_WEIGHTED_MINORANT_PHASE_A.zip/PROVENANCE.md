# Provenance

## Execution environment

Recommended and used research layer: **web GPT-5.6 Pro + local standalone Python/Linux container**. No Codex, Codex Ultra, repository integration, Git state, or large computation was used.

## Authority inputs

Three uploaded prior-stage bundles were inspected. Their archive SHA256 values are recorded in `SOURCE_LOCK.json`：

- `A303656_GLOBAL_ROUTE_RESET(4).zip`
- `A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(1).zip`
- `analytic_bad_prime_phaseA(2).zip`

The frozen positive-density bundle’s supplied verification scripts passed before this phase was written. Its scientific-core SHA256 is also locked in `SOURCE_LOCK.json`。

## Frozen facts imported, not reproved

1. \(|\mathcal D_X|=(\log X)^2/(\log3\log5)+O(\log X)\)。
2. Shift multiplicity is bounded and \(\sum_s w_X(s)^2=|\mathcal D_X|+O(1)\)。
3. The positive-density theorem is frozen。
4. The exact almost-all blocker is signed indicator covariance on the growing structured difference family。

## Primary literature

Primary PDFs were downloaded/read or inspected through publisher/arXiv scans. Local file hashes for available PDFs are recorded in `SOURCE_LOCK.json`; the PDFs themselves are not redistributed in this bundle.

## Computation scope

`scripts/sanity_checks.py`：

- deterministic SPF sieve through \(10^6\)；
- exact pointwise checks for \(\nu_\tau,\nu_0,\nu_{sf}\)；
- first moments, effective-support diagnostics, and eight fixed structured-shift diagnostics；
- no exhaustive A303656 search；
- no large \(T(n)\) campaign；
- no empirical claim promoted to theorem。

## Determinism

Text files use UTF-8 and LF line endings. JSON is sorted and indented. ZIP metadata is normalized by `scripts/build_deterministic_zip.py`。The final ZIP was built twice and byte-compared; verification details appear in `VERIFICATION.md`。
