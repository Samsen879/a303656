# Weight Candidates

## 1. Notation

令

\[
\mathcal S_2=\{m\ge1:m=a^2+b^2\text{ for some }a,b\in\mathbb Z\},
\]

\(r_2(m)\) 为有序带符号 representations 数，\(\tau(m)\) 为 divisor function。Fermat–Euler criterion 给出

\[
m\in\mathcal S_2
\Longleftrightarrow
v_q(m)\equiv0\pmod2\quad\text{for every prime }q\equiv3\pmod4.
\]

本文件只讨论 \(m\ge1\)；在 dyadic application 中 \(n-s\ge X/2>0\)。需要零延拓时，规定 \(\nu(m)=0\) for \(m\le0\)。

## 2. Lead candidate: \(\nu_\tau=r_2/(4\tau)\)

### Proposition 2.1 — exact support and boundedness

定义

\[
\nu_\tau(m)=\frac{r_2(m)}{4\tau(m)}.
\]

则

\[
\boxed{0\le\nu_\tau(m)\le\mathbf1_{\mathcal S_2}(m)},
\qquad
\boxed{\nu_\tau(m)>0\iff m\in\mathcal S_2}.
\]

更精确地，若 \(m\in\mathcal S_2\)，则

\[
\boxed{
\nu_\tau(m)=
\frac{1}{(v_2(m)+1)
\prod_{q\equiv3\ (4)}(v_q(m)+1)}.}
\tag{2.1}
\]

#### Proof

经典局部公式是

\[
r_2(m)=
\begin{cases}
4\displaystyle\prod_{p\equiv1\ (4)}(v_p(m)+1),&m\in\mathcal S_2,\\
0,&m\notin\mathcal S_2.
\end{cases}
\]

而

\[
\tau(m)=(v_2(m)+1)
\prod_{p\equiv1\ (4)}(v_p(m)+1)
\prod_{q\equiv3\ (4)}(v_q(m)+1).
\]

相除即得 (2.1)。每个 denominator factor 至少为 1，故 pointwise bound 的最优 universal constant 可取 \(C=1\)。\(\square\)

### Proposition 2.2 — correct first-moment scale

\(\nu_\tau\) 是 nonnegative Frobenian multiplicative function，Frobenian mean 为 \(1/2\)。其 prime-power values 是

\[
\nu_\tau(p^a)=
\begin{cases}
1,&p\equiv1\pmod4,\\
0,&p\equiv3\pmod4,\ a\text{ odd},\\
1/(a+1),&p\equiv3\pmod4,\ a\text{ even},\\
1/(a+1),&p=2.
\end{cases}
\]

特别地，除 ramified prime 2 外，prime restriction 是 \(\mathbb Q(i)/\mathbb Q\) 的 split-prime indicator；所有 prime powers 绝对值 \(\le1\)。因此 Loughran–Matthiesen Definitions 2.6–2.7 的 hypotheses 可逐项验证，且 Lemma 2.8 给出

\[
\boxed{
\sum_{m\le X}\nu_\tau(m)
=c_\tau X(\log X)^{-1/2}
+O\bigl(X(\log X)^{-3/2}\bigr),
\quad c_\tau>0.}
\tag{2.2}
\]

Euler product 可写成

\[
c_\tau=
\prod_p
\left(\sum_{a\ge0}\frac{\nu_\tau(p^a)}{p^a}\right)
\left(1-\frac1p\right)^{1/2}.
\]

对应 Dirichlet series 为

\[
\left(\sum_{a\ge0}\frac{2^{-as}}{a+1}\right)
\prod_{p\equiv1(4)}(1-p^{-s})^{-1}
\prod_{q\equiv3(4)}
\left(1+\sum_{j\ge1}\frac{q^{-2js}}{2j+1}\right).
\]

在固定 field \(\mathbb Q(i)\) 下该 asymptotic 是 qualitative effective in principle，但 cited theorem 未给出本项目可直接使用的 numerical \(X_0,c_\tau\)。这不影响本 phase：correlation requirement 仍完全缺失。

### Why this candidate is structurally better than \(r_2\)

- exact same support as \(\mathbf1_{\mathcal S_2}\)；
- bounded by 1，所以单个 high-representation integer 不会携带 arbitrarily large mass；
- correct Landau scale；
- multiplicative/Frobenian，one-point theory clean；
- 但 \(1/\tau\) 是 nonlinear damping，已知 \(r_2(n)r_2(n+h)\) formula 不会自动转移到 \(\nu_\tau(n)\nu_\tau(n+h)\)。

## 3. Two strict-subset candidates

### 3.1 No-inert-prime weight

\[
\nu_0(m)=\mathbf1_{\{q\nmid m\ \forall q\equiv3\ (4)\}}.
\]

它是 completely multiplicative 的 0–1 weight，且

\[
0\le\nu_0\le\mathbf1_{\mathcal S_2}.
\]

Prime mean 仍为 \(1/2\)，故 Lemma 2.8 给

\[
\sum_{m\le X}\nu_0(m)
=c_0X/\sqrt{\log X}+O(X/(\log X)^{3/2}),
\quad c_0>0.
\]

优点是局部定义最简单；缺点是 two-point problem 仍是 parallel sifted correlation，没有现成 signed asymptotic。

### 3.2 Split-squarefree weight

\[
\nu_{\mathrm{sf}}(m)=
\mathbf1_{\{m\text{ squarefree and every odd }p\mid m\text{ has }p\equiv1\ (4)\}}.
\]

同样有 \(0\le\nu_{\mathrm{sf}}\le\mathbf1_{\mathcal S_2}\)，Frobenian mean \(1/2\)，所以平均值是 \(c_{\mathrm{sf}}X/\sqrt{\log X}\)。Squarefree restriction 不解决 parallel-shift covariance。

## 4. General bounded Frobenian family

候选并不唯一。设 \(\nu\) multiplicative，满足

- \(\nu(p^a)=1\) for \(p\equiv1\pmod4\)；
- \(\nu(q^{2j+1})=0\) and \(0\le\nu(q^{2j})\le1\) for \(q\equiv3\pmod4\)；
- \(0\le\nu(2^a)\le1\)；
- prime-power bounds满足 Frobenian growth hypotheses。

则 \(0\le\nu\le\mathbf1_{\mathcal S_2}\)，且只要 split-prime value 保持 1，其 Frobenian mean 是 \(1/2\)，通常仍有 \(X/\sqrt{\log X}\) first moment。故“构造 weight”本身不是 bottleneck；“证明 parallel shifted concentration”才是 bottleneck。

## 5. Candidate matrix

| Candidate | Nonnegative | Supported on \(\mathcal S_2\) | Pointwise bounded by \(C\mathbf1\) | Correct mass | Correlation status |
|---|---:|---:|---:|---:|---|
| \(\mathbf1_{\mathcal S_2}\) | yes | exact | \(C=1\) | yes | exactly frozen indicator blocker |
| \(\nu_\tau=r_2/(4\tau)\) | yes | exact | \(C=1\) | **yes, exact theorem** | no parallel/growing-shift theorem found |
| \(\nu_0\) | yes | strict subset | \(C=1\) | **yes, exact theorem** | no signed parallel covariance theorem found |
| \(\nu_{\mathrm{sf}}\) | yes | strict subset | \(C=1\) | **yes, exact theorem** | same blocker |
| Hooley \(\rho=r_2t\) | **no** | support-faithful | no | damped mean | fixed-setup formula; sign failure |
| \(r_2/\sqrt{\log X}\) | yes | exact | **no** | yes | representation observable; high multiplicity |
| \(\min(1,r_2/B)\) | yes | exact | yes | not supplied uniformly | nonlinear clipping destroys known correlations |
| \(\rho_+\), \(|\rho|\), \(\rho^2\) | yes | exact | generally no | unverified | correlations do not follow from \(\rho\rho_h\) |
| Rosser/beta lower divisor sum | generally **signed** | lower-sieve relation only | no | sieve-dependent | sign/support failure |
| Selberg/enveloping square | yes | **not** support-faithful | often large | majorant mass | wrong direction |

## 6. High-multiplicity audit

For raw \(r_2\),

\[
\sum_{m\le X}r_2(m)\asymp X,
\qquad
\sum_{m\le X}r_2(m)^2\asymp X\log X.
\]

因此 normalizing the first moment to \(X/\sqrt{\log X}\) leaves a second moment of order \(X\), whereas a bounded support weight at natural density scale has diagonal mass at most \(O(X/\sqrt{\log X})\). Raw representation mass may overemphasize integers with many split prime factors. A statement such as “a weighted average is large for almost all parameters” only transfers to support if it gives per-parameter positivity or an explicit anti-concentration bound; weighted total mass alone does not。

For \(\nu_\tau\), pointwise \(\nu_\tau\le1\) eliminates this specific pathology. In particular,

\[
\#\{m\le X:\nu_\tau(m)>0\}
\ge \sum_{m\le X}\nu_\tau(m)
\gg X/\sqrt{\log X}.
\]

这只解决 single-variable mass concentration，不解决 shifted convolution \(V_X(n)=\sum_s w_X(s)\nu(n-s)\) 是否集中。

## 7. Sanity computation

`SANITY_CHECKS.json` 对所有 \(m\le10^6\) exact 验证了 (2.1)、\(0\le\nu_\tau\le\mathbf1_{\mathcal S_2}\)、以及 \(\nu_0,\nu_{\mathrm{sf}}\) 的 support implication。At \(10^6\)：

| weight | mass | mass\(\sqrt{\log X}/X\) |
|---|---:|---:|
| \(\mathbf1_{\mathcal S_2}\) | 216341 | 0.8041227 |
| \(\nu_0\) | 180751 | 0.6718374 |
| \(\nu_{\mathrm{sf}}\) | 124491 | 0.4627234 |
| \(\nu_\tau\) | 130786.1083 | 0.4861218 |

这些数值仅是 symbolic/moment sanity checks，不是 theorem evidence，也没有搜索 \(T(n)\)。
