# Executive Verdict

## Formal verdict

\[
\boxed{\texttt{NO PROMOTABLE ROUTE — SPECULATIVE WATCH}}
\]

项目状态保持 **PAUSED**。本 phase 没有重证被冻结的 positive-density theorem，也没有把未知的 indicator covariance 当作输入。

## 审计结论

本轮找到一个满足前三项要求的 exact bounded support weight：

\[
\boxed{\nu_\tau(m)=\frac{r_2(m)}{4\tau(m)}} \qquad (m\ge 1).
\]

若 \(\mathcal S_2\) 表示 sums of two squares，则

\[
0\le \nu_\tau(m)\le \mathbf 1_{\mathcal S_2}(m),
\qquad
\nu_\tau(m)>0\Longleftrightarrow m\in\mathcal S_2,
\]

而且由 Loughran–Matthiesen, Lemma 2.8，

\[
\sum_{m\le X}\nu_\tau(m)
=c_\tau\frac{X}{\sqrt{\log X}}
+O\!\left(\frac{X}{(\log X)^{3/2}}\right),
\qquad c_\tau>0.
\]

因此 requirements 1–3 被严格满足，且 pointwise constant 是 \(C=1\)。

但 promotion 所需的核心 trigger 不存在：没有核验到任何 primary-source theorem 能对

\[
h=3^c+5^d-3^{c'}-5^{d'}
\]

形成的 growing、parallel、structured shift family，给出 \(\nu_\tau\)（或任何其他 bounded support minorant）的 signed aggregate covariance little-o：

\[
\sum_{s,t}w_X(s)w_X(t)
\left(
C_{s,t}^{\nu}(X)-\frac{A_s^{\nu}(X)A_t^{\nu}(X)}{|I_X|}
\right)
=o\!\left(\frac{XW_X^2}{\log X}\right).
\]

这里 \(W_X=\sum_s w_X(s)\asymp(\log X)^2\)。现有结果分别在 sign、support、parallel geometry、fixed-configuration、fixed-shift、或 observable 上失配。

## 为什么不是 `PROMOTE`

1. Hooley 的 \(\rho=r_2t\) 是 support-faithful，但 \(t\) 明确不总为正；它不是 nonnegative minorant。
2. Kimmel–Kuperberg 与 McGrath 使用的是 **signed detector \(\rho\) + nonnegative outer sieve weight** 的 existence contradiction，不是 \(0\le\nu\le C\mathbf1_{\mathcal S_2}\) 的 concentration theorem。
3. Loughran–Matthiesen 的 Frobenian one-point theorem确立了 \(\nu_\tau\) 的正确 mass；其 Theorem 3.10 要求不同 affine forms 的 nonconstant parts 在 \(\mathbb Q\) 上 linearly independent，因而排除 \(n-s,n-t\) 这种 parallel pair。
4. Bantle 的 Theorem I 是 \(r(n)r(n+1)\) 的 representation-weighted asymptotic；indicator \(r_1(n)r_1(n+1)\) 只得到 Theorem II 的 fixed-shift lower bound。标题不能被误读为 indicator covariance theorem。
5. Cherubini–Fazzari, Theorem 1.5 给 fixed \(h\) 的 indicator pair lower bound \(\gg_{K,h}X/\log X\)，不是 signed covariance asymptotic，也没有 growing-shift uniformity。
6. Rosser/beta sieve 的 lower divisor sum是 signed；Selberg/enveloping squares 是 majorants。两者均未产生 nonnegative exact-support minorant with tractable correlations。
7. Green–Tao dense model/transference 不保留 support implication，并且其 own correlation condition专门承认 parallel shifts 不能由 linear-forms condition 控制。
8. Grimmelt 的 nonnegative-model frameworks 只在特定 additive convolution 中把 signed sieve minorant 近似为 nonnegative surrogate；surrogate 不要求 exact target support。Grimmelt–Teräväinen 的 absolute-value sieve correlations likewise 是 setup-specific upper bounds，不是 \(\nu_\tau\) 的 signed covariance。

## 为什么不是 `STOP`

\(\nu_\tau\)、\(\nu_0\) 和 \(\nu_{\mathrm{sf}}\) 显示：bounded, nonnegative, support-faithful、correct-mass 的 weights 并不稀缺。真正 bottleneck 已被压缩为一个非常具体的 parallel-shift correlation problem。因此该方向值得作为 **speculative watch** 保留，但目前没有 promotion-level theorem。

## 冻结边界

- positive-density theorem：保持 frozen；本轮不重证。
- almost-all：未证明。
- 本轮 standalone computation：仅验证 weight identities 与小规模 moments；没有进行大型 \(T(n)\) search。
- 最终状态：**OEIS A303656 remains UNRESOLVED**。
