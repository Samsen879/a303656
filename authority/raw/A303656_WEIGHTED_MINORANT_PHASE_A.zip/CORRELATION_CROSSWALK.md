# Correlation Crosswalk

## Required project object

对 bounded support weight \(\nu\)，项目需要

\[
\mathcal V_\nu(X):=
\sum_{s,t}w_X(s)w_X(t)
\left(C_{s,t}^\nu(X)-\frac{A_s^\nu(X)A_t^\nu(X)}{|I_X|}\right)
=o\!\left(\frac{XW_X^2}{\log X}\right).
\tag{R}
\]

核心 geometry 是 one-variable parallel forms \(n-s,n-t\)，且 number/locations of shifts grow with \(X\)。

## Primary-source theorem crosswalk

| Source / exact anchor | Observable | Sign / support | Shift geometry and uniformity | Effectivity | Outcome for (R) |
|---|---|---|---|---|---|
| Hooley (1971), Introduction; Sections 5–8; Eq. (20) | \(\rho_x(n)\rho_x(n+k)\), where \(\rho_x=r_2t_x\) | \(t_x\) explicitly “not necessarily always positive”; \(\rho_x=0\) off \(\mathcal S_2\) | Section 7 assumes \(0<k<x\); formula is embedded in a dispersion argument with \(x\)-dependent detector and arithmetic factor | no project-ready uniform numerical bound over structured multiset supplied | fails nonnegativity and bounded-minorant gate |
| Bantle (1986), Theorem I | \(r(n)r(n+1)\) in congruence condition | nonnegative, supported, but unbounded representation weight | fixed shift 1; asymptotic error depends on auxiliary \(\lambda\) | explicit power-type error in stated regime | wrong observable; no support covariance |
| Bantle (1986), Theorem II | \(r_1(n)r_1(n+1)\), indicator | exact support | fixed shift 1, short interval \(y\ge x^{2/3+\varepsilon}\) | lower-bound constant qualitative | lower bound only; no signed covariance |
| Cherubini–Fazzari (2022), Theorem 1.5; Proposition 3.1 | \(b_K(n)b_K(n+h)\) | exact norm-support indicator | \(h\in\mathbb Z\) fixed; constants \(\gg_{K,h}\) | no uniformity in growing \(h\) stated | lower bound only |
| McGrath (2022), Proposition 5.2 | abstract \(\rho_A\) plus outer \(w(n)\) | Prop. assumes \(\rho_A\ge0\), support on \(A\); application uses Hooley detector inside square | fixed finite bins/configuration; existence contradiction | constants depend on fixed setup | not a minorant covariance theorem |
| McGrath (2022), Lemma 5.4 / Lemma A.3 | \(r(n)r(n+h)\) in APs | nonnegative unbounded representation weight | Lemma 5.4: fixed \(h>0\), \(4\mid h\), all primes of \(h\) divide \(2q\); Lemma A.3 allows \(0<h<N^{3/4}\) but main local factor retains \(h\) | power-saving errors under stated arithmetic constraints | does not cover \(\nu_\tau\) or arbitrary structured shifts |
| McGrath (2022), Lemmas 5.5–5.6 | \(r^2\), auxiliary sums for \(\rho\) | a listed auxiliary main term \(Z^{(2)}\) is negative | fixed \(k,H\); Section 6 allows constants depending on fixed \(k\) | \(o(1)=O(D_0^{-1})\) for auxiliary sums | reinforces detector/sieve mechanism, not bounded support minorant |
| Kimmel–Kuperberg (2025), Theorem 1 | consecutive \(\mathcal S_2\) residue patterns | support conclusion | fixed odd squarefree \(q\), fixed tuple length \(M\), fixed two residue classes | asymptotic/existence with fixed data | positive-density pattern result, not per-base convolution concentration |
| Kimmel–Kuperberg (2025), Theorem 2, (16)–(22) | nonnegative outer \(w_n(\mathcal L)\), moments of signed \(\rho\) | outer weight nonnegative; \(\rho\) not nonnegative | fixed \(K\)-tuple \(\mathcal L(b)\); tuple locations may be \(O(\sqrt{\log x})\), but \(K\) fixed | constants/o-terms depend on fixed sieve parameters | no theorem for \(W_X\asymp(\log X)^2\) shifts or (R) |
| Loughran–Matthiesen (2023), Definitions 2.6–2.7; Lemma 2.8 | one-point mean of Frobenian multiplicative \(\rho\) | supports \(\nu_\tau,\nu_0,\nu_{sf}\); nonnegative | no shift correlation | qualitative asymptotic; no numerical threshold | proves requirement 3 only |
| Loughran–Matthiesen, Definition 3.9; Theorem 3.10 | products \(\prod_j\rho_j(\varphi_j(\mathbf n))\) | nonnegative Frobenian | fixed \(r\); nonconstant parts pairwise linearly independent over \(\mathbb Q\) | no uniform growing-system theorem | excludes parallel \(n-s,n-t\) exactly |
| MSTT (2023), Definition 9.1 | pseudorandomness over affine-linear systems | majorant/approximant framework | coefficient vectors pairwise nonparallel; parameters fixed per theorem | quantitative only within stated pseudorandomness setup | parallel shifts excluded |
| MSTT, Proposition A.3 | \(r_2\) and Type-I approximant | representation-weighted | short-interval higher uniformity, not support indicator | theorem for stated approximants | wrong observable |
| MSTT, Appendix A.4 | proposed indicator result | indicator | text is explicitly “potential”, “seems likely”, “we conjecture” | not a theorem | no admissible trigger |
| Green–Tao (2008), Definition 3.1 | linear forms condition for majorant \(\nu\) | nonnegative majorant | coefficient tuples nonzero and no rational multiples | fixed complexity | parallel shifts excluded |
| Green–Tao, Definition 3.2 | correlation upper condition | nonnegative majorant | explicitly introduced because \(x+h_j\) cannot be controlled by linear forms condition; gives upper envelope \(\tau(h_i-h_j)\) | moment bounds, not signed asymptotic | upper correlation control does not yield (R) |
| Green–Tao, Theorem 3.5 / Proposition 8.1 | dense model / relative Szemerédi | \(0\le f\le\nu\) | fixed progression complexity; global pattern count | ineffective/very weak quantitative decay | does not preserve exact support or prove almost-every-base coverage |
| Green–Tao, Definition 9.3 / Lemma 9.4 | square of truncated divisor sum | nonnegative **majorant** | linear-forms pseudorandomness after W-trick | fixed \(k\) | wrong inequality direction for a minorant |
| Iwaniec (1980), Theorem 1; Section 3, (3.2)–(3.6) | Rosser upper/lower sieve sums | lower coefficients satisfy a sign condition but the divisor sum can be negative | general sieve sequence; level/sifting parameter dependent | explicit sieve functions/errors under hypotheses | lower sieve is signed, not a nonnegative exact-support function |
| Grimmelt (2022), Proposition 2.1, (14)–(18) | convolution of a signed minorant with a nonnegative sequence, transferred through \(T_\nu,T_\nu^+\) | \(a,T_\nu^+\ge0\), but \(\nu,T_\nu\) may be signed; \(T_\nu^+\) has no target-support hypothesis | short-interval additive convolution; requires two local Fourier-closeness estimates and explicit \(L^2\)-exception bound | quantitative in the stated norms/parameters | model positivity is approximate convolution transference, not an exact-support minorant or (R) |
| Grimmelt–Teräväinen (2025), Definition 2.4; Proposition 3.4; Proposition 6.9; Theorem 7.9 | Chen lower sieve, additive approximation, absolute values of sieve weights, prime-to-Cramér model | the original lower sieve can be signed; nonnegative approximant/model is not required to have exact Chen-prime support | one highly structured binary Goldbach setup; approximation holds outside a power-saving exceptional set | authors state effective power saving in Theorem 1.1; constants depend on the full parameter hierarchy | no theorem for \(\mathcal S_2\), \(\nu_\tau\), or signed parallel-shift covariance |
| Parkkonen–Paulin (2026), Theorems 1.1 and 4.1 | pair correlations of logarithms of norm-form values | multiplicative/logarithmic observable | scaling/ratio geometry, not additive \(n,n+h\) | as stated in the paper | watch only; irrelevant to (R) |
| Croot–Mao–Pohoata–Sheffer–Yip (2026), Theorems 1.9–1.11; Theorem 4.1 | bounded-multiplicity norm-form sets and weighted combinatorial large sieve | nonnegative local weights in an upper-bound sieve; no exact-support minorant constructed | finite-set/global multiplicity geometry, not shifted convolution concentration | explicit qualitative dependence as stated | useful upper-bound machinery, but neither lower-tail coverage nor (R) |

## Fixed-shift versus growing structured shifts

A theorem of the shape

\[
\sum_{m\le X}\nu(m)\nu(m+h)
\sim \mathfrak S_\nu(h)c_\nu^2X/\log X
\]

for each fixed \(h\) does not license substitution of \(h=h(X)\)。本项目差集包含 \(\asymp W_X^2\) ordered pairs and shifts as large as \(X/2\) in the frozen domain。即使缩小到 \(X^\theta\) 或 subpolynomial shifts，只要要保持 \(W_X\gg\sqrt{\log X}\) 以压低 diagonal，shift range 仍必须 growing；fixed-parameter constants不能未审计地交换极限。

## What exact theorem would trigger promotion

以下任一项足够：

1. **Direct aggregate theorem**：对 \(\nu_\tau\)（或其他 \(0\le\nu\le\mathbf1_{\mathcal S_2}\) correct-mass weight）直接证明 (R)，包括真实 dyadic boundaries 与 multiplicities。
2. **Uniform pair asymptotic + averaged local factor**：对所有 relevant \(s\ne t\)，有可 summation 的 signed error，并证明
   \[
   \sum_{s\ne t}w_s w_t(\mathfrak S_\nu(t-s)-1)=o(W_X^2).
   \]
3. **Lower-tail theorem**：不经 full covariance，直接证明
   \[
   \#\{n\in I_X:V_X(n)=0\}=o(X)
   \]
   for an exact-support bounded weight。

本轮没有 primary source 达到其中任何一项。
