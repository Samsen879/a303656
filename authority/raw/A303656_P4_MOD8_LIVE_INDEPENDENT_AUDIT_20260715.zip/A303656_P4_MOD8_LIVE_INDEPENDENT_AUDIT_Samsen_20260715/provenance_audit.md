# Provenance 审计

本审计没有访问 Samsen 的 WSL repository。以下结论严格使用 “bundle evidence supports / does not support”。

| Claim | Bundle-evidence assessment |
|---|---|
| initial validated commit `f452f2db...` | **bundle evidence supports** 一个 internally consistent identifier 与 parent-chain starting point |
| SOURCE U `ee5bef63...` | **bundle evidence supports** reported identifier、parent、date、subject；**does not support** cryptographic verification，因为 Git object 未打包 |
| RESULTS V `6efcf58e...` | **bundle evidence supports** reported identifier 与 parent relation；**does not support** tree/diff verification |
| U parent 是 initial，V parent 是 U | **bundle evidence supports** `commit_chain.json` 中的关系；无 Git objects |
| RESULTS V 只加入 results/report | **bundle evidence does not support**：无 patches、tree listings 或 Git bundle |
| protected hashes unchanged | **bundle evidence supports** after-hashes 与五个 hard-coded expected hashes；**does not support** 全部 protected files 的 complete before/after evidence |
| tracked worktree clean | **bundle evidence supports** generated booleans/empty tracked status；**does not independently verify** 原 command output；`--untracked-files=no` 忽略 untracked files |
| raw archive path/SHA256/size | **bundle evidence supports** mutually consistent metadata；**does not support** archive-byte verification，因为 archive 缺失 |
| 8 fresh-replay artifacts byte-identical | **bundle evidence supports** deterministic hash table 且 included committed hashes 全匹配；**does not support** fresh exported U checkout 真正生成它们，因为 checkout、commands 与 logs 缺失 |
| core enumerators 未读取 precomputed result | **bundle evidence supports** static source；A/B 只接受 output path，并在本审计中 byte-identical replay |
| 本 run 未调用 `T`、factorization、direct oracle、P5/P6 search | **bundle evidence supports** included code path 与 command list；`authorities.json` counters 不是 runtime instrumentation，Git-to-bundle binding 也未独立认证 |

## Specific provenance defects

1. `results/metadata.json` 保留 `"results_commit": "RESULT_COMMIT_CONTAINING_THIS_FILE"`，没有绑定 V。
2. Exact frozen 13 masks、pair-order authority、G=231 pair-frequency authority 与多数 protected files 未打包。
3. External raw archive 未打包，其 SHA256 在本环境中不可验证。
4. 没有 SOURCE-U patch、RESULTS-V patch、`git cat-file` objects、signed tag 或 minimal Git bundle。
5. “fresh replay” manifest 是 summary artifact，不是 replay transcript。

## 本轮实际达到的 reproducibility

* bundle `SHA256SUMS`：38/38 listed files pass；
* bundle Enumerator A/B：独立重跑且与两个 raw certificates byte-identical；
* independent Python/C++：complete exact landscape agreement；
* full builder/verifier/corruption replay：因缺失 authorities 与 Git history，不能在 repository 外完成。
