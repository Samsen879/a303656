# Historical ledger coverage 审计

**Auditor：** Samsen  
**Scope：** exact P4/mod-8-live audit only；不评价任何新 `T(n)`。

## Bundle 中实际提供的 historical sources

| Ledger | 已打包内容 | 独立检查 | 缺失 provenance |
|---|---|---|---|
| Designed-class snapshot | 320 个 unique fixed-P4 tuples；列出 4 个 repository source hashes | tuple count、sorted `<4H` digest、全部 CRT residues 一致；重建出 10 full masks 与 10 live projections | 4 个 source files 均未打包；无 per-source class attribution |
| Evaluated-integer snapshot | 28 个 merged inclusive intervals 与 6,129 sparse points | 28 个 interval 可由 37 个 raw intervals merge 得到；sparse points sorted/unique；snapshot SHA256 与 protected hash 相同 | 13 个 component files 与 Git history 均未打包 |
| Frozen 13 mask set | 仅有 path/hash 与 downstream booleans | 无法检查 exact 13 bytes | `frozen_base_masks.json` 缺失 |
| G=231 pair frequencies | 仅有 protected hash 与 derived 60-index result | 60-element mathematical set identity 已重建 | `pair_frequencies.csv` 缺失，`winner_count=0` provenance 不能 replay |

## 对 user-required historical categories 的覆盖

| Required category | Bundle evidence | Verdict |
|---|---|---|
| fixed-P4 calibration panels | 通过 P4 census/class files 间接命名 | PARTIAL |
| G=231 census | class panel 与 derived identity 被命名；raw frequency file 缺失 | PARTIAL |
| weighted fixed-P4 experiments | registry 自报没有新 integers，并声明 subset relation | BUNDLE-SUPPORTED, NOT INDEPENDENTLY REPLAYABLE |
| P5 Family R | 两个 snapshots 均未明确列出 | NOT ESTABLISHED |
| P5 Family U | designed-class source 被命名；integer components 未明确命名 | PARTIAL / STALE-RISK |
| P5 Family Q | 未明确列出 | NOT ESTABLISHED |
| previous sparse feasibility | designed-class source 被命名 | PARTIAL |
| all classes containing an evaluated integer | **不能由 320-tuple designed ledger 表示** | FAIL for strict class freshness |
| abandoned/partial/interrupted runs | 无 ledger entries 或 negative evidence | NOT ESTABLISHED |
| collision/replay records | 无 complete historical ledger | NOT ESTABLISHED |

## 决定性 arithmetic consequence

Registry 包含 inclusive interval `[240000000001, 241600000000]`，长度 1,600,000,000；而 `L4 = 1,129,118,760`。因此该 interval 至少包含每个 residue class modulo `L4` 一次。由此：

* 468 个 maximizing CRT classes 全部含 historical evaluated members；
* 21 个 maximizing full masks 全部 historically realized；
* 5 个 maximizing live projections 全部 historically realized；
* strict class freshness 与 strict mask/projection freshness 均为 0。

所以 320-tuple field `previously_designed_class` 可用于表述 **design novelty**，不能在冻结定义下认证 **class-level freshness**。
