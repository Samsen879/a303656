#include <array>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <tuple>
#include <vector>

using Mask = std::array<std::uint64_t, 7>;
struct Pair { int c, d; std::uint64_t shift; };
struct Rec {
    int h8 = 0;
    int raw_g = 0;
    int dead = 0;
    std::uint64_t multiplicity = 0;
    std::array<int,4> first{};
};

static inline Mask mor(const Mask &a, const Mask &b) {
    Mask r{};
    for (int i=0;i<7;i++) r[i]=a[i]|b[i];
    return r;
}
static inline int pop(const Mask &a) {
    int s=0;
    for (auto x:a) s += __builtin_popcountll(x);
    return s;
}
static inline int pop_and(const Mask &a, const Mask &b) {
    int s=0;
    for (int i=0;i<7;i++) s += __builtin_popcountll(a[i]&b[i]);
    return s;
}
static inline void setbit(Mask &a, int i) { a[i/64] |= (std::uint64_t(1) << (i%64)); }
static std::string hex51(const Mask &m) {
    static const char *h="0123456789abcdef";
    std::string out; out.reserve(102);
    for (int i=0;i<51;i++) {
        unsigned byte = (m[i/8] >> (8*(i%8))) & 0xffU;
        out.push_back(h[byte>>4]); out.push_back(h[byte&15]);
    }
    return out;
}
static bool tuple_less(const std::array<int,4>&a,const std::array<int,4>&b){return a<b;}
static std::uint64_t ipow(std::uint64_t b,int e){std::uint64_t r=1;while(e--)r*=b;return r;}

int main(int argc,char**argv){
    if(argc!=2){std::cerr<<"usage: verifier output.json\n";return 2;}
    const std::uint64_t LOW=ipow(3,22)+ipow(5,16);
    std::vector<Pair> pairs;
    for(int c=0;c<24;c++) for(int d=0;d<17;d++) {
        std::uint64_t s=ipow(3,c)+ipow(5,d);
        if(s<=LOW) pairs.push_back({c,d,s});
    }
    if(pairs.size()!=407 || pairs.back().c!=23 || pairs.back().d!=15){std::cerr<<"domain failure\n";return 3;}
    int dup=0; for(auto &p:pairs) if(p.shift==28) dup++;
    if(dup!=2){std::cerr<<"duplicate failure\n";return 4;}

    Mask live{},dead{};
    for(int i=0;i<(int)pairs.size();i++){
        if((pairs[i].c&1) && !(pairs[i].d&1)) setbit(dead,i); else setbit(live,i);
    }
    if(pop(dead)!=107 || pop(live)!=300){std::cerr<<"partition failure\n";return 5;}

    const int P[4]={3,7,11,23}; const int Q[4]={9,49,121,529};
    std::vector<std::vector<Mask>> local(4);
    for(int z=0;z<4;z++){
        local[z].resize(Q[z]);
        for(int t=0;t<Q[z];t++){
            Mask m{};
            for(int i=0;i<(int)pairs.size();i++){
                std::int64_t diff=(std::int64_t(t)-std::int64_t(pairs[i].shift%Q[z]))%Q[z];
                if(diff<0) diff+=Q[z];
                if(diff!=0 && diff%P[z]==0) setbit(m,i);
            }
            local[z][t]=m;
        }
    }

    std::array<std::uint64_t,408> hist{},t3hist{},rawhist{},t3rawhist{};
    int hmin=999,hmax=-1,rawmin=999,rawmax=-1,t3min=999,t3max=-1,t3rawmin=999,t3rawmax=-1;
    std::uint64_t argcnt=0,rawarg=0,t3arg=0,t3rawarg=0,count=0;
    std::array<int,4> first{},rawfirst{},t3first{},t3rawfirst{};
    std::map<std::string,Rec> top;
    for(int t3=0;t3<Q[0];t3++){
      for(int t7=0;t7<Q[1];t7++){
        Mask m37=mor(local[0][t3],local[1][t7]);
        for(int t11=0;t11<Q[2];t11++){
          Mask m3711=mor(m37,local[2][t11]);
          for(int t23=0;t23<Q[3];t23++){
            Mask full=mor(m3711,local[3][t23]);
            int h=pop_and(full,live), g=pop(full), d=pop_and(full,dead);
            std::array<int,4> tup{t3,t7,t11,t23};
            hist[h]++; rawhist[g]++; count++;
            if(h<hmin)hmin=h;
            if(h>hmax){hmax=h;argcnt=1;first=tup;} else if(h==hmax)argcnt++;
            if(g<rawmin)rawmin=g;
            if(g>rawmax){rawmax=g;rawarg=1;rawfirst=tup;} else if(g==rawmax)rawarg++;
            if(h>=199){
                auto key=hex51(full); auto it=top.find(key);
                if(it==top.end()){
                    Rec r; r.h8=h;r.raw_g=g;r.dead=d;r.multiplicity=1;r.first=tup;top.emplace(key,r);
                }else{
                    it->second.multiplicity++;
                    if(tuple_less(tup,it->second.first))it->second.first=tup;
                }
            }
            if(t3==2){
                t3hist[h]++;t3rawhist[g]++;
                if(h<t3min)t3min=h;
                if(h>t3max){t3max=h;t3arg=1;t3first=tup;} else if(h==t3max)t3arg++;
                if(g<t3rawmin)t3rawmin=g;
                if(g>t3rawmax){t3rawmax=g;t3rawarg=1;t3rawfirst=tup;} else if(g==t3rawmax)t3rawarg++;
            }
          }
        }
      }
    }
    if(count!=28227969ULL){std::cerr<<"tuple count failure\n";return 6;}
    std::size_t maxmaskcount=0; std::uint64_t maxmult=0;
    for(auto &kv:top) if(kv.second.h8==hmax){maxmaskcount++;maxmult+=kv.second.multiplicity;}

    std::ofstream o(argv[1]);
    o<<"{\n";
    o<<"\"schema\":\"samsen-independent-cpp-p4-mod8-live-v1\",\n";
    o<<"\"tuple_count\":"<<count<<",\n";
    o<<"\"minimum\":"<<hmin<<",\"maximum\":"<<hmax<<",\"argmax_count\":"<<argcnt<<",\n";
    o<<"\"first_argmax\":["<<first[0]<<","<<first[1]<<","<<first[2]<<","<<first[3]<<"],\n";
    o<<"\"raw\":{\"minimum\":"<<rawmin<<",\"maximum\":"<<rawmax<<",\"argmax_count\":"<<rawarg<<",\"first_argmax\":["<<rawfirst[0]<<","<<rawfirst[1]<<","<<rawfirst[2]<<","<<rawfirst[3]<<"]},\n";
    o<<"\"t3eq2\":{\"tuple_count\":3136441,\"minimum\":"<<t3min<<",\"maximum\":"<<t3max<<",\"argmax_count\":"<<t3arg<<",\"first_argmax\":["<<t3first[0]<<","<<t3first[1]<<","<<t3first[2]<<","<<t3first[3]<<"],\"raw_minimum\":"<<t3rawmin<<",\"raw_maximum\":"<<t3rawmax<<",\"raw_argmax_count\":"<<t3rawarg<<"},\n";
    o<<"\"histogram\":[";for(int i=0;i<=407;i++){if(i)o<<",";o<<hist[i];}o<<"],\n";
    o<<"\"t3eq2_histogram\":[";for(int i=0;i<=407;i++){if(i)o<<",";o<<t3hist[i];}o<<"],\n";
    o<<"\"raw_histogram\":[";for(int i=0;i<=407;i++){if(i)o<<",";o<<rawhist[i];}o<<"],\n";
    o<<"\"t3eq2_raw_histogram\":[";for(int i=0;i<=407;i++){if(i)o<<",";o<<t3rawhist[i];}o<<"],\n";
    o<<"\"top_band_mask_count\":"<<top.size()<<",\"maximizing_mask_count\":"<<maxmaskcount<<",\"maximizing_tuple_multiplicity\":"<<maxmult<<",\n";
    o<<"\"maximizing_masks\":[";
    bool firstrow=true;
    for(auto &kv:top) if(kv.second.h8==hmax){
        if(!firstrow)o<<",";firstrow=false;auto&r=kv.second;
        o<<"{\"mask_hex\":\""<<kv.first<<"\",\"H8\":"<<r.h8<<",\"raw_G\":"<<r.raw_g<<",\"covered_dead\":"<<r.dead<<",\"tuple_multiplicity\":"<<r.multiplicity<<",\"first_tuple\":["<<r.first[0]<<","<<r.first[1]<<","<<r.first[2]<<","<<r.first[3]<<"]}";
    }
    o<<"]\n}\n";
    std::cout<<"tuple_count="<<count<<" H8=["<<hmin<<","<<hmax<<"] argmax="<<argcnt<<" max_masks="<<maxmaskcount<<" raw=["<<rawmin<<","<<rawmax<<"] raw_argmax="<<rawarg<<" t3_raw_argmax="<<t3rawarg<<"\n";
    return 0;
}
