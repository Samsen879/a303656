#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,hashlib,json,struct
from collections import Counter,defaultdict
from pathlib import Path

P=(3,7,11,23); MODS=(9,49,121,529); M4=9*49*121*529; L4=40*M4
LOW=3**22+5**16; HIGH=3**23+5**16-1; WIDTH=HIGH-LOW+1

def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def mask_bytes(m:int)->bytes:return m.to_bytes(51,'little')
def pairs():return [(c,d,3**c+5**d) for c in range(24) for d in range(17) if 3**c+5**d<=LOW]
def local_masks(ps,p):
 q=p*p;out=[0]*q
 for t in range(q):
  m=0
  for i,(_,_,s) in enumerate(ps):
   r=(t-s)%q
   if r and r%p==0:m|=1<<i
  out[t]=m
 return out
def cover(mm,t):return mm[0][t[0]]|mm[1][t[1]]|mm[2][t[2]]|mm[3][t[3]]
def crt(t):
 x=0;m=1
 for v,q in zip((34,*t),(40,*MODS)):
  k=((v-x)*pow(m,-1,q))%q;x+=m*k;m*=q
 return x%m
def members(r):
 k=(LOW-r+L4-1)//L4 if r<LOW else 0
 x=r+k*L4
 if x<LOW: raise AssertionError
 out=[]
 while x<=HIGH:
  out.append(x);x+=L4
 return out,k
def in_registry(n,intervals,sparse):
 # intervals are sorted disjoint; simple binary search
 lo,hi=0,len(intervals)
 while lo<hi:
  mid=(lo+hi)//2
  a,b=intervals[mid]
  if n<a:hi=mid
  elif n>b:lo=mid+1
  else:return True
 return n in sparse

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--bundle-root',required=True);ap.add_argument('--core-result',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
 root=Path(a.bundle_root);core=json.loads(Path(a.core_result).read_text())
 ps=pairs();mm=[local_masks(ps,p) for p in P]
 dead=sum(1<<i for i,(c,d,s) in enumerate(ps) if c%2 and d%2==0);live=((1<<407)-1)^dead
 maxrecs=core['landscape']['maximizing_masks'];toprecs=core['landscape']['top_band_masks']
 max_tuples=sorted(tuple(t) for r in maxrecs for t in r['tuples'])
 top_tuples=sorted(tuple(t) for r in toprecs for t in r['tuples'])
 assert len(max_tuples)==468 and len(set(max_tuples))==468 and len(top_tuples)==8001 and len(set(top_tuples))==8001

 designed=json.loads((root/'ledgers/historical_designed_class_ledger_snapshot.json').read_text())
 dtups=sorted({tuple(x['tuple']) for x in designed['classes']})
 denc=b''.join(struct.pack('<4H',*t) for t in dtups)
 designed_checks={
  'reported_class_count':designed['class_count'],'recomputed_class_count':len(dtups),
  'reported_canonical_tuple_digest':designed['canonical_tuple_digest'],'recomputed_canonical_tuple_digest':sha(denc),
  'tuple_digest_match':sha(denc)==designed['canonical_tuple_digest'],
  'crt_residue_mismatch_count':sum(crt(tuple(x['tuple']))!=x['crt_residue_mod_L4_for_n34mod40'] for x in designed['classes']),
  'source_files_present_in_bundle':{k:(root/k).exists() for k in designed['source_sha256']},
 }
 designed_masks=defaultdict(set);designed_projs=defaultdict(set)
 designed_mask_set=set();designed_proj_set=set()
 for t in dtups:
  m=cover(mm,t);d=sha(mask_bytes(m));pd=sha(mask_bytes(m&live));designed_mask_set.add(d);designed_proj_set.add(pd);designed_masks[d].add(t);designed_projs[pd].add(t)
 max_mask_set={r['mask_digest'] for r in maxrecs};max_proj_set={r['live_projection_digest'] for r in maxrecs}

 reg=json.loads((root/'ledgers/historical_evaluated_integer_registry_snapshot.json').read_text())
 intervals=[tuple(x) for x in reg['interval_union']];sparse=set(reg['sparse_points'])
 # reconstruct union of raw interval sources
 src=sorted((int(x['low']),int(x['high'])) for x in reg['interval_sources'])
 merged=[]
 for aa,bb in src:
  if not merged or aa>merged[-1][1]+1:merged.append([aa,bb])
  elif bb>merged[-1][1]:merged[-1][1]=bb
 registry_checks={
  'file_sha256':sha((root/'ledgers/historical_evaluated_integer_registry_snapshot.json').read_bytes()),
  'reported_interval_union_count':reg['interval_union_count'],'recomputed_interval_union_count':len(merged),
  'interval_union_matches_sources':merged==reg['interval_union'],
  'reported_raw_interval_count':reg['raw_interval_count'],'recomputed_raw_interval_count':len(src),
  'reported_sparse_point_count':reg['sparse_point_count'],'recomputed_sparse_point_count':len(sparse),
  'sparse_sorted_unique':reg['sparse_points']==sorted(sparse),
  'interval_union_sorted_disjoint_nonadjacent':all(intervals[i][1]+1<intervals[i+1][0] for i in range(len(intervals)-1)),
  'contains_full_residue_covering_interval':[],
 }
 for aa,bb in intervals:
  if bb-aa+1>=L4:registry_checks['contains_full_residue_covering_interval'].append({'low':aa,'high':bb,'length':bb-aa+1,'length_ge_L4':True})

 csvrows=list(csv.DictReader((root/'results/class_freshness_manifest.csv').open()))
 csv_by_t={tuple(int(r[k]) for k in ('t3','t7','t11','t23')):r for r in csvrows}
 assert len(csv_by_t)==len(csvrows)==8001
 top_digest_by_t={tuple(t):r['mask_digest'] for r in toprecs for t in r['tuples']}
 max_digest_by_t={tuple(t):r['mask_digest'] for r in maxrecs for t in r['tuples']}
 max_proj_by_mask={r['mask_digest']:r['live_projection_digest'] for r in maxrecs}

 generated=[];allints=defaultdict(list);freshints=defaultdict(list);mismatches=[]
 for t in top_tuples:
  r=crt(t);mem,q0=members(r);ev=[n for n in mem if in_registry(n,intervals,sparse)];fr=[n for n in mem if not in_registry(n,intervals,sparse)]
  md=top_digest_by_t[t]
  rec={'tuple':t,'mask_digest':md,'crt_residue':r,'member_count':len(mem),'members':mem,'previously_designed_class':t in set(dtups),'evaluated':ev,'fresh':fr,'starting_quotient':q0,
       'member_digest':sha(b''.join(struct.pack('<Q',n) for n in mem)),'fresh_member_digest':sha(b''.join(struct.pack('<Q',n) for n in fr))}
  generated.append(rec)
  for n in mem:allints[n].append(t)
  for n in fr:freshints[n].append(t)
  b=csv_by_t[t]
  expect={
   'mask_digest':md,'crt_residue':str(r),'modulus':str(L4),'member_count':str(len(mem)),
   'previously_designed_class':str(t in set(dtups)),'previously_evaluated_integer_count':str(len(ev)),'fresh_integer_count':str(len(fr)),
   'minimum_fresh_integer':str(min(fr) if fr else ''),'maximum_fresh_integer':str(max(fr) if fr else ''),
   'member_digest':rec['member_digest'],'fresh_member_digest':rec['fresh_member_digest']}
  for k,v in expect.items():
   if b[k]!=v:mismatches.append({'tuple':list(t),'field':k,'bundle':b[k],'independent':v})

 maxgen=[r for r in generated if r['tuple'] in set(max_tuples)]
 mask_group=defaultdict(list);proj_group=defaultdict(list)
 for r in maxgen:
  mask_group[r['mask_digest']].append(r)
  proj_group[max_proj_by_mask[r['mask_digest']]].append(r)
 def summarize(rows):
  ai=[n for r in rows for n in r['members']];fi=[n for r in rows for n in r['fresh']];ei=[n for r in rows for n in r['evaluated']]
  return {'class_count':len(rows),'class_integer_incidences':len(ai),'distinct_integers':len(set(ai)),'evaluated_integer_incidences':len(ei),'distinct_evaluated_integers':len(set(ei)),
          'fresh_integer_incidences':len(fi),'distinct_fresh_integers':len(set(fi)),'member_count_histogram':dict(sorted(Counter(len(r['members']) for r in rows).items())),
          'evaluated_count_per_class_histogram':dict(sorted(Counter(len(r['evaluated']) for r in rows).items())),
          'fresh_count_per_class_histogram':dict(sorted(Counter(len(r['fresh']) for r in rows).items())),
          'minimum_integer':min(ai) if ai else None,'maximum_integer':max(ai) if ai else None,'minimum_fresh_integer':min(fi) if fi else None,'maximum_fresh_integer':max(fi) if fi else None}
 total=summarize(maxgen)
 collision_hist=dict(sorted(Counter(len(v) for v in allints.values() if any(t in set(max_tuples) for t in v)).items()))
 # allints includes topband; recompute max-only collision map to avoid contamination.
 max_all=defaultdict(list);max_fresh=defaultdict(list)
 for r in maxgen:
  for n in r['members']:max_all[n].append(r['tuple'])
  for n in r['fresh']:max_fresh[n].append(r['tuple'])
 collision_hist=dict(sorted(Counter(len(v) for v in max_all.values()).items()))
 fresh_collision_hist=dict(sorted(Counter(len(v) for v in max_fresh.values()).items()))
 residues=[r['crt_residue'] for r in maxgen]
 strict_hist_class_seen=[]
 for r in maxgen:
  # Strict evaluated-class freshness: class is seen if any registry member exists.
  strict_hist_class_seen.append(bool(r['evaluated']))

 output={
  'schema':'samsen-freshness-activation-audit-v1',
  'constants':{'LOW':LOW,'HIGH':HIGH,'inclusive_width':WIDTH,'M4':M4,'L4':L4,'boundary_convention':'closed inclusive [LOW,HIGH]'},
  'historical_designed_class_snapshot':designed_checks|{
   'distinct_full_masks':len(designed_mask_set),'distinct_live_projections':len(designed_proj_set),
   'maximizing_full_mask_intersection':sorted(max_mask_set&designed_mask_set),'maximizing_full_mask_intersection_count':len(max_mask_set&designed_mask_set),
   'maximizing_live_projection_intersection':sorted(max_proj_set&designed_proj_set),'maximizing_live_projection_intersection_count':len(max_proj_set&designed_proj_set),
  },
  'historical_integer_registry_snapshot':registry_checks,
  'maximizer_activation':total|{
   'description_count':len(maxgen),'unique_tuple_count':len(set(r['tuple'] for r in maxgen)),'unique_crt_residue_count':len(set(residues)),
   'class_collision_count':len(residues)-len(set(residues)),'integer_collision_multiplicity_histogram':collision_hist,'fresh_integer_collision_multiplicity_histogram':fresh_collision_hist,
   'strict_previously_evaluated_class_count':sum(strict_hist_class_seen),'strict_fresh_class_count':len(strict_hist_class_seen)-sum(strict_hist_class_seen),
   'not_previously_designed_class_count':sum(not r['previously_designed_class'] for r in maxgen),
  },
  'per_mask':{d:summarize(rs) for d,rs in sorted(mask_group.items())},
  'per_live_projection':{d:summarize(rs)|{'full_mask_count':len({r['mask_digest'] for r in rs})} for d,rs in sorted(proj_group.items())},
  'full_top_band_manifest_crosscheck':{'row_count':len(csvrows),'recomputed_row_count':len(generated),'mismatch_count':len(mismatches),'mismatches':mismatches[:100]},
  'logical_freshness_findings':{
   'all_maximizer_classes_have_prior_evaluated_integer':all(strict_hist_class_seen),
   'reason':'The bundled registry contains the inclusive interval [240000000001,241600000000], length 1,600,000,000 > L4; therefore every residue class modulo L4 occurs at least once. Direct per-class reconstruction confirms at least one evaluated member for all 468 maximizing classes.',
   'full_masks_previously_realized_by_evaluated_integers':len(max_mask_set),
   'live_projections_previously_realized_by_evaluated_integers':len(max_proj_set),
   'new_vs_designed_is_not_strict_class_freshness':True,
  },
 }
 Path(a.out).write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'maximizer_activation':output['maximizer_activation'],'designed_intersections':{k:output['historical_designed_class_snapshot'][k] for k in ['maximizing_full_mask_intersection_count','maximizing_live_projection_intersection_count']},'manifest_mismatches':len(mismatches)},indent=2))
if __name__=='__main__':main()
