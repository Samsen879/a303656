#!/usr/bin/env python3
"""Standalone exact verifier for the frozen P4/mod-8-live landscape.

This program does not import or execute any code from the supplied audit bundle.
It reconstructs the 407 ordered exponent-pair identities, local exact-valuation-one
coverage masks, the D8/A8 partition, and enumerates all 28,227,969 CRT tuples.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import struct
import time
from collections import Counter, defaultdict
from pathlib import Path

PRIMES = (3, 7, 11, 23)
MODULI = tuple(p * p for p in PRIMES)
LOW = 3**22 + 5**16
HIGH = 3**23 + 5**16 - 1
PAIR_COUNT = 407
FULL_BYTES = (PAIR_COUNT + 7) // 8
TUPLE_COUNT = 9 * 49 * 121 * 529
T3EQ2_COUNT = 49 * 121 * 529
TOP_BAND_THRESHOLD = 199
BASELINES = {
    "CAL-216": (2, 41, 74, 504),
    "CAL-227": (2, 41, 50, 504),
    "CAL-230": (2, 7, 32, 504),
    "G231-COMMON": (2, 7, 50, 17),
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_mask_bytes(mask: int) -> bytes:
    if mask < 0 or mask.bit_length() > PAIR_COUNT:
        raise ValueError("mask outside 407-bit domain")
    return mask.to_bytes(FULL_BYTES, "little", signed=False)


def build_pairs() -> list[tuple[int, int, int]]:
    pairs: list[tuple[int, int, int]] = []
    for c in range(24):
        for d in range(17):
            shift = 3**c + 5**d
            if shift <= LOW:
                pairs.append((c, d, shift))
    assert len(pairs) == PAIR_COUNT
    assert pairs[0] == (0, 0, 2)
    assert pairs[-1][:2] == (23, 15)
    assert [(c, d) for c, d, s in pairs if s == 28] == [(1, 2), (3, 0)]
    excluded = (23, 16, 3**23 + 5**16)
    assert excluded[2] == HIGH + 1
    assert excluded[2] > LOW
    return pairs


def local_masks_direct(pairs: list[tuple[int, int, int]], p: int) -> list[int]:
    q = p * p
    table: list[int] = []
    for t in range(q):
        mask = 0
        for i, (_, _, shift) in enumerate(pairs):
            diff = (t - shift) % q
            if diff != 0 and diff % p == 0:
                mask |= 1 << i
        table.append(mask)
    return table


def local_masks_paircentric(pairs: list[tuple[int, int, int]], p: int) -> list[int]:
    q = p * p
    table = [0] * q
    for i, (_, _, shift) in enumerate(pairs):
        for k in range(1, p):
            table[(shift + k * p) % q] |= 1 << i
    return table


def cover(local: list[list[int]], t: tuple[int, int, int, int]) -> int:
    return local[0][t[0]] | local[1][t[1]] | local[2][t[2]] | local[3][t[3]]


def index_digest(indices: list[int]) -> str:
    return sha256(b"".join(struct.pack("<H", i) for i in indices))


def update_mask_record(records: dict[str, dict], full: int, h8: int, tup: tuple[int, int, int, int], dead_mask: int, live_mask: int) -> None:
    raw = canonical_mask_bytes(full)
    digest = sha256(raw)
    rec = records.get(digest)
    if rec is None:
        live_projection = full & live_mask
        live_raw = canonical_mask_bytes(live_projection)
        rec = {
            "mask_digest": digest,
            "mask_hex": raw.hex(),
            "live_projection_digest": sha256(live_raw),
            "live_projection_mask_hex": live_raw.hex(),
            "H8": h8,
            "raw_G": full.bit_count(),
            "covered_dead": (full & dead_mask).bit_count(),
            "tuple_multiplicity": 0,
            "first_tuple": list(tup),
            "tuples": [],
        }
        records[digest] = rec
    else:
        assert rec["H8"] == h8
        assert rec["mask_hex"] == raw.hex()
        if list(tup) < rec["first_tuple"]:
            rec["first_tuple"] = list(tup)
    rec["tuple_multiplicity"] += 1
    rec["tuples"].append(list(tup))


def enumerate_landscape(local: list[list[int]], dead_mask: int, live_mask: int) -> dict:
    hist = [0] * (PAIR_COUNT + 1)
    t3_hist = [0] * (PAIR_COUNT + 1)
    raw_hist = [0] * (PAIR_COUNT + 1)
    t3_raw_hist = [0] * (PAIR_COUNT + 1)
    h_min = PAIR_COUNT + 1
    h_max = -1
    first_argmax: tuple[int, int, int, int] | None = None
    argmax_count = 0
    raw_min = PAIR_COUNT + 1
    raw_max = -1
    raw_argmax_count = 0
    raw_first_argmax: tuple[int, int, int, int] | None = None
    t3_h_min = PAIR_COUNT + 1
    t3_h_max = -1
    t3_argmax_count = 0
    t3_first_argmax: tuple[int, int, int, int] | None = None
    t3_raw_min = PAIR_COUNT + 1
    t3_raw_max = -1
    t3_raw_argmax_count = 0
    t3_raw_first_argmax: tuple[int, int, int, int] | None = None
    top_band: dict[str, dict] = {}
    global_stream = hashlib.sha256()
    t3_stream = hashlib.sha256()
    count = 0

    m3s, m7s, m11s, m23s = local
    for t3, m3 in enumerate(m3s):
        for t7, m7 in enumerate(m7s):
            m37 = m3 | m7
            for t11, m11 in enumerate(m11s):
                m3711 = m37 | m11
                for t23, m23 in enumerate(m23s):
                    tup = (t3, t7, t11, t23)
                    full = m3711 | m23
                    h8 = (full & live_mask).bit_count()
                    raw_g = full.bit_count()
                    hist[h8] += 1
                    raw_hist[raw_g] += 1
                    global_stream.update(struct.pack("<5H", t3, t7, t11, t23, h8))
                    count += 1

                    if h8 < h_min:
                        h_min = h8
                    if h8 > h_max:
                        h_max = h8
                        argmax_count = 1
                        first_argmax = tup
                    elif h8 == h_max:
                        argmax_count += 1

                    if raw_g < raw_min:
                        raw_min = raw_g
                    if raw_g > raw_max:
                        raw_max = raw_g
                        raw_argmax_count = 1
                        raw_first_argmax = tup
                    elif raw_g == raw_max:
                        raw_argmax_count += 1

                    if h8 >= TOP_BAND_THRESHOLD:
                        update_mask_record(top_band, full, h8, tup, dead_mask, live_mask)

                    if t3 == 2:
                        t3_hist[h8] += 1
                        t3_raw_hist[raw_g] += 1
                        t3_stream.update(struct.pack("<5H", t3, t7, t11, t23, h8))
                        if h8 < t3_h_min:
                            t3_h_min = h8
                        if h8 > t3_h_max:
                            t3_h_max = h8
                            t3_argmax_count = 1
                            t3_first_argmax = tup
                        elif h8 == t3_h_max:
                            t3_argmax_count += 1
                        if raw_g < t3_raw_min:
                            t3_raw_min = raw_g
                        if raw_g > t3_raw_max:
                            t3_raw_max = raw_g
                            t3_raw_argmax_count = 1
                            t3_raw_first_argmax = tup
                        elif raw_g == t3_raw_max:
                            t3_raw_argmax_count += 1

    assert count == TUPLE_COUNT
    assert sum(hist) == TUPLE_COUNT
    assert sum(t3_hist) == T3EQ2_COUNT
    assert sum(raw_hist) == TUPLE_COUNT
    assert sum(t3_raw_hist) == T3EQ2_COUNT

    # Retain only true top-band masks and sort canonically by digest.
    top = sorted(top_band.values(), key=lambda r: r["mask_digest"])
    max_masks = [r for r in top if r["H8"] == h_max]
    max_tuples = sorted(tuple(t) for r in max_masks for t in r["tuples"])
    assert len(max_tuples) == argmax_count
    assert max_tuples[0] == first_argmax

    projection_groups: dict[str, dict] = {}
    for rec in max_masks:
        pd = rec["live_projection_digest"]
        group = projection_groups.get(pd)
        if group is None:
            group = {
                "live_projection_digest": pd,
                "live_projection_mask_hex": rec["live_projection_mask_hex"],
                "H8": rec["H8"],
                "aggregate_tuple_multiplicity": 0,
                "full_mask_digests": [],
            }
            projection_groups[pd] = group
        group["aggregate_tuple_multiplicity"] += rec["tuple_multiplicity"]
        group["full_mask_digests"].append(rec["mask_digest"])
    for group in projection_groups.values():
        group["full_mask_digests"].sort()

    # Aggregate over full-mask bytes ordered by full-mask digest, matching the
    # explicit canonical order used by this independent package.
    ordered_mask_bytes = b"".join(bytes.fromhex(r["mask_hex"]) for r in max_masks)
    ordered_mask_digest_aggregate = sha256(ordered_mask_bytes)
    ordered_digest_text_aggregate = sha256("".join(r["mask_digest"] for r in max_masks).encode())

    return {
        "tuple_count": count,
        "histogram": {str(i): v for i, v in enumerate(hist) if v},
        "minimum": h_min,
        "maximum": h_max,
        "argmax_count": argmax_count,
        "first_argmax": list(first_argmax) if first_argmax else None,
        "stream_digest": global_stream.hexdigest(),
        "raw": {
            "histogram": {str(i): v for i, v in enumerate(raw_hist) if v},
            "minimum": raw_min,
            "maximum": raw_max,
            "argmax_count": raw_argmax_count,
            "first_argmax": list(raw_first_argmax) if raw_first_argmax else None,
        },
        "t3eq2": {
            "tuple_count": sum(t3_hist),
            "histogram": {str(i): v for i, v in enumerate(t3_hist) if v},
            "minimum": t3_h_min,
            "maximum": t3_h_max,
            "argmax_count": t3_argmax_count,
            "first_argmax": list(t3_first_argmax) if t3_first_argmax else None,
            "stream_digest": t3_stream.hexdigest(),
            "raw": {
                "histogram": {str(i): v for i, v in enumerate(t3_raw_hist) if v},
                "minimum": t3_raw_min,
                "maximum": t3_raw_max,
                "argmax_count": t3_raw_argmax_count,
                "first_argmax": list(t3_raw_first_argmax) if t3_raw_first_argmax else None,
            },
        },
        "top_band_mask_count": len(top),
        "top_band_masks": top,
        "maximizing_mask_count": len(max_masks),
        "maximizing_masks": max_masks,
        "live_projection_count": len(projection_groups),
        "live_projections": sorted(projection_groups.values(), key=lambda r: r["live_projection_digest"]),
        "maximizing_mask_ordered_bytes_sha256": ordered_mask_digest_aggregate,
        "maximizing_mask_ordered_digest_text_sha256": ordered_digest_text_aggregate,
    }


def write_hist(path: Path, histogram: dict[str, int], maximum_index: int = 300) -> None:
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["H8", "count"])
        for i in range(maximum_index + 1):
            w.writerow([i, histogram.get(str(i), 0)])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    started = time.time()

    pairs = build_pairs()
    dead_indices = [i for i, (c, d, _) in enumerate(pairs) if c % 2 == 1 and d % 2 == 0]
    live_indices = [i for i in range(PAIR_COUNT) if i not in set(dead_indices)]
    dead_mask = sum(1 << i for i in dead_indices)
    live_mask = ((1 << PAIR_COUNT) - 1) ^ dead_mask
    assert len(dead_indices) == 107
    assert len(live_indices) == 300
    assert 12 * 9 - 1 == 107

    local_direct = [local_masks_direct(pairs, p) for p in PRIMES]
    local_paircentric = [local_masks_paircentric(pairs, p) for p in PRIMES]
    assert local_direct == local_paircentric

    landscape = enumerate_landscape(local_direct, dead_mask, live_mask)
    baselines = {}
    for name, tup in BASELINES.items():
        full = cover(local_direct, tup)
        baselines[name] = {
            "tuple": list(tup),
            "mask_digest": sha256(canonical_mask_bytes(full)),
            "mask_hex": canonical_mask_bytes(full).hex(),
            "raw_G": full.bit_count(),
            "covered_live": (full & live_mask).bit_count(),
            "covered_dead": (full & dead_mask).bit_count(),
            "live_residual": 300 - (full & live_mask).bit_count(),
        }

    payload = {
        "schema": "samsen-independent-p4-mod8-live-core-v1",
        "constants": {
            "primes": list(PRIMES),
            "moduli": list(MODULI),
            "M4": TUPLE_COUNT,
            "L4": 40 * TUPLE_COUNT,
            "activation_cell": [LOW, HIGH],
            "activation_cell_width_inclusive": HIGH - LOW + 1,
            "pair_count": PAIR_COUNT,
            "mask_bytes": FULL_BYTES,
        },
        "domain": {
            "ordering": "lexicographic c then d",
            "first_pair": list(pairs[0]),
            "last_pair": list(pairs[-1]),
            "excluded_pair": [23, 16, HIGH + 1],
            "duplicate_shift_28_pairs": [[c, d] for c, d, s in pairs if s == 28],
            "pair_list_sha256_json_compact": sha256(json.dumps(pairs, separators=(",", ":")).encode()),
        },
        "partition": {
            "D8_count": len(dead_indices),
            "A8_count": len(live_indices),
            "D8_indices": dead_indices,
            "A8_indices": live_indices,
            "D8_index_digest": index_digest(dead_indices),
            "A8_index_digest": index_digest(live_indices),
            "D8_mask_digest": sha256(canonical_mask_bytes(dead_mask)),
            "A8_mask_digest": sha256(canonical_mask_bytes(live_mask)),
        },
        "landscape": landscape,
        "baselines": baselines,
        "execution": {
            "elapsed_seconds": time.time() - started,
            "python": __import__("sys").version,
        },
    }
    (outdir / "independent_core_result.json").write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    write_hist(outdir / "global_histogram.csv", landscape["histogram"])
    write_hist(outdir / "t3eq2_histogram.csv", landscape["t3eq2"]["histogram"])
    write_hist(outdir / "raw_G_histogram.csv", landscape["raw"]["histogram"], 407)
    write_hist(outdir / "t3eq2_raw_G_histogram.csv", landscape["t3eq2"]["raw"]["histogram"], 407)
    with (outdir / "maximizing_masks.jsonl").open("w") as f:
        for rec in landscape["maximizing_masks"]:
            f.write(json.dumps(rec, sort_keys=True, separators=(",", ":")) + "\n")
    (outdir / "live_projections.json").write_text(json.dumps(landscape["live_projections"], indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "tuple_count": landscape["tuple_count"],
        "H8_min": landscape["minimum"],
        "H8_max": landscape["maximum"],
        "argmax_count": landscape["argmax_count"],
        "first_argmax": landscape["first_argmax"],
        "maximizing_masks": landscape["maximizing_mask_count"],
        "live_projections": landscape["live_projection_count"],
        "raw_min": landscape["raw"]["minimum"],
        "raw_max": landscape["raw"]["maximum"],
        "raw_argmax_count": landscape["raw"]["argmax_count"],
        "t3_raw_argmax_count": landscape["t3eq2"]["raw"]["argmax_count"],
        "ordered_mask_bytes_sha256": landscape["maximizing_mask_ordered_bytes_sha256"],
        "elapsed_seconds": payload["execution"]["elapsed_seconds"],
    }, indent=2))


if __name__ == "__main__":
    main()
