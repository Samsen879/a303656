# Limitations

1. 本审计无法访问 Samsen 的 WSL repository，也不声称检查过该 repository。
2. Git commit identifiers、parentage、tree contents、SOURCE/RESULTS separation、protected before-hashes 与 worktree state 仅依据 bundle evidence 评估。
3. External raw archive 未提供；reported SHA256 与 member contents 未被独立验证。
4. Exact frozen 13 mask file 与 historical source artifacts 缺失。
5. Evaluated-integer registry snapshot 在 arithmetic 上 self-consistent，但其 global historical completeness 未被独立建立；25,345 只在该 snapshot-relative 语义下 exact。
6. 先前网页端 reference package 的三个 byte-level payload hashes 未重算，因为 reference payload bytes/canonical schema 未提供。已比较 mathematical payload、CLI histograms、mask set、multiplicities 与 supplied ordered-mask aggregate。
7. G=231 60-pair set identity 已独立重建，但原始 `winner_count` data 不在 bundle 中。
8. 本审计没有计算任何 `T(n)`，没有 factorization 或 two-square oracle call，也没有 P5/P6 search。
9. Finite modular landscape 不解决 OEIS A303656；全局问题保持 **UNRESOLVED**。
