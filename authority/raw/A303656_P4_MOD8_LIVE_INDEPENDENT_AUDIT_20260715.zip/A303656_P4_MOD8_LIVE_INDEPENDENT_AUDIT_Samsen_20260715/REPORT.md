# OEIS A303656 — Exact P4 Mod-8-Live Coverage Landscape 独立审计报告

**审计用户名：** Samsen  
**定位：** MATHEMATICAL RESEARCH SUPERVISOR · INDEPENDENT COMPUTATIONAL RESEARCHER · ADVERSARIAL PROOF REFEREE  
**总体 verdict：** **REJECT / FIX REQUIRED**  
**A303656 全局状态：** **UNRESOLVED**

> Core exact modular landscape 通过独立完整复算；但 promotion 被否决。Bundle 的 promotion 逻辑把“not previously designed”替代为严格的 class freshness，而 bundle 自带 historical evaluated-integer registry 中一个长度为 1,600,000,000 的已评价连续区间已经覆盖全部 residue classes modulo \(L_4\)。

## 1. 分层 verdict

| 层级 | Verdict | 结论分类 |
|---|---|---|
| Core \(H_8\) landscape、histogram、argmax、mask set | **ACCEPT** | **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION** |
| Freshness 与 panel feasibility | **REJECT / FIX REQUIRED** | strict class/mask freshness claims 为 false；absolute integer freshness **NOT ESTABLISHED** |
| Overall promotion | **REJECT / FIX REQUIRED** | 不允许冻结 panel；不允许运行新 \(T\) |

本审计没有评价任何新 integer 的 \(T(n)\)，没有调用 factorization、direct two-square oracle，也没有启动 P5/P6 search。Finite modular computation 不构成 A303656 的一般性 proof。

## 2. Bundle completeness 与 integrity

Source bundle：`A303656_P4_MOD8_LIVE_AUDIT_BUNDLE_6efcf58.tar.zst`。

* archive SHA256：`60664f3ce1e9f7c7326b3387fd559aeee0da215c1ee2f76b87d2c42a0ede6a3a`；size 931,449 bytes；
* 安全解包检查未发现 path traversal、symlink、device 或其他特殊文件；
* bundle 内共 13 个 directories、39 个 regular files；
* `SHA256SUMS` 含 38 个 entries，覆盖除 manifest 自身以外的全部 regular files；38/38 hashes 全部匹配；
* 没有 duplicate/conflicting manifest；存在两个预期的 duplicate-content 情形：空 stderr logs，以及 corruption JSON 与其 stdout copy；
* core Enumerator A/B 可脱离 repository 运行，并已 byte-identical replay；
* full builder、repository verifier、完整 corruption replay 不能脱离原 repository 独立执行，因为其依赖 Git objects 与多项未打包 authorities；
* external raw archive 未打包，仅有 path/hash/size/member metadata。因此 reported SHA256 `3b3110a7...` 的 archive bytes 未被本审计验证；
* `results/metadata.json` 的 `results_commit` 仍是 `RESULT_COMMIT_CONTAINING_THIS_FILE` placeholder，构成 stale metadata；
* core 数学 report/result 未发现数值冲突，但 provenance report 不能替代缺失的 Git trees/diffs/objects。

全部 inventory 与逐文件 hash 结果见 `bundle_inventory.csv`、`bundle_sha256_verification.json`。

## 3. Core scientific payload 三方比较

| Quantity | 本轮独立重算 | Bundle/CLI | 冻结网页端 reference | 结果 |
|---|---:|---:|---:|---|
| tuple count | 28,227,969 | 28,227,969 | 28,227,969 | MATCH |
| \(|D_8|\) | 107 | 107 | 107 | MATCH |
| \(|A_8|\) | 300 | 300 | 300 | MATCH |
| global \(H_8\) min / max | 32 / 201 | 32 / 201 | 32 / 201 | MATCH |
| global argmax tuples | 468 | 468 | 468 | MATCH |
| lex-first argmax | (2,13,50,5) | (2,13,50,5) | (2,13,50,5) | MATCH |
| distinct maximizing full masks | 21 | 21 | 21 | MATCH |
| distinct live projections | 5 | 5 | 5 | MATCH |
| \(t_3=2\) max / argmax | 201 / 468 | 201 / 468 | 201 / 468 | MATCH |
| raw \(G\) min / max / argmax | 57 / 231 / 156 | certificates 中一致 | 57 / 231 / 156 | MATCH |
| \(t_3=2\) raw-\(G\) argmax | 84 | certificates 中一致 | 84 | MATCH |
| ordered maximizing-mask aggregate SHA256 | `3d6fb47a...bce3` | 可由 mask set 重建 | `3d6fb47a...bce3` | MATCH |

完整 global histogram 与 bundle **逐 bin 相等**，总和为 28,227,969，support 是连续的 \(32,33,\ldots,201\)。完整 \(t_3=2\) histogram 也逐 bin 相等。所有 468 个 global maximizers 均满足 \(t_3=2\)。

本轮 standalone Python 与 standalone C++ 均完整枚举 28,227,969 tuples，并在以下对象上完全一致：global/\(t_3=2\) \(H_8\) histograms、global/\(t_3=2\) raw-\(G\) histograms、extrema、21 个 51-byte maximizing masks、mask multiplicities 与 lex-first tuple。Bundle Enumerator A/B 也在 bundle 外重放为 byte-identical certificates。

四个 baseline 精确重建：

| Baseline | raw \(G\) | live covered | dead covered | live residual |
|---|---:|---:|---:|---:|
| CAL-216 | 216 | 189 | 27 | 111 |
| CAL-227 | 227 | 199 | 28 | 101 |
| CAL-230 | 230 | 183 | 47 | 117 |
| G231-COMMON | 231 | 184 | 47 | 116 |

G231 mask complement 有 176 个 pair identities，其与 \(D_8\) 的 intersection 精确为 bundle 报告的 60 个 indices。原始 `pair_frequencies.csv` 缺失，因此 `winner_count=0` 的数据 provenance 不能 replay；60-pair set identity 本身已独立重建。

详细比较见 `core_cross_comparison.json`、两份 recomputed histograms 与 execution logs。

## 4. Maximizing-mask cross-audit

Digest convention 已独立核对：pair \(i\) 对应 bit \(i\)；407 bits；exactly 51 bytes；little-endian integer packing；SHA256 over those 51 bytes。

* 21 个 distinct full masks；
* 5 个 distinct live projections；
* tuple multiplicity 总和为 468；
* 5 个 projection 的 aggregate tuple multiplicities 为 102、102、102、60、102；
* 5 个 projection 对应的 full-mask group sizes 为 5、4、4、3、5；
* 未发现 mask deduplication、tuple-order、bit-order 或 multiplicity bug；
* reference aggregate 的具体 convention 已反向核实：将 21 个 full-mask SHA256 hex strings lexicographically sort，以 newline 连接并保留 trailing newline，再 SHA256；结果为 `3d6fb47adb745d5501a53f2dcfddbc1106e8f67cfa85ea0d1ce61d487102bce3`。

逐 mask 的 full/live bits、raw \(G\)、dead count、\(H_8\)、multiplicity、lex-first tuple、digests 与 activation/freshness fields 见 `maximizing_masks_crosswalk.jsonl`；projection grouping 见 `live_projection_crosswalk.json`。

## 5. Freshness：关键否证

| Claim / quantity | CLI framing | 本轮独立审计 | Verdict |
|---|---|---|---|
| new vs frozen 13 full masks | 21/21 | frozen 13 exact bytes 未打包；仅 bundle-supported | **NOT ESTABLISHED independently** |
| new vs bundled 320 designed classes | 21/21 full masks；5/5 projections | 独立重建，intersection 为 0 | **PASS as design novelty** |
| strict historically new full masks | claimed 21 | 0/21 | **FAIL** |
| strict fresh CRT classes | claimed 468 | 0/468 | **FAIL** |
| descriptions / classes | 468 | 468 unique tuples/classes | MATCH |
| class-integer incidences | 未清晰区分 | 26,018 | CLARIFIED |
| distinct activation integers | 未清晰区分 | 26,018 | CLARIFIED |
| registered/evaluated integers | 673 | 673 distinct | MATCH relative snapshot |
| fresh integers | 25,345 | 25,345 distinct and incidences | MATCH **relative snapshot only** |
| integer collisions | none | histogram `{1: 26018}` | PASS |

### 5.1 Strict class freshness 为什么为 0

Bundle 自带 registry 包含 closed interval

\[
[240000000001,\,241600000000],
\]

其 inclusive length 为 1,600,000,000，而

\[
L_4=1,129,118,760.
\]

任意长度至少为 \(L_4\) 的连续整数 interval 都包含每个 residue class modulo \(L_4\) 至少一次。因此，该历史 interval 已经代表全部 fixed-P4 CRT classes。对 468 个 maximizing classes 的直接重建进一步给出：263 个 class 含 1 个 prior evaluated member，205 个 class 含 2 个，总计 673 个 prior evaluated integers。

所以：

* strict fresh CRT classes = **0/468**；
* strict historically new maximizing full masks = **0/21**；
* strict historically new maximizing live projections = **0/5**。

CLI 的 `previously_designed_class` 仅表示 tuple 不在 bundled 320-class design ledger 中。468/468 的确都是 not previously designed，但这是 **design novelty**，不是 user-frozen definition 下的 class-level freshness。

### 5.2 25,345 的准确含义

Activation cell 内：

* descriptions/classes = 468；
* class-integer incidences = 26,018；
* distinct integers = 26,018；
* registry 中已评价的 incidences/distinct integers = 673；
* registry snapshot-relative fresh incidences/distinct integers = 25,345；
* collision count = 0。

因此 25,345 在 bundled registry snapshot 的相对意义下是 exact finite computation；它既不是 class count，也不是 description count。由于 historical source components、P5 Family R/U/Q 的完整覆盖、abandoned/partial runs 与完整 provenance 未打包，25,345 作为 **absolute all-history freshness** 为 **NOT ESTABLISHED**。它只能安全表述为 bundled snapshot-relative count，并且在缺失历史来源可能补入更多 evaluated integers 时，是 absolute fresh count 的 upper bound。

完整结果见 `freshness_audit.json` 与 `historical_ledger_coverage.md`。

## 6. Activation-cell arithmetic 与 collision audit

Activation cell 是 closed interval

\[
[3^{22}+5^{16},\,3^{23}+5^{16}-1]
=[183968950234,\,246731069451],
\]

inclusive width 为 62,762,119,218。

468 个 CRT representatives 全部 normalized 到 \([0,L_4)\)，且彼此 distinct。每个 class 在 cell 内有 55 或 56 个 integers：190 classes 有 55 个，278 classes 有 56 个。

* total descriptions = 468；
* class-integer incidences = 26,018；
* distinct integers = 26,018；
* integer collision multiplicity histogram = `{1: 26018}`；
* distinct snapshot-relative fresh integers = 25,345；
* fresh collision multiplicity histogram = `{1: 25345}`；
* generated integer range = `[183969370514, 246730056194]`；
* snapshot-relative fresh range = `[183969370514, 246729501794]`。

未发现 off-by-one、negative quotient、CRT representative normalization、class collision 或 integer collision bug。Boundary convention、per-mask/per-projection counts 与 quotient histograms 见 `activation_cell_reconstruction.json`、`collision_report.json`。

## 7. Promotion gate 逐项审计

| Gate | Frozen condition | Status | 严格证据 |
|---:|---|---|---|
| 1 | \(H_{8,\max}\ge 200\) | **PASS** | 独立完整枚举得到 \(H_{8,\max}=201\) |
| 2 | 至少一个 maximizing mask 是 new | **FAIL** | historical interval 覆盖全部 \(L_4\) classes；21 个 masks 均已被历史 evaluated integers 实现 |
| 3 | 至少 4 个 fresh classes | **FAIL** | strict fresh classes = 0；468 个均有 1 或 2 个历史 evaluated members |
| 4 | fresh classes 分布于至少 2 个 new masks | **FAIL** | strict fresh classes = 0，strict-new masks = 0 |
| 5 | 每个 selected mask 至少 2 个 fresh classes | **FAIL** | 每个 mask 的 strict fresh-class count 均为 0 |
| 6 | 不看新 \(T\) 即可构造 balanced panel | **FAIL** | integer-fresh/T-blind panel 在算术上可构造，但 frozen gate 要求的 new class/mask/projection hierarchy 不存在，且 bundle 未提供 immutable projection-aware manifest |

Frozen promotion gate 的 overall status 为 **FAIL**。CLI 只有在替换语义后才会 PASS：`new mask = not in frozen 13`，`fresh class = not in 320 designed tuples`。这不是本轮冻结的严格 freshness definition。

## 8. Balanced prospective panel feasibility

Bundle 的 proposed design 主要在 mask level 检查：

* “best two masks” 虽偶然跨两个 live projections，但每个 projection 只有一个 mask，不能防止 pseudo-replication；
* “all 21 masks” 跨五个 projections，但未 equalize projection weights，也未冻结 integer selection rule；
* 没有 immutable panel manifest；
* selection 未使用新 \(T\)，但 `fresh_class_count` 实为 design novelty，不是 strict class freshness。

因此当前不得冻结任何 panel。

作为与 frozen gate 分离的 scientific-design 问题，推荐在 ledger/gate 修复后采用 raw-\(G\)-matched top-band controlled design，而不是只做 \(H_8=201\) census。对 fixed `raw G=227, t3=2` 的 exact availability：

| \(H_8\) | full masks | live projections | classes | eligible projections（每个至少 2 masks，且每 mask 至少 4 classes） |
|---:|---:|---:|---:|---:|
| 199 | 42 | 32 | 1,128 | 4 |
| 200 | 27 | 19 | 672 | 3 |
| 201 | 8 | 3 | 126 | 2 |

一个可预注册但**尚未授权**的 blueprint 是：每 band 2 projections、每 projection 2 masks、每 mask 4 classes、每 class 8 integers，共 \(3\times2\times2\times4\times8=384\) 个 distinct integers；通过 digest、lexicographic tuple 与固定 member indices 选择，完全 T-blind。见 `balanced_panel_feasibility.md`、`top_band_design_blueprint.json`。

## 9. Implementation independence

Bundle Enumerator A/B 在 pair-domain construction、local mask generation 与 live/dead representation 上有实质差异，且不 import 同一 core module；但二者共享 Python runtime、tuple order、bit packing、stream format、score accumulation pattern、digest convention、dedup pattern 与 output schema。因此应称为：

> **two execution paths with partial implementation independence**

不应称为 fully independent implementations。

本轮另加入不读取 bundle core code 的 standalone Python 与 seven-`uint64_t`-word C++ implementations，两者均完整枚举并 exact agree；再结合此前网页端 standalone reference，core landscape 的 overall independence level 为 strong multi-codebase/multi-language reproducibility。该结论不修复 historical-ledger semantics。

## 10. Corruption tests

Bundle reports 25/25 mutations 得到 nonzero exit（均为 rc=1）。Static source review 显示其中多项确实针对 pair order、duplicate shift、parity definition、mask length/digest 等；但 harness 丢弃每个 case 的 stdout/stderr，所以 unrelated verifier failure 也会被计为“拒绝”。部分 tests 首先触发 A/B mismatch 或 whole-file hash mismatch，并没有专门验证其名称所宣称的 semantic condition。

不足覆盖包括：matched A/B histogram-bin corruption、same-length mask-bit flip、multiplicity mutation、live-projection regrouping、class/integer collision injection、promotion-gate mutation、完整 ledger source omission，以及 `not previously designed` 与 strict freshness 的 semantic distinction。Backend invocation tests 修改 self-reported counters，不是 runtime instrumentation。

因此可认证：**bundle evidence supports 25 mutations produced nonzero exit**；不能认证“25 tests 已全面覆盖全部 required semantic corruptions”。见 `corruption_test_audit.md`。

## 11. Fresh replay 与 provenance

本审计不能访问 Samsen 的 WSL repository，因此只使用如下措辞：

* **bundle evidence supports** initial `f452f2db...`、SOURCE U `ee5bef63...`、RESULTS V `6efcf58e...` 的 internally consistent identifiers 与 parent metadata；
* **bundle evidence does not support** 对这三个 Git objects、trees 或 patches 的 cryptographic verification，因为 Git objects/minimal Git bundle 未提供；
* **bundle evidence does not support** “RESULTS V only adds results/report”，因为没有 U→V patch/tree listing；
* **bundle evidence supports** fresh-replay manifest 中 8 个 core artifact hashes 与 bundle 内 committed copies byte-identical；但没有 fresh exported U checkout、command transcript 或 replay logs，故不能独立认证 replay provenance；
* **bundle evidence supports** tracked-clean 的自报 fields；但没有认证原始 `git status` 输出，而且 command 使用 `--untracked-files=no`，不能排除 untracked generated inputs；
* **bundle evidence supports** protected after-hashes；**does not support** 全部 protected files 的完整 before/after evidence；
* **bundle evidence supports** included enumerator source 不读取 precomputed result，并且 A/B 在本审计中 byte-identical replay；
* **bundle evidence supports** included code path 未调用 \(T\)、factorization、direct oracle 或 P5/P6 search；自报 counters 不是 independent runtime instrumentation。

详见 `provenance_audit.md`。

## 12. 必须修复的事项

1. 冻结并区分 `design-novel class`、`strict class-fresh`、`integer-fresh`、`mask-new`、`projection-new`；不得把 design novelty 当作 freshness。
2. 提供 complete historical evaluated-class/mask/projection ledger，或正式修改 promotion gate 语义。按当前严格定义，在 1.6B historical interval 之后不存在 fresh \(L_4\) class。
3. 提供 exact frozen-13 mask bytes/digests，以及 complete evaluated-integer registry provenance，明确覆盖 P5 R/U/Q、partial/interrupted runs 与 direct-verification intervals。
4. 提供 minimal Git objects/bundle 或 U/V patches/tree listings，验证 SOURCE/RESULTS separation；提供 raw archive bytes 与 fresh replay transcript。
5. 修复 stale `results_commit` placeholder。
6. 只有前述语义和 provenance 修复后，才可生成、hash 并冻结 projection-aware immutable panel manifest；在此之前不得调用新 \(T\)。

## 13. 最终授权

* **Core exact landscape verdict：ACCEPT。**
* **Freshness and feasibility verdict：REJECT / FIX REQUIRED。**
* **Overall promotion verdict：REJECT / FIX REQUIRED。**
* **现在允许冻结 prospective panel：NO。**
* **现在允许运行 prospective \(T\) census：NO。**
* **Repository integration / P5/P6 search：本轮未执行，也未授权。**
* **A303656 全局问题：UNRESOLVED。**
