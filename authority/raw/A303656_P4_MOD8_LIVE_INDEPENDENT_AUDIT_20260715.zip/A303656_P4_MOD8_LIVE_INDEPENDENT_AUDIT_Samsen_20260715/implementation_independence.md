# Implementation independence 审计

## Bundle Enumerator A 与 Enumerator B

| Component | A | B | Independence assessment |
|---|---|---|---|
| pair-domain construction | threshold enumeration | closed 24×17 rectangle minus `(23,16)` | meaningful difference |
| local coverage masks | residue-centric scan over all pairs | pair-centric generation of `p-1` residues | meaningful difference |
| live/dead handling | full 407-bit mask intersected with A8 | separate 300-bit live 与 107-bit dead masks，再 scatter | meaningful difference |
| language/runtime | Python `int` bitsets | Python `int` bitsets | shared stack |
| tuple loop order | identical nested lexicographic order | identical nested lexicographic order | shared |
| score accumulation | `bit_count`, `Counter` | `bit_count`, `Counter` | shared pattern |
| stream serialization | identical `<5H` records 与 SHA256 | identical `<5H` records 与 SHA256 | shared；correlated risk |
| mask packing/digest | identical 51-byte little-endian SHA256 | identical 51-byte little-endian SHA256 | shared；correlated risk |
| top-band deduplication | SHA256-keyed dictionary | SHA256-keyed dictionary | shared pattern |
| expected constants/output schema | same values and fields | same values and fields | shared |
| imported core module | none | none | 无 literal shared source module |

**对 A/B pair 的 verdict：** 它们是 two separate execution paths，在 domain/local-mask/live-mask construction 上有 partial independence；但共享 language、tuple order、score/serialization convention、bit packing 与相近 control flow，不能称为 fully independent implementations。

## 加入本轮审计后的 overall independence

本 audit package 增加：

1. 一个不 import bundle code 的 standalone Python implementation，并在内部 cross-check 两种 local-mask construction；
2. 一个以 seven 64-bit words 表示每个 mask 的 standalone C++ implementation；
3. Python/C++ 完整处理 28,227,969 tuples，并在 global/t3 histograms、raw histograms、extrema、tuple multiplicities 与全部 21 个 maximizing mask bytes 上 exact agree；
4. bundle 的两个 enumerator certificates 在 bundle 外 byte-identical replay。

再结合此前冻结的网页端 standalone reference computation，core exact landscape 达到 strong multi-codebase、multi-language reproducibility。该 independence 结论不修复 historical-ledger semantics。
