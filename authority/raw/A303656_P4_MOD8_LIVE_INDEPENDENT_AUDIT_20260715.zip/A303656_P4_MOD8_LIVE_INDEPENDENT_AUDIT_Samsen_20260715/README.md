# A303656 P4 Mod-8-Live Independent Audit Package

**Auditor:** Samsen  
**Date:** 2026-07-15  
**Overall verdict:** `REJECT / FIX REQUIRED`  
**Global A303656 status:** `UNRESOLVED`

从 `REPORT.md` 开始阅读。机器可读 verdict 在 `AUDIT_VERDICT.json`。

核心导航：

* `core_cross_comparison.json`：本轮 independent Python/C++、bundle/CLI 与冻结网页端 reference 的 core cross-comparison；
* `global_histogram_recomputed.csv`、`t3eq2_histogram_recomputed.csv`：完整 independently recomputed histograms；
* `maximizing_masks_crosswalk.jsonl`、`live_projection_crosswalk.json`：21 full masks 与 5 live projections 的逐项审计；
* `freshness_audit.json`、`historical_ledger_coverage.md`：strict freshness 否证与 historical coverage；
* `activation_cell_reconstruction.json`、`collision_report.json`：activation-cell arithmetic 与 collision audit；
* `promotion_gate_audit.json`、`balanced_panel_feasibility.md`：逐项 gate 与 prospective design；
* `source/`：本轮 standalone Python/C++ verifiers 与 freshness helper；
* `logs/`：independent outputs、bundle Enumerator A/B byte-identical replay 与 unit-test logs；
* `SHA256SUMS.txt`：audit package 内全部其他 files 的 SHA256 manifest。

验证 package integrity：

```bash
sha256sum -c SHA256SUMS.txt
```

本 package 未执行任何新 `T(n)` evaluation、factorization、direct two-square oracle 或 P5/P6 search。
