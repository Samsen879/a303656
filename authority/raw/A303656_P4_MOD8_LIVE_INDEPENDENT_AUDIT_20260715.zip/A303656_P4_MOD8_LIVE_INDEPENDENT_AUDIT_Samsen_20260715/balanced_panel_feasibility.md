# Balanced prospective panel feasibility

## 对 bundle proposal 的审计

Maximizing universe 有 5 个 live projections、21 个 full masks、468 个 classes，以及 25,345 个 bundled-registry-snapshot-relative fresh integers。Projection aggregate tuple multiplicities 为 `102, 102, 102, 60, 102`；每个 projection 对应 3–5 个 full masks。未发现 class 或 integer collision。

Bundle 的 feasibility calculation 主要停留在 mask level：

* “best two masks” 选择两个各含 84 classes 的 masks，虽偶然跨两个 live projections，但每个 selected projection 只有 **一个 mask**；
* “all 21 masks” 在 bundle 的 not-previously-designed 语义下，每 mask 至少有 4 classes，并跨全部 5 projections；但没有 balance projection weights，也没有冻结 integer-selection rule；
* 未提供 immutable panel manifest；
* 计算没有调用新 `T`，但其 `fresh_class_count` 实为 design novelty，不是 strict class freshness。

因此 proposed design 不满足严格 freshness 下的层级：

`live projection → full mask → CRT class → integer`。

## H8=201-only 与 top-band controlled design

只做 `H8=201` census 无法检验 corrected `H8` 是否比 raw `G` 更能预测 integer-level `T`；它没有 score control band，而且仅有五个 projections，容易产生 pseudo-replication。更合理的 prospective design 是 raw-G-matched top-band comparison。

对 matched stratum `raw G = 227`, `t3 = 2` 的 exact availability：

| H8 | masks | live projections | classes | projections with ≥2 masks and ≥4 classes/mask |
|---:|---:|---:|---:|---:|
| 199 | 42 | 32 | 1,128 | 4 |
| 200 | 27 | 19 | 672 | 3 |
| 201 | 8 | 3 | 126 | 2 |

Ledger/gate 修复后，一个可 defensibly pre-register 的 rule 是：

1. 使用 `H8 ∈ {199,200,201}`，固定 `raw G=227` 与 `t3=2`；
2. 每个 H8 band 按 projection digest 选择 2 个 eligible live projections；
3. 每个 projection 按 full-mask digest 选择 2 个 full masks；
4. 每个 mask 按 lexicographic tuple 选择 4 个 classes；
5. 每个 class 在 ascending fresh-member list 中取固定 indices `[0,7,14,21,28,35,42,49]` 的 8 个 integers；
6. 总计 `3×2×2×4×8 = 384` 个 distinct integers；
7. 在任何新 `T` call 前冻结 registry hash、code hash、全部 exclusions 与 final manifest。

该 rule 是 T-blind 且 raw-G-controlled。但它只是 **DRAFT FEASIBILITY BLUEPRINT**，不是 authorized frozen panel；当前 strict promotion gate 失败，historical registry completeness 也未独立建立。
