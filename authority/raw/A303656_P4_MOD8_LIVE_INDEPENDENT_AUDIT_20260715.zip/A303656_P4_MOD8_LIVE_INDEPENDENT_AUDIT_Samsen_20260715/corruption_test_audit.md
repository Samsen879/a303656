# Corruption-test 审计

Bundle reports 25/25 nonzero exits，全部 return code 为 1。Harness 丢弃 per-case stdout/stderr，因此不能证明每次 rejection 的具体 reason；任何 unrelated verifier failure 都可能被计为 successful corruption test。由于 Git objects 与 protected authority files 未打包，完整 independent replay 不可行。

| Test | Reported RC | Source review 中最先触发的 verifier mechanism | Assessment |
|---|---:|---|---|
| `initial_HEAD_mismatch` | 1 | Git ancestry argument | targeted |
| `n_mod40_mutation` | 1 | exact `auth.scope` equality | targeted |
| `historical_panel_scope_expansion` | 1 | exact `auth.scope` equality | targeted |
| `flipped_c_parity` | 1 | partition definition equality | targeted |
| `flipped_d_parity` | 1 | partition definition equality | targeted |
| `omitted_excluded_boundary_pair` | 1 | domain excluded-pair check | targeted |
| `D8_count_corruption` | 1 | three D8 count checks | targeted |
| `A8_count_corruption` | 1 | A8 index length check | targeted |
| `duplicate_shift_pair_merger` | 1 | duplicate-pair list equality | targeted |
| `pair_bit_order_mutation` | 1 | index digest equality | targeted |
| `baseline_mask_mutation` | 1 | hard-coded baseline digest | targeted |
| `baseline_H8_expected_corruption` | 1 | hard-coded baseline H8 | targeted |
| `tuple_omission` | 1 | A/B certificate disagreement 先于 tuple-count check | non-specific |
| `tuple_duplication` | 1 | A/B certificate disagreement 先于 tuple-count check | non-specific |
| `H8_stream_corruption` | 1 | A/B certificate disagreement | non-specific |
| `maximizing_mask_omission` | 1 | A/B certificate disagreement | non-specific |
| `freshness_registry_interval_deletion` | 1 | whole-file SHA256 mismatch | integrity-only |
| `prior_sparse_point_deletion` | 1 | whole-file SHA256 mismatch | integrity-only |
| `class_integer_freshness_conflation` | 1 | CSV whole-file SHA256 mismatch | 名称误导；只检测 bytes，不检测 semantic conflation |
| `empirical_weight_injection` | 1 | scope-guard constant equality | self-report guard |
| `accidental_T_backend_invocation` | 1 | scope-guard constant equality | self-report guard |
| `accidental_direct_oracle_invocation` | 1 | scope-guard constant equality | self-report guard |
| `accidental_factorization_invocation` | 1 | scope-guard constant equality | self-report guard |
| `truncated_mask_bytes` | 1 | 51-byte length/digest check | targeted |
| `extra_mask_bytes` | 1 | 51-byte length/digest check | targeted |

## 未充分覆盖的 required corruption classes

* matched A/B pair 或 result artifact 中的 direct histogram-bin mutation；
* same-length top-band mask-bit flip；
* maximizing-mask multiplicity mutation；
* live-projection grouping mutation；
* class 或 integer collision injection；
* promotion-gate boolean/threshold mutation；
* omission of an entire historical ledger source；
* 区分 `not previously designed` 与 strict class freshness 的 semantic test；
* backend “invocation” tests 修改 self-reported counters，而非 instrument process calls。

**Verdict：** bundle evidence supports “25 mutations produced nonzero exit”。它不支持“所有 required semantic corruption classes 均被独立且 specifically tested”。
