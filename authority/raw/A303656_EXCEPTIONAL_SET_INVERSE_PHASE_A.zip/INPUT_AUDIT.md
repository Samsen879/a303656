# Input Audit

## 1. Uploaded artifacts

| Input | SHA256 | Integrity result |
|---|---|---|
| `A303656_GLOBAL_ROUTE_RESET(6).zip` | `b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13` | ZIP test PASS; internal `SHA256SUMS.txt` PASS |
| `A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(3).zip` | `aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2` | ZIP test PASS; frozen verifier PASS; nested archives PASS; two fresh replays PASS |
| `A303656_DESCENT_FINITE_REDUCTION_PHASE_A(2)(1)(3).zip` | `bebf5f5735fb476bb8d1859f297203715e07bc4de94f56bbf880f6763936205d` | ZIP test PASS; package validator PASS; internal `SHA256SUMS.txt` PASS |
| `分工规则.txt` | `94261338e1d2e0a348ff264e9a98322b647918eeca74b0932dcd90bac980b5f6` | byte hash recorded |
| `项目简介.txt` | `42903e1adb5731d195786538a1072aa5b54a5c2adbf7fe6b963226fa74a139ae` | byte hash recorded |

Full command output is frozen in `results/input_validation_summary.txt`.

## 2. Positive-density frozen core

- required files: PASS；
- scientific core file count: 40；
- canonical core hash:
  `8f7708954cb3e89f159bb01173b4160e1423bb7c7fc96d528b45a558a5de2220`；
- two independent generated replays: byte-identical across 42 compared paths；
- symbolic identity: \(\kappa K=1/4\), hence \(\kappa=1/(4K)\)；printed \(K/2\) alternative rejected。

一次早期 operator invocation 只调用 replay comparator 而未先生成 two replay directories；这产生 expected missing-file error。按 bundle `REPRODUCIBILITY.md` 的三步命令生成 directories 后，replay PASS。该事件不是 artifact defect，且未改变任何输入 bytes。

## 3. Adopted mathematical authority

本轮只继承以下 authority：

1. direct positive-density theorem，结论停在 \(|E_X|\le(1-c)X\)；
2. distinct shift count与 finite collision control；
3. Sidon-scale additive energy of \(B_X\)；
4. prior descent audit 中 fixed-modulus、private-witness 与 finite-reduction no-go boundaries；
5. global reset 的状态：A303656 unresolved，禁止把 almost-all/density 写成 universal theorem。

本轮没有把 prior second-moment proof 作为新贡献重跑，也没有改变 frozen conclusions。

## 4. New external source cache

8 个 primary PDFs 的 filename、bytes 与 SHA256 见 `SOURCE_PDF_HASHES.tsv`。PDF bytes 不嵌入本 ZIP；只保存 source lock，以避免不必要复制并保持 package 小型可审计。

## 5. Computation boundary

唯一新 computation 是 finite-group residue support check：

- \(2\le q\le500\)；
- selected \(q=441,1089,5929\)；
- no \(T(n)\) interval enumeration；
- no counterexample search；
- no large-scale computation。

script SHA256：
`6f45d0fb774bd88b1041b819c697d8366174390d86c9ce1ff06faea1b5fddc91`。

result SHA256：
`71c0bc6fb7510166709737f5d8bed40065ce791a345a3841b8a11d85f0efbdb5`。
