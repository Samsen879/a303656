#!/usr/bin/env python3
"""Deterministic finite-group falsification checks for Phase A.

This script does NOT enumerate A303656 values T(n) on an interval.  It only
computes residue supports in finite cyclic groups in order to test proposed
small-modulus lemmas.
"""
from __future__ import annotations

import argparse
import json
from hashlib import sha256
from pathlib import Path
from typing import Iterable


def power_orbit(base: int, modulus: int) -> list[int]:
    """Return all residues base**e (mod modulus), e >= 0, in first-visit order."""
    seen: set[int] = set()
    out: list[int] = []
    x = 1 % modulus
    while x not in seen:
        seen.add(x)
        out.append(x)
        x = (x * base) % modulus
    return out


def sumset_mod(a: Iterable[int], b: Iterable[int], modulus: int) -> set[int]:
    aa = tuple(a)
    bb = tuple(b)
    return {(x + y) % modulus for x in aa for y in bb}


def s2_residues(modulus: int) -> set[int]:
    squares = {x * x % modulus for x in range(modulus)}
    return sumset_mod(squares, squares, modulus)


def b_infty_residues(modulus: int) -> tuple[set[int], list[int], list[int]]:
    p3 = power_orbit(3, modulus)
    p5 = power_orbit(5, modulus)
    return sumset_mod(p3, p5, modulus), p3, p5


def exceptional_residues(modulus: int, shifts: Iterable[int]) -> list[int]:
    s2 = s2_residues(modulus)
    shifts_tuple = tuple(shifts)
    return [
        n
        for n in range(modulus)
        if all((n - b) % modulus not in s2 for b in shifts_tuple)
    ]


def build_payload(max_q: int = 500) -> dict[str, object]:
    failed_full_cover: list[dict[str, int]] = []
    summaries: list[dict[str, int | bool]] = []
    for q in range(2, max_q + 1):
        s2 = s2_residues(q)
        b, p3, p5 = b_infty_residues(q)
        cover = sumset_mod(s2, b, q)
        ok = len(cover) == q
        summaries.append(
            {
                "q": q,
                "s2_residue_count": len(s2),
                "pow3_orbit_count": len(p3),
                "pow5_orbit_count": len(p5),
                "b_infty_residue_count": len(b),
                "s2_plus_b_cover_count": len(cover),
                "full_cover": ok,
            }
        )
        if not ok:
            failed_full_cover.append({"q": q, "missing_count": q - len(cover)})

    selected: list[dict[str, object]] = []
    notes = {441: "3^2*7^2", 1089: "3^2*11^2", 5929: "7^2*11^2"}
    for q in (441, 1089, 5929):
        s2 = s2_residues(q)
        b, p3, p5 = b_infty_residues(q)
        cover = sumset_mod(s2, b, q)
        e24 = exceptional_residues(q, (2, 4))
        selected.append(
            {
                "q": q,
                "factor_note": notes[q],
                "s2_residue_count": len(s2),
                "pow3_orbit_count": len(p3),
                "pow5_orbit_count": len(p5),
                "b_infty_residue_count": len(b),
                "s2_plus_b_cover_count": len(cover),
                "s2_plus_b_full_cover": len(cover) == q,
                "exceptional_count_for_shifts_2_4": len(e24),
                "exceptional_residues_for_shifts_2_4": e24,
            }
        )

    return {
        "schema_version": 1,
        "purpose": "finite-group falsification only; no T(n) interval search",
        "definitions": {
            "S2_mod_q": "{x^2+y^2 mod q: x,y in Z/qZ}",
            "B_infty_mod_q": "{3^c+5^d mod q: c,d>=0}",
            "coverage": "S2_mod_q + B_infty_mod_q",
            "small_shift_exception": (
                "{n mod q: n-2 and n-4 are both outside S2_mod_q}"
            ),
        },
        "range_test": {
            "q_min": 2,
            "q_max": max_q,
            "all_full_cover": not failed_full_cover,
            "failed_full_cover": failed_full_cover,
            "per_modulus": summaries,
        },
        "selected_moduli": selected,
        "interpretation_guard": [
            "This finite computation refutes only a proposed small-modulus forbidden-residue trigger on the tested domain.",
            "It is not a proof for all moduli and is not a search for A303656 exceptions T(n)=0.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "results" / "finite_group_checks.json",
    )
    parser.add_argument("--max-q", type=int, default=500)
    args = parser.parse_args()
    if args.max_q < 2 or args.max_q > 500:
        raise SystemExit("--max-q must be in [2,500] for the frozen Phase A replay")
    payload = build_payload(args.max_q)
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text, encoding="utf-8", newline="\n")
    print(f"output={args.output}")
    print(f"sha256={sha256(text.encode('utf-8')).hexdigest()}")
    print(f"all_full_cover={payload['range_test']['all_full_cover']}")
    for row in payload["selected_moduli"]:
        print(
            f"q={row['q']} full={row['s2_plus_b_full_cover']} "
            f"small_shift_exceptions={row['exceptional_count_for_shifts_2_4']}"
        )


if __name__ == "__main__":
    main()
