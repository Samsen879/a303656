#!/usr/bin/env python3
"""Offline validator for A303656 exceptional-set inverse Phase A."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

REQUIRED = {
    'README.md',
    'EXECUTIVE_VERDICT.md',
    'EXCEPTIONAL_SET_FORMALISM.md',
    'FOURIER_AND_SPECTRAL_ANALYSIS.md',
    'INVERSE_THEOREM_CANDIDATES.md',
    'DENSITY_INCREMENT_CANDIDATES.md',
    'DIFFERENCE_SET_CROSSWALK.md',
    'EFFECTIVITY_AND_DESCENT_GAP.md',
    'LITERATURE_AUDIT.md',
    'NO_GO_RESULTS.md',
    'REPORT.md',
    'PROMOTION_VERDICT.json',
    'INPUT_AUDIT.md',
    'LIMITATIONS.md',
    'REPRODUCIBILITY.md',
    'ENVIRONMENT_RECORD.json',
    'WEB_SOURCES_LOCK.json',
    'PROOF_LEDGER.json',
    'SOURCE_PDF_HASHES.tsv',
    'CANDIDATE_SCORECARD.csv',
    'PACKAGE_FILE_LIST.txt',
    'SHA256SUMS.txt',
    'VALIDATION.txt',
    'scripts/finite_group_checks.py',
    'scripts/build_deterministic_zip.py',
    'scripts/validate_package.py',
    'results/finite_group_checks.json',
    'results/input_validation_summary.txt',
}

EXPECTED_UPLOADS = {
    'A303656_GLOBAL_ROUTE_RESET(6).zip': 'b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13',
    'A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(3).zip': 'aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2',
    'A303656_DESCENT_FINITE_REDUCTION_PHASE_A(2)(1)(3).zip': 'bebf5f5735fb476bb8d1859f297203715e07bc4de94f56bbf880f6763936205d',
    '分工规则.txt': '94261338e1d2e0a348ff264e9a98322b647918eeca74b0932dcd90bac980b5f6',
    '项目简介.txt': '42903e1adb5731d195786538a1072aa5b54a5c2adbf7fe6b963226fa74a139ae',
}

EXPECTED_RESULT_HASH = '71c0bc6fb7510166709737f5d8bed40065ce791a345a3841b8a11d85f0efbdb5'


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def fail(msg: str) -> None:
    raise RuntimeError(msg)


def validate(root: Path, checksums: bool = True) -> list[str]:
    log: list[str] = []
    if any(p.is_symlink() for p in root.rglob('*')):
        fail('symlink found')
    present = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    missing = sorted(REQUIRED - present)
    if missing:
        fail(f'missing required files: {missing}')
    log.append(f'required_files=PASS ({len(REQUIRED)})')

    verdict = json.loads((root / 'PROMOTION_VERDICT.json').read_text(encoding='utf-8'))
    expected = {
        'schema': 'a303656-exceptional-set-inverse-phase-a-v1',
        'decision': 'NO PROMOTABLE ROUTE — SPECULATIVE WATCH',
        'decision_code': 'SPECULATIVE_WATCH_ONLY',
        'final_required_output': 'NO PROMOTABLE ROUTE — SPECULATIVE WATCH',
        'global_problem_status': 'UNRESOLVED',
        'promoted': False,
        'promoted_candidate_ids': [],
        'nontrivial_inverse_theorem_for_actual_E_X': False,
        'directly_applicable_primary_source_found': False,
        'conditional_exceptional_set_theorem_with_clearly_weaker_core': False,
        'explicit_thin_set_classification_found': False,
    }
    for key, value in expected.items():
        if verdict.get(key) != value:
            fail(f'verdict mismatch {key}: {verdict.get(key)!r}')
    execution = verdict.get('execution', {})
    for key in ('codex_used', 'ultra_used', 'repository_integration_used', 'large_scale_computation_used', 'new_bounded_search_performed'):
        if execution.get(key) is not False:
            fail(f'prohibited execution flag not false: {key}')
    log.append('promotion_verdict=PASS')

    json_paths = sorted(p for p in root.rglob('*.json') if p.is_file())
    for path in json_paths:
        json.loads(path.read_text(encoding='utf-8'))
    log.append(f'json_parse=PASS ({len(json_paths)} files)')

    result_path = root / 'results/finite_group_checks.json'
    result = json.loads(result_path.read_text(encoding='utf-8'))
    if sha256(result_path) != EXPECTED_RESULT_HASH:
        fail('finite result hash mismatch')
    rt = result.get('range_test', {})
    if (rt.get('q_min'), rt.get('q_max'), rt.get('all_full_cover')) != (2, 500, True):
        fail('finite range result mismatch')
    selected = {row['q']: row for row in result.get('selected_moduli', [])}
    expected_selected = {441: 24, 1089: 40, 5929: 120}
    for q, count in expected_selected.items():
        row = selected.get(q)
        if not row or row.get('s2_plus_b_full_cover') is not True or row.get('exceptional_count_for_shifts_2_4') != count:
            fail(f'selected modulus mismatch q={q}')
    if 'no T(n) interval search' not in result.get('purpose', ''):
        fail('computation boundary missing')
    log.append('finite_result_schema=PASS')

    expected_bytes = result_path.read_bytes()
    with tempfile.TemporaryDirectory(prefix='a303656-phase-a-replay-') as td:
        out = Path(td) / 'finite_group_checks.json'
        proc = subprocess.run(
            [sys.executable, str(root / 'scripts/finite_group_checks.py'), '--max-q', '500', '--output', str(out)],
            cwd=root,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
        )
        if proc.returncode != 0:
            fail(f'finite replay failed: {proc.stderr}')
        if out.read_bytes() != expected_bytes:
            fail('finite replay not byte-identical')
    log.append(f'finite_replay=PASS (sha256={EXPECTED_RESULT_HASH})')

    with (root / 'SOURCE_PDF_HASHES.tsv').open(encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f, delimiter='\t'))
    if len(rows) != 8 or set(rows[0]) != {'id', 'filename', 'bytes', 'sha256'}:
        fail('source hash table schema/count mismatch')
    for row in rows:
        if len(row['sha256']) != 64 or any(c not in '0123456789abcdef' for c in row['sha256']):
            fail(f'invalid source hash: {row}')
        if int(row['bytes']) <= 0:
            fail(f'invalid source bytes: {row}')
    log.append('source_hash_table=PASS (8 primary PDFs)')

    with (root / 'CANDIDATE_SCORECARD.csv').open(encoding='utf-8', newline='') as f:
        reader = csv.DictReader(f)
        score_rows = list(reader)
    if not score_rows or any(row.get('promoted') != 'NO' for row in score_rows):
        fail('candidate scorecard promotion mismatch')
    if len({row['candidate_id'] for row in score_rows}) != len(score_rows):
        fail('duplicate candidate IDs')
    log.append(f'candidate_scorecard=PASS ({len(score_rows)} rows)')

    audit = (root / 'INPUT_AUDIT.md').read_text(encoding='utf-8')
    for name, digest in EXPECTED_UPLOADS.items():
        if name not in audit or digest not in audit:
            fail(f'input audit missing {name} or digest')
    log.append('input_audit_hashes=PASS')

    report = (root / 'REPORT.md').read_text(encoding='utf-8')
    for required_phrase in (
        'NO PROMOTABLE ROUTE — SPECULATIVE WATCH',
        'OEIS A303656: UNRESOLVED.',
        '\\frac{\\log X}{\\sqrt X}',
        'E_X-B_X',
    ):
        if required_phrase not in report:
            fail(f'report missing phrase: {required_phrase}')
    log.append('report_guardrails=PASS')

    file_list = [line for line in (root / 'PACKAGE_FILE_LIST.txt').read_text(encoding='utf-8').splitlines() if line]
    if file_list != sorted(present):
        fail('PACKAGE_FILE_LIST mismatch')
    log.append(f'package_file_list=PASS ({len(file_list)} files)')

    if checksums:
        rows_sum: list[tuple[str, str]] = []
        for line in (root / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
            if not line:
                continue
            digest, rel = line.split('  ', 1)
            rows_sum.append((digest, rel))
        expected_paths = sorted(p for p in present if p != 'SHA256SUMS.txt')
        if [rel for _, rel in rows_sum] != expected_paths:
            fail('SHA256SUMS path list mismatch')
        for digest, rel in rows_sum:
            if sha256(root / rel) != digest:
                fail(f'checksum mismatch: {rel}')
        log.append(f'internal_checksums=PASS ({len(rows_sum)} files)')
    else:
        log.append('internal_checksums=SKIPPED bootstrap')

    if (root / 'PROMOTED_ROUTE_SPEC.md').exists():
        fail('PROMOTED_ROUTE_SPEC.md must not exist')
    log.append('nonpromotion_file_logic=PASS')
    return log


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--bootstrap', action='store_true')
    args = parser.parse_args()
    try:
        log = validate(args.root.resolve(), checksums=not args.bootstrap)
    except Exception as exc:  # noqa: BLE001
        print('VALIDATION=FAIL')
        print(f'reason={exc}')
        return 1
    print('VALIDATION=PASS')
    for line in log:
        print(line)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
