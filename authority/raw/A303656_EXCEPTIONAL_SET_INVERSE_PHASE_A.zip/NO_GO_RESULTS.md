# No-Go Results

本文件区分 `PROVED NO-GO`、`FINITE FALSIFICATION` 与 `UNSUPPORTED LEAP`。

## NG-1 — Difference-set substitution

### Claim rejected

\[
(E_X-B_X)\cap\mathcal S_2=\varnothing
\Rightarrow
(E_X-E_X)\cap\mathcal S_2=\varnothing.
\]

### Status

**UNSUPPORTED / false as a logical inference.** 左边只控制 points \(e-b\)，右边控制 pairs \(e-e'\)。没有 implication。故 Rice/Fan–Lott theorem 不能无条件套用。

## NG-2 — One-sided van der Corput bound controls cross pairs

### Claim rejected

least-eigenvalue bound

\[
\Re\widehat\mu(\gamma)\ge-\varepsilon
\]

足以控制 any disjoint cross pair \(E,B\)。

### Status

**FALSE IN GENERAL.** self-correlation 乘 \(|\widehat{1_A}|^2\ge0\)；cross-correlation 乘任意 phase 的
\(\widehat{1_E}\overline{\widehat{1_B}}\)。需要 absolute eigenvalue/singular-value control 或额外 phase alignment。

## NG-3 — Fixed \(o(1)\) pseudorandomness 足够

### Claim rejected

只要 \(\sup_{minor}|\widehat\mu|=o(1)\)，便可推出 density increment。

### Status

**FALSE AT THIS SPARSITY.** 必须达到

\[
o(\sqrt\beta)
=o((\log X)/\sqrt X),
\]

因为 \(\beta=|B_X|/M\asymp(\log X)^2/X\)。fixed transference error 不够。

## NG-4 — Sidon-scale energy forces bounded spectrum

### Claim rejected

\[
E^+(B_X)\ll|B_X|^2
\]

意味着 only \(O(1)\) relevant Fourier modes。

### Status

**FALSE / quantitatively insufficient.** 只得

\[
|\operatorname{Spec}_\rho(B_X)|
\ll X/(\rho^4\log^4X),
\]

仍增长。低 energy 是 spectrum dispersion statement，不是 bounded-major-arc theorem。

## NG-5 — Small fixed modulus directly compresses exceptions

### Finite falsification

`finite_group_checks.py` 计算

\[
\mathcal S_2(q)=\{x^2+y^2\bmod q\},
\quad
B_\infty(q)=\{3^c+5^d\bmod q:c,d\ge0\}.
\]

结果：对全部 \(2\le q\le500\)，以及 \(q=441,1089,5929\)，

\[
\mathcal S_2(q)+B_\infty(q)=\mathbb Z/q\mathbb Z.
\]

### Status

**FINITE FALSIFICATION ONLY.** 它反驳这些 moduli 上的“存在 permanently forbidden residue” candidate；不证明 all moduli，也不搜索 \(T(n)\)。

作为 sanity contrast，只取 shifts \(\{2,4\}\) 时，selected moduli 上仍有 24、40、120 个 local exceptional residues；加入完整 power orbits 后 coverage 变为 full。这说明 local residue profile 对 shift menu 很敏感。

## NG-6 — Prime-level inverse sieve

### Claim rejected

exception condition 自动迫使 \(E_X\) modulo many primes 占少数 residues。

### Status

**NO DERIVATION.** every residue modulo a prime is a sum of two squares，所以 two-square support 本身没有 prime-level omitted classes。odd-valuation obstruction 位于 \(p^2,p^3,\dots\)，且 witness depends on pair。

## NG-7 — Pair witnesses 可用 trivial pigeonhole 压缩

### Claim rejected

由

\[
\forall(e,b)\ \exists p\equiv3(4):v_p(e-b)\text{ odd}
\]

可推出 fixed \(p\) 覆盖 constant fraction of all pairs。

### Status

**UNSUPPORTED.** candidate primes 随 \(X\) 增长；一个 pair 可有多个 witnesses；没有 bounded total witness weight。private-witness CRT constructions 进一步表明有限 local data 可支持分散 witnesses。

## NG-8 — Dense-model error \(o(1)\) 可替代 \(o(\beta)\)

### Status

**FALSE BY ZERO-MODE SCALE.** cross main term 是 \(\alpha\beta\)，而 \(\beta\to0\)。误差若只为 \(o(1)\)，可远大于 signal。

## NG-9 — Fixed-k upper correlations imply almost-all coverage

### Claim rejected

fixed-k Selberg-sieve upper bounds加 divergent mean自动给 \(|E_X|=o(X)\)。

### Status

**FALSE AS A METHOD CLAIM.** second moment upper bound只给 Paley–Zygmund positive density。要使 uncovered mass \(o(X)\)，需要 variance little-\(o\)、signed covariance cancellation、growing moments with sharp constants，或其他 concentration mechanism。

更一般地，若 nonnegative representation function \(R\) 支撑在至多 \((1-\delta)N\) points，则

\[
\sum R^k\ge
\frac{(\sum R)^k}{((1-\delta)N)^{k-1}}.
\]

dense zero set 与较大 moments 完全兼容；固定阶 upper bounds不自动排除它。

## NG-10 — 一次 increment 等于可迭代 route

### Status

**FALSE.** restriction 后 shift family 变为 affine S-unit slice；没有 hereditary theorem，下一步不能重复。一个无法迭代或 effectivize 的 increment 不具 universal leverage。

## NG-11 — \(o(X)\) 等于 all sufficiently large

### Status

**FALSE.** 每个 dyadic interval 一个 exception 即为 counterexample。需 descent、eventual emptiness 或 finite reduction。

## NG-12 — Coarse-statistic inverse theorem

### Theorem (cyclic countermodel)

固定 \(0<\delta<1\) 与 integer \(Q\)。存在 infinitely many finite cyclic groups \(G\) 与 subsets \(S,E,B\subset G\)，满足

1. \(|B|=m=(1+o(1))(\log|G|)^2\)；
2. \(E^+(B)=2m^2-m\)；
3. \(|S|/|G|\asymp1/\sqrt{\log|G|}\)；
4. \(|E|/|G|=\delta+o(1)\)；
5. \((E-B)\cap S=\varnothing\)；
6. every nontrivial character of \(G\) has order \(>Q\)；
7. \(\max_{\chi\ne1}|\widehat{1_E}(\chi)|=o(1)\)。

### Proof

取 large \(m\)。令 \(L=2m+1\)，

\[
B_H=\{t+Lt^2:0\le t<m\}.
\]

取 prime \(P\) 大于所有 two-sum differences 的 absolute range 且 \(P>Q\)。若
\(b_a+b_b\equiv b_c+b_d\pmod P\)，则无 wrap-around，且

\[
(a+b-c-d)+L(a^2+b^2-c^2-d^2)=0.
\]

第一括号 absolute value 小于 \(L\)，故两括号皆为零；unordered pairs 相同。因此 \(B_H\subset\mathbb Z/P\mathbb Z\) 是 Sidon，energy \(2m^2-m\)。

再取 prime

\[
r\asymp\exp(\sqrt m),\qquad r>Q,\quad r\ne P,
\]

令 \(K=\mathbb Z/r\mathbb Z\)。用 independent categorical coloring 把 \(K\) 分为 disjoint \(C,D,R\)，其中

\[
\mathbb P(x\in C)=m^{-1/4},
\qquad
\mathbb P(x\in D)=\delta.
\]

Hoeffding inequality 与 union bound over all nontrivial characters 给出一个 realization，使

\[
|C|/r=m^{-1/4}+o(m^{-1/4}),
\quad
|D|/r=\delta+o(1),
\]

并且 \(1_C,1_D\) 的所有 nontrivial normalized Fourier coefficients 都是 \(o(1)\)。

令

\[
G=(\mathbb Z/P\mathbb Z)\times K,
\quad
S=(\mathbb Z/P\mathbb Z)\times C,
\]

\[
E=(\mathbb Z/P\mathbb Z)\times D,
\quad
B=B_H\times\{0\}.
\]

因 \(P,r\) distinct primes，\(G\cong\mathbb Z/(Pr)\mathbb Z\) cyclic。\(E-B\) 的 second coordinate 属于 \(D\)，而 \(S\) 的 second coordinate 属于 \(C\)，故 cross-avoidance 成立。Fourier factorization 给 clause 7；所有 nontrivial character orders 为 \(P,r\) 或 \(Pr\)，给 clause 6。最后

\[
\log|G|=\sqrt m+O(\log m),
\]

故 \(m=(1+o(1))(\log|G|)^2\)，且
\(m^{-1/4}\asymp1/\sqrt{\log|G|}\)。∎

### Consequence

support density、sparse-shift size、Sidon-scale energy 与 cross-avoidance 这四类粗统计，即使精确匹配 A303656 scales，也不能推出 bounded-modulus increment、large Fourier coefficient 或 Bohr structure。成功 theorem 必须使用 \(\mathcal S_2\) 与 \(3^c+5^d\) 的 arithmetic，不可只写“apply additive combinatorics”。

## No-go verdict

本轮没有证明真实 A303656 inverse route 不可能；证明的是一批常见 shortcut 无效，并锁定任何未来 theorem 必须跨越的 scale/phase/closure/effectivity gates。
