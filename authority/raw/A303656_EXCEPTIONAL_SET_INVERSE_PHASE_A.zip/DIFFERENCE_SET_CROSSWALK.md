# Difference-Set Crosswalk

## 1. 逻辑形状

A303656 exceptional condition 是

\[
(E_X-B_X)\cap\mathcal S_2=\varnothing.
\tag{cross}
\]

classical Sárközy-type hypotheses 是

\[
(A-A)\cap\mathcal S_2=\varnothing.
\tag{self}
\]

`cross` 与 `self` 的 Fourier forms 分别为

\[
\sum_\gamma \widehat\mu(\gamma)
\widehat{1_E}(\gamma)
\overline{\widehat{1_B}(\gamma)}=0,
\]

与

\[
\sum_\gamma \widehat\mu(\gamma)
|\widehat{1_A}(\gamma)|^2=0.
\]

后者的 spectral weight 非负，least-eigenvalue/one-sided Fourier inequalities 可用；前者存在 arbitrary phase。

## 2. Primary theorem crosswalk

| Source | Exact hypothesis used by source | Conclusion | A303656 是否满足 | Failure mode |
|---|---|---|---|---|
| Rice, *Binary Quadratic Forms in Difference Sets*, arXiv:1810.03680v2, Theorem 1.1 / Lemma 2.1 | \((A-A)\cap I(h)=\varnothing\) for a fixed nondegenerate binary quadratic form | \(|A|\ll_h Ne^{-c\sqrt{\log N}}\); hereditary density increment \(\delta'\ge(1+c)\delta\), \(N'\gg\delta^4N\) | **No** | We know only \(E_X-B_X\) avoidance. Restricting/translating by a fixed \(b\) does not change differences: \((E_X-b)-(E_X-b)=E_X-E_X\). |
| Fan–Lott, arXiv:2606.29185v2, Cor. 1.2 | \((A-A)\cap S_N=\varnothing\) | \(|A|\ll_\varepsilon N^{7/8+\varepsilon}\) | **No** | Same self/cross mismatch; proof uses one-sided Fourier weight against \(|\widehat{1_A}|^2\). |
| Younis, arXiv:1908.06058v1, Thm. 1.3(i) | Construction problem for \((A-A)\cap\mathcal S_2=\{0\}\) | Exists \(|A|\gg N^{1/2}\) | Not an upper theorem | Shows even true self-difference avoidance admits polynomially large sets; no near-linear bound can be assumed. |
| Sárközy/Pintz–Steiger–Szemerédi square-difference machinery | \((A-A)\cap\{m^2:m\ne0\}=\varnothing\) | density decay via iterative major arcs | **No** | Exception status is pointwise avoidance after sparse shifts, not square-free difference set. |
| Green–Harper, arXiv:1311.6176v1 | \(A\bmod p\subset S_p\), \(|S_p|\approx p/2\), plus additive structure/near-extremality | improved large-sieve bounds / robustness conclusions | **No** | No prime-level omitted residues for \(E_X\) are known; every residue mod prime is a sum of two squares. |
| Walsh, arXiv:1105.1551v2, Thm. 1.1 | A high-dimensional set occupies \(<\alpha p^k\) classes for every prime | set small or almost contained in bounded-degree algebraic hypersurface | **No** | Ill-distribution is input, not output of cross-avoidance. |
| Croot–Mao–Pohoata–Sheffer–Yip, arXiv:2606.17487v2 | ill-distribution plus Sidon/bounded representation multiplicity of differences or norm values | strong size bounds | **No** | We have low energy for \(B_X\), not bounded multiplicity for norm values of \(E_X-E_X\); no ill-distribution of \(E_X\). |
| Ramaré–Viswanadham, arXiv:2509.23260v1, Thm. 1.6 | one full primitive norm variable and two relative-positive-density subsets | ternary additive representation theorem | **No** | \(B_X\) has relative density \(\asymp(\log X)^{5/2}/X\to0\) inside the norm set; binary convolution. |
| Chow–Prendiville–Vazquez, arXiv:2606.02312v1 | fixed translation-invariant configurations in dense/majorized settings | arithmetic regularity alternative to transference | **No direct fit** | growing sparse shift family and error scale \(o(|B_X|/X)\) are absent. |

## 3. Why translating does not create a difference-free set

对任何 fixed \(b\in B_X\)，exception condition 给

\[
E_X-b\subset\mathbb Z\setminus\mathcal S_2.
\]

但

\[
(E_X-b)-(E_X-b)=E_X-E_X.
\]

一个 set 本身位于 \(\mathbb Z\setminus\mathcal S_2\) 完全不表示其 differences 避开 \(\mathcal S_2\)。例如两个 non-two-square integers 的 difference 可以是 1，而 \(1\in\mathcal S_2\)。因此不能对 \(E_X-b\) 套 Sárközy theorem。

## 4. Graph spectral viewpoint

令 Cayley operator \(T_\mu\) 以 two-square differences 为 edges。Fan–Lott 给 least-eigenvalue 型 lower bound；Hoffman bound 对 independent set 使用同一个 vector twice，quadratic form 为 \(\langle1_A,T_\mu1_A\rangle\)。

A303656 给两个不同 vectors 的 zero edge count：

\[
\langle1_E,T_\mu1_B\rangle=0.
\]

least eigenvalue 不控制 arbitrary bilinear form。要从 bipartite edge-free pair 推出 size/increment，通常需要 second singular value/absolute Fourier bound 或 vertex-expansion theorem，而不仅是 lower spectral edge。

## 5. 可以合法借用什么

Rice/Fan–Lott machinery 仍提供三类设计线索：

1. major/minor arc weights 的构造方式；
2. character coefficient 到 progression density increment 的转换；
3. 用 square scaling 保持 norm-form image 的 hereditary mechanism。

但要合法移植，必须把 self-correlation 替换为 cross-correlation theorem，并同时处理 sparse \(B_X\) alignment。现有 primary theorem 没有完成这一步。

## 6. Crosswalk verdict

所有强 difference-set theorem 的 decisive hypothesis 都位于 \(E_X-E_X\) 或 \(Q(E_X-E_X)\)；本问题只控制 \(E_X-B_X\)。无条件套用属于 quantifier/hypothesis error。
