# Literature Audit

## 1. Source policy

- theorem statements 只基于 primary PDFs、arXiv exact versions、publisher metadata 或 OEIS entry；search snippets 仅用于 discovery。
- 本轮下载的 8 份 primary PDFs 的 bytes 与 SHA256 见 `SOURCE_PDF_HASHES.tsv`。
- Radomskii 与 Freiberg–Kurlberg–Rosenzweig 的 exact source locks 继承自 authenticated positive-density/global-reset bundles。
- audit 截止日期：2026-07-18。

## 2. Directly relevant primary sources

### 2.1 Steve Fan and Andrew Lott

**Source.** *The van der Corput property for sums of two squares*, arXiv:2606.29185v2, 12 Jul 2026.

**Exact result.** Theorem 1.1 constructs nonnegative weights \(c_d\) on two-square integers \(d\le N\), total mass 1, with

\[
\Re\sum c_de(d\theta)\ge-C_\varepsilon N^{-1/8+\varepsilon}.
\]

Corollary 1.2: if \((A-A)\cap S_N=\varnothing\)，then

\[
|A|\le C_\varepsilon N^{7/8+\varepsilon}.
\]

Proposition 6.3 supplies an absolute minor-arc estimate in their \(H\)-parameter construction.

**Applicability verdict.** **Not directly applicable.** A303656 gives cross-avoidance, not self-difference avoidance. The global theorem is one-sided; even the minor-arc exponent corresponds to \(N^{-1/8+o(1)}\), far above the required \(N^{-1/2}\log N\) scale.

### 2.2 Olivier Ramaré and G. K. Viswanadham

**Source.** *The trigonometric polynomial on sums of two squares, an additive problem and generalisation*, arXiv:2509.23260v1, 27 Sep 2025; Trans. Amer. Math. Soc., DOI 10.1090/tran/9598.

**Exact result.** Theorem 1.5 bounds the normalized exponential sum on odd primitive sums of two coprime squares by

\[
\ll_A \varphi(q)^{-1}+\sqrt{q/N}(\log N)^7+(\log N)^{-A}.
\]

Theorem 1.6 is a ternary additive theorem with one full norm variable and two relative-positive-density variables.

**Applicability verdict.** **No direct transference.** The \(B_X\) variable has only \(O((\log X)^2)\) elements and vanishing relative density. The exponential-sum scale is not enough for the sparse-shift zero-mode.

### 2.3 Alex Rice

**Source.** *Binary Quadratic Forms in Difference Sets*, arXiv:1810.03680v2, 12 May 2019.

**Exact result.** Theorem 1.1: if distinct differences of \(A\subset[1,N]\) avoid the image of a fixed nondegenerate integral binary quadratic form, then

\[
|A|\ll_h N e^{-c(h)\sqrt{\log N}}.
\]

Lemma 2.1 gives a hereditary increment

\[
N'\gg_h\delta^4N,
\qquad
\delta'\ge(1+c(h))\delta.
\]

**Applicability verdict.** **Hypothesis absent.** Its strength comes from self-difference heredity; A303656 cross avoidance does not provide it.

### 2.4 Khalid Younis

**Source.** *Lower Bounds in the Polynomial Szemerédi Theorem*, arXiv:1908.06058v1, 16 Aug 2019.

**Exact result.** Theorem 1.3(i) constructs \(A\subset[N]\), \(|A|\gg N^{1/2}\), with all nonzero differences avoiding sums of two squares.

**Applicability verdict.** Lower-bound warning: even genuine self-difference avoidance can support polynomially large sets. It blocks unjustified expectations of near-finite difference-free sets.

### 2.5 Ernie Croot, Junzhe Mao, Cosmin Pohoata, Adam Sheffer, Chi Hoi Yip

**Source.** *A Combinatorial Large Sieve for Sidon Sets, Distances, and Norm Forms*, arXiv:2606.17487v2, 24 Jun 2026.

**Exact results.** Theorem 1.1 treats ill-distributed Sidon subsets; Theorem 1.5 treats sets in \([N]^2\) with uniformly bounded multiplicity of quadratic-form distances; Theorems 1.9–1.11 extend to norm forms.

**Applicability verdict.** **No direct bridge.** We have Sidon-scale energy for the sparse shift set \(B_X\), not a Sidon/bounded-norm-multiplicity property of \(E_X\). Nor do we know that \(E_X\) is ill-distributed modulo many primes.

### 2.6 Ben Green and Adam J. Harper

**Source.** *Inverse Questions for the Large Sieve*, arXiv:1311.6176v1, 24 Nov 2013.

**Exact scope.** The paper assumes \(A\bmod p\) lies in prescribed sets of about half the residue classes and proves improvements under additive structure/robustness hypotheses; it explicitly notes that the general inverse large sieve problem is not solved.

**Applicability verdict.** **Input hypothesis unavailable.** Cross-avoidance does not imply prime-level residue sparsity of \(E_X\).

### 2.7 Miguel N. Walsh

**Source.** *The Inverse Sieve Problem in High Dimensions*, arXiv:1105.1551v2, 28 Jun 2011.

**Exact result.** Theorem 1.1: a sufficiently large subset of \([N]^d\) occupying fewer than \(\alpha p^k\) classes for every prime is either small or almost contained in a bounded-degree polynomial zero set.

**Applicability verdict.** **No trigger.** The needed ill-distribution is not known for \(E_X\); in one dimension a polynomial zero-set classification also needs careful interpretation because a fixed nonzero polynomial has finitely many integer roots.

### 2.8 Sam Chow, Sean Prendiville, Santiago Vazquez

**Source.** *Arithmetic Regularity as an Alternative to Transference*, arXiv:2606.02312v1, 1 Jun 2026.

**Exact scope.** arithmetic regularity/dense-model replacement for fixed translation-invariant configurations in sparse arithmetic settings.

**Applicability verdict.** **No direct theorem.** A303656 has a growing lacunary shift family and requires error at the vanishing scale \(o(|B_X|/X)\), not fixed dense-model accuracy.

## 3. Inherited primary sources

### 3.1 Artyom Radomskii

**Source.** *Variants of Romanoff's theorem*, arXiv:2504.09954v6, revised 13 Jul 2026.

**Role.** Theorem 1.1 plus its two-square example substantially subsume the headline positive-density representation phenomenon under verified hypotheses.

**Inverse-route verdict.** It remains a Paley–Zygmund/second-moment density theorem. It does not prove concentration, \(|E_X|=o(X)\), inverse structure, or universal coverage.

### 3.2 Freiberg–Kurlberg–Rosenzweig

**Source.** *Poisson distribution for gaps between sums of two squares and level spacings for toral point scatterers*, arXiv:1701.01157v1; CNTP 11 (2017).

**Role.** fixed-tuple Selberg-sieve indicator upper bounds used in the positive-density bundle.

**Inverse-route verdict.** fixed-\(k\) upper correlations do not supply signed covariance or high-order concentration for the growing \(B_X\) family.

## 4. Finite-group/local literature conclusion

For any prime \(p\), every residue modulo \(p\) is representable as a sum of two squares: for odd \(p\), the sets of squares shifted by a target have total cardinality exceeding \(p\); for \(p=2\) direct check applies. Thus prime-level local obstruction cannot create an inverse-sieve trigger for \(E_X\).

Restrictions appear at powers of primes \(p\equiv3\pmod4\), but the witness prime and valuation can vary with \((e,b)\). No audited primary source turns this pairwise witness family into a bounded residue profile for \(E_X\).

## 5. Literature decision matrix

| Needed theorem | Closest source | Exact mismatch | Decision |
|---|---|---|---|
| absolute bipartite S2 spectral gap at \((\log X)/\sqrt X\) | Fan–Lott; Ramaré–Viswanadham | one-sided or much weaker exponent; no \(B_X\)-alignment | unavailable |
| self-contained density increment for \(E_X\) | Rice | self-difference vs cross-difference | unavailable |
| inverse sieve/thin classification | Green–Harper; Walsh; Croot et al. | ill-distribution/bounded multiplicity not derived | unavailable |
| transference with \(O((\log X)^2)\) shifts | Ramaré–Viswanadham; Chow–Prendiville–Vazquez | dense relative variables/fixed configuration | unavailable |
| effective exceptional-set elimination | none located | almost-all/density bounds do not descend | unavailable |

## 6. Audit verdict

No primary source located by 2026-07-18 supplies a theorem directly applicable to \(E_X\) that meets the promotion gate. The literature justifies a narrow speculative watch, not execution escalation.
