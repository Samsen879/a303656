# Executive Verdict

## 判定

> **NO PROMOTABLE ROUTE — SPECULATIVE WATCH**

## 为什么不是 promotion

本轮 promotion gate 逐项结果如下。

| Gate | 所需结果 | 本轮结果 |
|---|---|---|
| G1 | 针对真实 \(E_X\) 的 nontrivial inverse theorem | **未证明**。只证明了以 missing absolute minor-spectrum estimate 为前提的 elementary cross-spectral lemma。 |
| G2 | primary source 中可直接应用的 transference/density-increment theorem | **未发现**。现有 theorem 需要 self-differences、dense relative variables、ill-distribution 或 bounded multiplicity；这些 hypotheses 均未从 \(E_X-B_X\) avoidance 得到。 |
| G3 | 完整 conditional exceptional-set theorem，且核心 hypothesis 明显弱于 A303656 | **未达到**。`CROSS-MA + HEREDITARY-CLOSURE` 可推出 contradiction，但 closure/absolute-gap hypothesis 正是主要困难，不能诚实标为明显更弱。 |
| G4 | explicit thin-set classification，可接 descent/finite verification | **未得到**。pair-dependent odd-valuation witnesses 仍不能压缩成 finite templates。 |

## 本轮真正证明了什么

### V1. Exact bipartite spectral localization

对任意 finite cyclic encoding、任意支撑于 two-square set 的 probability measure \(\mu\)，cross-avoidance 给出

\[
0=\alpha\beta+
\sum_{\gamma\ne 1}
\widehat{1_E}(\gamma)
\overline{\widehat\mu(\gamma)\widehat{1_B}(\gamma)}.
\]

若某 major spectrum \(\Gamma\) 外有 absolute bound

\[
\eta:=\sup_{\gamma\notin\Gamma}|\widehat\mu(\gamma)|
\le \tfrac12\sqrt{\alpha\beta},
\]

则至少一半 zero-mode 必须由 \(\Gamma\) 承担。令

\[
L_\Gamma:=\beta^{-1}
\sum_{\gamma\in\Gamma}
|\widehat\mu(\gamma)\widehat{1_B}(\gamma)|,
\]

便有

\[
\max_{\gamma\in\Gamma}|\widehat{1_E}(\gamma)|
\ge \frac{\alpha}{2L_\Gamma}.
\]

若 \(|\Gamma|\le K\)，则 \(L_\Gamma\le K\)，从而得到 \(\alpha/(2K)\) 级 Fourier coefficient。

这是 exact diagnostic lemma，不是实际 \(E_X\) inverse theorem，因为所需 absolute gap 尚无来源。

### V2. Fourier coefficient 到 explicit residue increment

若 character \(\chi\) 的 order 为 \(q\)，且

\[
|\widehat{1_E}(\chi)|\ge \rho\alpha,
\]

则某个 residue fiber modulo \(q\) 上的 relative density 至少为

\[
\alpha(1+\rho/2).
\]

因此 V1 在 \(L_\Gamma=O_\delta(1)\) 且 character orders bounded 时确实会产生 quantitative density increment。

### V3. Critical scale theorem

由于

\[
|B_X|\asymp(\log X)^2,
\qquad
\beta=|B_X|/M\asymp(\log X)^2/X,
\]

对 \(|E_X|\ge\delta X\) 而言，V1 所需的 absolute minor-spectrum scale 是

\[
\eta\ll_\delta \sqrt\beta
\asymp \frac{\log X}{\sqrt X}.
\]

这不是技术细节，而是 sparse-shift zero-mode \(\alpha\beta\) 的强制尺度。

### V4. Coarse-data countermodel

本轮证明：可在 finite cyclic groups 中同时实现

- \(|B|\asymp(\log|G|)^2\)；
- \(E^+(B)=2|B|^2-|B|\)；
- \(|S|/|G|\asymp1/\sqrt{\log|G|}\)；
- \(|E|/|G|\to\delta>0\)；
- \((E-B)\cap S=\varnothing\)；
- \(E\) 的所有 nontrivial Fourier coefficients 都趋于零；
- group 中不存在 bounded-order nontrivial characters。

所以仅凭 support density、\(|B|\)、Sidon-scale energy 与 cross-avoidance，不能推出 bounded-modulus density increment。任何成功 theorem 必须使用 genuine arithmetic of \(\mathcal S_2\) 与 \(3^c+5^d\)。

## 决定性阻塞

1. **Absolute-spectrum barrier**：已知 two-square Fourier theorem 不提供 \(O((\log X)/\sqrt X)\) 的 global absolute gap。
2. **Phase barrier**：self-difference 产生 \(|\widehat{1_A}|^2\)，cross-avoidance 产生 \(\widehat{1_E}\overline{\widehat{1_B}}\)，phase 可任意。
3. **Major-spectrum size/alignment barrier**：standard major arcs 数量增长；\(B_X\) 的 additive energy 只给大谱数量上界 \(O(X/(\rho^4\log^4X))\)，远非 bounded。
4. **Iteration closure barrier**：restricting \(E_X\) 到一个 fiber 不自动产生同型 \(B_Y\)。
5. **Effectivity barrier**：density-zero 或 power-saving exceptional-set bounds 仍可能允许 infinitely many exceptions。

## Speculative watch：只有以下触发器值得重开

1. 一个针对 two-square support 的 **bipartite/vertex-expansion theorem**，在 explicit major-arc projection 后给出 \(o((\log X)/\sqrt X)\) absolute error，并控制与 \(B_X\) 的 spectral alignment。
2. 一个对 iterated affine slices of \(3^c+5^d\) 封闭的 **hereditary density-increment theorem**。
3. 一个 effective **finite odd-valuation witness compression / thin-family classification**，能把任何大 exception 降到较小 exception 或有限状态。

没有上述 trigger 时，不应启动 Codex、Ultra、repository integration 或新的 bounded search。

**OEIS A303656: UNRESOLVED.**
