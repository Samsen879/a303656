# A303656 Exceptional-Set Inverse Theorem and Density-Increment Trigger Hunt — Phase A Report

## 1. Executive answer

本轮问题是：已知 \(\mathcal S_2+B_X\) 在每个 dyadic interval 覆盖 positive proportion，能否从一个 positive-density exceptional set \(E_X\) 反推出 explicit Fourier/Bohr/residue structure，迭代后得到 \(|E_X|=o(X)\)，甚至 effective elimination？

结论：

> **NO PROMOTABLE ROUTE — SPECULATIVE WATCH**

原因不是“没有尝试 additive combinatorics”，而是 exact cross-Fourier equation 显示所需 theorem 比现有 two-square estimates强得多，并且一次 increment 后 shift family 不封闭。

## 2. Authenticated starting point

三个用户上传 bundle 均通过 SHA256、ZIP integrity 与 internal validation：

- global reset：`b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13`；
- positive-density frozen：`aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2`；
- descent/finite-reduction Phase A：`bebf5f5735fb476bb8d1859f297203715e07bc4de94f56bbf880f6763936205d`。

positive bundle 的 40-file scientific core、nested archives、symbolic constant \(\kappa=1/(4K)\) 与 two independent replays 均通过；descent package validator 与 global/descent internal SHA manifests 均通过。详见 `INPUT_AUDIT.md` 与 `results/input_validation_summary.txt`。

采用的前阶段定理只有：

\[
|B_X|=\frac{(\log X)^2}{\log3\log5}+O(\log X),
\quad E^+(B_X)\ll|B_X|^2,
\]

以及 positive-density representation theorem。没有重做 second moment。

## 3. Exact Fourier reduction

在 \(G=\mathbb Z/(4X+1)\mathbb Z\) 中，令 \(f=1_{E_X}\)、\(g=1_{B_X}\)，\(\mu\) 为 any probability measure supported on \(\mathcal S_2\cap[0,2X]\)。cross-avoidance 无 wrap-around 地等价于

\[
f\,T_\mu g=0.
\]

因此

\[
0=\alpha\beta+
\sum_{\gamma\ne1}
\widehat f(\gamma)
\overline{\widehat\mu(\gamma)\widehat g(\gamma)}.
\tag{3.1}
\]

同时，因为 \(T_\mu g=0\) on \(E_X\)，

\[
\alpha\beta^2
\le
\sum_{\gamma\ne1}
|\widehat\mu(\gamma)|^2|\widehat g(\gamma)|^2.
\tag{3.2}
\]

式 (3.1) 是 inverse-theorem starting point；式 (3.2) 是 exceptional-set flattening criterion。

## 4. Critical threshold

若 \(|E_X|\ge\delta X\)，则 \(\alpha\gg\delta\)。而

\[
\beta=|B_X|/(4X+1)\asymp(\log X)^2/X.
\]

把 (3.1) 的 minor spectrum 用 absolute bound \(\eta\) 控制时，minor contribution 最多 \(\eta\sqrt{\alpha\beta}\)。要留下 fixed proportion of zero-mode，必须

\[
\eta\ll_\delta\sqrt\beta
\asymp\frac{\log X}{\sqrt X}.
\tag{4.1}
\]

这解释了为什么“support 有 positive density”“minor arcs 是 \(o(1)\)”或普通 dense model 都不够。signal 本身只有 \((\log X)^2/X\) 级。

## 5. Exact inverse implication

若 major set \(\Gamma\) 外达到 (4.1)，则

\[
\sum_{\gamma\in\Gamma}
|\widehat f||\widehat\mu||\widehat g|
\ge\alpha\beta/2.
\]

定义

\[
L_\Gamma=\beta^{-1}
\sum_{\gamma\in\Gamma}|\widehat\mu\widehat g|,
\]

便有

\[
\max_{\gamma\in\Gamma}|\widehat f(\gamma)|
\ge\alpha/(2L_\Gamma).
\]

若 \(L_\Gamma=O_\delta(1)\)，某 character 给 constant relative Fourier coefficient；若其 order 为 bounded \(q\)，则某 residue class modulo \(q\) 上 density 增加 fixed proportion。

这是完整 one-step mechanism。它明确要求：

1. absolute minor gap at (4.1)；
2. bounded \(B_X\)-aligned major mass；
3. bounded/effective character order。

## 6. Known Fourier theorems 为什么不触发

### 6.1 Fan–Lott

Fan–Lott 的 global theorem 是

\[
\Re\widehat\mu(\theta)\ge-O(N^{-1/8+\varepsilon}),
\]

并通过 \(|\widehat{1_A}|^2\) 证明 self-difference result。A303656 cross term有 arbitrary phase，所以 one-sided bound不够。其 minor-arc scale \(N^{-1/8+o(1)}\) 也比 (4.1) 大 \(N^{3/8-o(1)}/\log N\)。

### 6.2 Ramaré–Viswanadham

其 normalized support sum bound的前两项最佳平衡约为 \(N^{-1/3}\) polylog，仍不达 (4.1)。其 ternary application需要 relative-positive-density sparse variables，而 \(B_X\) relative density趋零。

### 6.3 Generic Cauchy

不使用 arithmetic 时只能强制

\[
\max_{\gamma\ne1}\frac{|\widehat f(\gamma)|}{\alpha}
\gg\frac{(\log X)^{3/4}}{\sqrt X},
\]

对应 vanishing increment，不能在 scale 耗尽前迭代。

## 7. \(B_X\) energy 的真实含义

energy identity 给

\[
\sum|\widehat g|^4\ll |B_X|^2/M^3.
\]

因此 relative \(\rho\)-spectrum 至多

\[
O\!\left(\frac{X}{\rho^4(\log X)^4}\right)
\]

个 frequencies。该数量仍 polynomially growing。low energy 说明 spectrum dispersed，不说明由 finite explicit moduli 控制。故不能把前阶段 energy lemma升级为 bounded-spectrum inverse theorem。

## 8. Difference-set route 的 hypothesis error

Rice 与 Fan–Lott 要求

\[
(A-A)\cap\mathcal S_2=\varnothing.
\]

我们只有

\[
(E_X-B_X)\cap\mathcal S_2=\varnothing.
\]

对 fixed \(b\)，虽然 \(E_X-b\) 的 points 都不是 sums of two squares，但其 difference set仍是 \(E_X-E_X\)。因此 self-difference theorem不能直接应用。该错误若不显式排除，会把 one-sided spectrum误用为 bipartite expansion。

## 9. Density increment 的 closure defect

若 \(e,b\) 同 residue modulo \(q^2\)，square rescaling保持 two-square property。但 restrict 后 shifts 是

\[
(3^c+5^d-r)/q^2
\]

with exponent congruence constraints，不再是原始 family。要迭代必须对所有 iterated affine S-unit slices证明同一个 inverse theorem。当前 literature 与输入 artifacts 均没有此 hereditary theorem。

因此一次 density increment，即使存在，也不能自动得到 contradiction。

## 10. Inverse sieve 与 residue profile

每个 non-two-square difference有一个 \(p\equiv3\pmod4\) 的 odd valuation witness，但 witness depends on \((e,b)\)。prime-level residues没有限制，因为 every residue mod prime is a sum of two squares。inverse-sieve theorem所需的 ill-distribution of \(E_X\) 没有来源。

finite-group experiment进一步发现：对 \(2\le q\le500\) 与 selected squarefull moduli 441、1089、5929，完整 exponent orbits 满足

\[
\mathcal S_2(q)+B_\infty(q)=\mathbb Z/q\mathbb Z.
\]

这不证明 all \(q\)，但否定了最简单的小 modulus forbidden-residue trigger。

## 11. Coarse-data impossibility result

本轮构造 finite cyclic countermodels，匹配以下 scales：

\[
|B|\sim(\log|G|)^2,
\quad
E^+(B)\sim2|B|^2,
\quad
|S|/|G|\sim1/\sqrt{\log|G|},
\]

同时 \(E\) 有 fixed positive density、\((E-B)\cap S=\varnothing\)，但 \(E\) Fourier-uniform，且无 bounded-order nontrivial characters。

故任何只依赖上述粗统计的 inverse theorem 是 false。未来成功必须利用 two-square local factors、major arcs 与 power-orbit arithmetic 的具体耦合。

## 12. Effectivity

即使证明 \(|E_X|=o(X)\)，仍不能推出 A303656。需要 eventual emptiness、descent、finite reduction 或 eventually-empty thin classification。现有 conditional Fourier criterion没有 effective constants/descendant verifier，也没有 finite bound；因此不授权新的 bounded search。

## 13. Candidate verdicts

| Candidate | Exact payoff | Missing core | Verdict |
|---|---|---|---|
| bounded-modulus inverse theorem | constant residue increment | absolute gap + bounded alignment | speculative |
| Bohr inverse theorem | structured density increment | bounded rank/radius + closure | speculative |
| odd-valuation witness compression | inverse sieve/descent | pair-to-finite-template theorem | speculative |
| thin algebraic/arithmetic classification | finite verification bridge | explicit eventually-empty families | speculative |
| Fan–Lott transfer | power-saving if self-difference | wrong hypothesis/phase | stop |
| energy-to-bounded-spectrum | finite major spectrum | false from energy alone | stop |
| fixed-modulus local compression | omitted residues | finite tests show full coverage | stop as simple route |

## 14. Promotion decision

本轮没有：

- 针对真实 \(E_X\) 的 nontrivial inverse theorem；
- 可直接应用的 primary transference/density-increment theorem；
- 核心 hypothesis 明显弱于 A303656 的完整 conditional exceptional-set theorem；
- explicit thin-set classification。

因此唯一合规 verdict 为：

> **NO PROMOTABLE ROUTE — SPECULATIVE WATCH**

重开仅限三类 external trigger：critical-scale bipartite spectral theorem、hereditary affine-S-unit increment theorem、effective finite witness/thin-family classification。

**OEIS A303656: UNRESOLVED.**
