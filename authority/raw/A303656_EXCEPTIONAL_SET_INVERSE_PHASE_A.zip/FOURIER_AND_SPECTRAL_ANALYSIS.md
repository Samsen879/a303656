# Fourier and Spectral Analysis

## 1. Zero-mode 的强制尺度

在 `EXCEPTIONAL_SET_FORMALISM.md` 的 finite cyclic encoding 中，

\[
\alpha=|E_X|/M,\qquad
\beta=|B_X|/M,
\qquad M=4X+1.
\]

若 \(|E_X|\ge\delta X\)，则 \(\alpha\gg\delta\)，而

\[
\beta
=\frac{1+o(1)}{4\log3\log5}\frac{(\log X)^2}{X}.
\]

cross identity 的 trivial-character term 是 \(\alpha\beta\)。若 minor spectrum 只用

\[
\sup_{\gamma\notin\Gamma}|\widehat\mu(\gamma)|\le\eta
\]

控制，则 Cauchy–Schwarz 给出的 minor contribution 上界是

\[
\eta\sqrt{\alpha\beta}.
\]

要让其小于 zero-mode 的固定比例，必须有

\[
\boxed{
\eta\ll_\delta\sqrt\beta
\asymp_\delta\frac{\log X}{\sqrt X}.}
\tag{critical-scale}
\]

这是本轮最重要的 quantitative diagnostic。\(|B_X|=O((\log X)^2)\) 使 zero-mode 极小；固定 \(o(1)\) pseudorandomness 完全不够。

## 2. Absolute spectral gap 的 exact payoff

### Proposition S1

若存在 probability measure \(\mu_X\) supported on \(\mathcal S_2\cap[0,2X]\) 使

\[
\lambda_X:=\max_{\gamma\ne1}|\widehat\mu_X(\gamma)|,
\]

则

\[
\frac{|E_X|}{M}=\alpha\le\frac{\lambda_X^2}{\beta}.
\tag{S1}
\]

### Proof

由 F2，

\[
\alpha\beta^2
\le\sum_{\gamma\ne1}|\widehat\mu|^2|\widehat g|^2
\le\lambda_X^2\sum_\gamma|\widehat g|^2
=\lambda_X^2\beta.
\]

约去 \(\beta\)。∎

故 \(|E_X|=o(X)\) 的充分条件是

\[
\lambda_X=o(\sqrt\beta)
=o\!\left(\frac{\log X}{\sqrt X}\right).
\]

这个 hypothesis 极强；任何 measure 支撑在只有 \(\asymp X/\sqrt{\log X}\) 个点上时，其 total Fourier \(\ell^2\)-mass \(\sum_\gamma|\widehat\mu(\gamma)|^2\) 至少约为 \(\sqrt{\log X}\)，所以不能期待所有 coefficients 轻易达到这一 scale。

## 3. Weighted flattening 是最精确的目标

absolute gap 不是必要条件。F2 显示真正精确的 sufficient condition 是

\[
\boxed{
\sum_{\gamma\ne1}
|\widehat\mu_X(\gamma)|^2
|\widehat{1_{B_X}}(\gamma)|^2
=o(\beta^2).}
\tag{WF}
\]

`WF` 只要求 two-square spectrum 在 \(B_X\) 的 spectral support 上 flatten；它比 global \(L^\infty\) gap 更合理。但它仍是一个 signed/variance-level statement。已冻结 positive-density proof 只得到 second moment 的 \(O(1)\)-ratio，不得到 little-\(o\) flattening。

## 4. Fan–Lott theorem 的精确 crosswalk

Fan–Lott, arXiv:2606.29185v2, Theorem 1.1 构造 nonnegative coefficients \(c_d\) supported on

\[
S_N=\{1\le d\le N:d=x^2+y^2\},\qquad \sum c_d=1,
\]

满足

\[
\Re\sum_{d\in S_N}c_de(d\theta)
\ge-C_\varepsilon N^{-1/8+\varepsilon}
\quad(\theta\in\mathbb R/\mathbb Z).
\tag{FL-one-sided}
\]

其 Proposition 6.3 在其 minor arcs 上给出

\[
|F_H(\theta)|\ll H^{-1/2+2\sigma+\varepsilon},
\]

而 construction 的 natural range 是 \(N\asymp H^4\)，即约 \(N^{-1/8+o(1)}\)。

### 两个独立 mismatch

1. **Exponent mismatch.** 即使把 minor-arc estimate 直接移植为 finite-group absolute estimate，\(N^{-1/8+o(1)}\) 相比 `critical-scale` 大
   \[
   \frac{N^{-1/8}}{N^{-1/2}\log N}
   =\frac{N^{3/8}}{\log N}.
   \]
2. **Phase mismatch.** `FL-one-sided` 控制 \(\Re\widehat\mu\) 的下界。self-difference identity 中 multiplier 乘 \(|\widehat{1_A}|^2\ge0\)，所以 least-eigenvalue information 有效。cross identity 中 multiplier 乘
   \(\widehat{1_E}\overline{\widehat{1_B}}\)，其 phase 不受控制；one-sided lower bound 不能替代 absolute gap。

因此 Fan–Lott 是重要 diagnostic source，但不是当前 inverse trigger。

## 5. Ramaré–Viswanadham exponential sum 的尺度

Ramaré–Viswanadham, arXiv:2509.23260v1, Theorem 1.5 对 primitive odd sums-of-two-squares exponential sum 给出 normalized estimate

\[
\frac{S(\alpha;N)}{N/\sqrt{\log N}}
\ll_A
\frac1{\varphi(q)}
+\sqrt{\frac qN}(\log N)^7
+\frac1{(\log N)^A}
\tag{RV}
\]

在相应 rational approximation 范围内成立。

忽略 \(q/\varphi(q)\) 的 polylog loss，前两项在
\(q\asymp N^{1/3}\) 附近平衡为约

\[
N^{-1/3}(\log N)^{O(1)}.
\]

这仍比 `critical-scale` \(N^{-1/2}\log N\) 大约 \(N^{1/6}\) 乘 polylog。更重要的是，RV 的 additive application 是 ternary：一个 full norm variable 加两个 relative-positive-density sparse variables。\(B_X\) 只有 \(O((\log X)^2)\) 个元素，其 relative density 对 two-square set 趋于零。因此该 transference/circle-method theorem 不能直接应用。

## 6. \(B_X\) 的 Fourier spectrum

令 \(m=|B_X|\)，\(g=1_{B_X}\)，\(M>2X\)。由前阶段 energy theorem，modular equality 与 integer equality 相同，且

\[
\sum_{\gamma\in\widehat G}|\widehat g(\gamma)|^4
=\frac{E^+(B_X)}{M^3}
\ll\frac{m^2}{M^3}.
\tag{B-L4}
\]

对 relative large spectrum

\[
\operatorname{Spec}_\rho(B_X)=
\{\gamma:|\widehat g(\gamma)|\ge\rho\beta\},
\]

有 exact consequence

\[
|\operatorname{Spec}_\rho(B_X)|
\ll\frac{M}{\rho^4m^2}
\asymp\frac{X}{\rho^4(\log X)^4}.
\tag{B-spec-count}
\]

这比 Parseval 的 \(O(M/(\rho^2m))\) 更强，但仍远非 \(O_\rho(1)\)。

### 解释

Sidon-scale energy 说明 \(B_X\) 的 Fourier mass 相对分散；它不说明 spectrum 集中在 bounded-order characters，也不保证与 two-square major arcs 对齐。低 energy 甚至与“存在一个有限 major spectrum 承担全部 zero-mode”方向相反。

Chang-type large-spectrum dimension bounds在这里至多给出随 \(\log(1/\beta)\asymp\log X\) 增长的 dimension；它们不产生 explicit bounded modulus，也不解决 descendant closure。

## 7. Generic Fourier certificate 为什么不够

取 \(\mu\) 为 \(A_X=\mathcal S_2\cap[0,2X]\) 上 uniform measure。纯 Cauchy–Schwarz 至少强制一个 character 满足

\[
\frac{|\widehat{1_{E_X}}(\gamma)|}{\alpha}
\ge\frac{\sqrt{|A_X||B_X|}}{M}
\asymp\frac{(\log X)^{3/4}}{\sqrt X}.
\tag{generic}
\]

这确实是一个 inverse signal，但它趋于零，而且 character order 不受控制。由 fiber lemma 得到的 multiplicative density gain 仅为
\(1+O((\log X)^{3/4}/\sqrt X)\)。在任何每步缩短 scale 的 iteration 中，这种 gain 不具 universal leverage。

## 8. Major arcs 的 cardinality 与 alignment

即使得到 minor bound，F3 的 density increment 取决于

\[
L_\Gamma=eta^{-1}
\sum_{\gamma\in\Gamma}
|\widehat\mu(\gamma)\widehat g(\gamma)|.
\]

standard major arcs 一般包含随 \(X\) 增长的 rational neighborhoods；仅有 \(|\Gamma|\to\infty\) 时，粗界给出的 increment 是 \(O(1/|\Gamma|)\)。成功 theorem 必须额外证明以下至少一种：

- \(L_\Gamma=O_\delta(1)\)；
- zero-mode mass 集中在 bounded number of explicit characters；
- 一个多频 Bohr increment，其 rank/radius 与 descendant closure 均可迭代。

目前没有 primary source 提供这些结论给 \((\mathcal S_2,B_X)\) pair。

## 9. Spectral verdict

Fourier formalism 已把 target 压缩为一个非常具体的 theorem：

> 构造 \(\mu_X\) 与 explicit major spectrum \(\Gamma_X\)，使 minor absolute norm 达到 \(O((\log X)/\sqrt X)\)，major aligned mass bounded，并让所得 character/Bohr increment 对 affine slices of \(3^c+5^d\) hereditary。

现有估计在 scale、phase、major-spectrum complexity 与 iteration closure 四方面同时不满足。
