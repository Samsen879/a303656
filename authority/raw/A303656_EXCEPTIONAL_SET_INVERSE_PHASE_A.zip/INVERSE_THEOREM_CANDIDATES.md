# Inverse-Theorem Candidates

每个 candidate 都写成 exact theorem。`PROVED` 只用于本 bundle 内已完整证明的 implication；不把缺失 hypothesis 包装成结论。

## IT-0 — Abstract bipartite spectral localization

### Exact theorem

设 \(G\) 为 finite abelian group，\(E,B,S\subset G\)，\((E-B)\cap S=\varnothing\)。设 \(\mu\) 为 supported on \(S\) 的 probability measure，\(\alpha=|E|/|G|\)、\(\beta=|B|/|G|\)。若存在 \(\Gamma\subset\widehat G\setminus\{1\}\) 使

\[
\sup_{\gamma\notin\Gamma,\gamma\ne1}|\widehat\mu(\gamma)|
\le\tfrac12\sqrt{\alpha\beta},
\]

则

\[
\max_{\gamma\in\Gamma}|\widehat{1_E}(\gamma)|
\ge\frac{\alpha}{2L_\Gamma},
\quad
L_\Gamma=\beta^{-1}\sum_{\gamma\in\Gamma}
|\widehat\mu(\gamma)\widehat{1_B}(\gamma)|.
\]

### Status

**PROVED**, 见 `EXCEPTIONAL_SET_FORMALISM.md`。它是 elementary diagnostic lemma，不是针对真实 \(E_X\) 的 S2-specific inverse theorem；missing work 完全位于 absolute minor bound 与 major alignment。

## IT-1 — Bounded-modulus inverse theorem for \(E_X\)

### Exact target theorem

对每个 \(\delta>0\)，存在 effective constants

\[
Q(\delta)\in\mathbb N,
\qquad c(\delta)>0,
\qquad X_0(\delta),
\]

使得对每个 \(X\ge X_0(\delta)\)，若

\[
|E_X|\ge\delta X,
\]

则存在 \(2\le q\le Q(\delta)\) 与 \(r\pmod q\) 满足

\[
\frac{|E_X\cap\{n\equiv r\pmod q\}|}
{|[X,2X]\cap\{n\equiv r\pmod q\}|}
\ge \frac{|E_X|}{X+1}+c(\delta).
\tag{IT1}
\]

### Sufficient spectral theorem

IT-1 会由以下 uniform statement 推出：存在 supported on \(\mathcal S_2\cap[0,2X]\) 的 \(\mu_X\) 与 characters set \(\Gamma_X\)，使

1. 每个 \(\gamma\in\Gamma_X\) 的 order \(\le Q(\delta)\)；
2. \(L_{\Gamma_X}(\mu_X,B_X)\le L(\delta)\)；
3. \(\sup_{\gamma\notin\Gamma_X}|\widehat\mu_X(\gamma)|\le c_0\sqrt{\delta|B_X|/X}\) with sufficiently small \(c_0\).

### Status

**OPEN / NOT ESTABLISHED.** Fan–Lott 与 Ramaré–Viswanadham 都不达到 absolute scale；standard major spectra 也不 bounded。

## IT-2 — Quantitative Bohr inverse theorem

### Exact target theorem

对每个 \(\delta>0\)，存在 effective \(r(\delta)\), \(\rho(\delta)>0\), \(c(\delta)>0\) 使：若 \(|E_X|\ge\delta X\)，则存在 characters
\(\Gamma=\{\gamma_1,\dots,\gamma_k\}\)，\(k\le r(\delta)\)，以及 translate \(x_0+\operatorname{Bohr}(\Gamma,\rho)\)，满足

\[
|\operatorname{Bohr}(\Gamma,\rho)|\ge c(\delta)X
\]

且

\[
\operatorname{dens}_{x_0+\operatorname{Bohr}}
(E_X)
\ge\operatorname{dens}_{[X,2X]}(E_X)+c(\delta).
\tag{IT2}
\]

此外，characters 必须来自 explicit rational frequencies，其 denominators 有 effective bound。

### Status

**OPEN.** F3 可把 bounded aligned spectrum 转成 one-character increment；没有 theorem 把真实 cross-avoidance 转成 bounded-rank Bohr structure。即使 IT-2 成立，仍需 descendant closure 才能迭代。

## IT-3 — Residue-profile compression

### Exact target theorem

对每个 \(\delta>0\)，存在 explicit \(q\le Q(\delta)\) 与 \(\kappa(\delta)>0\)，使若 \(|E_X|\ge\delta X\)，则

\[
|E_X\bmod q^2|
\le (1-\kappa(\delta))q^2.
\tag{IT3}
\]

若还能指定 omitted residue classes 并证明它们在 rescaling 下保持 avoidance，IT-3 可触发 density increment/descent。

### Status

**NOT ESTABLISHED.** 纯 local-support 版本在 tested moduli 上失败：对全部 \(2\le q\le500\) 及 \(q=441,1089,5929\)，finite experiment 得到

\[
\mathcal S_2(q)+B_\infty(q)=\mathbb Z/q\mathbb Z,
\]

其中 \(B_\infty(q)=\{3^c+5^d\bmod q:c,d\ge0\}\)。因此任何 IT-3 必须使用 global compatibility，而非“某 residue 永远 locally impossible”的简单机制。

## IT-4 — Odd-valuation witness compression

Fermat two-square criterion 给出：若 \(m\notin\mathcal S_2\)，则存在 prime \(p\equiv3\pmod4\) 使 \(v_p(m)\) 为 odd。

### Exact target theorem

对每个 \(\delta>0\)，存在 effective finite set

\[
\mathcal P_\delta\subset\{p:p\equiv3\pmod4\},
\]

以及 \(\eta(\delta)>0\)，使若 \(|E_X|\ge\delta X\)，则存在 \(p\in\mathcal P_\delta\) 使

\[
\#\{(e,b)\in E_X\times B_X:v_p(e-b)\text{ is odd}\}
\ge\eta(\delta)|E_X||B_X|.
\tag{IT4}
\]

并且该 pair-density condition 必须推出 \(E_X\) 在 explicit classes modulo \(p^{2k}\) 上的 density increment 或 thin classification。

### Status

**OPEN; no bounded witness compression.** 对每个 pair \((e,b)\) 的 witness prime 可不同。trivial averaging 的 prime universe 随 \(X\) 增长，不能产生固定 \(p\)。前阶段 private-witness CRT constructions 说明有限 witness menu 不能由局部可满足性直接推出。

## IT-5 — Inverse sieve for \(E_X\)

### Exact target theorem

存在 \(\theta,\kappa,c>0\)，使若 \(|E_X|\ge\delta X\)，则对至少
\(c\pi(X^\theta)\) 个 primes \(p\le X^\theta\)，有

\[
|E_X\bmod p|\le(1-\kappa)p.
\tag{IT5-local}
\]

进一步，存在 bounded-degree polynomial/arithmetic family \(\mathcal A_X\) 使

\[
|E_X\setminus\mathcal A_X|=o(|E_X|),
\quad
|\mathcal A_X|\ll X^{1-\eta}.
\tag{IT5-global}
\]

### Status

**NO HYPOTHESIS BRIDGE.** 对每个 prime \(p\)，every residue is a sum of two squares modulo \(p\)；cross-avoidance 不给 \(E_X\) 的 prime-level omitted residues。Walsh、Green–Harper 与 modern combinatorial large sieve 都从 ill-distribution hypothesis 出发，而不替用户证明它。

## IT-6 — Explicit thin witness-template classification

### Exact target theorem

存在 explicit finite list of templates \(\mathfrak T_1,\dots,\mathfrak T_J\)，每个 template 由有限 primes、valuation parities 与 congruence conditions 构成，使对所有 sufficiently large \(X\)，

\[
E_X\subseteq\bigcup_{j=1}^J\mathfrak T_j(X),
\tag{IT6-cover}
\]

并且每个 template 满足以下至少一项：

1. effective count \(|\mathfrak T_j(X)|=0\) for \(X\ge X_j\)；
2. 一个 effective descent map \(n\mapsto n'<n\) 保持 exception status；
3. membership 可化为一个有 certified finite bound 的 Diophantine equation。

### Status

**OPEN.** 只有 \(|\mathfrak T_j(X)|\ll X^{1-\eta}\) 不够，因为仍可无限。现有 private-witness phenomenon 正是 IT-6 的主要障碍。

## IT-7 — Dense-model/transference at sparse-shift accuracy

### Exact target theorem

构造 \(T_{\mu_X}1_{B_X}\) 的 dense model \(F_X:G\to[0,O(\beta)]\)，使

\[
\|T_{\mu_X}1_{B_X}-F_X\|_{\mathcal U}
=o(\beta)
\tag{IT7-error}
\]

对一个足以控制 correlation with every \(1_E\) 的 norm \(\mathcal U\) 成立，并且 \(F_X\ge c\beta\) except on \(o(X)\) points。

### Status

**OPEN / SCALE MISMATCH.** standard transference 的 fixed \(o(1)\) error 不够；这里 zero-mode 是 \(\alpha\beta\)，故必须有 \(o(\beta)=o((\log X)^2/X)\) 级 error。Ramaré–Viswanadham 的 theorem 处理两个 relative-positive-density variables，不覆盖该 regime。

## Candidate ranking

1. **最有信息价值但未达 gate：IT-1**。它把目标压缩为 absolute minor spectrum + bounded alignment。
2. **若未来出现新 theorem，最可能与 IT-2/IT-7 形式接近**，但必须同时解决 closure。
3. **最可能与 descent 拼接：IT-4/IT-6**，但目前没有 finite witness compression。
4. **IT-3/IT-5 的简单 local form 已受强 no-go evidence**。

没有 candidate 达到 promotion。
