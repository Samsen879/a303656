# Reproducibility

## 1. Locked environment

见 `ENVIRONMENT_RECORD.json`。文本均为 UTF-8、LF endings；JSON 使用 sorted keys 与 2-space indentation。

## 2. Replay finite-group experiment

从 unpacked package root：

```bash
python3 scripts/finite_group_checks.py \
  --max-q 500 \
  --output results/finite_group_checks.json
sha256sum results/finite_group_checks.json
```

expected result hash：

```text
71c0bc6fb7510166709737f5d8bed40065ce791a345a3841b8a11d85f0efbdb5
```

该 script 只计算 finite cyclic residue supports，不枚举 \(T(n)\)。

## 3. Validate package

```bash
python3 scripts/validate_package.py --root .
```

validator 检查：

- required deliverables；
- `PROMOTION_VERDICT.json` exact fields；
- all JSON parse；
- finite experiment byte-identical replay in a temporary directory；
- source hash table format；
- sorted `PACKAGE_FILE_LIST.txt`；
- internal `SHA256SUMS.txt`，self-excluding checksum file；
- no promoted-route file under nonpromotion verdict。

## 4. Build deterministic ZIP

```bash
python3 scripts/build_deterministic_zip.py \
  --root . \
  --output /tmp/A303656_EXCEPTIONAL_SET_INVERSE_PHASE_A_a.zip
python3 scripts/build_deterministic_zip.py \
  --root . \
  --output /tmp/A303656_EXCEPTIONAL_SET_INVERSE_PHASE_A_b.zip
cmp /tmp/A303656_EXCEPTIONAL_SET_INVERSE_PHASE_A_a.zip \
    /tmp/A303656_EXCEPTIONAL_SET_INVERSE_PHASE_A_b.zip
sha256sum /tmp/A303656_EXCEPTIONAL_SET_INVERSE_PHASE_A_a.zip
```

ZIP policy：

- sorted paths；
- fixed timestamp `2000-01-01 00:00:00`；
- normalized regular-file modes；
- UTF-8 filenames；
- DEFLATE level 9；
- no archive comment/extra fields。

outer ZIP hash 保存在 ZIP 外部的 `.zip.sha256`，避免 self-reference。

## 5. Source verification

`SOURCE_PDF_HASHES.tsv` 锁定本轮 primary PDF bytes。source statements 的 version/theorem locator 在 `WEB_SOURCES_LOCK.json`。下载源不嵌入 package；重审者应使用 exact arXiv version 并比对 SHA256。

## 6. Input validation

`results/input_validation_summary.txt` 是本轮输入 audit 的 command transcript。它包含 uploaded SHA256、ZIP tests、positive frozen-core verifier、two replays、descent validator 与 internal manifests。
