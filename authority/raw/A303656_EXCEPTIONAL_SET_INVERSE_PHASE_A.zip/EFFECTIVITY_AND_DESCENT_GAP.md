# Effectivity and Descent Gap

## 1. \(o(X)\) 仍不等于 universal coverage

即使未来证明

\[
|E_X|=o(X),
\]

也只表示 uncovered proportion 趋于零。它允许每个 dyadic interval 恰有一个 exception，因而允许 infinitely many exceptions。

同样，任意固定 power saving

\[
|E_X|\ll X^{1-\eta}
\]

在 \(X\to\infty\) 时仍趋于无穷；它不能与 finite verification 直接拼接。

## 2. 什么形式的 theorem 才能闭合 A303656

至少需要以下四类之一。

### U1. Effective eventual emptiness

给出 explicit \(X_0\) 并证明

\[
E_X=\varnothing\qquad(X\ge X_0).
\]

然后 certified finite verification 覆盖 \(n<2X_0\)。

### U2. Effective descent

构造可验证 map \(D\)，使每个 sufficiently large exception \(n\) 产生更小 exception

\[
1<n'=D(n)<n,
\]

并保持所需 representation obstruction。minimal-counterexample argument 随即闭合。

### U3. Eventually-empty thin classification

证明 exceptions 落在 finite explicit families 中，并对每个 family 证明它在大尺度为空；仅证明 family 稀疏不够。

### U4. Effective finite reduction

把任何 counterexample 的存在压缩为某 explicit bounded domain 中 counterexample 的存在，并提供 independently checkable certificate format。

## 3. Density increment 的 effectivity requirements

要从 density increment 得出 effective exceptional-set theorem，所有下列参数都必须可计算：

- major spectrum denominator/order bound \(Q(\delta)\)；
- increment \(c(\delta)\)；
- scale loss \(\Lambda(\delta)\)；
- theorem 适用 threshold \(N_*(\delta)\)；
- descendant family description 与 membership algorithm；
- iteration depth。

如果 constants 只 existential，最多得到 qualitative density decay；不能给 finite verification cutoff。

Ramaré–Viswanadham Theorem 1.5 明确指出其 implied constant 在某些 parameter range 才可 effective computation；即使忽略 applicability mismatch，这类 effectivity caveat 也必须保留。Fan–Lott 的 power-saving constants likewise 不自动给 A303656 finite bound。

## 4. Common-residue rescaling 的 precise gap

若 \(e\equiv b\equiv r\pmod{q^2}\)，则

\[
e-b=q^2(e'-b'),
\]

且 two-square property 在乘除 square \(q^2\) 下等价。因此这是一条合法 descent symmetry。

缺失的是同时性：

1. Fourier increment 选出的 \(E\)-fiber 未必与大量 shifts 同 residue；
2. 选出 compatible shifts 后，\((3^c+5^d-r)/q^2\) 不是 original shift form；
3. 下一轮 theorem 必须对该 affine slice uniform；
4. 多次迭代的 denominator、exponent congruences 与 affine constants 会增长。

没有对这些 descendants 的 finite-state compression，不能声称 descent。

## 5. Private-witness obstruction

对每个 \((e,b)\)，非 two-square integer \(e-b\) 至少有一个 odd valuation witness prime \(p\equiv3\pmod4\)。但 witness 可依赖 pair。

一个有效 descent theorem 需要把

\[
\forall b\in B_X\ \exists p=p(e,b)
\]

压缩为类似

\[
\exists p\in\mathcal P_0\ \forall b\in B_X' 
\]

或 finite template。前阶段 CRT constructions 表明，在有限 local constraints 下可人为分配 private witnesses；因此简单 pigeonhole/residue compression 没有逻辑根据。

## 6. 与 finite verification 拼接的最低 artifact 标准

若未来 route 声称 effective exceptional-set theorem，artifact 至少应包含：

1. exact theorem with all constants and quantifiers；
2. machine-readable \(X_0\) 或 descent state bound；
3. verifier that checks each transformation without unproved heuristic；
4. independent implementation or mathematical replay for finite component；
5. authenticated input/provenance；
6. proof that finite domain covers all cases, not merely sampled cases。

本 Phase A 没有产生这样的 bound，因此没有授权新的 bounded search。

## 7. Effectivity verdict

本轮最强 exact implication是：`WF` 可推出 \(|E_X|=o(X)\)，`CROSS-MA + hereditary closure` 可推出 density contradiction。两者都未验证；即使第一项验证，也仍缺 universal descent。故 effectivity/descent gap 未闭合。
