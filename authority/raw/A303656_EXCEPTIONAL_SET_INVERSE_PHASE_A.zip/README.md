# A303656 Exceptional-Set Inverse Theorem and Density-Increment Trigger Hunt — Phase A

## 任务边界

本 bundle 只研究以下 exceptional set 的 inverse/density-increment 机制：

\[
\mathcal S_2:=\{u^2+v^2:u,v\in\mathbb Z\},\qquad
B_X:=\{3^c+5^d\le X/2:c,d\in\mathbb N_0\},
\]
\[
E_X:=\{n\in[X,2X]\cap\mathbb Z:n-b\notin\mathcal S_2\text{ for every }b\in B_X\}.
\]

已冻结的 positive-density theorem 只给出 \(|E_X|\le (1-c)X\)。本轮没有重做 second moment，也没有进行新的 bounded search 或任何 \(T(n)\) interval search。

## 最终判定

> **NO PROMOTABLE ROUTE — SPECULATIVE WATCH**

本轮证明了若干 exact Fourier identities、一个 elementary bipartite spectral localization lemma、一个 character-to-residue density increment lemma、一个 abstract iteration lemma，以及一个匹配本问题粗尺度的 cyclic-group countermodel。它们精确定位了缺失 theorem，但没有得到针对真实 \(E_X\) 的 nontrivial inverse theorem。

## 核心结论

1. 若 \(|E_X|\ge\delta X\)，把 cross-avoidance 转成常数量级 density increment 所需的 absolute minor-spectrum scale 是
   \[
   \sup_{\gamma\notin\Gamma}|\widehat\mu_X(\gamma)|
   \ll_\delta \sqrt{|B_X|/X}
   \asymp_\delta \frac{\log X}{\sqrt X}.
   \]
2. Fan–Lott 的 power-saving van der Corput weight 是 one-sided/self-difference 工具；其 minor-arc scale \(X^{-1/8+o(1)}\) 也远高于上述 threshold。
3. Ramaré–Viswanadham 的 normalized support exponential-sum bound，即使在分母最优平衡处也只有约 \(X^{-1/3}\) 乘 polylog，不能给出所需 \(X^{-1/2}\log X\) absolute gap。
4. \(E_X-B_X\) 避免 \(\mathcal S_2\) 不推出 \(E_X-E_X\) 避免 \(\mathcal S_2\)；Rice、Fan–Lott 等 self-difference theorem 不能直接套用。
5. 即使得到一次 residue-class density increment，restriction/rescaling 后的 shift family 不再是原始 \(3^c+5^d\) family；缺少 hereditary descendant theorem，无法迭代。
6. \(o(X)\) exceptional-set estimate 仍不推出 all sufficiently large；还需要 effective descent、finite reduction 或 eventually-empty thin classification。

## 文件导航

- `EXECUTIVE_VERDICT.md`：promotion gate 与最终判定。
- `EXCEPTIONAL_SET_FORMALISM.md`：finite cyclic encoding 与 exact cross identities。
- `FOURIER_AND_SPECTRAL_ANALYSIS.md`：critical scale、phase barrier、\(B_X\) spectrum。
- `INVERSE_THEOREM_CANDIDATES.md`：每个 candidate 的 exact theorem statement 与状态。
- `DENSITY_INCREMENT_CANDIDATES.md`：increment、iteration、closure defect。
- `DIFFERENCE_SET_CROSSWALK.md`：Rice/Fan–Lott/Sárközy/inverse-sieve hypotheses 对照。
- `EFFECTIVITY_AND_DESCENT_GAP.md`：从 density-zero 到 universal statement 的逻辑缺口。
- `LITERATURE_AUDIT.md`：primary-source theorem audit。
- `NO_GO_RESULTS.md`：已证明或已压力测试的 no-go statements。
- `REPORT.md`：完整 synthesis。
- `PROMOTION_VERDICT.json`：machine-readable verdict。
- `scripts/finite_group_checks.py` 与 `results/finite_group_checks.json`：只做 finite-group lemma falsification，不搜索 \(T(n)\)。

## 状态

**OEIS A303656: UNRESOLVED.**
