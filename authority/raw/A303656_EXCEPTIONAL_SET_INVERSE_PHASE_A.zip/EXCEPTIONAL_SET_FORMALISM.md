# Exceptional-Set Formalism

## 1. 基本对象

令

\[
\mathcal S_2=\{u^2+v^2:u,v\in\mathbb Z\},
\]

并对整数 \(X\ge2\) 定义

\[
D_X=\{(c,d)\in\mathbb N_0^2:3^c+5^d\le X/2\},
\]

\[
B_X=\{3^c+5^d:(c,d)\in D_X\},
\]

这里 \(B_X\) 是 distinct-value set。exceptional set 为

\[
E_X=\{n\in[X,2X]\cap\mathbb Z:
(n-B_X)\cap\mathcal S_2=\varnothing\}.
\]

等价地，\(n\notin E_X\) 当且仅当存在 \(b\in B_X\) 与 \(s\in\mathcal S_2\) 使 \(n=s+b\)。

冻结的前阶段结果给出

\[
|B_X|=\frac{(\log X)^2}{\log3\,\log5}+O(\log X),
\tag{B-size}
\]

以及 distinct-shift additive energy

\[
E^+(B_X):=\#\{b_1+b_2=b_3+b_4:b_i\in B_X\}
\ll |B_X|^2.
\tag{B-energy}
\]

这些结论在本轮作为 authenticated input 使用，不重新证明。

## 2. 无 wrap-around 的 finite cyclic encoding

取

\[
M=4X+1,
\qquad G=\mathbb Z/M\mathbb Z.
\]

把 \([0,2X]\)、\(B_X\subset[2,X/2]\) 与 \(E_X\subset[X,2X]\) 自然嵌入 \(G\)。令

\[
A_X=\mathcal S_2\cap[0,2X],\quad
f=1_{E_X},\quad g=1_{B_X},
\]

并记

\[
\alpha=\mathbb E_G f=|E_X|/M,
\qquad
\beta=\mathbb E_G g=|B_X|/M.
\]

若 \(|E_X|\ge\delta X\)，则

\[
\alpha\ge \frac{\delta X}{4X+1}\ge\delta/5.
\tag{density-embedding}
\]

取任意 probability measure \(\mu\) supported on \(A_X\)，即 \(\mu(x)\ge0\)、\(\sum_x\mu(x)=1\)。定义 averaging operator

\[
T_\mu h(x)=\sum_{y\in G}\mu(y)h(x-y).
\]

因为 \(M>4X\)，对 \(e\in E_X\) 与 \(y\in A_X\)，条件 \(g(e-y)=1\) 在 \(G\) 中等价于普通整数等式 \(y=e-b\)；不存在 wrap-around 假解。因此

\[
f(x)T_\mu g(x)=0\quad(x\in G).
\tag{cross-zero}
\]

这一步准确编码了 \(E_X-B_X\) avoidance，且没有把它误写成 \(E_X-E_X\) avoidance。

## 3. Fourier conventions

对 function \(h:G\to\mathbb C\)，令

\[
\widehat h(\gamma)=\mathbb E_{x\in G}h(x)\overline{\gamma(x)},
\]

其中 \(\gamma\in\widehat G\)。对 probability measure \(\mu\)，令

\[
\widehat\mu(\gamma)=\sum_{x\in G}\mu(x)\overline{\gamma(x)}.
\]

于是

\[
\widehat{T_\mu h}(\gamma)=\widehat\mu(\gamma)\widehat h(\gamma),
\qquad
\widehat\mu(1)=1,
\]

且 Parseval 为

\[
\langle h_1,h_2\rangle
=\sum_{\gamma\in\widehat G}
\widehat h_1(\gamma)\overline{\widehat h_2(\gamma)}.
\]

## 4. Exact cross-Fourier identity

### Theorem F1 — Cross-zero identity

在上述设定下，

\[
0=\langle f,T_\mu g\rangle
=\alpha\beta+
\sum_{\gamma\ne1}
\widehat f(\gamma)
\overline{\widehat\mu(\gamma)\widehat g(\gamma)}.
\tag{F1}
\]

### Proof

`cross-zero` 给出左端为零。trivial character 的贡献为
\(\widehat f(1)\widehat\mu(1)\widehat g(1)=\alpha\beta\)，其余项即 displayed sum。∎

这是一条 trilinear cross identity。self-difference argument 中出现的
\(|\widehat{1_A}(\gamma)|^2\) 在这里不存在。

## 5. Exact zero-set energy identity

令 \(R=T_\mu g\)。其 mean 为 \(\beta\)，且 \(R=0\) on \(E_X\)。因此：

### Theorem F2 — Spectral-energy lower bound

\[
\alpha\beta^2
\le \|R-\beta\|_2^2
=\sum_{\gamma\ne1}
|\widehat\mu(\gamma)|^2|\widehat g(\gamma)|^2.
\tag{F2}
\]

### Proof

在 \(E_X\) 上 \(|R-\beta|^2=\beta^2\)，故左不等式成立。右等式由 Parseval 与 \(\widehat R=\widehat\mu\widehat g\) 得到。∎

定义 weighted flattening variance

\[
V_X(\mu):=
\sum_{\gamma\ne1}|\widehat\mu(\gamma)|^2|\widehat g(\gamma)|^2.
\]

则 exact consequence 为

\[
|E_X|/M=\alpha\le V_X(\mu)/\beta^2.
\tag{F2-consequence}
\]

因此若能构造 \(\mu_X\) 使 \(V_X(\mu_X)=o(\beta^2)\)，便立即得到 \(|E_X|=o(X)\)。这不是已知结论；它是 missing signed/flattening estimate 的 Fourier 形式。

## 6. Bipartite spectral localization

给定 \(\Gamma\subset\widehat G\setminus\{1\}\)，定义

\[
\eta(\Gamma)=\sup_{\gamma\notin\Gamma,\ \gamma\ne1}
|\widehat\mu(\gamma)|,
\]

以及 \(B\)-aligned major mass

\[
L_\Gamma(\mu,B)=
\frac1\beta
\sum_{\gamma\in\Gamma}
|\widehat\mu(\gamma)\widehat g(\gamma)|.
\]

### Theorem F3 — Exact bipartite inverse inequality

\[
\sum_{\gamma\in\Gamma}
|\widehat f(\gamma)|
|\widehat\mu(\gamma)|
|\widehat g(\gamma)|
\ge
\alpha\beta-\eta(\Gamma)\sqrt{\alpha\beta}.
\tag{F3}
\]

若

\[
\eta(\Gamma)\le\frac12\sqrt{\alpha\beta},
\tag{minor-threshold}
\]

则

\[
\max_{\gamma\in\Gamma}|\widehat f(\gamma)|
\ge \frac{\alpha}{2L_\Gamma(\mu,B)}.
\tag{F3a}
\]

特别地，若 \(|\Gamma|\le K\)，则 \(L_\Gamma\le K\)，故

\[
\max_{\gamma\in\Gamma}|\widehat f(\gamma)|
\ge \frac{\alpha}{2K}.
\tag{F3b}
\]

### Proof

由 F1 与 triangle inequality，全部 nontrivial spectrum 的 absolute trilinear mass 至少为 \(\alpha\beta\)。在 \(\Gamma\) 外，Cauchy–Schwarz 与 Parseval 给出

\[
\sum_{\gamma\notin\Gamma,\gamma\ne1}
|\widehat f||\widehat\mu||\widehat g|
\le
\eta(\Gamma)
\Big(\sum|\widehat f|^2\Big)^{1/2}
\Big(\sum|\widehat g|^2\Big)^{1/2}
\le\eta(\Gamma)\sqrt{\alpha\beta}.
\]

这证明 F3。若 `minor-threshold` 成立，major mass 至少 \(\alpha\beta/2\)；再用 \(L_\Gamma\) 定义得到 F3a。因为 \(|\widehat\mu|\le1\)、\(|\widehat g|\le\beta\)，有 \(L_\Gamma\le|\Gamma|\)，从而 F3b。∎

**Interpretation.** F3 是一个 exact abstract lemma；真正困难是为 sums-of-two-squares measure 证明 `minor-threshold`，并使 \(L_\Gamma\) 与 character orders 可控。

## 7. Character-to-residue density increment

### Theorem F4 — Explicit fiber increment

设 character \(\chi\) 的 order 为 \(q\)，并令 \(\alpha_r\) 为 \(E\) 在 fiber
\(\{x:\chi(x)=e(r/q)\}\) 上的 relative density。若

\[
|\widehat f(\chi)|\ge\rho\alpha,
\]

则存在 \(r\in\mathbb Z/q\mathbb Z\) 使

\[
\alpha_r\ge\alpha+\frac12\rho\alpha
=\alpha(1+\rho/2).
\tag{F4}
\]

### Proof

写 \(d_r=\alpha_r-\alpha\)。则 \(\sum_r d_r=0\)，且

\[
\widehat f(\chi)=q^{-1}\sum_r d_r e(-r/q).
\]

故

\[
|\widehat f(\chi)|
\le q^{-1}\sum_r|d_r|
=2q^{-1}\sum_{d_r>0}d_r
\le2\max_r d_r.
\]

结论随即成立。∎

结合 F3b，若 \(|\Gamma|\le K\)，则某 fiber 的 density 至少

\[
\alpha\left(1+\frac1{4K}\right).
\]

## 8. 无额外 arithmetic input 时能强制出的最大信息

取 \(\mu\) 为 \(A_X\) 上的 uniform probability measure，令 \(s=|A_X|\)、\(m=|B_X|\)。由 F1、Cauchy–Schwarz 与 measure Parseval，必有

\[
\max_{\gamma\ne1}
\frac{|\widehat f(\gamma)|}{\alpha}
\ge \frac{\sqrt{sm}}{M}.
\tag{generic-certificate}
\]

Landau–Ramanujan scale 给出 \(s\asymp X/\sqrt{\log X}\)，而 \(m\asymp(\log X)^2\)，所以右端仅为

\[
\asymp \frac{(\log X)^{3/4}}{\sqrt X}.
\]

它趋于零；即使转成 residue increment，也不是可迭代的 constant increment。

## 9. Formalism 的逻辑边界

- F1–F4 不使用 \(\mathcal S_2\) 的特殊 arithmetic，只使用 support avoidance。
- 它们不能把 one-sided lower Fourier bound 自动升级为 absolute minor-arc bound。
- 它们只给 \(E\) 的 fiber increment，不保证 shift family 在该 fiber 下封闭。
- 它们不能由 \(|E_X|=o(X)\) 推出 \(E_X=\varnothing\) for all large \(X\)。
