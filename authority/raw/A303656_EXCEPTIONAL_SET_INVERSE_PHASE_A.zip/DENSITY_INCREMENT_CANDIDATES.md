# Density-Increment Candidates

## 1. 一次 increment：已证明

由 `EXCEPTIONAL_SET_FORMALISM.md` 的 F3–F4：若 cross spectrum 集中在 \(K\) 个 characters，minor absolute norm 达到 critical scale，则某 character fiber 上

\[
\alpha'\ge\alpha\left(1+\frac1{4K}\right).
\tag{DI-one-step}
\]

若 character order \(q\) bounded，这确实是 explicit modulus quantitative density increment。

问题不在 one-step algebra，而在：

1. 是否能从真实 sums-of-two-squares spectrum 得到 bounded \(K\)/alignment；
2. restrict/rescale 后是否仍属于可再次应用同一 theorem 的 class。

## 2. Abstract iteration theorem

### Theorem DI-ITER

设 \(\mathfrak C\) 是一类带 scale \(N\) 与 density \(\alpha\) 的 objects。假设存在 constants \(\kappa>0\)、\(\Lambda\ge2\)、\(N_*\)，使每个 \((\mathcal O,N,\alpha)\in\mathfrak C\) with \(N\ge N_*\)、\(0<\alpha\le1\) 都产生 descendant

\[
(\mathcal O',N',\alpha')\in\mathfrak C
\]

满足

\[
N'\ge N/\Lambda,
\qquad
\alpha'\ge(1+\kappa)\alpha.
\]

令

\[
J=\left\lceil
\frac{\log(1/\alpha)}{\log(1+\kappa)}
\right\rceil+1.
\]

若 \(N\ge N_*\Lambda^J\)，则这样的 object 不存在。

### Proof

迭代 \(J\) 次仍保持 scale 至少 \(N_*\)，而 density 至少
\((1+\kappa)^J\alpha>1\)，矛盾。∎

DI-ITER 清楚说明：**hereditary class 是 density increment 的必要组成，不是附加美化。**

## 3. A303656 triple 不具有已知 hereditary closure

若在 modulo \(q^2\) 的某 class \(r\) 上同时 restrict

\[
e=r+q^2e',\qquad b=r+q^2b',
\]

则

\[
e-b=q^2(e'-b').
\]

因为 \(q^2m\in\mathcal S_2\iff m\in\mathcal S_2\)，two-square avoidance 在这种 common-residue rescaling 下保持。

但 one-character density increment 只说明很多 \(e\in E_X\) 落在一个 class；它不说明很多 \(b\in B_X\) 落在同一个 class。即使强行选择一个 shift residue class，descendant shift set 变成

\[
B'=
\left\{
\frac{3^c+5^d-r}{q^2}:
3^c+5^d\equiv r\pmod{q^2},\ 3^c+5^d\le X/2
\right\}.
\tag{affine-slice}
\]

这不是原始 form \(\{3^{c'}+5^{d'}\}\)。exponent congruence conditions 由 multiplicative orbits 决定；多次迭代产生 increasingly complicated affine S-unit slices。

因此要使用 DI-ITER，必须把 theorem 扩展到一个 hereditary family

\[
\mathfrak B=
\left\{
\frac{3^c+5^d-a}{Q^2}:
(c,d)\in\Omega,
\ Q^2\mid3^c+5^d-a
\right\}
\]

并对所有 iterated descendants 保持 uniform constants。当前没有这样的 theorem。

## 4. Candidate DI-1 — Bounded-order spectral increment

### Exact theorem

对每个 \(\delta>0\) 存在 \(Q,K,c>0\)，使任何 density \(\ge\delta\) 的 exceptional object in a hereditary descendant class 都存在 order \(q\le Q\) character with

\[
|\widehat{1_E}(\chi)|\ge c\alpha.
\]

### Payoff

F4 给出 multiplicative increment \(1+c/2\)，DI-ITER 给 contradiction。

### Status

**CORE LEMMA OPEN + DESCENDANT CLASS UNBUILT.**

## 5. Candidate DI-2 — \(q^2\)-compatible common-fiber increment

### Exact theorem

若 \(|E_X|\ge\delta X\)，则存在 \(q\le Q(\delta)\)、\(r\pmod{q^2}\) 使

\[
\operatorname{dens}(E_X\mid r\bmod q^2)
\ge(1+c(\delta))\operatorname{dens}(E_X),
\]

且

\[
|B_X\cap(r\bmod q^2)|
\ge c_B(\delta)|B_X|,
\]

并且 rescaled pair \((E',B')\) belongs to the same theorem class with scale \(\gg X/q^2\)。

### Status

**NOT ESTABLISHED.** 第二、第三 clauses 不是由 Fourier coefficient of \(E_X\) 自动得到的。\(B_X\) 在 fixed residue class 中可能只保留约 \(|B_X|/q^2\)，且 family shape 改变。

## 6. Candidate DI-3 — Bohr-set increment

### Exact theorem

存在 rank \(r=O_\delta(1)\)、radius \(\rho\gg_\delta1\) 的 Bohr set \(\mathcal B\)，\(|\mathcal B|\gg_\delta X\)，使某 translate 上 \(E_X\) density 增加 \(c(\delta)\)，并且 \(B_X\) 的 compatible slice/rescaling 仍属于 hereditary class。

### Status

**OPEN.** 普通 Bohr increment 不提供 integer affine rescaling，更不提供 S-unit shift closure。若 radius 或 rank 随 \(X\) 退化，iteration 也失效。

## 7. Candidate DI-4 — Fan–Lott/Sárközy transfer

### Proposed but invalid implication

\[
(E_X-B_X)\cap\mathcal S_2=\varnothing
\quad\Longrightarrow\quad
(E_X-E_X)\cap\mathcal S_2=\varnothing.
\]

### Status

**FALSE AS AN INFERENCE.** 对 fixed \(b\)，translated set \(E_X-b\) 的 difference set 仍是 \(E_X-E_X\)；exception condition 只说每个 point \(e-b\) 不在 \(\mathcal S_2\)，不说两个 such points 的 difference 不在 \(\mathcal S_2\)。因此 Rice/Fan–Lott self-difference density increment 不会被触发。

## 8. Candidate DI-5 — Energy-driven bounded spectrum

### Exact desired implication

\[
E^+(B_X)\ll|B_X|^2
\quad\Longrightarrow\quad
\text{cross zero-mode is carried by }O_\delta(1)
\text{ characters}.
\tag{bad-implication}
\]

### Status

**NOT VALID.** energy 只给

\[
|\operatorname{Spec}_\rho(B_X)|
\ll X/(\rho^4\log^4X),
\]

其上界仍增长。Sidon-like sets 可有广泛 dispersed spectrum；低 energy 不产生 bounded major spectrum。

## 9. Candidate DI-6 — Vanishing increment from generic certificate

由 generic Fourier certificate，relative coefficient 只有

\[
\rho_X\asymp(\log X)^{3/4}/\sqrt X.
\]

F4 给 relative density gain \(1+O(\rho_X)\)。要把 fixed density 推过 1，粗略需要 \(\gg1/\rho_X\) 次 steps，即

\[
\gg\frac{\sqrt X}{(\log X)^{3/4}}
\]

次。任何每步至少除以 2 的 scale loss 会在 \(O(\log X)\) 次后耗尽 interval。因此 generic increment 不可迭代。

## 10. Candidate DI-7 — Complete conditional theorem `CROSS-MA`

### Conditional theorem

固定 \(\delta>0\)。设存在 hereditary class \(\mathfrak C_\delta\)，包含所有 A303656 exceptional triples 及其 compatible affine descendants，并有 constants \(Q,L,c_0,\Lambda\) 满足：对每个 object \((E,B,S;N)\in\mathfrak C_\delta\) with density \(\alpha\ge\delta\)，存在 supported on \(S\) 的 probability measure \(\mu\) 与 characters \(\Gamma\) 使

1. orders of \(\Gamma\) are at most \(Q\)；
2. \(L_\Gamma(\mu,B)\le L\)；
3. \(\sup_{\gamma\notin\Gamma}|\widehat\mu(\gamma)|\le\tfrac12\sqrt{\alpha\beta}\)；
4. F3/F4 所给 enriched fiber 产生 descendant in \(\mathfrak C_\delta\) with scale \(N'\ge N/\Lambda\)。

则对 sufficiently large effective \(N\)，不存在 density \(\ge\delta\) 的 objects；特别地 \(|E_X|<\delta X\)。若 hypotheses 对任意 \(\delta>0\) uniform/effective 成立，则 \(|E_X|=o(X)\)。

### Proof

F3 gives \(|\widehat{1_E}(\chi)|\ge\alpha/(2L)\) for some \(\chi\in\Gamma\)。F4 gives descendant density at least \(\alpha(1+1/(4L))\)。Clause 4 preserves class and scale；apply DI-ITER。∎

### Promotion assessment

这是一个完整 conditional theorem，但不 promotion。Clauses 2–4 包含当前所有核心困难，尤其 absolute critical-scale estimate 与 hereditary closure；它们并未被证明，也不能称为“明显弱于 A303656”的可验证 hypothesis。

## 11. Density-increment verdict

one-step trigger 已形式化并证明；iteration trigger 未找到。没有 closure 的 density increment 只有 local information，不具 universal leverage。
