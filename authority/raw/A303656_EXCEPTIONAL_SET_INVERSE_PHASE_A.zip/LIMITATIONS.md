# Limitations

1. 没有证明针对真实 \(E_X\) 的 inverse theorem。
2. finite-group countermodel只排除依赖粗统计的 universal argument；它不模拟 sums-of-two-squares 的全部 arithmetic。
3. residue experiment只覆盖 \(q\le500\) 与三个 selected moduli；不能外推到 all moduli。
4. literature audit 截止 2026-07-18，不声称 exhaustive across unpublished manuscripts。
5. Fan–Lott/Ramaré quantitative comparison是 applicability barrier，不是对其 theorem 的改进或反驳。
6. abstract `CROSS-MA` theorem把 missing hypotheses显式化；没有证明这些 hypotheses 比 A303656 更容易。
7. \(|E_X|=o(X)\) criterion `WF` 是 sufficient condition，不是已验证 estimate。
8. no exact finite cutoff、descent map 或 thin-family classification was produced。
9. no Codex、Ultra、repository integration 或 new bounded search was used。
10. **OEIS A303656 remains unresolved.**
