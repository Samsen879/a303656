# Literature audit

## 1. Audit scope and standard

检索日期：**2026-07-16**。

本审计只记录能够影响本项目 route decision 的结果。技术结论优先取自 original papers、official arXiv versions 或作者主页版本；survey 仅用于定位 theorem 与 constants。每项均检查：

1. theorem 的 exact regime；
2. constants 是否 explicit/effective；
3. 是否同时适用于两个可能不同的 subgroups \(H=\langle3\rangle\)、\(K=\langle5\rangle\)；
4. 是否适用于 \(\mathbb F_p\) 之外的 \(\mathbb Z/p^2\mathbb Z\)；
5. 是否能改善本项目的 elementary order bound；
6. 是否依赖 GRH 或其他 unproved assumptions。

结论先行：现有 subgroup sumset / exponential-sum literature 提供 genuine cancellation，但没有发现一个同时满足“explicit、two-subgroup、\(p^2\)-compatible、在本项目 order regimes 实际优于 \(1/\max(m,n)\)”的 theorem。

---

## 2. Applicable exact identities

### 2.1 Fourier/Parseval identity for cross additive energy

For finite subsets \(A,B\) of a finite abelian group \(G\),

\[
E_+(A,B)=\sum_x(1_A*1_B)(x)^2
=\frac1{|G|}\sum_{\xi\in\widehat G}
|\widehat{1_A}(\xi)|^2|\widehat{1_B}(\xi)|^2.
\]

A convenient primary-source formulation appears in Schoen–Shkredov, *On a question of Cochrane and Pinner concerning multiplicative subgroups*, arXiv:1008.0723, equations (8)–(9).

**Applicability.** Exact for two different sets \(A,B\), including \(H,K\subset\mathbb F_p\). It supplies the correct centered-energy decomposition used in this package. It is an identity, not a cancellation theorem. On \(\mathbb Z/p^2\mathbb Z\), the same finite-abelian-group identity remains valid, but subgroup-specific bounds do not automatically transfer.

**Assumptions:** none beyond finiteness.  
**Constants:** exact.  
**GRH:** no.  
**Verdict:** **USED / PROVED framework**, but no pointwise gain by itself.

---

## 3. Multiplicative-subgroup energy and sumset bounds over \(\mathbb F_p\)

### 3.1 Heath-Brown–Konyagin energy scale

Schoen–Shkredov record the consequence

\[
E_+(R)\ll |R|^{5/2},
\qquad |R|=O(p^{2/3}),
\]

for a multiplicative subgroup \(R\subset\mathbb F_p^*\), tracing it to Heath-Brown and Konyagin, *New bounds for Gauss sums derived from \(k\)-th powers, and for Heilbronn's exponential sum*, Q. J. Math. **51** (2000), 221–235.

For two different subgroups, Cauchy–Schwarz gives only

\[
E_+(H,K)^2\le E_+(H)E_+(K).
\]

Combining the displayed energy scales yields a pointwise Cauchy estimate with normalized size roughly \((|H||K|)^{-3/8}\). This is weaker than the elementary bound \(1/\max(|H|,|K|)\) throughout the symmetric regime and cannot pass Gate A even before tracking the implicit constant.

**Assumptions:** subgroup(s) in \(\mathbb F_p^*\); the stated energy scale requires size \(O(p^{2/3})\).  
**Constants:** implicit, not supplied in a form useful for the small/medium primes here.  
**Two different subgroups:** only after an additional Cauchy step.  
**\(p^2\):** no.  
**Uniform in \(p\):** asymptotically yes with implicit constants, but not explicit enough for finite certification.  
**GRH:** no.  
**Verdict:** **AUDITED / NOT USEFUL** for local maximum coverage.

### 3.2 Improved sumset bounds of Schoen–Shkredov

Schoen–Shkredov prove stronger lower bounds for \(|R\pm R|\) when

\[
p^\varepsilon\le |R|\le p^{2/3-\varepsilon},
\]

with a gain \(\delta(\varepsilon)>0\). These are genuine sum-product results. However, a large sumset does not give the required uniform bound on

\[
\max_a(1_H*1_K)(a),
\]

especially for two different subgroups. The theorem also does not handle the punctured \(p^2\)-fiber correction \(N_{p,a}-N^{(2)}_{p,b}\).

**Constants:** asymptotic/implicit.  
**Two different subgroups:** not in the needed convolution-maximum form.  
**\(p^2\):** no.  
**GRH:** no.  
**Verdict:** **RELATED BUT LOGICALLY INSUFFICIENT**.

---

## 4. Exponential sums over small multiplicative subgroups

### 4.1 Bourgain–Glibichuk–Konyagin (BGK)

The BGK theorem, as stated in Kowalski's 2024 expository account, says: for every \(\gamma>0\), there exists \(\nu(\gamma)>0\) such that every subgroup \(H\subset\mathbb F_p^*\) with \(|H|\ge p^\gamma\) satisfies

\[
\max_{a\ne0}
\left|\sum_{x\in H}e(ax/p)\right|
\ll_\gamma |H|p^{-\nu(\gamma)}.
\]

The original source is Bourgain–Glibichuk–Konyagin, *Estimates for the number of sums and products and for exponential sums in fields of prime order*, J. London Math. Soc. **73** (2006), 380–398.

Kowalski notes that \(\nu\) can in principle be made explicit, but also explicitly states that the constants in the final estimate were not tracked in the exposition. Even an effective BGK bound for each of \(H,K\) would still need a careful product-Fourier calculation and an explicit crossover showing a gain over \(1/\max(m,n)\) at the actual orders. No such crossover was found for the present data.

**Assumptions:** one multiplicative subgroup of \(\mathbb F_p^*\), size at least \(p^\gamma\).  
**Constants:** depend on \(\gamma\); not practically explicit in the audited formulation.  
**Two different subgroups:** can be inserted into a Fourier product only after separate bounds; no direct optimal cross-convolution theorem.  
**\(p^2\):** no.  
**Uniform in \(p\):** asymptotic for fixed \(\gamma\).  
**GRH:** no.  
**Verdict:** **THEORETICALLY NONTRIVIAL, PRACTICALLY NON-PROMOTING**.

### 4.2 Square-root and classical Gauss-sum bounds

Classical Gauss-sum estimates give \(O(\sqrt p)\) for nontrivial Fourier coefficients after character decomposition. They become nontrivial relative to \(|H|\) only when \(|H|\gg\sqrt p\). In the present local maximum problem, that does not uniformly beat the order bound, and many relevant orders lie below or around this threshold.

**Verdict:** **INSUFFICIENT AS A UNIFORM LOCAL THEOREM**.

---

## 5. Results modulo \(p^2\)

### 5.1 Shkredov's Heilbronn subgroup estimate

Shkredov's notes, *An introduction to higher energies and sumsets*, arXiv:1512.00627, prove for the special subgroup

\[
\Gamma=\{m^p\bmod p^2:1\le m\le p-1\}
\subset (\mathbb Z/p^2\mathbb Z)^*
\]

that

\[
E_3(\Gamma)\ll p^3\log p.
\]

This is a genuine \(p^2\)-level result, but \(\Gamma\) is the Heilbronn subgroup of order \(p-1\). The orbits generated by 3 and 5 modulo \(p^2\) are arbitrary cyclic subgroups whose orders vary with \(p\); they need not equal \(\Gamma\), nor does the theorem directly control cross convolution between them.

**Assumptions:** the very specific Heilbronn subgroup.  
**Constants:** implicit.  
**Two different subgroups:** no.  
**Uniform arbitrary \(p^2\)-subgroups:** no.  
**GRH:** no.  
**Verdict:** **NOT TRANSFERABLE TO THE REQUIRED \(p^2\) FIBERS**.

### 5.2 Audit conclusion for \(p^2\)

No primary-source theorem was found that gives an explicit pointwise bound for

\[
1_{\langle3\rangle_{p^2}}*1_{\langle5\rangle_{p^2}}
\]

uniformly over eligible primes, with constants strong enough to improve the elementary local bound after the persistent-fiber subtraction. This is a genuine literature gap for the present application, not evidence that such a theorem is impossible.

Classification: **UNKNOWN** whether a sufficiently sharp specialized theorem can be proved; **NOT FOUND** in the audited literature.

---

## 6. Extremal additive structure in multiplicative subgroups

Alon–Bourgain, *Additive Patterns in Multiplicative Subgroups*, construct infinitely many sum-free multiplicative subgroups of size \(\Omega(p^{1/3})\) in prime fields. This does not give a direct upper bound on \(1_H*1_K\), but it is an important adversarial warning: multiplicative subgroups can have highly non-random additive structure well inside polynomial-size regimes.

**Relevance:** it undermines any unproved assumption that subgroup sums are automatically equidistributed at the sizes encountered here.  
**Two different subgroups / \(p^2\):** no.  
**GRH:** the paper uses analytic number theory for its constructions, but the cited existence statement is unconditional.  
**Verdict:** **CONTEXTUAL WARNING**, not a usable inequality.

---

## 7. Mertens products in arithmetic progressions

Williams, *Mertens' theorem for arithmetic progressions*, J. Number Theory **6** (1974), 353–359, proves for a fixed reduced progression \(l\bmod k\) an asymptotic of the form

\[
\prod_{\substack{p\le x\\p\equiv l\ (k)}}
\left(1-\frac1p\right)
= C(k,l)(\log x)^{-1/\varphi(k)}
\left(1+O_k\!\left(\frac1{\log x}\right)\right),
\]

with an explicit character-product expression for \(C(k,l)\).

For eligible primes \(p\equiv3\pmod4\), omitting \(p=3\), this gives decay on the scale \((\log x)^{-1/2}\). Since

\[
\frac{1-(p-1)/p^2}{1-1/p}
=1+\frac1{p(p-1)},
\]

whose product converges, the random-CRT survival product has the same logarithmic order.

**Assumptions:** fixed progression, unconditional.  
**Constants:** expressed through Dirichlet \(L\)-values; finite effective calibration still requires computation.  
**GRH:** no.  
**Verdict:** **USED FOR ASYMPTOTIC SCALE ONLY**. The package's strongest full-torus obstruction needs only ordinary Mertens and is proved without this sharper progression-specific form.

---

## 8. Random covering inequalities

### 8.1 Janson inequalities

Riordan–Warnke, *The Janson inequalities for general up-sets*, Random Structures & Algorithms **46** (2015), 391–395, extend Janson inequalities from principal up-sets to arbitrary up-sets under a positive-correlation framework.

Here the underlying coordinate \(t_p\) is categorical with \(p^2\) mutually exclusive values, and the survivor/blocking events have both positive and negative pair correlations depending on the congruence type. They are not a natural family of increasing up-sets in a product Boolean lattice. Re-encoding a categorical variable into Bernoulli variables introduces hard exclusivity constraints and does not restore the hypotheses.

**Verdict:** **HYPOTHESES FAIL / NOT A ROUTE TO OPTIMIZED ANTI-COVER**.

### 8.2 Chen–Stein

Arratia–Goldstein–Gordon, *Two moments suffice for Poisson approximations: the Chen–Stein method*, Ann. Probab. **17** (1989), 9–25, give total-variation bounds in terms of local dependence neighborhoods and quantities \(b_1,b_2,b_3\).

In this project each survivor indicator \(Y_u\) depends on every prime coordinate. Two exponent identities generally share all coordinates, so the natural dependency graph is complete. Taking the whole index set as every dependence neighborhood makes \(b_1,b_2\) quadratic and destroys a useful Poisson approximation. High-correlation duplicate-shift clusters create additional clumping.

Even a valid approximation to the distribution of random \(U\) would not control \(\min_{\mathbf t}U(\mathbf t)\).

**Verdict:** **NO SPARSE DEPENDENCY / WRONG TARGET QUANTIFIER**.

### 8.3 Suen inequality

Suen's correlation inequality for sums of Bernoulli variables is likewise formulated through a dependency graph and parameters measuring local dependence. The same complete-dependency obstruction applies. Any nontrivial application would first require a new cluster decomposition that is itself the missing theorem.

**Verdict:** **NOT USEFUL WITHOUT NEW STRUCTURE**.

### 8.4 Lovász local lemma and Shearer criterion

The LLL proves existence of an assignment avoiding a collection of low-probability bad events under sparse dependency. For anti-cover, the desired statement is that **every** residue tuple leaves a survivor, not that there exists a tuple with some avoidance property. Moreover, the survivor events depend on all prime coordinates, giving complete dependency.

**Verdict:** **WRONG EXISTENTIAL DIRECTION AND WRONG DEPENDENCY GEOMETRY**.

---

## 9. Covering, LP, Delsarte, entropy, and SDP literature

### 9.1 Fractional covering / LP duality

Finite hypergraph covering has an exact LP dual. In the colored setting here, the relaxation used in `anti_cover_inequalities.md` is elementary finite-dimensional duality and requires no unproved assumptions. Its weakness is computational state size and integrality, not validity.

**Constants:** exact for a frozen finite instance when a rational certificate is exported.  
**Scalability:** no theorem was found that compresses the joint signature multiset uniformly across expanding prime families.  
**Verdict:** **VALID FINITE TOOL, NO FAMILY LEVERAGE**.

### 9.2 Delsarte linear programming

Delsarte's association-scheme method converts symmetry-invariant code/packing problems to low-dimensional LPs. Each local survivor matrix here has a three-eigenspace algebra, but the joint signature histogram of \(3^c+5^d\) is not invariant under the full local association scheme. Therefore the optimized covering problem does not collapse to three parameters per prime.

**Verdict:** **FORMAL ANALOGY ONLY; REQUIRED SYMMETRY ABSENT**.

### 9.3 Entropy and Shearer-type inequalities

Marginal entropy can show that many joint signatures occur, but high entropy does not exclude a rare optimized residue tuple covering every identity. A uniform anti-cover needs pointwise control or an integral covering gap.

**Verdict:** **AVERAGE INFORMATION DOES NOT CONTROL THE EXTREMAL TUPLE**.

### 9.4 Semidefinite hierarchies

An SDP/Sum-of-Squares hierarchy can encode codegrees and higher intersections. Without a bounded-level theorem, increasing the hierarchy converges toward the original exact covering problem. No low-degree uniform certificate was identified.

**Verdict:** **NO THEOREM PAYOFF AT IDENTIFIED STATE SIZE**.

---

## 10. Literature-to-route conclusion

The audited literature supports three rigorous conclusions:

1. Fourier/energy identities are exactly the right language for the local fibers.
2. Existing uncentered energy and subgroup-sumset bounds do not beat the elementary local order bound in the regime and normalization relevant here.
3. Known \(p^2\)-results are too specialized to control the two cyclic orbits generated by 3 and 5.

It does **not** support any of the following required promotion claims:

* an explicit uniform local theorem stronger than \(1/\max(m,n)\);
* a positive lower bound on intersections for adversarial residue choices;
* a realistic probabilistic cover criterion for the full periodic lattice;
* a Janson/Chen–Stein/LLL bridge from random tuples to the optimized tuple.

Accordingly the literature audit supports the route verdict **STOP ANALYTIC BAD-PRIME ROUTE**, while leaving open the possibility of a future, highly specialized centered \(p^2\)-Fourier theorem.

---

## 11. Primary references

1. N. Alon and J. Bourgain, *Additive Patterns in Multiplicative Subgroups*.
2. R. Arratia, L. Goldstein, and L. Gordon, *Two moments suffice for Poisson approximations: the Chen–Stein method*, Ann. Probab. 17 (1989), 9–25.
3. J. Bourgain, A. Glibichuk, and S. Konyagin, *Estimates for the number of sums and products and for exponential sums in fields of prime order*, J. London Math. Soc. 73 (2006), 380–398.
4. D. R. Heath-Brown and S. V. Konyagin, *New bounds for Gauss sums derived from \(k\)-th powers, and for Heilbronn's exponential sum*, Q. J. Math. 51 (2000), 221–235.
5. E. Kowalski, *Exponential sums over small subgroups, revisited* (2024 expository manuscript).
6. O. Riordan and L. Warnke, *The Janson inequalities for general up-sets*, Random Structures & Algorithms 46 (2015), 391–395; arXiv:1203.1024.
7. T. Schoen and I. D. Shkredov, *On a question of Cochrane and Pinner concerning multiplicative subgroups*, arXiv:1008.0723.
8. I. D. Shkredov, *An introduction to higher energies and sumsets*, arXiv:1512.00627.
9. S. Janson, *New versions of Suen's correlation inequality*, Random Structures & Algorithms 13 (1998), 467–483.
10. J. B. Shearer, *On a problem of Spencer*, Combinatorica 5 (1985), 241–245.
11. K. S. Williams, *Mertens' theorem for arithmetic progressions*, J. Number Theory 6 (1974), 353–359.
12. P. Delsarte, *An algebraic approach to the association schemes of coding theory*, Philips Research Reports Supplements 10 (1973).
