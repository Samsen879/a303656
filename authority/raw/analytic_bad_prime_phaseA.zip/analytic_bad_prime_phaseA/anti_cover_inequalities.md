# Anti-cover inequalities

## 1. Deterministic union bound

Let \(\mathcal D\) be any finite domain on which all local covered sets are defined, and let

\[
\alpha_p^{\max}=
\max_{t_p}\frac{|C(p,t_p)|}{|\mathcal D|}.
\]

For every residue tuple \(\mathbf t\),

\[
\left|\bigcup_{p\in\mathcal P}C(p,t_p)\right|
\le\sum_{p\in\mathcal P}|C(p,t_p)|
\le |\mathcal D|\sum_{p\in\mathcal P}\alpha_p^{\max}.
\]

Hence

\[
\boxed{
\frac{U(\mathbf t)}{|\mathcal D|}
\ge 1-\sum_{p\in\mathcal P}\alpha_p^{\max}.}
\]

On a joint exponent torus, the local density for prime \(p\) equals the density on its own local torus, because projection onto \(\mathbb Z/r_p\times\mathbb Z/s_p\) has constant fibers. Therefore the exact single-prime values may be inserted into the family union bound.

Using the elementary order estimate gives the fully analytic but weaker form

\[
\boxed{
\frac{U(\mathbf t)}{|\mathcal D|}
\ge 1-
\sum_{p\in\mathcal P}
\frac1{\max(\operatorname{ord}_p(3),\operatorname{ord}_p(5))}.}
\]

These inequalities have the correct adversarial quantifier: they hold for **every** residue choice.

## 2. Exact finite anti-cover for eligible primes \(p\le200\)

For all 23 eligible primes \(p\le200\), exact local computation gives

\[
\sum_{p\le200}\alpha_p^{\max}
=0.6144687686816598066\ldots.
\]

Therefore, on their full joint exponent torus, every residue tuple leaves at least

\[
\boxed{
0.3855312313183401933\ldots
}
\]

of all exponent-pair identities uncovered.

The exact rational numerator and denominator are stored in `results/scaling_summary.json`. The corresponding sum of elementary order bounds is

\[
0.7822315517595062121\ldots,
\]

which still gives a positive lower bound but loses substantially more.

Classification:

> **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**, combined with a **PROVED** union inequality.

This is not promotion Gate B. It concerns one fixed finite family; no theorem shows that the sum remains below one along an expanding family.

## 3. Inclusion--exclusion needs minimum, not average, overlap

A second-order upper bound on the union would require a residue-uniform lower bound on intersections. For \(k=|\mathcal P|\), if one had

\[
S_2(\mathbf t)=\sum_{p<q}|C(p,t_p)\cap C(q,t_q)|,
\]

then the pointwise inequality

\[
1_{\cup C_p}
\le r-\frac{r(r-1)}{k}
\quad (r=\text{number of covering sets containing the point})
\]

implies

\[
\left|\bigcup_pC_p\right|
\le \sum_p|C_p|-\frac{2}{k}S_2.
\]

This is useful only if \(S_2\) has a positive lower bound valid for all optimized residue choices.

Random residues give the average intersection

\[
\mathbb E_{t_p,t_q}|C(p,t_p)\cap C(q,t_q)|
=q_pq_q|\mathcal D|,
\]

but average intersection has the wrong quantifier.

## 4. Exact failure of pairwise minimum-overlap strategy

Two joint tori were small enough for exhaustive pairwise residue enumeration.

| family | torus size | mean intersection | exact minimum | residue pairs with zero intersection |
|---|---:|---:|---:|---:|
| \(\{7,11\}\) | 485,100 | 4,909.0909 | 0 | 539 |
| \(\{11,23\}\) | 3,200,450 | 11,000 | 0 | 5,819 |

Classification:

> **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**.

Thus even when average intersections are macroscopic, optimized residues can make a pairwise intersection empty. No positive pairwise lower bound depending only on \(q_p,q_q\), local means, or local second moments is possible in general.

This directly blocks an average inclusion--exclusion argument.

## 5. Spectral lower bound

Let \(f\) be the joint shift-signature histogram in CRT space, let

\[
S=\bigotimes_{p\in\mathcal P}S_p,
\qquad Q=\prod_pp^2,
\]

and write

\[
f=\frac{|\mathcal D|}{Q}\mathbf1+g,
\qquad \langle g,\mathbf1\rangle=0.
\]

The largest nonconstant singular value of \(S\) is

\[
\sigma_*=
\left(\prod_p(p^2-p+1)\right)
\max_p\frac{p-1}{p^2-p+1}.
\]

Since \(U=Sf\),

\[
\boxed{
\min_{\mathbf t}U(\mathbf t)
\ge |\mathcal D|\prod_p\frac{p^2-p+1}{p^2}
-
\sigma_*\left\|f-\frac{|\mathcal D|}{Q}\mathbf1\right\|_2.}
\]

This is a rigorous adversarial inequality, but it loses the full \(\ell^2\) norm of the nonconstant signature mass. It is positive on the three tested single-prime tori and negative by huge margins on every tested multi-prime family. For example, on the synthetic \(P_4\) box it gives approximately \(-9.79\times10^7\), while the exact minimum is 182.

The local three-eigenvalue association scheme therefore does not yield a useful family anti-cover inequality through the top singular value alone.

## 6. Fractional covering and LP duality

For a finite domain, choose a probability weight \(w_u\ge0\) with \(\sum_uw_u=1\). Every deterministic cover would satisfy

\[
1=w\!\left(\bigcup_p C(p,t_p)\right)
\le\sum_p w(C(p,t_p))
\le\sum_p\max_{t_p}w(C(p,t_p)).
\]

Therefore:

\[
\boxed{
\exists w:\ 
\sum_p\max_{t_p}w(C(p,t_p))<1
\quad\Longrightarrow\quad
\text{no perfect cover}.}
\]

This is the natural weighted union bound and a finite-dimensional LP dual certificate.

An equivalent maximin relaxation introduces probability distributions \(x_{p,t}\) over local residues and maximizes \(z\) subject to

\[
z\le\sum_{p,t}B_{p,t}(u)x_{p,t}
\quad\text{for every }u,
\qquad
\sum_tx_{p,t}=1.
\]

A deterministic perfect cover would force the relaxation optimum to be at least one. Strong finite LP duality identifies the optimum with

\[
\min_{w\in\Delta(\mathcal D)}
\sum_p\max_t w(C(p,t)).
\]

On the synthetic \(407\)-pair box with \(P_4\), a floating-point HiGHS solve returned

\[
z^*=0.4860674177,
\]

versus 0.6535626536 for uniform weights. This indicates that weighted duality can be much stronger than cardinality union bounds.

However:

* no rational primal/dual certificate was exported;
* the domain is a synthetic finite box, not the accepted active/live 407-pair domain;
* an LP on a finite box does not control the full exponent lattice;
* scaling the LP to the joint torus recreates the signature-state explosion.

Classification:

> **COMPUTATIONAL OBSERVATION**, not a proof object and not a promotion gate.

## 7. Delsarte and semidefinite relaxations

Each local CRT coordinate has a three-class association algebra, so a Delsarte-style reduction is formally available when the joint signature multiset is invariant under the same algebra. In this problem, the histogram of

\[
(3^c+5^d\bmod p^2)_{p\in\mathcal P}
\]

is highly nonuniform and is not invariant under arbitrary translations or fiber permutations. The symmetry reduction therefore does not collapse the optimized problem to a few orbit variables.

A semidefinite hierarchy can encode higher-order intersection moments, but without a theorem bounding the required level it approaches the original exact covering problem. No low-degree SDP certificate valid uniformly over residue choices was found.

## 8. Entropy and Shearer-type inequalities

Entropy inequalities can upper-bound the number of possible joint signatures or relate marginal entropies, but a no-cover theorem requires a pointwise statement about one optimized union. High Shannon entropy does not exclude a small exceptional set of residue assignments with full coverage.

Shearer-type local-lemma criteria also have the wrong dependency geometry: every survivor event depends on every prime coordinate, producing a complete event-dependency graph. No sparse conditional-independence graph survives after the exponent-pair identities are fixed.

## 9. Dependent random choice

Dependent random choice is designed to find large vertex subsets with many common neighbors from average density. Here the needed conclusion is a lower bound on intersections for **all** adversarial residue choices. Exact zero intersections show that average-density hypotheses alone cannot provide that conclusion. DRC could potentially identify correlated clusters, but it does not yield a uniform anti-cover certificate.

## 10. Hypergraph covering interpretation

Take exponent-pair identities as vertices. For each prime \(p\), the sets \(C(p,t)\) form a color class of hyperedges, and one must select exactly one hyperedge of each color. The perfect-cover question is a colored hypergraph covering problem.

The random-CRT moments describe the average coverage of a random transversal of color classes. The optimized problem is the covering number of such transversals. General hypergraph covering bounds use parameters such as maximum degree, codegree, fractional cover, or expansion. In the present hypergraph:

* every vertex has exactly \(p-1\) incident edges in the \(p\)-color class;
* codegrees have the three exact local collision types;
* some pairwise selected edges can be disjoint;
* the signature multiset creates high-multiplicity clusters.

These local parameters do not force an integral covering gap.

## 11. Anti-cover verdict

The only scalable-looking deterministic inequality found is the union bound, and it is nontrivial only while \(\sum_p\alpha_p^{\max}<1\). Pairwise average overlap cannot improve it because minimum intersections can be zero. The global spectral conversion is rigorous but vacuous on multi-prime data. Fractional LP duality is promising for isolated finite instances but has no state compression or family theorem.

Accordingly, Phase A did not obtain a nontrivial family anti-cover theorem. Promotion Gate B is not met.
