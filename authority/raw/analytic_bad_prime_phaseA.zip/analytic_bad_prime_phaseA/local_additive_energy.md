# Local residue fibers and additive energy

## 1. Natural single-prime domain

Fix an eligible prime

\[
p\equiv3\pmod4,\qquad p\nmid15.
\]

Put

\[
r=\operatorname{ord}_{p^2}(3),\qquad s=\operatorname{ord}_{p^2}(5),
\]

and use the exact local exponent torus

\[
\mathcal D_p=\mathbb Z/r\mathbb Z\times\mathbb Z/s\mathbb Z,
\qquad M_p=rs.
\]

Also put

\[
m=\operatorname{ord}_{p}(3),\qquad n=\operatorname{ord}_{p}(5),
\]

and

\[
\ell_3=r/m,\qquad \ell_5=s/n,
\qquad L=\ell_3\ell_5.
\]

For a unit modulo \(p\), the order modulo \(p^2\) is either its order modulo \(p\) or \(p\) times that order, so \(\ell_3,\ell_5\in\{1,p\}\).

Let

\[
H=\langle3\rangle\subset\mathbb F_p^*,\qquad
K=\langle5\rangle\subset\mathbb F_p^*,
\]

and

\[
H_2=\langle3\rangle,\quad K_2=\langle5\rangle
\subset(\mathbb Z/p^2\mathbb Z)^*.
\]

The exponent maps on the local torus are bijections onto \(H_2\) and \(K_2\). Modulo \(p\), every element of \(H\) occurs \(\ell_3\) times and every element of \(K\) occurs \(\ell_5\) times.

## 2. Exact convolution formulas

Define

\[
N_{p,a}=\#\{(c,d)\in\mathcal D_p:3^c+5^d\equiv a\pmod p\},
\]

and

\[
N^{(2)}_{p,b}=\#\{(c,d)\in\mathcal D_p:3^c+5^d\equiv b\pmod{p^2}\}.
\]

With additive convolution on the indicated additive groups,

\[
\boxed{N_{p,a}=L(1_H*1_K)(a),}
\]

\[
\boxed{N^{(2)}_{p,b}=(1_{H_2}*1_{K_2})(b).}
\]

The refinement identity is exact:

\[
\boxed{N_{p,a}=\sum_{\substack{b\bmod p^2\\b\equiv a\pmod p}}N^{(2)}_{p,b}.}
\]

For a residue choice \(t=b\bmod p^2\), the blocked exponent-pair count is not \(N_{p,b\bmod p}\), because the exact lift \(3^c+5^d\equiv b\pmod{p^2}\) has valuation at least two and must be deleted. Hence

\[
\boxed{|C(p,b)|=N_{p,b\bmod p}-N^{(2)}_{p,b}.}
\]

This is the persistent-coverage correction.

## 3. Mass, energy and maximum formulas

The mass identities are

\[
\sum_{a\bmod p}N_{p,a}=rs,
\qquad
\sum_{b\bmod p^2}N^{(2)}_{p,b}=rs.
\]

Let

\[
E_+(H,K)
=\#\{h_1+k_1=h_2+k_2:h_i\in H,k_i\in K\}.
\]

Then

\[
\boxed{\sum_aN_{p,a}^2=L^2E_+(H,K),}
\]

and, in the additive group \(\mathbb Z/p^2\mathbb Z\),

\[
\boxed{\sum_b\bigl(N^{(2)}_{p,b}\bigr)^2=E_+(H_2,K_2).}
\]

Writing \(C_b=N_{p,b\bmod p}-N^{(2)}_{p,b}\), expansion inside each modulo-\(p\) fiber gives the useful exact identity

\[
\boxed{
\sum_{b\bmod p^2}C_b^2
=(p-2)\sum_{a\bmod p}N_{p,a}^2
+\sum_{b\bmod p^2}\bigl(N^{(2)}_{p,b}\bigr)^2.}
\]

Also

\[
\sum_b C_b=(p-1)rs,
\]

so the mean local coverage density over uniform \(b\) is exactly

\[
\frac{1}{p^2rs}\sum_bC_b=\frac{p-1}{p^2}.
\]

The exact optimized local density is

\[
\boxed{
\alpha_p^{\max}
=\frac1{rs}\max_{a\bmod p}
\left(
N_{p,a}-
\min_{\substack{b\bmod p^2\\b\equiv a\pmod p}}
N^{(2)}_{p,b}
\right).}
\]

This formula separates the modulo-\(p\) concentration from the \(p^2\)-persistent correction.

## 4. Elementary order bound

Since a convolution coefficient counts pairs in \(H\times K\),

\[
(1_H*1_K)(a)\le\min(m,n).
\]

Therefore

\[
N_{p,a}\le L\min(m,n),
\]

and, because \(rs=Lmn\),

\[
\boxed{
\frac{p-1}{p^2}
\le \alpha_p^{\max}
\le \frac1{\max(m,n)}.}
\]

The lower bound is only maximum at least mean. The upper bound is the strongest general local bound obtained in this phase.

## 5. Fourier representation

Use the unnormalized additive Fourier transform on \(\mathbb F_p\):

\[
\widehat f(\xi)=\sum_{x\in\mathbb F_p}f(x)e_p(-\xi x).
\]

Parseval gives

\[
\boxed{
E_+(H,K)=\frac1p\sum_{\xi\in\mathbb F_p}
|\widehat{1_H}(\xi)|^2|\widehat{1_K}(\xi)|^2.}
\]

For the representation function \(r(a)=(1_H*1_K)(a)\),

\[
r(a)=\frac{mn}{p}
+\frac1p\sum_{\xi\ne0}
\widehat{1_H}(\xi)\widehat{1_K}(\xi)e_p(\xi a).
\]

A centered \(L^2\) estimate therefore yields

\[
\boxed{
r(a)\le
\frac{mn}{p}
+
\sqrt{\frac{p-1}{p}
\left(E_+(H,K)-\frac{m^2n^2}{p}\right)}.}
\]

After division by \(mn\), this gives the `centered_energy_bound_sharp` column in `results/local_prime_statistics.csv`. It is rigorous, but it is useful only if the centered energy is much smaller than the generic upper bounds.

## 6. Why the uncentered second moment cannot improve the order bound

The direct Cauchy bound is

\[
\|1_H*1_K\|_\infty\le\sqrt{E_+(H,K)}.
\]

There are at least \(mn\) diagonal energy solutions, so

\[
E_+(H,K)\ge mn.
\]

Consequently the normalized uncentered bound satisfies

\[
\frac{\sqrt{E_+(H,K)}}{mn}
\ge\frac1{\sqrt{mn}}
\ge\frac1{\max(m,n)}.
\]

Thus:

\[
\boxed{
\text{The uncentered additive-energy/Cauchy bound can never beat the elementary order bound.}}
\]

This is a **PROVED negative barrier**, not merely a numerical observation.

## 7. Why the standard subgroup-energy theorem is also too weak

A classical theorem of Heath-Brown--Konyagin, in the commonly used asymptotic form, gives

\[
E_+(H)\ll |H|^{5/2}
\qquad (|H|\ll p^{2/3}),
\]

with an implicit constant. By Cauchy in Fourier space,

\[
E_+(H,K)\le\sqrt{E_+(H)E_+(K)}
\ll (mn)^{5/4}.
\]

Hence

\[
\frac{\sqrt{E_+(H,K)}}{mn}
\ll (mn)^{-3/8}.
\]

If \(M=\max(m,n)\) and \(m_0=\min(m,n)\), then

\[
\frac{(mn)^{-3/8}}{1/M}
=M^{5/8}m_0^{-3/8}\ge1.
\]

Ignoring the implicit constant already shows that this power bound is never stronger than \(1/M\); the unknown constant only worsens the comparison. The same problem remains in the centered form unless one proves substantially sharper cancellation than the standard energy theorem supplies.

## 8. Exact computation for eligible primes \(p\le200\)

The package computed every local coefficient for all 23 eligible primes \(p\le200\). The primary implementation is an exact C++ circular convolution using modular NTT; an independent NumPy complex FFT reconstructed and checked all 292,271 coefficients, with maximum distance to the nearest integer

\[
2.46\times10^{-11}.
\]

Classification:

> **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**.

Summary of bound quality:

| normalized statistic over the 23 primes | minimum | median | maximum |
|---|---:|---:|---:|
| \(\alpha_p^{\max}/(1/\max(m,n))\) | 0.5028 | 0.9767 | 0.9950 |
| sharp centered-energy bound / order bound | 1.0000 | 1.1048 | 2.3094 |
| uncentered-energy bound / order bound | 1.6125 | 6.6713 | 14.0367 |
| max/mean local coverage | 1.0051 | 1.0232 | 3.0455 |

The sharp centered bound never strictly improves the order bound in the tested set. Equality to floating precision occurs for several highly symmetric cases; otherwise it is worse.

The strongest exceptional concentration is at \(p=67\):

\[
\operatorname{ord}_{67}(3)=
\operatorname{ord}_{67}(5)=22,
\]

\[
\alpha_{67}^{\max}=0.0447761194,
\qquad
\frac{p-1}{p^2}=0.0147026064,
\]

so max/mean is \(3.04545\), while the elementary order bound is \(1/22=0.0454545\). This example shows that a local residue can nearly saturate the order ceiling and that an asymptotic "approximately \(1/p\)" claim is false without order hypotheses.

Other elevated max/mean ratios occur at \(p=71\) (1.62286), \(p=191\) (1.48144), and \(p=11\) (1.32). There is no monotone improvement with \(p\).

## 9. Applicability of the literature

The audited finite-field results have three recurring limitations for this problem.

1. They usually concern one subgroup \(H=K\), whereas the present convolution may involve two different subgroups \(\langle3\rangle\) and \(\langle5\rangle\).
2. The constants in \(\ll\), or the exponent \(\eta(\varepsilon)\) in small-subgroup exponential-sum bounds, are not explicit enough to compare with the tiny gap between \(\alpha_p^{\max}\) and \(1/\max(m,n)\).
3. They are results in the field \(\mathbb F_p\). The persistent correction requires additive convolution in \(\mathbb Z/p^2\mathbb Z\), where zero divisors and lifting structure matter. Known Heilbronn-subgroup estimates at modulus \(p^2\) concern the special subgroup \(\{m^p\bmod p^2\}\), not arbitrary \(\langle3\rangle\) and \(\langle5\rangle\).

## 10. Local-route verdict

No theorem of the requested form

\[
\alpha_p^{\max}\le\frac1p+\varepsilon_p
\]

with a useful explicit \(\varepsilon_p\), uniform in the relevant order regimes, was obtained. Standard uncentered energy is structurally weaker than the elementary order bound; the best centered bound is exact but did not improve that bound for any tested prime. This fails promotion Gate A.
