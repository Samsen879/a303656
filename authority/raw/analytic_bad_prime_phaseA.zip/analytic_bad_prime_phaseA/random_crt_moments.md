# Random-CRT survivor moments

## 1. Single-prime blocking probability

Fix one exponent pair \(u\), let \(x=s_u\bmod p^2\), and choose \(t\) uniformly from \(\mathbb Z/p^2\mathbb Z\). The congruence

\[
t\equiv x\pmod p
\]

has exactly \(p\) lifts modulo \(p^2\). Blocking requires all of these except \(t=x\). Hence

\[
\Pr(B_{p,t}(u)=1)=q_p:=\frac{p-1}{p^2},
\]

and the local survival probability is

\[
\lambda_p:=1-q_p=\frac{p^2-p+1}{p^2}.
\]

For independent CRT coordinates,

\[
\Pr(Y_u=1)=\Lambda_{\mathcal P}:=
\prod_{p\in\mathcal P}\lambda_p.
\]

Therefore, for \(M=|\mathcal D|\),

\[
\boxed{\mathbb E U=M\Lambda_{\mathcal P}.}
\]

This formula counts exponent-pair identities. Duplicate shifts contribute once per identity.

## 2. Exact two-point local factor

Let

\[
x=s_u\bmod p^2,\qquad y=s_v\bmod p^2.
\]

The local joint-survival factor is

\[
\gamma_p(u,v)=
\Pr\bigl(t\notin A_p(x)\cup A_p(y)\bigr).
\]

There are exactly three cases.

### Case 1: different residues modulo \(p\)

If \(x\not\equiv y\pmod p\), the two blocking fibers are disjoint and each has size \(p-1\). Thus

\[
\gamma_p(u,v)
=1-\frac{2(p-1)}{p^2}
=\frac{p^2-2p+2}{p^2}.
\]

### Case 2: same residue modulo \(p\), different modulo \(p^2\)

If \(x\equiv y\pmod p\) but \(x\ne y\pmod{p^2}\), both block sets lie in the same \(p\)-element fiber. Their intersection is that fiber with \(x,y\) deleted, so it has size \(p-2\). The union has size

\[
(p-1)+(p-1)-(p-2)=p.
\]

Therefore

\[
\gamma_p(u,v)=1-\frac p{p^2}
=\frac{p^2-p}{p^2}.
\]

### Case 3: equal modulo \(p^2\)

If \(x=y\), the two blocking sets coincide. Hence

\[
\gamma_p(u,v)=1-\frac{p-1}{p^2}
=\frac{p^2-p+1}{p^2}=\lambda_p.
\]

Combining the cases,

\[
\boxed{
\gamma_p(u,v)=
\begin{cases}
\dfrac{p^2-2p+2}{p^2},&s_u\not\equiv s_v\pmod p,\\[6pt]
\dfrac{p^2-p}{p^2},&s_u\equiv s_v\pmod p,
\ s_u\not\equiv s_v\pmod{p^2},\\[6pt]
\dfrac{p^2-p+1}{p^2},&s_u\equiv s_v\pmod{p^2}.
\end{cases}}
\]

Because the CRT coordinates are independent,

\[
\Pr(Y_u=Y_v=1)=\prod_{p\in\mathcal P}\gamma_p(u,v).
\]

Thus

\[
\boxed{
\mathbb E U^2=
\sum_{u,v\in\mathcal D}
\prod_{p\in\mathcal P}\gamma_p(u,v),
}
\]

and

\[
\boxed{
\operatorname{Var}(U)=
\sum_{u,v\in\mathcal D}
\left(
\prod_p\gamma_p(u,v)-\Lambda_{\mathcal P}^2
\right).
}
\]

The sum is over ordered exponent-pair identities.

## 3. Local correlation signs

The independent local baseline is \(\lambda_p^2\).

* Different modulo \(p\):
  \[
  \gamma_p-\lambda_p^2=-q_p^2<0.
  \]

* Same modulo \(p\), different modulo \(p^2\):
  \[
  \gamma_p-\lambda_p^2
  =\frac{p^3-3p^2+2p-1}{p^4}>0
  \qquad(p\ge3).
  \]

* Equal modulo \(p^2\):
  \[
  \gamma_p-\lambda_p^2
  =\lambda_p(1-\lambda_p)=\lambda_p q_p>0.
  \]

A global pair can have mixed local types, so its global covariance need not have the sign of any single coordinate. High positive correlation is concentrated in pairs that repeatedly collide modulo \(p\) or \(p^2\).

Exact duplicate integer shifts collide modulo every \(p^2\), so their survivor indicators are identical. This is a genuine multiplicity cluster, not an error to be removed.

## 4. Association-scheme form

Let \(X_p=\mathbb Z/p^2\mathbb Z\). Index rows by CRT residues \(t\) and columns by shift residues \(x\). Let \(J\) be the all-ones matrix and let \(P\) be the block matrix whose entries are one precisely when \(t\equiv x\pmod p\). Since the blocking matrix is \(P-I\), the local survival matrix is

\[
S_p=J-P+I.
\]

It is symmetric. Its Gram matrix is

\[
K_p=S_p^TS_p=S_p^2
=(p^2-2p+2)J+(p-2)P+I.
\]

The three entry values of \(K_p/p^2\) are exactly the three \(\gamma_p\)-values above.

### Three eigenspaces

The space \(\mathbb R^{p^2}\) decomposes orthogonally into:

1. constants, dimension \(1\);
2. functions constant on each modulo-\(p\) fiber with total sum zero, dimension \(p-1\);
3. functions with sum zero inside every fiber, dimension \(p(p-1)\).

On these spaces, the eigenvalues of \(S_p\) are respectively

\[
L_p:=p^2-p+1,
\qquad 1-p,
\qquad 1,
\]

and the eigenvalues of \(K_p\) are

\[
L_p^2,
\qquad (p-1)^2,
\qquad1.
\]

Thus the local matrix is full rank but belongs to a three-class association algebra. For \(k\) primes the tensor product has at most \(3^k\) spectral types, but generally still has full rank \(Q=\prod p^2\).

### Signature-histogram formula

Let

\[
f(\mathbf x)=\#\{u\in\mathcal D:
 s_u\equiv x_p\pmod{p^2}\ \forall p\},
\qquad
Q=\prod_{p\in\mathcal P}p^2.
\]

Then the complete survivor-count vector is

\[
U=(\bigotimes_{p\in\mathcal P}S_p)f.
\]

Consequently,

\[
\boxed{
\mathbb E U^2
=\frac1Q\left\langle f,
\left(\bigotimes_pK_p\right)f
\right\rangle.}
\]

The constant spectral mode is \((\mathbb E U)^2\); the variance is precisely the weighted nonconstant spectral energy of the signature histogram.

This is the most useful structural formula of Phase A. It compresses moment evaluation and explains high-correlation clusters. It does **not** convert the optimized minimum into a second-moment quantity.

## 5. A rigorous spectral lower bound and why it fails

Write

\[
f=\frac MQ\mathbf1+g,
\qquad \langle g,\mathbf1\rangle=0.
\]

The largest nonconstant singular value of the tensor survivor operator is

\[
\sigma_*
=\left(\prod_pL_p\right)
\max_{p\in\mathcal P}\frac{p-1}{L_p}.
\]

Since pointwise norm is bounded by \(\ell^2\)-norm,

\[
\boxed{
\min_{\mathbf t}U(\mathbf t)
\ge
M\Lambda_{\mathcal P}
-
\sigma_*
\left\|f-\frac MQ\mathbf1\right\|_2.}
\]

This is a valid \(L^2\)-to-\(L^\infty\) inequality. It is positive for the tested single-prime tori, but it is catastrophically negative for every tested multi-prime family:

| family/domain | spectral lower bound | exact \(\min U\) |
|---|---:|---:|
| \(\{7\}\), torus | 1445.12 | 1512 |
| \(\{11\}\), torus | 157.40 | 245 |
| \(\{23\}\), torus | 116880.50 | 122452 |
| \(\{7,11\}\), torus | -1230691.90 | 370440 |
| \(\{11,23\}\), torus | -36444080.29 | 2725822 |
| synthetic \(P_4\), box \(11\times37\) | -97878396.09 | 182 |

The tensor nonconstant singular value loses too much information. This exact failure is one manifestation of the route's optimized-tail blocker.

## 6. What standard probability tools prove

Let \(\mu=\mathbb E U\), \(\sigma^2=\operatorname{Var}(U)\).

### Markov

Since \(U\) is a nonnegative integer,

\[
\Pr(U>0)=\Pr(U\ge1)\le\mathbb E U.
\]

Therefore

\[
\boxed{\mathbb E U<1\Longrightarrow\Pr(U=0)>0.}
\]

This proves existence of a perfect cover tuple on the frozen finite domain. It says nothing about how common the tuple is and is useless for anti-covering.

### Chebyshev

If \(\mu>0\),

\[
\Pr(U=0)
\le\Pr(|U-\mu|\ge\mu)
\le\frac{\sigma^2}{\mu^2}.
\]

Hence

\[
\Pr(U>0)\ge1-\frac{\sigma^2}{\mu^2}.
\]

The bound is nontrivial only when the coefficient of variation is below one. Even then it allows exceptional perfect-cover tuples.

### Paley--Zygmund / second-moment method

At threshold zero,

\[
\boxed{
\Pr(U>0)
\ge\frac{(\mathbb E U)^2}{\mathbb E U^2}
=\frac1{1+\sigma^2/\mu^2}.}
\]

This is an exact lower bound on the fraction of CRT tuples leaving at least one survivor. It cannot prove that every tuple leaves a survivor.

### Janson-type inequalities

Classical Janson inequalities are strongest for monotone events built from independent Bernoulli coordinates, or general up-sets with suitable positive correlation. Here each \(t_p\) is a categorical variable, and \(Y_u\) is not monotone under a natural one-hot Bernoulli encoding. More decisively, the exact local covariances take both signs. No applicable Janson dependency structure with a small \(\Delta\) was found.

### Chen--Stein and Suen

Every survivor event \(Y_u\) depends on every prime coordinate. The naive dependency graph on exponent pairs is complete. The Chen--Stein neighborhood terms \(b_1,b_2,b_3\), and the analogous Suen \(\Delta\)-terms, are therefore of quadratic scale unless a new cluster quotient or conditional-independence decomposition is proved. Exact signature collisions create clumps rather than rare approximately independent events. The resulting bounds are vacuous in the tested domains.

### Lovász local lemma and Shearer-type criteria

To find a perfect cover one would try to avoid all survivor events \(Y_u\). Their variable sets are identical: every event depends on all \(t_p\). The dependency graph is complete, so the local lemma gives no improvement over a crude global existence calculation. Conversely, an anti-cover theorem asks to prove that **every** assignment has at least one survivor; the local lemma is an existential avoidance theorem and has the wrong quantifier.

## 7. What the second moment is useful for

| Question | Usefulness of exact second moment |
|---|---|
| Existence of a perfect cover | only indirectly; first moment \(<1\) suffices, second moment does not improve this in general |
| Nonexistence of a perfect cover | no, unless converted to a uniform pointwise bound; current conversion is vacuous |
| Fraction of tuples with survivors | yes, via Paley--Zygmund/Chebyshev and exact enumeration |
| Expected minimum survivor count | no natural control; \(\min U\) is an optimized statistic, not an expectation |
| Near-cover search feasibility | yes as a random-search calibration; small \(\mu\) and tail estimates can predict sampling difficulty |
| Optimized maximum coverage | no scalable control found |

## 8. Calibration result

On the synthetic box \(0\le c<11,0\le d<37\), with \(P_4=\{3,7,11,23\}\):

\[
\mathbb E U=244.2374242015,
\qquad
\operatorname{Var}(U)=1952.587114124,
\]

\[
\Pr(U>0)\ge0.968304476
\quad\text{(Paley--Zygmund)},
\]

while exact enumeration gives

\[
\Pr(U>0)=1,
\qquad
\min U=182,
\qquad
\max\text{ coverage}=225.
\]

The random expected coverage is only \(162.7626\), so optimization gains about \(62.24\) covered identities. This large optimized-versus-random gap directly demonstrates why random moments do not predict maximum coverage.

This synthetic box is not the accepted frozen 407-pair active/live domain. It cannot explain the accepted values \(G_{\max}=231\), \(H_{8,\max}=201\), the 21 maximizing full masks, or their five live projections.
