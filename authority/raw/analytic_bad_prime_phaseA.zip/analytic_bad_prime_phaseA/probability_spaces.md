# Probability spaces

## 1. Model A: random CRT residue tuple

Fix a finite exponent-pair domain \(\mathcal D\) and a finite prime family \(\mathcal P\). The probability space is

\[
\Omega_{\mathrm{CRT}}=\prod_{p\in\mathcal P}\mathbb Z/p^2\mathbb Z,
\]

with the product of uniform measures. Thus the coordinates \(t_p\) are independent and uniform.

The random variable is

\[
U(\mathbf t)=\sum_{u\in\mathcal D}Y_u(\mathbf t).
\]

This model is exact for statements about the **distribution over CRT tuples**. It does not randomize exponent pairs, and it does not assert that an optimized tuple behaves typically.

### What it represents

* exact fraction of CRT tuples with a given survivor count;
* exact first and second moments over residue choices;
* a probabilistic-method existence result if \(\mathbb E U<1\);
* random-search calibration and near-cover tail diagnostics.

### What it does not represent

* the minimum \(\min_{\mathbf t}U(\mathbf t)\) without an additional uniform inequality;
* nonexistence of a perfect cover from the fact that most tuples have survivors;
* a distribution on integers \(n\) beyond the CRT residue coordinates;
* a global exponent-lattice statement when \(\mathcal D\) is only a finite box.

## 2. Model B: uniform exponent torus

For eligible primes \(p\equiv3\pmod4\), \(p\nmid15\), define

\[
r_p=\operatorname{ord}_{p^2}(3),\qquad
s_p=\operatorname{ord}_{p^2}(5),
\]

and

\[
R=\operatorname{lcm}_{p\in\mathcal P}r_p,
\qquad
S=\operatorname{lcm}_{p\in\mathcal P}s_p.
\]

Then

\[
3^{c+R}\equiv3^c\pmod{p^2},
\qquad
5^{d+S}\equiv5^d\pmod{p^2}
\]

for every \(p\in\mathcal P\). Hence the map

\[
(c,d)\mapsto
\bigl(3^c+5^d\bmod p^2\bigr)_{p\in\mathcal P}
\]

factors exactly through

\[
\mathcal T_{\mathcal P}=\mathbb Z/R\mathbb Z\times\mathbb Z/S\mathbb Z.
\]

Every exponent pair in \(\mathbb Z_{\ge0}^2\) is represented by its residue class on the torus. No exponent-pair identities are merged: two torus points mapping to the same shift vector remain two points and contribute multiplicity two.

### Period explosion

Let

\[
L=\sum_{p\in\mathcal P}\log p,
\qquad
N=\prod_{p\in\mathcal P}p^2=e^{2L}.
\]

Because \(3^R\equiv1\pmod{p^2}\) for every \(p\), the Chinese remainder theorem gives

\[
N\mid 3^R-1.
\]

Therefore

\[
R\ge\frac{\log(N+1)}{\log3}.
\]

Likewise,

\[
S\ge\frac{\log(N+1)}{\log5}.
\]

In particular,

\[
RS\ge
\frac{\log(N+1)^2}{\log3\log5}
\asymp L^2.
\]

This is only a lower bound, but it already shows that the joint torus cannot remain small as the prime family expands.

### Can the torus be avoided explicitly?

Several exact representations exist, but none removes the essential state growth in the optimized problem.

1. **CRT signature tensor.** Let
   \[
   Q=\prod_{p\in\mathcal P}p^2
   \]
   and store the histogram
   \[
   f(\mathbf x)=\#\{u\in\mathcal T_{\mathcal P}:s_u\equiv x_p\pmod{p^2}\ \forall p\}.
   \]
   This replaces an \(RS\)-array by a \(Q\)-array. It helps only when \(Q\) is smaller.

2. **Factor graph / generalized CRT constraints.** Each exponent variable is constrained modulo several orders. This can avoid a dense torus when the order-factor incidence graph has low treewidth. In the present setting, the many shared factors of \(p-1\) make uniformly bounded treewidth implausible; no such theorem was found.

3. **Fourier decomposition on \(\mathbb Z/R\times\mathbb Z/S\).** This diagonalizes translation-invariant operators on exponent space, but the optimized union of residue fibers is not a single low-frequency operator.

4. **Tensor product in CRT space.** The local survivor operator has only three eigenspaces per prime, yielding \(3^{|\mathcal P|}\) spectral types. This gives exact moments once \(f\) is known, but it does not cheaply construct \(f\) and does not control its pointwise minimum after transformation.

Thus tensor/Fourier methods compress the **moment calculation**, not the optimized-cover problem.

## 3. Model C: finite exponent boxes

Let

\[
\mathcal D_{C,D}=\{(c,d):0\le c<C,\ 0\le d<D\}.
\]

A finite box is useful for exact calibration, but its averages need not approximate periodic averages unless the box dimensions dominate the periods.

### Exact one-dimensional discrepancy

Write

\[
C=qR+r,\qquad0\le r<R.
\]

The total-variation distance between the distribution of \(c\bmod R\), for uniform \(0\le c<C\), and the uniform distribution on \(\mathbb Z/R\mathbb Z\) is exactly

\[
\delta_C=\frac{r(R-r)}{CR}
\le \min\left(1,\frac{R}{4C}\right).
\]

Similarly, if \(D=sS+t\),

\[
\delta_D=\frac{t(S-t)}{DS}
\le \min\left(1,\frac{S}{4D}\right).
\]

### Box-to-torus error for first moments

For every periodic function \(F:\mathbb Z/R\times\mathbb Z/S\to[0,1]\),

\[
\left|
\frac1{CD}\sum_{0\le c<C\atop0\le d<D}F(c,d)
-
\frac1{RS}\sum_{c\bmod R\atop d\bmod S}F(c,d)
\right|
\le
\delta_C+\delta_D-\delta_C\delta_D
\le\delta_C+\delta_D.
\]

This follows by a product coupling of the empirical residue distributions with the uniform distributions.

### Error for pair averages / second moments

A pair statistic depends on two independent exponent-pair samples. Its box distribution differs from the uniform torus pair distribution by at most

\[
1-(1-\delta_C)^2(1-\delta_D)^2
\le2\delta_C+2\delta_D.
\]

Consequently, a finite-box covariance experiment has no uniform periodic interpretation unless \(C\gg R\) and \(D\gg S\), or unless a sharper problem-specific discrepancy theorem is proved.

## 4. Comparison of the models

| Model | Random object | Exact target | Main strength | Main failure mode |
|---|---|---|---|---|
| A: random CRT | \(\mathbf t\) | distribution of \(U(\mathbf t)\) | exact moments, probabilistic method | typical tuple \(\ne\) optimized tuple |
| B: exponent torus | \((c,d)\) modulo joint periods | full exponent-lattice local signatures | exact periodic representation | \(R,S,Q\) explode; optimized minimum remains hard |
| C: finite box | bounded exponent identities | finite experiment | manageable exact computation | boundary error can be order one |

The models answer different questions. Any inference crossing models must display the period or boundary error explicitly.
