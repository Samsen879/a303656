# Mathematical framework

## 1. Scope and global status

The original question is whether every integer \(n>1\) has a representation

\[
n=a^2+b^2+3^c+5^d,
\qquad a,b,c,d\in\mathbb Z_{\ge 0}.
\]

This Phase A does **not** compute any new \(T(n)\), does not use a two-square oracle, and does not search for integers \(n\). Its only purpose is to test whether bad-prime covering events support a scalable analytic theorem.

\[
\boxed{\text{OEIS A303656: UNRESOLVED}.}
\]

No result in this package is a general proof of the conjecture or a certified counterexample.

## 2. Bad-prime obstruction

Let \(p\equiv3\pmod4\). For an integer shift

\[
s_u=3^c+5^d,\qquad u=(c,d),
\]

if

\[
v_p(n-s_u)=1,
\]

then \(n-s_u\) is not a sum of two squares. In the coordinate

\[
t_p=n\bmod p^2,
\]

define, for \(x=s_u\bmod p^2\),

\[
A_p(x)=\{t\in\mathbb Z/p^2\mathbb Z:
 t\equiv x\pmod p,\ t\ne x\pmod{p^2}\}.
\]

The local blocking indicator is

\[
B_{p,t}(u)=1_{A_p(s_u)}(t).
\]

The set \(A_p(x)\) has exactly \(p-1\) elements: the congruence class of \(x\pmod p\) contains \(p\) lifts modulo \(p^2\), and precisely one lift, \(x\), is deleted.

For a finite prime family \(\mathcal P\),

\[
B_{\mathcal P,\mathbf t}(u)=\max_{p\in\mathcal P}B_{p,t_p}(u),
\qquad
Y_u(\mathbf t)=1-B_{\mathcal P,\mathbf t}(u),
\]

and on a specified exponent-pair domain \(\mathcal D\),

\[
U(\mathbf t)=\sum_{u\in\mathcal D}Y_u(\mathbf t).
\]

The local covered set is

\[
C(p,t)=\{u\in\mathcal D:B_{p,t}(u)=1\}.
\]

Thus \(U(\mathbf t)=|\mathcal D\setminus\bigcup_p C(p,t_p)|\).

## 3. Logical relation to A303656

A finite family \(\mathcal P\) and a CRT tuple \(\mathbf t\) that covers the **entire infinite exponent lattice**, equivalently an exact joint periodic torus representing that lattice, would produce a modular obstruction: every exponent pair would force some valuation \(v_p(n-s_u)=1\) for each integer \(n\) in the corresponding CRT class. This would yield counterexamples after choosing a positive sufficiently large CRT representative.

By contrast:

* a cover of a finite box proves only a finite-domain statement;
* a positive survivor density for one fixed finite family merely rules out that particular family as a complete modular cover;
* random-tuple survivor probability does not control an optimized tuple;
* failure of one bad-prime strategy does not prove the original universal representation statement.

## 4. Domain discipline

Three domains occur and are never identified without an explicit error term.

### 4.1 Finite active domain

An arbitrary finite set of exponent-pair identities. Its geometry and multiplicities must be retained exactly.

### 4.2 Joint periodic torus

For eligible primes

\[
p\equiv3\pmod4,\qquad p\nmid15,
\]

put

\[
r_p=\operatorname{ord}_{p^2}(3),\qquad
s_p=\operatorname{ord}_{p^2}(5),
\]

and

\[
R_{\mathcal P}=\operatorname{lcm}_{p\in\mathcal P}r_p,
\qquad
S_{\mathcal P}=\operatorname{lcm}_{p\in\mathcal P}s_p.
\]

The torus is

\[
\mathcal T_{\mathcal P}=\mathbb Z/R_{\mathcal P}\mathbb Z
\times\mathbb Z/S_{\mathcal P}\mathbb Z.
\]

Every exponent pair has a unique residue-class representative on this torus, and every local shift vector modulo all \(p^2\) repeats with these periods.

### 4.3 Finite box

\[
\mathcal D_{C,D}=\{(c,d):0\le c<C,\ 0\le d<D\}.
\]

It is not a periodic model unless \(C,D\) are exact multiples of the joint periods, or a proved boundary/equidistribution error is included.

## 5. Pair identities and duplicate shifts

The sample space consists of exponent-pair identities, not distinct integer shifts. If

\[
3^{c_1}+5^{d_1}=3^{c_2}+5^{d_2}
\]

with \((c_1,d_1)\ne(c_2,d_2)\), both identities remain separate summands in \(U\). Their survivor indicators are identical for every CRT tuple and hence perfectly correlated.

In the synthetic box \(0\le c<11,0\le d<37\), the shift \(28\) occurs from both \((1,2)\) and \((3,0)\); this is retained as one multiplicity-two cluster, not deduplicated.

## 6. The special role of \(p=3\)

The fixed historical calibration family

\[
P_4=\{3,7,11,23\}
\]

contains \(3\), which is outside the eligible class \(p\nmid15\). The local finite-box blocking indicator is still algebraically meaningful for \(p=3\), but \(\operatorname{ord}_9(3)\) is undefined. Consequently:

* \(P_4\) is used only for finite-box random-CRT calibration;
* it is never used as a multiplicative-period torus in this package;
* all local subgroup/additive-energy theorems and the full-torus scaling theorem use only eligible primes.

## 7. Classification labels

The package uses the following labels literally.

* **PROVED**: an elementary or cited theorem with a complete argument supplied.
* **CERTIFIED BY INDEPENDENT VERIFIER**: an exact claim checked by a separate implementation for the stated scope.
* **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**: finite integer output reproduced by independent implementations, with the domain frozen.
* **COMPUTATIONAL OBSERVATION**: numerical output without a proof object or without sufficient independent certification.
* **HEURISTIC**: an approximation, random model, calibrated asymptotic, or independence assumption.
* **UNKNOWN / UNRESOLVED**: no conclusion established.

## 8. Core route question

The optimized covering problem is

\[
\min_{\mathbf t}U(\mathbf t),
\]

whereas first and second moments control averages such as

\[
\frac1Q\sum_{\mathbf t}U(\mathbf t),
\qquad
\frac1Q\sum_{\mathbf t}U(\mathbf t)^2,
\qquad Q=\prod_{p\in\mathcal P}p^2.
\]

The central adversarial issue is therefore an \(L^2\)-to-\(L^\infty\) gap: a small variance or a large fraction of tuples with survivors does not rule out a rare optimized tuple with \(U=0\). This gap is the main route blocker identified in Phase A.
