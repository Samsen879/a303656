# ANALYTIC BAD-PRIME ANTI-COVER / SECOND-MOMENT FEASIBILITY STUDY — PHASE A

## Research report

**Research role:** mathematical research supervisor; independent analytic number theorist; computational researcher; adversarial proof referee.  
**User:** Samsen.  
**Execution environment:** webpage GPT-5.6 Pro with standalone Python/C++ and Linux container.  
**Repository integration:** none.  
**Final route verdict:**

\[
\boxed{\textbf{STOP ANALYTIC BAD-PRIME ROUTE}.}
\]

**Global project status:**

\[
\boxed{\text{OEIS A303656: UNRESOLVED}.}
\]

No result below is a general proof or a certified counterexample.

---

# 1. Research question and frozen framework

The original question asks whether every integer \(n>1\) admits

\[
n=a^2+b^2+3^c+5^d,
\qquad a,b,c,d\in\mathbb Z_{\ge0}.
\]

For an exponent-pair identity \(u=(c,d)\), write

\[
s_u=3^c+5^d.
\]

For an eligible prime

\[
p\equiv3\pmod4,
\qquad p\nmid15,
\]

if \(v_p(n-s_u)=1\), then \(n-s_u\) cannot be a sum of two squares. With

\[
t_p=n\bmod p^2,
\]

define

\[
B_{p,t_p}(u)=1
\iff
t_p\equiv s_u\pmod p,
\quad
t_p\not\equiv s_u\pmod{p^2}.
\]

For a finite family \(\mathcal P\),

\[
Y_u(\mathbf t)=
\prod_{p\in\mathcal P}(1-B_{p,t_p}(u)),
\qquad
U(\mathbf t)=\sum_{u\in\mathcal D}Y_u(\mathbf t).
\]

Here \(\mathcal D\) is always stated explicitly: a finite multiset of exponent identities, a full joint periodic torus, or a finite box. Duplicate identities are never deduplicated. In particular,

\[
3^1+5^2=3^3+5^0=28
\]

contributes two summands and creates a perfectly correlated pair.

The central question of this phase is not whether random residues usually block many exponent pairs. It is whether exact moments, additive energy, or overlap inequalities can control the optimized quantity

\[
\min_{\mathbf t}U(\mathbf t).
\]

The answer found here is negative for the audited framework.

---

# 2. Executive mathematical findings

## 2.1 Exact random-CRT first and second moments

For fixed \(x\bmod p^2\), the blocking fiber

\[
A_p(x)=\{t:t\equiv x\pmod p,\ t\ne x\pmod{p^2}\}
\]

contains exactly \(p-1\) of the \(p^2\) residues. Thus

\[
q_p:=\Pr(B_{p,t_p}(u)=1)=\frac{p-1}{p^2},
\qquad
\lambda_p:=1-q_p=rac{p^2-p+1}{p^2}.
\]

For two exponent identities \(u,v\), the exact joint local survival factor is

\[
\gamma_p(u,v)=
\begin{cases}
\dfrac{p^2-2p+2}{p^2},
&s_u\not\equiv s_v\pmod p,\\[5pt]
\dfrac{p^2-p}{p^2},
&s_u\equiv s_v\pmod p,
\ s_u\not\equiv s_v\pmod{p^2},\\[5pt]
\dfrac{p^2-p+1}{p^2},
&s_u\equiv s_v\pmod{p^2}.
\end{cases}
\]

Therefore

\[
\boxed{
\mathbb EU=|\mathcal D|
\prod_{p\in\mathcal P}\lambda_p,}
\]

\[
\boxed{
\mathbb EU^2=
\sum_{u,v\in\mathcal D}
\prod_{p\in\mathcal P}\gamma_p(u,v),}
\]

and

\[
\operatorname{Var}(U)=\mathbb EU^2-(\mathbb EU)^2.
\]

Status: **PROVED**.

## 2.2 Exact correlation signs

At one prime,

\[
\gamma_p(u,v)-\lambda_p^2
=
\begin{cases}
-q_p^2<0,&s_u\not\equiv s_v\pmod p,\\[4pt]
\dfrac{p^3-3p^2+2p-1}{p^4}>0,
&s_u\equiv s_v\pmod p,
\ s_u\not\equiv s_v\pmod{p^2},\\[7pt]
q_p\lambda_p>0,&s_u\equiv s_v\pmod{p^2}.
\end{cases}
\]

Thus the process is neither globally positively associated nor globally negatively associated. Congruence clusters generate strong positive correlations; different mod-\(p\) fibers generate weak negative correlations.

## 2.3 Exact association operator

Let \(P\) be the matrix recording equality modulo \(p\), and \(J\) the all-ones matrix on \(\mathbb Z/p^2\mathbb Z\). The local survivor transform is

\[
S_p=J-P+I.
\]

Its three eigenspaces and eigenvalues are:

| eigenspace | eigenvalue |
|---|---:|
| constants | \(p^2-p+1\) |
| functions constant on each mod-\(p\) fiber, total sum zero | \(1-p\) |
| functions summing to zero inside each fiber | \(1\) |

Moreover,

\[
K_p=S_p^2
=(p^2-2p+2)J+(p-2)P+I.
\]

For the joint signature histogram \(f\) on CRT space,

\[
U=\left(\bigotimes_pS_p\right)f,
\]

\[
\mathbb EU^2=
\frac1{\prod_pp^2}
\left\langle f,
\left(\bigotimes_pK_p\right)f
\right\rangle.
\]

This is the cleanest structural formula in the study. It compresses the moment calculation to \(3^{|\mathcal P|}\) spectral types once the histogram is known. It does not compress the construction of that histogram or the extremal minimum of its transform.

---

# 3. Task A — correct probability spaces

## 3.1 Model A: random CRT residue tuple

The probability space is

\[
\Omega_{\mathrm{CRT}}
=
\prod_{p\in\mathcal P}\mathbb Z/p^2\mathbb Z,
\]

with independent uniform coordinates.

It exactly answers:

* the fraction of residue tuples with a given \(U\);
* first and second moments over residue choices;
* random-search calibration;
* a probabilistic-method cover existence result when \(\mathbb EU<1\).

It does not answer:

* whether the optimized minimum is zero;
* whether a rare perfect cover exists;
* whether a finite box represents the infinite exponent lattice.

The gap is one of quantifiers:

\[
\Pr_{\mathbf t}(U>0)\approx1
\quad\not\Rightarrow\quad
\forall\mathbf t,\,U(\mathbf t)>0.
\]

## 3.2 Model B: uniform exponent torus

For eligible \(p\), let

\[
r_p=\operatorname{ord}_{p^2}(3),
\qquad
s_p=\operatorname{ord}_{p^2}(5),
\]

and

\[
R_{\mathcal P}=\operatorname{lcm}_{p\in\mathcal P}r_p,
\qquad
S_{\mathcal P}=\operatorname{lcm}_{p\in\mathcal P}s_p.
\]

Then all local shift signatures repeat exactly on

\[
\mathcal T_{\mathcal P}
=
\mathbb Z/R_{\mathcal P}\mathbb Z
\times
\mathbb Z/S_{\mathcal P}\mathbb Z.
\]

Every exponent pair is represented by one torus class; distinct torus points remain distinct identities even when their shift vectors collide.

The fixed historical family \(P_4=\{3,7,11,23\}\) is not a Model-B family because \(3\) is not a unit modulo 9. It is used only in a finite-box Model-A calibration.

### Period explosion

Let

\[
L=\sum_{p\in\mathcal P}\log p,
\qquad
N=\prod_{p\in\mathcal P}p^2=e^{2L}.
\]

Since \(N\mid3^{R_{\mathcal P}}-1\) and \(N\mid5^{S_{\mathcal P}}-1\),

\[
R_{\mathcal P}
\ge\frac{\log(N+1)}{\log3},
\qquad
S_{\mathcal P}
\ge\frac{\log(N+1)}{\log5},
\]

so

\[
R_{\mathcal P}S_{\mathcal P}
\gg L^2.
\]

CRT tensors, factor graphs, and Fourier decompositions can avoid explicitly storing one representation or another in favorable small cases, but no method found removes the intrinsic state growth of the optimized covering problem.

## 3.3 Model C: finite exponent boxes

For

\[
\mathcal D_{C,D}
=\{(c,d):0\le c<C,\ 0\le d<D\},
\]

write

\[
C=qR+r,
\qquad
D=sS+t,
\]

and

\[
\delta_C=\frac{r(R-r)}{CR},
\qquad
\delta_D=\frac{t(S-t)}{DS}.
\]

For any \([0,1]\)-valued periodic statistic \(F\),

\[
\left|
\mathbb E_{\mathcal D_{C,D}}F
-
\mathbb E_{\mathbb Z/R\times\mathbb Z/S}F
\right|
\le
\delta_C+\delta_D-
\delta_C\delta_D.
\]

For a statistic of an ordered pair of exponent samples, the error is at most

\[
1-(1-\delta_C)^2(1-\delta_D)^2
\le2\delta_C+2\delta_D.
\]

Status: **PROVED**.

When \(C<R\) or \(D<S\), the error can be order one. Finite-box experiments are therefore not extrapolated to the periodic or global domain.

---

# 4. Task B — what probability inequalities do and do not prove

## 4.1 Markov

Because \(U\) is a nonnegative integer,

\[
\Pr(U>0)\le\mathbb EU.
\]

Thus

\[
\mathbb EU<1
\quad\Longrightarrow\quad
\exists\mathbf t:
U(\mathbf t)=0.
\]

This is a valid finite-domain probabilistic-method cover criterion.

It cannot prove nonexistence of a perfect cover.

## 4.2 Chebyshev

\[
\Pr(U=0)
\le
\frac{\operatorname{Var}(U)}{(\mathbb EU)^2}.
\]

A small coefficient of variation proves that few random tuples are perfect covers. It does not prove that there are none.

## 4.3 Paley–Zygmund / second-moment method

\[
\Pr(U>0)
\ge
\frac{(\mathbb EU)^2}{\mathbb EU^2}
=
\frac1{1+\operatorname{Var}(U)/(\mathbb EU)^2}.
\]

This rigorously lower-bounds the fraction of tuples with survivors. It has the wrong quantifier for anti-cover.

## 4.4 Janson-type inequalities

The local coordinate is categorical, not a product of independent Bernoulli inclusion variables. The pair correlations have mixed sign. The events are not a natural system of positively correlated up-sets. Re-encoding each categorical coordinate into Bernoulli bits adds hard exclusivity constraints.

Conclusion: standard Janson hypotheses do not match the process, and even a valid random lower-tail estimate would not control the optimized tuple.

## 4.5 Chen–Stein and Suen

Every survivor indicator depends on every prime coordinate. The natural dependency graph on exponent identities is complete. The dependency-neighborhood terms are therefore quadratic, and duplicate/high-correlation clusters violate a sparse-clump picture.

Conclusion: no useful Poisson approximation was obtained. More importantly, a Poisson approximation to random \(U\) would still not prove a no-cover theorem.

## 4.6 Lovász local lemma and Shearer

LLL proves existence of an assignment avoiding bad events under sparse dependency. The desired anti-cover statement is universal over all assignments. Here dependency is complete.

Conclusion: wrong dependency geometry and wrong existential direction.

---

# 5. Task C — local residue fibers and additive energy

## 5.1 Natural local domain

For one eligible prime, use

\[
\mathcal D_p=
\mathbb Z/r_p\mathbb Z
\times
\mathbb Z/s_p\mathbb Z,
\qquad
M_p=r_ps_p.
\]

Let

\[
m=\operatorname{ord}_p(3),
\qquad
n=\operatorname{ord}_p(5),
\]

\[
\ell_3=r_p/m,
\qquad
\ell_5=s_p/n,
\qquad
L=\ell_3\ell_5.
\]

Define

\[
H=\langle3\rangle\subset\mathbb F_p^*,
\qquad
K=\langle5\rangle\subset\mathbb F_p^*,
\]

and the corresponding cyclic subgroups \(H_2,K_2\subset(\mathbb Z/p^2\mathbb Z)^*\).

Then

\[
N_{p,a}
=L(1_H*1_K)(a),
\]

\[
N^{(2)}_{p,b}
=(1_{H_2}*1_{K_2})(b),
\]

and

\[
N_{p,a}
=
\sum_{b\equiv a\pmod p}N^{(2)}_{p,b}.
\]

For residue \(t_p=b\), exact coverage is

\[
C_{p,b}=N_{p,b\bmod p}-N^{(2)}_{p,b}.
\]

This is the persistent-coverage correction. A mod-\(p\) hit that also agrees mod \(p^2\) is not blocked.

## 5.2 Exact moments of local fibers

\[
\sum_aN_{p,a}=r_ps_p,
\qquad
\sum_bN^{(2)}_{p,b}=r_ps_p.
\]

Writing cross additive energy as

\[
E_+(H,K)
=\sum_a(1_H*1_K)(a)^2,
\]

we have

\[
\sum_aN_{p,a}^2=L^2E_+(H,K),
\]

and

\[
\sum_b\left(N^{(2)}_{p,b}\right)^2
=E_+(H_2,K_2).
\]

The exact coverage second moment is

\[
\boxed{
\sum_bC_{p,b}^2
=(p-2)\sum_aN_{p,a}^2
+
\sum_b\left(N^{(2)}_{p,b}\right)^2.}
\]

## 5.3 Exact local maximum and elementary bounds

\[
\boxed{
\alpha_p^{\max}
=
\frac1{r_ps_p}
\max_{b\bmod p^2}
\left(N_{p,b\bmod p}-N^{(2)}_{p,b}\right).}
\]

Because the mean coverage density is \(q_p=(p-1)/p^2\),

\[
q_p\le\alpha_p^{\max}.
\]

Since

\[
1_H*1_K(a)\le\min(m,n),
\]

\[
\boxed{
\alpha_p^{\max}
\le
\frac1{\max(m,n)}.}
\]

This elementary bound is the actual benchmark. Any proposed energy theorem must beat it, not merely beat 1.

## 5.4 Fourier and centered bound

Parseval gives

\[
E_+(H,K)
=\frac1p
\sum_{\xi\in\mathbb F_p}
|\widehat{1_H}(\xi)|^2
|\widehat{1_K}(\xi)|^2.
\]

For the representation function \(r(a)=1_H*1_K(a)\),

\[
r(a)
\le
\frac{mn}{p}
+
\sqrt{
\frac{p-1}{p}
\left(E_+(H,K)-\frac{m^2n^2}{p}\right)}.
\]

This is exact as a Cauchy consequence of the centered Fourier decomposition, but the resulting numerical bound did not improve the elementary order bound for any eligible \(p\le200\).

## 5.5 Uncentered energy barrier

The diagonal quadruples imply

\[
E_+(H,K)\ge mn.
\]

Therefore

\[
\frac{\sqrt{E_+(H,K)}}{mn}
\ge
\frac1{\sqrt{mn}}
\ge
\frac1{\max(m,n)}.
\]

Hence a pointwise estimate obtained only through

\[
\|1_H*1_K\|_\infty
\le\sqrt{E_+(H,K)}
\]

can never beat the elementary order bound.

Status: **PROVED**.

This is a decisive negative result for the proposed uncentered second-moment route.

## 5.6 Literature comparison

* Heath-Brown–Konyagin energy bounds, even after a cross Cauchy step, remain weaker than the elementary bound in this normalization.
* BGK gives genuine Fourier cancellation for subgroups \(|H|\ge p^\gamma\), but practical explicit constants and a crossover to the required bound were not available.
* Located \(p^2\)-results concern the special Heilbronn subgroup, not arbitrary cyclic orbits generated by 3 and 5.
* Sumset expansion does not directly bound the maximum cross-convolution coefficient.

Conclusion: no literature theorem met Gate A.

---

# 6. Task D — anti-cover inequalities

## 6.1 Deterministic union bound

For every residue tuple,

\[
\boxed{
\frac{U(\mathbf t)}{|\mathcal D|}
\ge
1-
\sum_{p\in\mathcal P}\alpha_p^{\max}.}
\]

On a joint torus, projection to each local torus has constant fibers, so the exact local densities apply without constructing the full joint torus.

The fully analytic weaker version is

\[
\frac{U(\mathbf t)}{|\mathcal D|}
\ge
1-
\sum_{p\in\mathcal P}
\frac1{\max(\operatorname{ord}_p3,
\operatorname{ord}_p5)}.
\]

## 6.2 Exact finite-family consequence

For all 23 eligible primes \(p\le200\),

\[
\sum_p\alpha_p^{\max}
=0.6144687686816598066\ldots.
\]

Therefore every residue tuple on their joint torus leaves at least

\[
\boxed{
0.3855312313183401933\ldots}
\]

of the exponent identities uncovered.

Status: exact local values are **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**; the union deduction is **PROVED**.

This does not scale under adding primes and therefore does not meet Gate B.

## 6.3 Why average overlap cannot improve the union bound

Random residues satisfy

\[
\mathbb E|C(p,t_p)\cap C(q,t_q)|
=q_pq_q|\mathcal D|.
\]

An optimized inclusion–exclusion bound needs a lower bound on

\[
\min_{t_p,t_q}
|C(p,t_p)\cap C(q,t_q)|.
\]

Exact enumeration gives:

| pair | mean intersection | exact minimum | number of zero choices |
|---|---:|---:|---:|
| \(\{7,11\}\) | 4,909.0909 | 0 | 539 |
| \(\{11,23\}\) | 11,000 | 0 | 5,819 |

Status: **CERTIFIED BY INDEPENDENT VERIFIER**.

Thus any universal pairwise lower bound based only on mean densities or second moments is false.

## 6.4 Spectral conversion

Writing

\[
f=\frac{|\mathcal D|}{Q}\mathbf1+g,
\qquad
Q=\prod_pp^2,
\]

the top nonconstant singular value of \(\bigotimes S_p\) is

\[
\sigma_*
=
\left(\prod_p(p^2-p+1)\right)
\max_p\frac{p-1}{p^2-p+1}.
\]

Hence

\[
\min_{\mathbf t}U(\mathbf t)
\ge
|\mathcal D|
\prod_p\frac{p^2-p+1}{p^2}
-
\sigma_*
\left\|f-rac{|\mathcal D|}{Q}\mathbf1\right\|_2.
\]

This is a valid \(L^2\)-to-pointwise inequality, but it is hugely negative on every tested multi-prime family. On the synthetic \(P_4\) box it is about \(-9.79\times10^7\), versus the exact minimum 182.

Conclusion: the three-class local association scheme does not solve the global \(L^2\)-to-\(L^\infty\) problem.

## 6.5 Fractional LP and related relaxations

For any probability weight \(w\) on exponent identities,

\[
\sum_p\max_{t_p}w(C(p,t_p))<1
\]

is a valid no-cover certificate. This is the exact finite fractional-cover dual.

A floating HiGHS solve on the synthetic \(P_4\) box found an optimum 0.4860674177, stronger than uniform weighting. No rational certificate was exported, and the state does not scale to the full torus.

Classification: **COMPUTATIONAL OBSERVATION**.

Delsarte/SDP, entropy, dependent random choice, and Shearer-type methods all fail for the same reason: they control average/symmetric information, while the joint signature histogram is nonuniform and the needed statement is pointwise over adversarial residue choices.

---

# 7. Task E — cover-oriented probabilistic method

For a frozen finite domain of size \(M\),

\[
M
\prod_{p\in\mathcal P}
\left(1-rac{p-1}{p^2}\right)<1
\]

is a sufficient condition for existence of a perfect cover tuple.

## 7.1 Asymptotic product

Since

\[
1-rac{p-1}{p^2}
=
\left(1-rac1p\right)
\left(1+rac1{p(p-1)}\right),
\]

and the second product converges, the decay is controlled by \(\sum1/p\). Along primes \(p\equiv3\pmod4\), the progression-Mertens scale is

\[
\Lambda(x)
=\Theta((\log x)^{-1/2}).
\]

This is extremely slow.

## 7.2 First 598 eligible primes

For the first 598 eligible primes, ending at 9631,

\[
\Lambda_{598}
=0.4486188544431750627\ldots.
\]

For \(M=407\),

\[
\mathbb EU
=182.5878737583722505\ldots.
\]

Thus the criterion is not close. A calibrated asymptotic estimate places the finite-box threshold at an astronomical prime scale; that calibration is explicitly **HEURISTIC**.

The frozen 598-prime lower bound and this first-moment calculation are not of the same strength. The former is a combinatorial lower bound on any possible global cover family; the latter is a very weak random-existence sufficient condition.

## 7.3 Full-periodic obstruction theorem

For any expanding eligible families, with \(x=\max\mathcal P\),

\[
R_{\mathcal P}S_{\mathcal P}
\gg
\left(\sum_{p\in\mathcal P}\log p\right)^2,
\]

while

\[
\prod_{p\in\mathcal P}
\left(1-rac{p-1}{p^2}\right)
\ge
\prod_{p\le x}
\left(1-rac1p\right)
\gg\frac1{\log x}.
\]

Since \(\sum_{p\in\mathcal P}\log p\ge\log x\),

\[
\boxed{
\mathbb EU
=R_{\mathcal P}S_{\mathcal P}\Lambda_{\mathcal P}
\gg\log x\to\infty.}
\]

Status: **PROVED**, unconditional.

This proves that the naive first-moment cover criterion cannot scale on the full exponent torus. It does not rule out an optimized perfect cover.

---

# 8. Task F — standalone exact computation

## 8.1 Local scope

All 23 eligible primes \(p\le200\) were analyzed. The package records:

* \(\operatorname{ord}_p(3),\operatorname{ord}_p(5)\);
* \(\operatorname{ord}_{p^2}(3),\operatorname{ord}_{p^2}(5)\);
* local torus size;
* complete \(N_{p,a}\) and \(N^{(2)}_{p,b}\) histograms;
* exact \(\alpha_p^{\max}\);
* mean, variance, second moment, max/mean ratio;
* number of maximizing residues;
* persistent-fiber correction;
* energy and order bounds.

Primary exact method: modular NTT.  
Independent verifier: complex circular FFT with a maximum rounding error \(2.46\times10^{-11}\).  
All 292,271 coefficients matched.

## 8.2 Main local empirical conclusion

Across the 23 primes:

* exact \(\alpha_p^{\max}\) is often close to the elementary order bound;
* the sharp centered-energy bound never strictly improves the order bound;
* the uncentered-energy bound is worse by factors from 1.61 to 14.04;
* exceptional concentration occurs, notably max/mean \(=3.04545\) at \(p=67\);
* no normalized quantity shows stable improvement with growing \(p\).

Classification: exact numbers are **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**; trend assessment is **COMPUTATIONAL OBSERVATION**.

## 8.3 Family moments

Seven exact instances were exhaustively computed and independently verified, totaling 31,435,047 CRT tuples. Every instance had \(U>0\) for every tuple, but that fact is finite.

The synthetic \(P_4\) box has

\[
\mathbb EU=244.2374\ldots,
\qquad
\operatorname{Var}(U)=1952.587\ldots,
\]

\[
\min U=182,
\qquad
\max\text{ coverage}=225.
\]

The mean coverage is only 162.7626. Optimization gains more than 62 additional covered identities beyond the random mean.

This does not reproduce the accepted historical raw/live landscape because the true domain and live filters were not reconstructed. It does demonstrate why random moments alone do not explain optimized masks.

## 8.4 Reproducibility

`bash scripts/run_all.sh` rebuilds and reruns the standalone package. Exact and independent-verifier outputs, logs, environment metadata, and SHA-256 hashes are included.

---

# 9. Task G — literature audit

The audit covered:

* additive energy and sumsets of multiplicative subgroups;
* exponential sums over small subgroups;
* higher energies modulo \(p^2\);
* Mertens products in arithmetic progressions;
* Janson, Chen–Stein, Suen, LLL/Shearer;
* fractional covering, Delsarte, entropy, and SDP approaches.

Key findings:

1. Exact Fourier/Parseval identities apply directly.
2. Heath-Brown–Konyagin/Schoen–Shkredov energy scales do not beat the elementary local maximum bound after normalization.
3. BGK supplies asymptotic cancellation for \(|H|\ge p^\gamma\), but no practical explicit cross-convolution plus \(p^2\)-correction theorem was found.
4. Located \(p^2\)-energy results are specialized to the Heilbronn subgroup.
5. Alon–Bourgain's sum-free subgroup constructions warn that subgroup additive behavior need not be random.
6. Janson and Chen–Stein require positive/up-set or sparse-dependency structures absent here.
7. Mertens in progressions confirms that the survival product decays only logarithmically.

No theorem found met Gate A, B, or C. Full details and exact applicability conditions are in `literature_audit.md`.

---

# 10. Task H — candidate rigorous partial results

## Candidate 1: exact moment/association theorem

Status: **PROVED**.  
Payoff: correct probability model, exact correlations, duplicate handling, tensor operator.  
Limitation: random \(L^2\), not optimized \(L^\infty\).

## Candidate 2: box-to-torus discrepancy theorem

Status: **PROVED**.  
Payoff: prevents invalid finite-to-periodic extrapolation.  
Limitation: may be order one and gives no representation theorem.

## Candidate 3: uncentered additive-energy barrier

Status: **PROVED**.  
Payoff: eliminates a standard second-moment route without large computation.  
Limitation: does not exclude a new centered generator-specific theorem.

## Candidate 4: full-periodic first-moment obstruction

Status: **PROVED**.  
Payoff: scalable negative theorem; adding primes cannot make \(\mathbb EU<1\) work on the full torus.  
Limitation: says nothing about a rare optimized cover.

## Candidate 5: finite anti-cover through \(p\le200\)

Status: **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION + PROVED union reduction**.  
Payoff: every residue choice leaves at least 38.5531% of the full joint torus.  
Limitation: one finite family only.

## Candidate 6: explicit centered \(p^2\) two-orbit theorem

Status: **UNKNOWN**.  
Required form: an explicit pointwise cross-convolution/fiber bound uniformly stronger than \(1/\max(m,n)\).  
Evidence: none of the tested standard bounds improve the benchmark.

## Publication assessment

The exact moment theorem and full-torus obstruction are useful lemmas/propositions in a broader methodological paper. The finite anti-cover certificate is a strong reproducible example. No result has sufficient direct A303656 leverage for a standalone major theorem claim.

---

# 11. Task I — comparison with other routes

The present route has low theorem leverage because it studies a proxy obstruction under random residue choices, while the problem is an optimized universal statement.

Clear comparisons:

* fixed \(P_4/P_5\) optimization and interval scans are high-quality finite computation but likely to generate only more finite landscapes;
* global \((p^2)\)-cover search is logically decisive if successful but currently too large and unguided;
* joint-prime exact search is justified only to test a specific lemma, as done here for minimum intersections;
* Gate V3 is a provenance project, not an analytic bridge;
* circle method/additive combinatorics may yield average results but at least attack the actual representation count;
* direct study of two-square density and an analytic sieve on \(n-3^c-5^d\) are logically closer and offer more plausible theorem leverage.

The best next analytic subject is not another bad-prime moment. It is the actual count of exponent pairs for which the remainder is a sum of two squares, with explicit control of shift correlations and large-prime tails.

Full comparison is in `route_comparison.md`.

---

# 12. Promotion-gate decision

## Gate A: nontrivial local theorem

**FAIL.** No explicit local inequality improves the elementary order bound in a meaningful regime. Standard energy bounds are provably unable to do so.

## Gate B: nontrivial family anti-cover theorem

**FAIL.** The positive \(p\le200\) margin is finite and not stable under family expansion. Pairwise minimum intersections can be zero.

## Gate C: useful probabilistic cover criterion

**FAIL.** For 407 points, the first 598 eligible primes leave expectation 182.6. On the full torus the criterion is asymptotically impossible.

## Gate D: validated scalable signal

**FAIL.** No normalized local bound improves with \(p\); exceptional concentrations and optimized tails remain.

## Gate E: finite theorem-payoff subproblem

**FAIL.** Small joint tori already refuted the most natural intersection lemma. No remaining \(\le10^8\)-state computation has a clearly stated theorem payoff.

---

# 13. Final adversarial verdict

The route has produced useful mathematics, but the mathematics is mostly diagnostic:

* exact moments are available;
* their correlation structure is understood;
* standard additive energy is too weak;
* average overlap cannot control adversarial overlap;
* full-torus first moment is structurally self-defeating;
* the only positive anti-cover result is fixed-family and non-scalable.

The decisive blocker is not insufficient computation. It is the absence of a theorem converting random \(L^2\) information into an optimized colored-cover lower bound. More prime enumeration or larger moment tables would not repair that defect.

Therefore:

\[
\boxed{\textbf{STOP ANALYTIC BAD-PRIME ROUTE}.}
\]

Do not promote to Phase B. Do not send continuation work to ordinary Codex or Codex Ultra. A new route-selection phase should be performed on webpage GPT-5.6 Pro before any implementation, with direct analytic sieve / two-square representation density as the first subject to audit.

---

# 14. Package map

| file | content |
|---|---|
| `EXECUTIVE_VERDICT.md` | compact decision and required deliverables |
| `ROUTE_VERDICT.json` | machine-readable verdict and gates |
| `mathematical_framework.md` | frozen definitions, domains, logical relation |
| `probability_spaces.md` | Models A/B/C and boundary errors |
| `random_crt_moments.md` | exact moments, correlations, operators, inequalities |
| `local_additive_energy.md` | local fibers, convolution, energy, Fourier bounds |
| `anti_cover_inequalities.md` | union, intersection, spectral, LP, hypergraph analysis |
| `candidate_theorems.md` | precise statements, proofs, status, limitations |
| `literature_audit.md` | primary-source theorem audit and applicability |
| `computational_experiments.md` | algorithms, exact results, independent verification |
| `route_comparison.md` | comparison against other research directions |
| `limitations.md` | explicit non-claims and epistemic limits |
| `scripts/` | standalone source and reproduction runner |
| `results/` | exact CSV/JSON outputs and independent verifier records |
| `logs/` | execution logs |
| `environment.json` | software/hardware metadata |
| `SHA256SUMS.txt` | package integrity hashes |
