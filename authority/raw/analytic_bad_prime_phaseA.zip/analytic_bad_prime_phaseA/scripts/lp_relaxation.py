#!/usr/bin/env python3
import json
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parents[1]
C,D=11,37;P=[3,7,11,23];pairs=[(c,d) for c in range(C) for d in range(D)]
blocks=[];local=[]
for p in P:
 n=p*p;x=np.array([(pow(3,c,n)+pow(5,d,n))%n for c,d in pairs],dtype=np.int64);t=np.arange(n,dtype=np.int64)
 B=((t[None,:]%p==x[:,None]%p)&(t[None,:]!=x[:,None])).astype(float);blocks.append(B)
 local.append({'p':p,'max_coverage_count':int(B.sum(axis=0).max()),'max_coverage_density':float(B.sum(axis=0).max()/(C*D))})
B=np.concatenate(blocks,axis=1);M,N=B.shape
# Maximize z subject to z <= B_u x, sum_t x_{p,t}=1, x>=0.
c=np.zeros(N+1);c[-1]=-1
A_ub=np.zeros((M,N+1));A_ub[:,:N]=-B;A_ub[:,-1]=1
A_eq=np.zeros((len(P),N+1));off=0
for i,p in enumerate(P):n=p*p;A_eq[i,off:off+n]=1;off+=n
res=linprog(c,A_ub=A_ub,b_ub=np.zeros(M),A_eq=A_eq,b_eq=np.ones(len(P)),bounds=[(0,None)]*N+[(None,None)],method='highs')
out={
 'classification':'COMPUTATIONAL OBSERVATION (floating-point LP; no rational dual certificate exported)',
 'domain':'synthetic box D_{11,37}','domain_size':M,'family':P,'variables_including_z':N+1,'coverage_constraints':M,
 'solver_success':bool(res.success),'solver_message':res.message,'fractional_maximin_blocking_value':float(-res.fun),
 'integral_perfect_cover_would_require_value_at_least':1.0,
 'uniform_weight_union_bound_sum_local_maxima':sum(x['max_coverage_density'] for x in local),
 'local_finite_box_statistics':local,
 'dual_interpretation':'z*=min_{w in simplex(D)} sum_p max_t w(C(p,t)); z*<1 would be an exact no-cover certificate if accompanied by a verified rational dual solution.',
 'limitation':'This finite synthetic box is not the accepted 407-pair active/live domain, and the present output is not a proof object.'
}
(ROOT/'results/lp_relaxation_P4_box.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
