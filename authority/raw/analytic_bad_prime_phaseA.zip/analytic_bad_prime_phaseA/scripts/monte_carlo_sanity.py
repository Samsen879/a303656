#!/usr/bin/env python3
import json,math,random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
C,D=11,37; P=[3,7,11,23]; M=C*D
pairs=[(c,d) for c in range(C) for d in range(D)]
res={p:[(pow(3,c,p*p)+pow(5,d,p*p))%(p*p) for c,d in pairs] for p in P}
rng=random.Random(20260716);N=50000
vals=[]
for _ in range(N):
    ts={p:rng.randrange(p*p) for p in P};u=0
    for i in range(M):
        survive=True
        for p in P:
            x=res[p][i];t=ts[p]
            if t%p==x%p and t!=x:
                survive=False;break
        if survive:u+=1
    vals.append(u)
mean=sum(vals)/N; var=sum((x-mean)**2 for x in vals)/N
exact=json.load(open(ROOT/'results/family_P4_box_11x37.json'))
out={'classification':'COMPUTATIONAL OBSERVATION / deterministic-seed Monte Carlo sanity check','seed':20260716,'samples':N,'sample_mean':mean,'sample_variance':var,'exact_mean':exact['E_U'],'exact_variance':exact['variance'],'mean_z_error_in_standard_errors':(mean-exact['E_U'])/math.sqrt(exact['variance']/N),'variance_relative_error':var/exact['variance']-1}
(ROOT/'results/monte_carlo_sanity.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
