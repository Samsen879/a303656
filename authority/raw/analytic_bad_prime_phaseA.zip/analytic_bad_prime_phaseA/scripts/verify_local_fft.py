#!/usr/bin/env python3
"""Independent all-coefficient verifier for local_prime_statistics.csv.

Algorithmically independent of the C++ radix-2 NTT implementation: this uses a
length-p^2 complex DFT to obtain the circular additive convolution directly,
rounds only after recording the distance to the nearest integer, and checks every
coefficient-derived statistic and every exact mass/energy identity.
"""
from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SUMMARY = ROOT / "results" / "local_prime_statistics.csv"
OUT = ROOT / "results" / "independent_local_fft_verification.json"


def orbit_indicator(base: int, modulus: int, order: int) -> np.ndarray:
    out = np.zeros(modulus, dtype=np.float64)
    x = 1
    for _ in range(order):
        if out[x] != 0:
            raise AssertionError("premature orbit repetition")
        out[x] = 1.0
        x = (x * base) % modulus
    if x != 1:
        raise AssertionError("orbit does not close")
    return out


def near(a: float, b: float, tol: float = 5e-10) -> bool:
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


def main() -> None:
    rows = list(csv.DictReader(SUMMARY.open()))
    records: list[dict] = []
    global_max_rounding_error = 0.0
    for row in rows:
        p = int(row["p"])
        n = p * p
        r = int(row["ord_p2_3"])
        s = int(row["ord_p2_5"])
        A = orbit_indicator(3, n, r)
        B = orbit_indicator(5, n, s)

        raw = np.fft.ifft(np.fft.fft(A) * np.fft.fft(B)).real
        nearest = np.rint(raw)
        max_err = float(np.max(np.abs(raw - nearest)))
        global_max_rounding_error = max(global_max_rounding_error, max_err)
        # The observed margin is enormous relative to the 1/2 rounding threshold.
        if max_err >= 1e-6:
            raise AssertionError(f"unsafe FFT rounding margin at p={p}: {max_err}")
        N2 = nearest.astype(np.int64)
        if np.any(N2 < 0) or int(N2.max()) > min(r, s):
            raise AssertionError(f"invalid coefficient at p={p}")

        Np = np.bincount(np.arange(n) % p, weights=N2, minlength=p)
        if not np.all(Np == np.rint(Np)):
            raise AssertionError("nonintegral p-fiber count")
        Np = np.rint(Np).astype(np.int64)
        cov = Np[np.arange(n) % p] - N2

        M = r * s
        checks = {
            "sum_Np": int(Np.sum()) == int(row["sum_Np"]) == M,
            "sum_Np_sq": int(Np @ Np) == int(row["sum_Np_sq"]),
            "max_Np": int(Np.max()) == int(row["max_Np"]),
            "num_max_Np": int(np.sum(Np == Np.max())) == int(row["num_max_Np"]),
            "sum_Np2": int(N2.sum()) == int(row["sum_Np2"]) == M,
            "sum_Np2_sq": int(N2 @ N2) == int(row["sum_Np2_sq"]),
            "max_Np2": int(N2.max()) == int(row["max_Np2"]),
            "num_max_Np2": int(np.sum(N2 == N2.max())) == int(row["num_max_Np2"]),
            "coverage_sum": int(cov.sum()) == int(row["coverage_sum"]) == M * (p - 1),
            "coverage_sum_sq": int(cov @ cov) == int(row["coverage_sum_sq"]),
            "max_coverage_count": int(cov.max()) == int(row["max_coverage_count"]),
            "num_maximizing_residues": int(np.sum(cov == cov.max())) == int(row["num_maximizing_residues"]),
            "coverage_energy_identity": int(cov @ cov)
            == (p - 2) * int(Np @ Np) + int(N2 @ N2),
            "alpha_max": near(int(cov.max()) / M, float(row["alpha_max"])),
        }
        if not all(checks.values()):
            failed = [k for k, v in checks.items() if not v]
            raise AssertionError(f"p={p} failed checks: {failed}")
        records.append(
            {
                "p": p,
                "all_p2_coefficients_checked": n,
                "max_distance_to_nearest_integer": max_err,
                "rounding_threshold_margin_factor": 0.5 / max_err if max_err else "infinite",
                "all_checks_passed": True,
            }
        )

    payload = {
        "classification": "INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION",
        "scope": "all p^2 convolution coefficients and all derived local statistics for every eligible prime p<=200",
        "primary_implementation": "C++ exact radix-2 NTT modulo 998244353",
        "independent_implementation": "Python/NumPy length-p^2 complex circular FFT with recorded rounding margin",
        "eligible_prime_count": len(records),
        "total_coefficients_checked": sum(r["all_p2_coefficients_checked"] for r in records),
        "global_max_distance_to_nearest_integer": global_max_rounding_error,
        "minimum_margin_to_half_integer": 0.5 - global_max_rounding_error,
        "all_checks_passed": True,
        "caveat": "The independent implementation uses floating FFT, but every coefficient is separated from a half-integer by the recorded margin and all exact integer identities agree with the modular NTT output.",
        "records": records,
    }
    OUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({k: payload[k] for k in ("eligible_prime_count", "total_coefficients_checked", "global_max_distance_to_nearest_integer", "all_checks_passed")}, indent=2))


if __name__ == "__main__":
    main()
