#!/usr/bin/env python3
import csv,gzip,json,math,random
from collections import defaultdict,Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def brute_order(a,n):
    x=1
    for k in range(1,n+1):
        x=(x*a)%n
        if x==1:return k
    raise RuntimeError

def orbit(a,n,order):
    out=[];x=1
    for _ in range(order):out.append(x);x=x*a%n
    assert x==1 and len(set(out))==order
    return out

stats=list(csv.DictReader(open(ROOT/'results/local_prime_statistics.csv')))
hist=defaultdict(dict); fibers=defaultdict(dict); covs=defaultdict(dict)
with gzip.open(ROOT/'results/local_histograms_long.csv.gz','rt') as f:
    for r in csv.DictReader(f):
        p=int(r['p']);level=r['level'];x=int(r['residue']);hist[(p,level)][x]=int(r['count'])
        if level=='p2':fibers[p][x]=int(r['p_fiber_count']);covs[p][x]=int(r['coverage_count'])
checks=[];rng=random.Random(1759)
for row in stats:
    p=int(row['p']);n=p*p
    r=brute_order(3,n);s=brute_order(5,n)
    assert r==int(row['ord_p2_3']) and s==int(row['ord_p2_5'])
    H=orbit(3,n,r);K=orbit(5,n,s);KS=set(K)
    n2=hist[(p,'p2')];np_=hist[(p,'p')]
    assert sum(n2.values())==r*s==int(row['local_torus_size'])
    assert all(np_[a]==sum(n2[a+j*p] for j in range(p)) for a in range(p))
    assert sum(covs[p].values())==(r*s)*(p-1)
    if p<=31:
        ctr=Counter((h+k)%n for h in H for k in K)
        assert all(ctr[b]==n2[b] for b in range(n))
        mode='full_direct_convolution'
        samples=n
    else:
        candidates={0,n-1,int(row['num_maximizing_residues'])%n}
        maxcov=int(row['max_coverage_count'])
        for b,v in covs[p].items():
            if v==maxcov:
                candidates.add(b)
                if len(candidates)>=8: break
        while len(candidates)<20:candidates.add(rng.randrange(n))
        for b in candidates:
            direct=sum(1 for h in H if (b-h)%n in KS)
            assert direct==n2[b]
            assert np_[b%p]-direct==covs[p][b]
        mode='deterministic_sampled_coefficients'
        samples=len(candidates)
    checks.append({'p':p,'order_check':True,'histogram_identites':True,'coefficient_check_mode':mode,'coefficients_checked':samples})

# Independent exact pair-pattern numerator for the P4 size-matched box.
C,D=11,37;P=[3,7,11,23];M=C*D
sh=[]
for p in P:
    n=p*p; sh.append([(pow(3,c,n)+pow(5,d,n))%n for c in range(C) for d in range(D)])
Q=math.prod(p*p for p in P); numer=0
for u in range(M):
  for v in range(M):
    prod=1
    for j,p in enumerate(P):
      x,y=sh[j][u],sh[j][v]
      if x==y: g=p*p-p+1
      elif x%p==y%p:g=p*p-p
      else:g=p*p-2*p+2
      prod*=g
    numer+=prod
cpp=json.load(open(ROOT/'results/family_P4_box_11x37.json'))
assert numer==int(cpp['sum_U2'])
assert M*math.prod(p*p-p+1 for p in P)==int(cpp['sum_U'])
# Directly verify lexicographic minimizer and maximizer U values.
def U_at(ts):
  ans=0
  for u in range(M):
    if all(not (ts[j]%P[j]==sh[j][u]%P[j] and ts[j]!=sh[j][u]) for j in range(len(P))):ans+=1
  return ans
assert U_at(cpp['lex_first_argmin'])==cpp['min_U']
assert U_at(cpp['lex_first_argmax'])==cpp['max_U']

out={
 'classification':'CERTIFIED BY INDEPENDENT VERIFIER for stated checks; exhaustive local coefficient verification only for p<=31',
 'local_prime_checks':checks,
 'P4_pair_moment_exact_numerator_match':True,
 'P4_extremizer_direct_recheck':True,
 'limitations':'For p>31 the independent Python verifier checks orders, all aggregate identities, and deterministic sampled convolution coefficients; it does not independently reconstruct every p^2 coefficient.'
}
(ROOT/'results/independent_verification.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
