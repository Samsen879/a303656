#!/usr/bin/env python3
"""Structural and cross-result validator for the Phase A research package.

This validator does not rerun the expensive enumerations.  It verifies package
completeness, parses every JSON/CSV/GZIP artifact, and checks the principal
cross-file invariants and independent-verifier flags.
"""
from __future__ import annotations

import csv
import gzip
import json
import sys
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"

REQUIRED_TOP = [
    "REPORT.md",
    "EXECUTIVE_VERDICT.md",
    "ROUTE_VERDICT.json",
    "mathematical_framework.md",
    "probability_spaces.md",
    "random_crt_moments.md",
    "local_additive_energy.md",
    "anti_cover_inequalities.md",
    "candidate_theorems.md",
    "literature_audit.md",
    "computational_experiments.md",
    "route_comparison.md",
    "limitations.md",
    "environment.json",
]
REQUIRED_RESULTS = [
    "local_prime_statistics.csv",
    "pair_correlation_statistics.csv",
    "prime_family_moments.csv",
    "calibration_P4.json",
    "scaling_summary.json",
]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        require(bool(reader.fieldnames), f"CSV has no header: {path}")
        require(bool(rows), f"CSV has no data rows: {path}")
        return rows


def fraction_from_record(record: dict[str, str]) -> Fraction:
    return Fraction(int(record["numerator"]), int(record["denominator"]))


def main() -> int:
    checks: list[str] = []

    for rel in REQUIRED_TOP:
        path = ROOT / rel
        require(path.is_file() and path.stat().st_size > 0, f"missing/empty: {rel}")
    for rel in REQUIRED_RESULTS:
        path = RESULTS / rel
        require(path.is_file() and path.stat().st_size > 0, f"missing/empty: results/{rel}")
    checks.append("required deliverables present and nonempty")

    json_paths = sorted(ROOT.rglob("*.json"))
    parsed = {path: load_json(path) for path in json_paths}
    require(len(parsed) >= 15, "unexpectedly few JSON artifacts")
    checks.append(f"parsed {len(parsed)} JSON artifacts")

    csv_paths = sorted(ROOT.rglob("*.csv"))
    csv_rows = {path: load_csv(path) for path in csv_paths}
    require(len(csv_rows) >= 10, "unexpectedly few CSV artifacts")
    checks.append(f"parsed {len(csv_rows)} CSV artifacts")

    hist_gz = RESULTS / "local_histograms_long.csv.gz"
    with gzip.open(hist_gz, "rt", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = next(reader)
        row_count = sum(1 for _ in reader)
    require(header == ["p", "level", "residue", "count", "p_fiber_count", "coverage_count"],
            "unexpected histogram header")
    require(row_count == 294468, f"unexpected compressed histogram row count: {row_count}")
    checks.append(f"validated GZIP histogram ({row_count} data rows)")

    verdict = parsed[ROOT / "ROUTE_VERDICT.json"]
    require(verdict["global_status"] == "UNRESOLVED", "global status changed")
    require(verdict["route_verdict"] == "STOP ANALYTIC BAD-PRIME ROUTE", "route verdict mismatch")
    require(verdict["promotion_gates"]["any_gate_met"] is False, "promotion gate incorrectly passed")
    require(all(value is False for key, value in verdict["promotion_gates"].items() if key != "any_gate_met"),
            "one or more promotion gates unexpectedly true")
    require(all(value is False for value in verdict["forbidden_actions_compliance"].values()),
            "a forbidden action was marked as performed")
    checks.append("route/global-status/gate/forbidden-action invariants pass")

    local_rows = csv_rows[RESULTS / "local_prime_statistics.csv"]
    primes = [int(row["p"]) for row in local_rows]
    require(len(primes) == 23 and len(set(primes)) == 23, "eligible-prime table cardinality mismatch")
    require(primes == sorted(primes), "eligible-prime table not sorted")
    require(all(p <= 200 and p % 4 == 3 and p not in (3, 5) for p in primes), "ineligible p in local table")
    coeff_count = sum(p * p for p in primes)
    require(coeff_count == 292271, f"local coefficient count mismatch: {coeff_count}")
    require(all(Fraction(int(row["max_coverage_count"]), int(row["local_torus_size"])) <=
                Fraction(1, max(int(row["ord_p_3"]), int(row["ord_p_5"])))
                for row in local_rows), "local exact alpha violates order bound")
    checks.append("23-prime local table and exact order bounds pass")

    local_fft = parsed[RESULTS / "independent_local_fft_verification.json"]
    require(local_fft["all_checks_passed"] is True, "independent local FFT verifier failed")
    require(local_fft["eligible_prime_count"] == 23, "local FFT prime count mismatch")
    require(local_fft["total_coefficients_checked"] == coeff_count, "local FFT coefficient count mismatch")
    require(local_fft["global_max_distance_to_nearest_integer"] < 1e-8,
            "FFT integer-recovery margin unexpectedly weak")
    checks.append("independent local FFT verification passes")

    family = parsed[RESULTS / "independent_family_numpy_verification.json"]
    require(family["all_checks_passed"] is True, "independent family verifier failed")
    require(family["family_instance_count"] == 7, "family-instance count mismatch")
    require(family["total_CRT_tuple_survivor_counts_checked"] == 31435047,
            "family CRT-tuple count mismatch")
    require(all(record["all_checks_passed"] for record in family["records"]),
            "one family verifier record failed")
    checks.append("independent 7-family NumPy verification passes")

    pair_direct = parsed[RESULTS / "independent_pairwise_intersection_verification.json"]
    require(len(pair_direct["families"]) == 2, "pairwise verifier family count mismatch")
    expected_pairwise = {
        (7, 11): (485100, 5929, 0, 7560, 539),
        (11, 23): (3200450, 64009, 0, 16698, 5819),
    }
    for record in pair_direct["families"]:
        key = (record["p"], record["q"])
        require(key in expected_pairwise, f"unexpected pairwise family: {key}")
        observed = (
            record["domain_size"], record["tuple_count"],
            record["min_intersection_count"], record["max_intersection_count"],
            record["zero_intersection_tuple_count"],
        )
        require(observed == expected_pairwise[key], f"direct pairwise verifier mismatch: {key}")
    checks.append("independent direct pairwise-intersection verification passes")

    scaling_verify = parsed[RESULTS / "independent_scaling_verification.json"]
    for key in ["survival_product_exact_match", "reciprocal_sum_exact_match", "local_alpha_sum_exact_match"]:
        require(scaling_verify[key] is True, f"scaling verifier failed: {key}")
    require(scaling_verify["eligible_count"] == 598 and scaling_verify["last_prime"] == 9631,
            "598-prime scaling metadata mismatch")
    checks.append("independent SymPy scaling verification passes")

    scaling = parsed[RESULTS / "scaling_summary.json"]
    alpha_sum = fraction_from_record(scaling["sum_exact_alpha_max_le_200_exact"])
    survivor = fraction_from_record(scaling["deterministic_union_bound_survivor_density_le_200_exact"])
    require(alpha_sum + survivor == 1, "finite anti-cover fractions do not sum to one")
    require(survivor > Fraction(385, 1000), "finite anti-cover lower bound unexpectedly weak")
    require(scaling["first_598_eligible_last_prime"] == 9631, "scaling summary last prime mismatch")
    checks.append("finite anti-cover and 598-prime exact fractions are internally consistent")

    p4 = parsed[RESULTS / "calibration_P4.json"]
    syn = p4["synthetic_size_matched_domain"]["exact_random_CRT_results"]
    require(syn["domain_size"] == 407, "synthetic P4 box size mismatch")
    require(syn["min_U"] == 182 and syn["max_coverage"] == 225, "synthetic P4 extrema mismatch")
    require(syn["perfect_cover_tuple_count"] == 0, "unexpected perfect cover in synthetic P4 box")
    require(p4["synthetic_size_matched_domain"]["pair_correlation_summary"]["offdiagonal_ordered_pairs_with_equal_integer_shift"] == 2,
            "duplicate-shift identity count mismatch")
    checks.append("synthetic P4 calibration and duplicate-shift accounting pass")

    report = (ROOT / "REPORT.md").read_text(encoding="utf-8")
    executive = (ROOT / "EXECUTIVE_VERDICT.md").read_text(encoding="utf-8")
    for text_name, text in [("REPORT.md", report), ("EXECUTIVE_VERDICT.md", executive)]:
        require("STOP ANALYTIC BAD-PRIME ROUTE" in text, f"verdict absent from {text_name}")
        require("OEIS A303656" in text and "UNRESOLVED" in text, f"global status absent from {text_name}")
    checks.append("human-readable entrypoints state the frozen global and route verdicts")

    print("PHASE A PACKAGE VALIDATION: PASS")
    print(f"root: {ROOT}")
    for index, message in enumerate(checks, 1):
        print(f"{index:02d}. PASS — {message}")
    print(f"total checks: {len(checks)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:  # deliberately broad for a one-shot verifier
        print(f"PHASE A PACKAGE VALIDATION: FAIL — {exc}", file=sys.stderr)
        raise
