#!/usr/bin/env python3
import argparse, csv, json, math
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np

def shifts_box(C,D,mod):
    a=np.empty(C,dtype=np.int64); b=np.empty(D,dtype=np.int64)
    a[0]=1%mod
    for i in range(1,C): a[i]=(a[i-1]*3)%mod
    b[0]=1%mod
    for i in range(1,D): b[i]=(b[i-1]*5)%mod
    return ((a[:,None]+b[None,:])%mod).reshape(-1)

def analyze(C,D,family,out_csv,out_json):
    M=C*D
    codes=np.zeros((M,M),dtype=np.uint16)
    local=[]
    lambdas=[]
    gammas_by_p=[]
    for j,p in enumerate(family):
        n=p*p
        x=shifts_box(C,D,n)
        eqp=(x[:,None]%p)==(x[None,:]%p)
        eq2=x[:,None]==x[None,:]
        typ=np.zeros((M,M),dtype=np.uint8)
        typ[eqp]=1; typ[eq2]=2
        codes += typ.astype(np.uint16)*(3**j)
        cnt=np.bincount(typ.ravel(),minlength=3)
        q=(p-1)/(p*p); lam=1-q; lambdas.append(lam)
        g=[1-2*q,1-1/p,lam]
        gammas_by_p.append(g)
        for t,name in enumerate(['different_mod_p','same_mod_p_not_p2','same_mod_p2']):
            local.append({
                'domain':f'box_{C}x{D}','family':','.join(map(str,family)),'row_type':'local_type',
                'p':p,'pattern':name,'type_code':t,'ordered_pair_count':int(cnt[t]),
                'pair_fraction':float(cnt[t]/(M*M)),'gamma':g[t],
                'independent_baseline':lam*lam,'correlation_ratio':g[t]/(lam*lam),
                'E_U2_contribution':float(cnt[t]*g[t])
            })
    pattern_counts=np.bincount(codes.ravel(),minlength=3**len(family))
    joint=[]; Q=math.prod(p*p for p in family); Lambda=math.prod(lambdas)
    e2=0.0
    for code,count in enumerate(pattern_counts):
        if count==0: continue
        z=code; types=[]; gamma=1.0
        for j,p in enumerate(family):
            t=z%3;z//=3;types.append(t);gamma*=gammas_by_p[j][t]
        e2 += int(count)*gamma
        joint.append({
            'domain':f'box_{C}x{D}','family':','.join(map(str,family)),'row_type':'joint_pattern',
            'p':'','pattern':'|'.join(map(str,types)),'type_code':code,'ordered_pair_count':int(count),
            'pair_fraction':float(count/(M*M)),'gamma':gamma,'independent_baseline':Lambda*Lambda,
            'correlation_ratio':gamma/(Lambda*Lambda),'E_U2_contribution':float(count*gamma)
        })
    # Exact integer-shift duplicate groups; identities remain distinct.
    vals=[]
    for c in range(C):
        for d in range(D): vals.append(pow(3,c)+pow(5,d))
    grp=Counter(vals)
    duplicate_groups=[v for v in grp.values() if v>1]
    exact_equal_ordered=sum(v*v for v in grp.values())
    summary={
        'classification':'INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION',
        'domain':f'box_{C}x{D}','C':C,'D':D,'domain_size':M,'family':family,
        'ordered_pair_count':M*M,'joint_pattern_count_nonzero':len(joint),
        'E_U2_from_pair_formula':e2,
        'E_U_from_formula':M*Lambda,
        'variance_from_pair_formula':e2-(M*Lambda)**2,
        'duplicate_integer_shift_group_count':len(duplicate_groups),
        'duplicate_integer_shift_multiplicities':sorted(duplicate_groups,reverse=True),
        'ordered_pairs_with_equal_integer_shift':exact_equal_ordered,
        'offdiagonal_ordered_pairs_with_equal_integer_shift':exact_equal_ordered-M,
        'note':'u,v are ordered exponent-pair identities; duplicate integer shifts are not merged.'
    }
    fields=['domain','family','row_type','p','pattern','type_code','ordered_pair_count','pair_fraction','gamma','independent_baseline','correlation_ratio','E_U2_contribution']
    with open(out_csv,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(local+joint)
    Path(out_json).write_text(json.dumps(summary,indent=2),encoding='utf-8')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--C',type=int,required=True);ap.add_argument('--D',type=int,required=True)
    ap.add_argument('--family',required=True);ap.add_argument('--out-csv',required=True);ap.add_argument('--out-json',required=True)
    a=ap.parse_args(); analyze(a.C,a.D,[int(x) for x in a.family.split(',')],a.out_csv,a.out_json)
