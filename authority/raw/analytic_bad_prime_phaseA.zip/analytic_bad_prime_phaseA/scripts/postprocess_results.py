#!/usr/bin/env python3
import csv,json,math,glob,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
# Enrich local prime statistics with exact/comparator bounds.
p=ROOT/'results/local_prime_statistics.csv'
rows=list(csv.DictReader(p.open()))
extra=['trivial_order_bound','uncentered_energy_bound','centered_energy_bound','centered_energy_bound_sharp','parseval_cauchy_bound','alpha_over_trivial','centered_bound_over_trivial','centered_sharp_over_trivial','uncentered_bound_over_trivial']
for r in rows:
    pp=int(r['p']);m=int(r['ord_p_3']);n=int(r['ord_p_5']);r2=int(r['ord_p2_3']);s2=int(r['ord_p2_5']);M=int(r['local_torus_size'])
    L=(r2//m)*(s2//n); E=int(r['sum_Np_sq'])/(L*L)
    trivial=1/max(m,n)
    unc=math.sqrt(int(r['sum_Np_sq']))/M
    centered=1/pp+math.sqrt(max(0.0,E-(m*n)**2/pp))/(m*n)
    centered_sharp=1/pp+math.sqrt((pp-1)/pp*max(0.0,E-(m*n)**2/pp))/(m*n)
    parseval=1/pp+1/math.sqrt(m*n)
    alpha=float(r['alpha_max'])
    r.update({
      'trivial_order_bound':repr(trivial),'uncentered_energy_bound':repr(unc),'centered_energy_bound':repr(centered),
      'centered_energy_bound_sharp':repr(centered_sharp),'parseval_cauchy_bound':repr(parseval),'alpha_over_trivial':repr(alpha/trivial),
      'centered_bound_over_trivial':repr(centered/trivial),'centered_sharp_over_trivial':repr(centered_sharp/trivial),'uncentered_bound_over_trivial':repr(unc/trivial)})
with p.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)
# Aggregate family JSON files.
jsons=[]
for fn in sorted(glob.glob(str(ROOT/'results/family_*.json'))):
    d=json.load(open(fn));d['source_file']=os.path.basename(fn);jsons.append(d)
fields=['source_file','family','domain_type','C','D','domain_size','crt_tuple_count','E_U','E_U2','variance','coefficient_of_variation_squared','paley_zygmund_lower_bound_Pr_U_positive','exact_Pr_U_positive','perfect_cover_tuple_count','min_U','max_U','max_coverage','max_coverage_density','number_argmin','lex_first_argmin']
with (ROOT/'results/prime_family_moments.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for d in jsons:
        row={k:d.get(k) for k in fields}; row['family']=','.join(map(str,d['family'])); row['lex_first_argmin']=json.dumps(d['lex_first_argmin'])
        w.writerow(row)
