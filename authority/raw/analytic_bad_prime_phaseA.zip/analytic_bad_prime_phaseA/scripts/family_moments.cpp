#include <bits/stdc++.h>
using namespace std;
using u64=unsigned long long;
using u128=__uint128_t;
using i128=__int128_t;

u64 modpow(u64 a,u64 e,u64 m){u64 r=1%m;while(e){if(e&1)r=(u128)r*a%m;a=(u128)a*a%m;e>>=1;}return r;}
vector<u64> factors(u64 n){vector<u64>v;for(u64 d=2;d*d<=n;d+=(d==2?1:2))if(n%d==0){v.push_back(d);while(n%d==0)n/=d;}if(n>1)v.push_back(n);return v;}
u64 ordermod(u64 a,u64 mod,u64 phi){if(std::gcd(a,mod)!=1)return 0;u64 o=phi;for(u64 q:factors(phi))while(o%q==0&&modpow(a,o/q,mod)==1)o/=q;return o;}
u64 gcd64(u64 a,u64 b){while(b){u64 t=a%b;a=b;b=t;}return a;}
u64 lcm64(u64 a,u64 b){return a/gcd64(a,b)*b;}
string u128s(u128 x){if(!x)return"0";string s;while(x){s.push_back('0'+x%10);x/=10;}reverse(s.begin(),s.end());return s;}
long double ld(u128 x){long double r=0,b=1;while(x){r+=(unsigned)(x%1000000000ULL)*b;b*=1000000000.0L;x/=1000000000ULL;}return r;}
vector<int> parsefam(const string&s){vector<int>v;stringstream ss(s);string x;while(getline(ss,x,','))v.push_back(stoi(x));return v;}
string json_array(const vector<int>&v){string s="[";for(size_t i=0;i<v.size();i++){if(i)s+=",";s+=to_string(v[i]);}return s+"]";}
string json_array_u64(const vector<u64>&v){string s="[";for(size_t i=0;i<v.size();i++){if(i)s+=",";s+=to_string(v[i]);}return s+"]";}

int main(int argc,char**argv){
    string fams,domain="box",out="family.json",hist="";u64 C=0,D=0;
    for(int i=1;i<argc;i++){
        string a=argv[i];
        if(a=="--family"&&i+1<argc)fams=argv[++i];
        else if(a=="--domain"&&i+1<argc)domain=argv[++i];
        else if(a=="--C"&&i+1<argc)C=stoull(argv[++i]);
        else if(a=="--D"&&i+1<argc)D=stoull(argv[++i]);
        else if(a=="--out"&&i+1<argc)out=argv[++i];
        else if(a=="--hist"&&i+1<argc)hist=argv[++i];
        else {cerr<<"unknown arg "<<a<<"\n";return 2;}
    }
    if(fams.empty()){cerr<<"family required\n";return 2;}
    vector<int>P=parsefam(fams);int k=P.size();
    vector<u64>dims(k),r3(k),r5(k);
    for(int i=0;i<k;i++){
        u64 p=P[i],n=p*p;dims[i]=n;
        if(domain=="torus"){
            if(p==3||p==5){cerr<<"p=3 or 5 invalid for multiplicative torus\n";return 2;}
            r3[i]=ordermod(3,n,p*(p-1));r5[i]=ordermod(5,n,p*(p-1));
        }
    }
    if(domain=="torus"){
        C=1;D=1;for(int i=0;i<k;i++){C=lcm64(C,r3[i]);D=lcm64(D,r5[i]);}
    } else if(domain!="box"){cerr<<"domain must be box or torus\n";return 2;}
    if(C==0||D==0){cerr<<"C,D required\n";return 2;}
    u128 M128=(u128)C*D;if(M128>UINT32_MAX){cerr<<"domain too large for uint32 count\n";return 2;}u64 M=(u64)M128;
    u128 Q128=1;for(u64 d:dims)Q128*=d;if(Q128>500000000ULL){cerr<<"CRT tensor too large\n";return 2;}u64 Q=(u64)Q128;
    cerr<<"family="<<fams<<" domain="<<domain<<" C="<<C<<" D="<<D<<" M="<<M<<" Q="<<Q<<"\n";
    vector<vector<u64>> pc3(k,vector<u64>(C)),pd5(k,vector<u64>(D));
    for(int i=0;i<k;i++){
        u64 n=dims[i];pc3[i][0]=1%n;for(u64 c=1;c<C;c++)pc3[i][c]=(u128)pc3[i][c-1]*3%n;
        pd5[i][0]=1%n;for(u64 d=1;d<D;d++)pd5[i][d]=(u128)pd5[i][d-1]*5%n;
    }
    vector<u64>stride(k);u64 st=1;for(int i=k-1;i>=0;i--){stride[i]=st;st*=dims[i];}
    vector<uint32_t>A(Q,0);
    for(u64 c=0;c<C;c++)for(u64 d=0;d<D;d++){
        u64 idx=0;for(int i=0;i<k;i++){u64 x=(pc3[i][c]+pd5[i][d])%dims[i];idx+=x*stride[i];}
        A[idx]++;
    }
    u128 chk=0,sig_l2=0;u64 sig_distinct=0;uint32_t sig_max=0;for(auto v:A){chk+=v;sig_l2+=(u128)v*v;if(v){sig_distinct++;sig_max=max(sig_max,v);}}if(chk!=M){cerr<<"hist sum mismatch\n";return 3;}
    // Apply local survival operator S_p = J - block(J_p) + I along each axis.
    for(int ax=0;ax<k;ax++){
        u64 n=dims[ax],p=P[ax],s=stride[ax],outer=Q/(n*s);
        vector<u64>fiber(p);
        for(u64 o=0;o<outer;o++)for(u64 off=0;off<s;off++){
            u64 base=o*n*s+off,total=0;fill(fiber.begin(),fiber.end(),0);
            for(u64 j=0;j<n;j++){u64 v=A[base+j*s];total+=v;fiber[j%p]+=v;}
            for(u64 j=0;j<n;j++){u64 nv=total-fiber[j%p]+A[base+j*s];if(nv>UINT32_MAX){cerr<<"overflow\n";return 3;}A[base+j*s]=(uint32_t)nv;}
        }
        cerr<<" transformed p="<<p<<"\n";
    }
    uint32_t umin=UINT32_MAX,umax=0;u64 nmin=0,nmax=0,firstmin=0,firstmax=0,zero=0,positive=0;
    u128 sum=0,sumsq=0;vector<u64>H(M+1,0);
    for(u64 i=0;i<Q;i++){
        uint32_t u=A[i];sum+=u;sumsq+=(u128)u*u;H[u]++;if(u==0)zero++;else positive++;
        if(u<umin){umin=u;nmin=1;firstmin=i;}else if(u==umin)nmin++;
        if(u>umax){umax=u;nmax=1;firstmax=i;}else if(u==umax)nmax++;
    }
    auto decode=[&](u64 idx){vector<u64>v(k);for(int i=0;i<k;i++)v[i]=(idx/stride[i])%dims[i];return v;};
    vector<u64>argmin=decode(firstmin),argmax=decode(firstmax);
    long double mean=ld(sum)/(long double)Q,second=ld(sumsq)/(long double)Q;
    long double var=max((long double)0,second-mean*mean),cv2=(mean?var/(mean*mean):0),pz=(sumsq?ld(sum)*ld(sum)/((long double)Q*ld(sumsq)):0);
    u128 Lprod=1;long double max_nonconst_ratio=0;for(int p:P){u128 L=(u128)p*p-p+1;Lprod*=L;max_nonconst_ratio=max(max_nonconst_ratio,(long double)(p-1)/(long double)L);}
    u128 expected_sum=(u128)M*Lprod;
    long double disc2=max((long double)0,ld(sig_l2)-(long double)M*M/(long double)Q);
    long double spectral_sigma=ld(Lprod)*max_nonconst_ratio;
    long double spectral_lower=mean-spectral_sigma*sqrtl(disc2);
    if(sum!=expected_sum){cerr<<"first moment sum mismatch got="<<u128s(sum)<<" exp="<<u128s(expected_sum)<<"\n";return 3;}
    ofstream os(out);os<<setprecision(18);
    os<<"{\n";
    os<<"  \"classification\": \"INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION\",\n";
    os<<"  \"family\": "<<json_array(P)<<",\n";
    os<<"  \"domain_type\": \""<<domain<<"\",\n";
    os<<"  \"C\": "<<C<<", \"D\": "<<D<<", \"domain_size\": "<<M<<",\n";
    os<<"  \"joint_torus_R\": "<<(domain=="torus"?C:0)<<", \"joint_torus_S\": "<<(domain=="torus"?D:0)<<",\n";
    os<<"  \"crt_tuple_count\": "<<Q<<",\n";
    os<<"  \"distinct_signature_count\": "<<sig_distinct<<", \"max_signature_multiplicity\": "<<sig_max<<", \"signature_l2_squared\": \""<<u128s(sig_l2)<<"\",\n";
    os<<"  \"sum_U\": \""<<u128s(sum)<<"\", \"sum_U2\": \""<<u128s(sumsq)<<"\",\n";
    os<<"  \"E_U\": "<<(double)mean<<", \"E_U2\": "<<(double)second<<", \"variance\": "<<(double)var<<",\n";
    os<<"  \"coefficient_of_variation_squared\": "<<(double)cv2<<", \"paley_zygmund_lower_bound_Pr_U_positive\": "<<(double)pz<<",\n";
    os<<"  \"spectral_uniform_lower_bound_min_U\": "<<(double)spectral_lower<<", \"spectral_bound_nontrivial\": "<<(spectral_lower>0?"true":"false")<<",\n";
    os<<"  \"exact_Pr_U_positive\": "<<(double)((long double)positive/Q)<<", \"perfect_cover_tuple_count\": "<<zero<<",\n";
    os<<"  \"min_U\": "<<umin<<", \"number_argmin\": "<<nmin<<", \"lex_first_argmin\": "<<json_array_u64(argmin)<<",\n";
    os<<"  \"max_U\": "<<umax<<", \"number_argmax\": "<<nmax<<", \"lex_first_argmax\": "<<json_array_u64(argmax)<<",\n";
    os<<"  \"max_coverage\": "<<(M-umin)<<", \"max_coverage_density\": "<<(double)((long double)(M-umin)/M)<<"\n";
    os<<"}\n";
    if(!hist.empty()){
        ofstream hh(hist);hh<<"U,count\n";for(u64 u=0;u<H.size();u++)if(H[u])hh<<u<<","<<H[u]<<"\n";
    }
    return 0;
}
