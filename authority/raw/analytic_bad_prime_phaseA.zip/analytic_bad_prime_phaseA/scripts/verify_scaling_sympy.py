#!/usr/bin/env python3
from __future__ import annotations
import csv, json
from fractions import Fraction
from pathlib import Path
import sympy as sp
ROOT=Path(__file__).resolve().parents[1]
S=json.loads((ROOT/'results/scaling_summary.json').read_text())
# Independent prime generation: SymPy primerange rather than the trial-division generator.
P=[]
bound=10000
while len(P)<598:
    P=[int(p) for p in sp.primerange(2,bound) if int(p)%4==3 and int(p) not in (3,5)]
    bound*=2
P=P[:598]
prod=sp.Rational(1,1)
rec=sp.Rational(0,1)
for p in P:
    prod*=sp.Rational(p*p-p+1,p*p)
    rec+=sp.Rational(1,p)
stored=S['first_598_survival_product_exact']
assert int(stored['numerator'])==int(prod.p)
assert int(stored['denominator'])==int(prod.q)
storedr=S['first_598_sum_reciprocals_exact']
assert int(storedr['numerator'])==int(rec.p)
assert int(storedr['denominator'])==int(rec.q)
# Independent aggregation of exact local densities.
rows=list(csv.DictReader((ROOT/'results/local_prime_statistics.csv').open()))
sa=sum((Fraction(int(r['max_coverage_count']),int(r['local_torus_size'])) for r in rows),Fraction())
st=S['sum_exact_alpha_max_le_200_exact']
assert sa==Fraction(int(st['numerator']),int(st['denominator']))
out={
 'classification':'CERTIFIED BY INDEPENDENT VERIFIER',
 'method':'SymPy prime generation and exact Rational arithmetic; independent of trial-division/Fraction scaling script',
 'eligible_count':len(P),
 'last_prime':P[-1],
 'survival_product_exact_match':True,
 'reciprocal_sum_exact_match':True,
 'local_alpha_sum_exact_match':True
}
(ROOT/'results/independent_scaling_verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
