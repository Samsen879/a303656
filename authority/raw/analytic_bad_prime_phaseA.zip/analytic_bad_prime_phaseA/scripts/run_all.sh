#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p results logs

CXX=${CXX:-g++}
CXXFLAGS=${CXXFLAGS:--O3 -std=c++20 -Wall -Wextra -pedantic}

$CXX $CXXFLAGS scripts/local_prime_stats.cpp -o scripts/local_prime_stats
$CXX $CXXFLAGS scripts/family_moments.cpp -o scripts/family_moments

scripts/local_prime_stats --max-prime 200 \
  --summary results/local_prime_statistics.csv \
  --hist results/local_histograms_long.csv \
  > logs/local_prime_stats.stdout.log 2> logs/local_prime_stats.stderr.log
gzip -f results/local_histograms_long.csv

run_family () {
  local tag="$1"; shift
  scripts/family_moments "$@" \
    --out "results/family_${tag}.json" \
    --hist "results/family_${tag}_U_histogram.csv" \
    > "logs/family_${tag}.stdout.log" 2> "logs/family_${tag}.stderr.log"
}
run_family 7 --family 7 --domain torus
run_family 11 --family 11 --domain torus
run_family 23 --family 23 --domain torus
run_family 7_11_torus --family 7,11 --domain torus
run_family 11_23_torus --family 11,23 --domain torus
run_family 7_11_23_box_11x37 --family 7,11,23 --domain box --C 11 --D 37
run_family P4_box_11x37 --family 3,7,11,23 --domain box --C 11 --D 37

python scripts/postprocess_results.py > logs/postprocess_results.log 2>&1
python scripts/pair_correlations.py --C 11 --D 37 --family 3,7,11,23 \
  --out-csv results/pair_correlation_statistics.csv \
  --out-json results/pair_correlation_summary.json \
  > logs/pair_correlations.log 2>&1
python scripts/monte_carlo_sanity.py > logs/monte_carlo_sanity.log 2>&1
python scripts/pairwise_intersections.py > logs/pairwise_intersections.log 2>&1
python scripts/lp_relaxation.py > logs/lp_relaxation.log 2>&1
python scripts/verify_exact.py > logs/verify_exact.log 2>&1
python scripts/verify_local_fft.py > logs/verify_local_fft.log 2>&1
python scripts/verify_family_numpy.py > logs/verify_family_numpy.log 2>&1
$CXX $CXXFLAGS scripts/verify_pairwise_intersections_direct.cpp -o scripts/verify_pairwise_intersections_direct
scripts/verify_pairwise_intersections_direct > results/independent_pairwise_intersection_verification.json 2> logs/verify_pairwise_intersections_direct.log
python scripts/scaling_analysis.py > logs/scaling_analysis.log 2>&1
python scripts/verify_scaling_sympy.py > logs/verify_scaling_sympy.log 2>&1
python scripts/validate_package.py > logs/validation_summary.log 2>&1

echo "Phase A standalone computations and package validation completed."
