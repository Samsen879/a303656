#!/usr/bin/env python3
import csv,math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]

def order(a,n):
 x=1
 for k in range(1,n+1):
  x=x*a%n
  if x==1:return k
 raise RuntimeError

def lcm(a,b):return a//math.gcd(a,b)*b

def powseq(a,L,n):
 x=np.empty(L,dtype=np.int64);x[0]=1%n
 for i in range(1,L):x[i]=x[i-1]*a%n
 return x

def block_matrix(p):
 n=p*p;x=np.arange(n)
 return ((x[:,None]%p==x[None,:]%p)&(x[:,None]!=x[None,:])).astype(np.int64)

def analyze(p,q):
 np_,nq=p*p,q*q
 R=lcm(order(3,np_),order(3,nq));S=lcm(order(5,np_),order(5,nq));M=R*S
 a1=powseq(3,R,np_);b1=powseq(5,S,np_);a2=powseq(3,R,nq);b2=powseq(5,S,nq)
 F=np.zeros((np_,nq),dtype=np.int64)
 for c in range(R):
  x=(a1[c]+b1)%np_;y=(a2[c]+b2)%nq
  np.add.at(F,(x,y),1)
 B1=block_matrix(p);B2=block_matrix(q)
 I=B1@F@B2.T
 mean=I.mean();mn=int(I.min());mx=int(I.max())
 return {'family':f'{p},{q}','R':R,'S':S,'domain_size':M,'tuple_count':np_*nq,'mean_intersection_count':mean,'mean_intersection_density':mean/M,'min_intersection_count':mn,'min_intersection_density':mn/M,'max_intersection_count':mx,'max_intersection_density':mx/M,'min_over_mean':mn/mean if mean else 0,'zero_intersection_tuple_count':int(np.count_nonzero(I==0)),'number_argmin':int(np.count_nonzero(I==mn))}
rows=[analyze(7,11),analyze(11,23)]
with open(ROOT/'results/pairwise_intersection_statistics.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print(rows)
