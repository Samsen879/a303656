#include <bits/stdc++.h>
using namespace std;
using int64 = long long;
using u64 = unsigned long long;
using i128 = __int128_t;
using u128 = __uint128_t;

static const int MOD = 998244353;
static const int G = 3;

long long modpowll(long long a, long long e, long long mod){
    long long r=1%mod;
    while(e){
        if(e&1) r=(__int128)r*a%mod;
        a=(__int128)a*a%mod;
        e>>=1;
    }
    return r;
}
int modpow(int a, int e){
    long long r=1, x=a;
    while(e){ if(e&1) r=r*x%MOD; x=x*x%MOD; e>>=1; }
    return (int)r;
}
void ntt(vector<int>& a, bool invert){
    int n=a.size();
    for(int i=1,j=0;i<n;i++){
        int bit=n>>1;
        for(; j&bit; bit>>=1) j^=bit;
        j^=bit;
        if(i<j) swap(a[i],a[j]);
    }
    for(int len=2;len<=n;len<<=1){
        int wlen=modpow(G,(MOD-1)/len);
        if(invert) wlen=modpow(wlen,MOD-2);
        for(int i=0;i<n;i+=len){
            long long w=1;
            for(int j=0;j<len/2;j++){
                int u=a[i+j], v=(int)(a[i+j+len/2]*w%MOD);
                int x=u+v; if(x>=MOD)x-=MOD;
                int y=u-v; if(y<0)y+=MOD;
                a[i+j]=x; a[i+j+len/2]=y;
                w=w*wlen%MOD;
            }
        }
    }
    if(invert){
        int invn=modpow(n,MOD-2);
        for(int &x:a) x=(int)((long long)x*invn%MOD);
    }
}
vector<u64> circular_convolution_01(const vector<int>& A, const vector<int>& B){
    int n=A.size();
    int need=2*n-1, L=1;
    while(L<need) L<<=1;
    if(L>(1<<23)) throw runtime_error("NTT length exceeds modulus capability");
    vector<int> fa(L),fb(L);
    copy(A.begin(),A.end(),fa.begin());
    copy(B.begin(),B.end(),fb.begin());
    ntt(fa,false); ntt(fb,false);
    for(int i=0;i<L;i++) fa[i]=(long long)fa[i]*fb[i]%MOD;
    ntt(fa,true);
    vector<u64> out(n,0);
    for(int i=0;i<need;i++) out[i%n]+=fa[i];
    return out;
}
vector<long long> factor_distinct(long long n){
    vector<long long> f;
    for(long long d=2;d*d<=n;d+=(d==2?1:2)) if(n%d==0){
        f.push_back(d); while(n%d==0)n/=d;
    }
    if(n>1)f.push_back(n);
    return f;
}
long long multiplicative_order(long long a, long long mod, long long phi){
    if(std::gcd(a,mod)!=1) return 0;
    long long ord=phi;
    for(long long q:factor_distinct(phi)) while(ord%q==0 && modpowll(a,ord/q,mod)==1) ord/=q;
    return ord;
}
bool isprime(int n){
    if(n<2)return false;
    if(n%2==0)return n==2;
    for(int d=3;1LL*d*d<=n;d+=2) if(n%d==0)return false;
    return true;
}
string u128str(u128 x){
    if(x==0)return "0";
    string s; while(x){s.push_back('0'+x%10);x/=10;} reverse(s.begin(),s.end()); return s;
}
long double to_ld(u128 x){
    long double r=0, base=1;
    while(x){ r += (unsigned)(x%1000000000ULL)*base; base*=1000000000.0L; x/=1000000000ULL; }
    return r;
}

int main(int argc,char**argv){
    int maxp=200;
    string summary="local_prime_statistics.csv", hist="local_histograms_long.csv";
    for(int i=1;i<argc;i++){
        string a=argv[i];
        if(a=="--max-prime" && i+1<argc) maxp=stoi(argv[++i]);
        else if(a=="--summary" && i+1<argc) summary=argv[++i];
        else if(a=="--hist" && i+1<argc) hist=argv[++i];
        else { cerr<<"Unknown arg: "<<a<<"\n"; return 2; }
    }
    ofstream os(summary), oh(hist);
    if(!os||!oh){cerr<<"cannot open output\n";return 2;}
    os << "p,ord_p_3,ord_p_5,ord_p2_3,ord_p2_5,lift_3,lift_5,local_torus_size,";
    os << "sum_Np,sum_Np_sq,max_Np,num_max_Np,sum_Np2,sum_Np2_sq,max_Np2,num_max_Np2,";
    os << "coverage_sum,coverage_sum_sq,mean_coverage_count,variance_coverage_count,sd_coverage_count,";
    os << "max_coverage_count,alpha_max,mean_density,max_mean_ratio,num_maximizing_residues,";
    os << "p_level_ceiling_gap,min_p2_at_max,max_p2_at_max,max_zscore,exceptional_flag\n";
    oh << "p,level,residue,count,p_fiber_count,coverage_count\n";

    for(int p=2;p<=maxp;p++){
        if(!isprime(p) || p%4!=3 || p==3 || p==5) continue;
        long long n=1LL*p*p, phi=1LL*p*(p-1);
        long long o3=multiplicative_order(3,p,p-1), o5=multiplicative_order(5,p,p-1);
        long long r=multiplicative_order(3,n,phi), s=multiplicative_order(5,n,phi);
        if(!r||!s) throw runtime_error("order zero");
        vector<int>A(n),B(n);
        long long x=1;
        for(long long i=0;i<r;i++){ if(A[x]) throw runtime_error("3 orbit duplicate early"); A[x]=1; x=x*3%n; }
        if(x!=1) throw runtime_error("3 orbit did not close");
        x=1;
        for(long long i=0;i<s;i++){ if(B[x]) throw runtime_error("5 orbit duplicate early"); B[x]=1; x=x*5%n; }
        if(x!=1) throw runtime_error("5 orbit did not close");
        vector<u64>N2=circular_convolution_01(A,B);
        u128 M=(u128)r*s;
        u128 sum2=0, sum2sq=0; u64 max2=0, nummax2=0;
        for(u64 v:N2){
            if(v>(u64)min(r,s)) throw runtime_error("coefficient too large");
            sum2+=v; sum2sq+=(u128)v*v;
            if(v>max2){max2=v;nummax2=1;} else if(v==max2)nummax2++;
        }
        if(sum2!=M) throw runtime_error("convolution sum mismatch");
        vector<u64>Np(p,0);
        for(long long b=0;b<n;b++) Np[b%p]+=N2[b];
        u128 sump=0,sumpsq=0; u64 maxpcount=0,nummaxp=0;
        for(u64 v:Np){
            sump+=v; sumpsq+=(u128)v*v;
            if(v>maxpcount){maxpcount=v;nummaxp=1;} else if(v==maxpcount)nummaxp++;
        }
        if(sump!=M) throw runtime_error("p-fiber sum mismatch");
        vector<u64>cov(n);
        u128 csum=0,csumsq=0; u64 cmax=0,ncmax=0,minN2max=ULLONG_MAX,maxN2max=0;
        for(long long b=0;b<n;b++){
            cov[b]=Np[b%p]-N2[b];
            csum+=cov[b]; csumsq+=(u128)cov[b]*cov[b];
            if(cov[b]>cmax){cmax=cov[b];ncmax=1;minN2max=maxN2max=N2[b];}
            else if(cov[b]==cmax){ncmax++;minN2max=min(minN2max,N2[b]);maxN2max=max(maxN2max,N2[b]);}
        }
        u128 expected_csum=M*(p-1);
        if(csum!=expected_csum) throw runtime_error("coverage sum identity mismatch");
        long double mean=to_ld(csum)/(long double)n;
        long double second=to_ld(csumsq)/(long double)n;
        long double var=max((long double)0,second-mean*mean);
        long double sd=sqrtl(var);
        long double alpha=(long double)cmax/to_ld(M);
        long double md=(long double)(p-1)/(long double)n;
        long double ratio=(mean? (long double)cmax/mean:0);
        long double z=(sd?((long double)cmax-mean)/sd:0);
        int exceptional=(ratio>=1.25L || z>=3.0L);
        u64 ceiling_gap=maxpcount-cmax;

        os<<p<<","<<o3<<","<<o5<<","<<r<<","<<s<<","<<(r/o3)<<","<<(s/o5)<<","<<u128str(M)<<",";
        os<<u128str(sump)<<","<<u128str(sumpsq)<<","<<maxpcount<<","<<nummaxp<<",";
        os<<u128str(sum2)<<","<<u128str(sum2sq)<<","<<max2<<","<<nummax2<<",";
        os<<u128str(csum)<<","<<u128str(csumsq)<<","<<setprecision(18)<<(double)mean<<","<<(double)var<<","<<(double)sd<<",";
        os<<cmax<<","<<(double)alpha<<","<<(double)md<<","<<(double)ratio<<","<<ncmax<<",";
        os<<ceiling_gap<<","<<minN2max<<","<<maxN2max<<","<<(double)z<<","<<exceptional<<"\n";

        for(int a=0;a<p;a++) oh<<p<<",p,"<<a<<","<<Np[a]<<",,"<<"\n";
        for(long long b=0;b<n;b++) oh<<p<<",p2,"<<b<<","<<N2[b]<<","<<Np[b%p]<<","<<cov[b]<<"\n";
        cerr<<"p="<<p<<" r="<<r<<" s="<<s<<" M="<<u128str(M)<<" alpha="<<(double)alpha<<"\n";
    }
    return 0;
}
