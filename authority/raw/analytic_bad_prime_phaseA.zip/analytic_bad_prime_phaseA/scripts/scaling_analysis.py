#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
from decimal import Decimal, getcontext
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
getcontext().prec = 100


def isprime(n: int) -> bool:
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    d = 3
    while d * d <= n:
        if n % d == 0:
            return False
        d += 2
    return True


def eligible_primes(k: int) -> list[int]:
    out: list[int] = []
    n = 7
    while len(out) < k:
        if n % 4 == 3 and isprime(n) and n not in (3, 5):
            out.append(n)
        n += 4
    return out


def dec(fr: Fraction) -> Decimal:
    return Decimal(fr.numerator) / Decimal(fr.denominator)


P = eligible_primes(598)
prod_exact = Fraction(1, 1)
sum_recip_exact = Fraction(0, 1)
for p in P:
    prod_exact *= Fraction(p * p - p + 1, p * p)
    sum_recip_exact += Fraction(1, p)
prod_dec = dec(prod_exact)
M = 407
expected_dec = Decimal(M) * prod_dec

# HEURISTIC calibration only: Mertens in the progression 3 mod 4 gives
# Lambda(x) ~ C/sqrt(log x); calibrate C at x0=P[-1].
x0 = P[-1]
logx_est = math.log(x0) * float(expected_dec) ** 2

# Exact local union bound through p<=200.
rows = list(csv.DictReader(open(ROOT / "results/local_prime_statistics.csv")))
sum_alpha_exact = sum(
    (Fraction(int(r["max_coverage_count"]), int(r["local_torus_size"])) for r in rows),
    Fraction(0, 1),
)
sum_trivial_exact = sum(
    (Fraction(1, max(int(r["ord_p_3"]), int(r["ord_p_5"]))) for r in rows),
    Fraction(0, 1),
)
survivor_exact = 1 - sum_alpha_exact

summary = {
    "classification": {
        "first_598_product": "INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION (exact rational retained)",
        "local_union_sum_p_le_200": "INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION",
        "asymptotic_x_estimate": "HEURISTIC calibration of a rigorous asymptotic order",
        "full_torus_first_moment_obstruction": "PROVED",
    },
    "finite_domain_size": M,
    "first_598_eligible_last_prime": P[-1],
    "first_598_survival_product_exact": {
        "numerator": str(prod_exact.numerator),
        "denominator": str(prod_exact.denominator),
    },
    "first_598_survival_product_decimal": format(prod_dec, ".80g"),
    "first_598_expected_survivors_for_M407_decimal": format(expected_dec, ".80g"),
    "first_598_sum_reciprocals_exact": {
        "numerator": str(sum_recip_exact.numerator),
        "denominator": str(sum_recip_exact.denominator),
    },
    "first_598_sum_reciprocals_decimal": format(dec(sum_recip_exact), ".80g"),
    "required_log_x_calibrated_for_EU_below_1": logx_est,
    "required_log10_x_calibrated_for_EU_below_1": logx_est / math.log(10),
    "eligible_primes_le_200_count": len(rows),
    "sum_exact_alpha_max_le_200_exact": {
        "numerator": str(sum_alpha_exact.numerator),
        "denominator": str(sum_alpha_exact.denominator),
    },
    "sum_exact_alpha_max_le_200_decimal": format(dec(sum_alpha_exact), ".80g"),
    "deterministic_union_bound_survivor_density_le_200_exact": {
        "numerator": str(survivor_exact.numerator),
        "denominator": str(survivor_exact.denominator),
    },
    "deterministic_union_bound_survivor_density_le_200_decimal": format(dec(survivor_exact), ".80g"),
    "sum_trivial_order_bounds_le_200_exact": {
        "numerator": str(sum_trivial_exact.numerator),
        "denominator": str(sum_trivial_exact.denominator),
    },
    "sum_trivial_order_bounds_le_200_decimal": format(dec(sum_trivial_exact), ".80g"),
    "product_asymptotic": "over eligible p<=x, log Lambda(x)=-0.5 log log x+O(1), hence Lambda(x)=Theta((log x)^(-1/2))",
    "full_torus_obstruction": "For every expanding eligible family with x=max(P), R*S*Lambda >= c*log(x) for all sufficiently large x; hence E[U]=R*S*Lambda tends to infinity and the first-moment criterion E[U]<1 is not scalable on the full joint torus.",
}
(ROOT / "results/scaling_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

# Exact product checkpoints represented by high-precision decimal; final exact
# fraction is retained above. This table is descriptive, not a proof object.
with (ROOT / "results/first_moment_product_checkpoints.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["k", "last_prime", "survival_product_decimal_50d", "expected_survivors_M407_decimal_50d"])
    acc = Fraction(1, 1)
    for i, p in enumerate(P, 1):
        acc *= Fraction(p * p - p + 1, p * p)
        if i <= 25 or i % 25 == 0 or i == 598:
            v = dec(acc)
            w.writerow([i, p, format(v, ".50g"), format(Decimal(M) * v, ".50g")])
