# Computational experiments

## 1. Scope and prohibition audit

本轮 computation 全部为 standalone、small/medium exact or independently checked computation。没有：

* 计算任何新 \(T(n)\)；
* 调用 two-square oracle；
* 对整数 \(n\) 做 factorization census；
* interval scan；
* Gate V3 implementation；
* P5/P6 adaptive search；
* 扩大 frozen \(B=5000\)；
* 启动 598-prime global cover search；
* repository integration、Git 或 Codex CLI。

计算对象仅为局部 residue fibers、random-CRT moments、两个 manageable joint tori、一个 synthetic \(407\)-pair calibration box，以及 analytic scaling products。

---

## 2. Implementations and verification layers

### 2.1 Local prime statistics

Primary implementation: `scripts/local_prime_stats.cpp`.

For every eligible prime \(p\le200\), it computes:

\[
m=\operatorname{ord}_p(3),\quad n=\operatorname{ord}_p(5),
\quad r=\operatorname{ord}_{p^2}(3),\quad s=\operatorname{ord}_{p^2}(5),
\]

then forms the exact indicator arrays of \(\langle3\rangle\) and \(\langle5\rangle\) in \(\mathbb Z/p^2\mathbb Z\). Circular convolution is evaluated by radix-2 NTT modulo \(998244353\). Every true coefficient is at most \(\min(r,s)\), far below the modulus, so the modular output equals the integer coefficient rather than merely its residue.

The program then computes all \(N^{(2)}_{p,b}\), aggregates

\[
N_{p,a}=\sum_{b\equiv a\pmod p}N^{(2)}_{p,b},
\]

and evaluates the exact persistent coverage

\[
C_{p,b}=N_{p,b\bmod p}-N^{(2)}_{p,b}.
\]

Independent verifier: `scripts/verify_local_fft.py`.

It reconstructs every orbit and evaluates a separate complex NumPy circular FFT. It checked all \(292{,}271\) coefficients for the 23 eligible primes. The largest distance of an FFT coefficient from the nearest integer was

\[
2.4556356947869062\times10^{-11},
\]

leaving a margin of more than \(2\times10^{10}\) relative to the half-integer rounding threshold. All exact sum, energy, maximum, multiplicity, and coverage identities matched the NTT output.

Classification:

> **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**.

### 2.2 Exact family moments

Primary implementation: `scripts/family_moments.cpp`.

It constructs the joint shift-signature histogram in mixed-radix CRT coordinates and applies, for every prime, the local integer survivor transform

\[
S_p=J-P+I.
\]

Every CRT tuple's survivor count is enumerated exactly when the product state count is manageable.

Independent verifier: `scripts/verify_family_numpy.py`.

It independently reconstructs the histogram with vectorized `numpy.bincount`, reshapes each \(p^2\)-coordinate into a \(p\times p\) fiber array, and applies \(J-P+I\) in exact unsigned-integer arithmetic. It checked all extrema, multiplicities, complete \(U\)-histograms, \(\sum U\), and \(\sum U^2\).

Verified scope:

\[
31{,}435{,}047
\]

individual CRT-tuple survivor counts across 7 instances. Peak verifier memory was approximately 1.22 GB; wall time was 8.90 seconds in the recorded environment.

Classification:

> **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**.

### 2.3 Pairwise-intersection minima

Primary implementation: `scripts/pairwise_intersections.py`, using exact integer matrix products after constructing local coverage incidence matrices.

Independent verifier: `scripts/verify_pairwise_intersections_direct.cpp`, using direct exponent/lift enumeration with no matrix multiplication and no shared coverage generator. It reproduced both complete intersection distributions. Recorded resource use: 0.87 seconds wall time and 7.2 MB maximum RSS.

Classification:

> **CERTIFIED BY INDEPENDENT VERIFIER**.

### 2.4 Scaling products

Primary implementation: `scripts/scaling_analysis.py`, using trial-division prime generation and Python `Fraction` exact arithmetic.

Independent verifier: `scripts/verify_scaling_sympy.py`, using SymPy prime generation and `Rational`. It reproduced:

* the first 598 eligible primes and terminal prime \(9631\);
* the exact survival product;
* the exact reciprocal-prime sum;
* the exact sum of local \(\alpha_p^{\max}\) for \(p\le200\).

Classification:

> **CERTIFIED BY INDEPENDENT VERIFIER**.

---

## 3. Local prime results for \(p\le200\)

There are 23 eligible primes:

\[
7,11,19,23,31,43,47,59,67,71,79,83,103,107,127,131,139,151,163,167,179,191,199.
\]

Full exact results are in `results/local_prime_statistics.csv`; all residue histograms are in `results/local_histograms_long.csv.gz`.

Selected columns are summarized below.

| \(p\) | \(\operatorname{ord}_p3\) | \(\operatorname{ord}_p5\) | \(\alpha_p^{\max}\) | mean \((p-1)/p^2\) | max/mean | \(\alpha_p^{\max}/[1/\max(m,n)]\) |
|---:|---:|---:|---:|---:|---:|---:|
| 7 | 6 | 6 | 0.142857143 | 0.122448980 | 1.1667 | 0.8571 |
| 11 | 5 | 5 | 0.109090909 | 0.082644628 | 1.3200 | 0.5455 |
| 23 | 11 | 22 | 0.043478261 | 0.041587902 | 1.0455 | 0.9565 |
| 43 | 42 | 42 | 0.023255814 | 0.022714981 | 1.0238 | 0.9767 |
| 59 | 29 | 29 | 0.017533606 | 0.016661879 | 1.0523 | 0.5085 |
| 67 | 22 | 22 | 0.044776119 | 0.014702606 | 3.0455 | 0.9851 |
| 71 | 35 | 5 | 0.022535211 | 0.013886134 | 1.6229 | 0.7887 |
| 131 | 65 | 65 | 0.007751028 | 0.007575316 | 1.0232 | 0.5038 |
| 151 | 50 | 75 | 0.007682119 | 0.006578659 | 1.1677 | 0.5762 |
| 179 | 89 | 89 | 0.005649363 | 0.005555382 | 1.0169 | 0.5028 |
| 191 | 95 | 19 | 0.007715624 | 0.005208191 | 1.4814 | 0.7330 |
| 199 | 198 | 33 | 0.005025126 | 0.004999874 | 1.0051 | 0.9950 |

Across all 23 primes:

* \(\alpha_p^{\max}\) divided by the elementary order bound has minimum 0.502793, median 0.976744, and maximum 0.994975;
* the sharp centered-energy bound divided by the order bound has minimum 1, median 1.104805, and maximum 2.309368;
* the uncentered-energy/Cauchy bound divided by the order bound has minimum 1.612452, median 6.671253, and maximum 14.036748;
* the exact max/mean ratio has median 1.023195, mean 1.180572, and maximum 3.045455 at \(p=67\).

The data therefore show no trend by which standard second-moment bounds approach a useful local theorem. The elementary order bound is often nearly sharp; the exceptional concentration at \(p=67\) shows that a random/equidistributed approximation can fail by a factor exceeding 3 even at a moderate prime.

Classification:

> exact values: **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**;  
> absence of an improving trend: **COMPUTATIONAL OBSERVATION**.

---

## 4. Exact local identities checked computationally

For every tested prime, the programs checked:

\[
\sum_aN_{p,a}=rs,
\qquad
\sum_bN^{(2)}_{p,b}=rs,
\]

\[
\sum_bC_{p,b}=rs(p-1),
\]

and

\[
\sum_b C_{p,b}^2
=(p-2)\sum_aN_{p,a}^2+
\sum_b\left(N^{(2)}_{p,b}\right)^2.
\]

These identities also have independent algebraic proofs in `local_additive_energy.md`; the computation is a consistency check, not the source of the theorem.

---

## 5. Exact prime-family moments

| family | domain | \(|\mathcal D|\) | CRT tuples | \(\mathbb EU\) | \(\operatorname{Var}U\) | Paley–Zygmund lower bound | exact min \(U\) | max coverage density |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| \(\{7\}\) | torus | 1,764 | 49 | 1,548 | 216 | 0.999910 | 1,512 | 0.142857 |
| \(\{11\}\) | torus | 275 | 121 | 252.2727 | 74.3802 | 0.998833 | 245 | 0.109091 |
| \(\{23\}\) | torus | 128,018 | 529 | 122,694 | 63,888 | 0.999996 | 122,452 | 0.043478 |
| \(\{7,11\}\) | torus | 485,100 | 5,929 | 390,518.18 | \(1.920001\times10^8\) | 0.998743 | 370,440 | 0.236364 |
| \(\{11,23\}\) | torus | 3,200,450 | 64,009 | 2,813,850 | \(9.287682\times10^9\) | 0.998828 | 2,725,822 | 0.148300 |
| \(\{7,11,23\}\) | box \(11\times37\) | 407 | 3,136,441 | 314.0195 | 147.0805 | 0.998511 | 285 | 0.299754 |
| \(\{3,7,11,23\}\) | synthetic box \(11\times37\) | 407 | 28,227,969 | 244.2374 | 1,952.587 | 0.968304 | 182 | 0.552826 |

Every listed exact probability \(\Pr(U>0)\) equals 1 on the enumerated instance: no perfect cover tuple occurred. This remains a finite statement and is not an anti-cover theorem for larger domains or families.

The Paley–Zygmund bounds are numerically close to 1 because random tuples almost always leave survivors. Yet the optimized tuples cover substantially more than the random mean. On the synthetic \(P_4\) box:

\[
\mathbb E(\text{coverage})=407-244.2374=162.7626,
\]

whereas the optimized exact coverage is

\[
225.
\]

This is the concrete random-versus-optimized gap that blocks a second-moment anti-cover argument.

---

## 6. Pair correlations and collision types

`results/pair_correlation_statistics.csv` records, for each exact family instance, the counts of ordered exponent-pair pairs in every vector of local collision types:

1. distinct modulo \(p\);
2. equal modulo \(p\), unequal modulo \(p^2\);
3. equal modulo \(p^2\).

For the synthetic \(P_4\) box, the exact pair formula and exhaustive \(\sum U^2\) agree. The shift collision \(28=3^1+5^2=3^3+5^0\) is represented by two exponent identities and appears as a perfectly correlated multiplicity-two cluster.

The correlation matrix has the predicted local three-eigenspace structure, but the joint signature histogram carries many nonconstant spectral components. It is not numerically low rank in a way that controls \(\min U\).

Full distributions and summary statistics are in:

* `results/pair_correlation_statistics.csv`;
* `results/pair_correlation_summary.json`.

Classification:

> exact collision counts: **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**;  
> no exploitable low-rank collapse: **COMPUTATIONAL OBSERVATION**.

---

## 7. Optimized pairwise intersections

For two prime colors, let \(C(p,t_p)\) and \(C(q,t_q)\) be their selected coverage sets on the exact joint torus. The complete distributions are:

| family | torus size | residue-choice pairs | mean intersection | minimum intersection | maximum intersection | zero-intersection choices |
|---|---:|---:|---:|---:|---:|---:|
| \(\{7,11\}\) | 485,100 | 5,929 | 4,909.0909 | **0** | 7,560 | 539 |
| \(\{11,23\}\) | 3,200,450 | 64,009 | 11,000 | **0** | 16,698 | 5,819 |

This is not merely a small-intersection effect: the adversary can choose completely disjoint local covered sets for many residue pairs, despite substantial average overlap.

Consequences:

* random average intersection cannot be inserted into an inclusion–exclusion upper bound valid for every residue choice;
* any pairwise anti-cover improvement must use additional structure beyond local densities and average codegrees;
* a uniform positive pairwise intersection lemma is false already for these small families.

Classification:

> **CERTIFIED BY INDEPENDENT VERIFIER**.

---

## 8. Deterministic finite-family anti-cover through \(p\le200\)

The exact sum of local maximum densities for all eligible \(p\le200\) is

\[
\sum_{\substack{p\le200\\p\equiv3\ (4)\\p\nmid15}}
\alpha_p^{\max}
=0.6144687686816598066133\ldots.
\]

Therefore, on the exact joint torus and for every residue tuple,

\[
\frac{U(\mathbf t)}{|\mathcal T|}
\ge
1-\sum_p\alpha_p^{\max}
=0.3855312313183401933866\ldots.
\]

The corresponding elementary order-bound sum is approximately 0.78223155, so exact local fibers strengthen this one finite union-bound certificate.

This is the strongest positive computationally assisted result in the package. It is not scalable: adding primes increases the right-hand sum, and no theorem keeps it below 1.

Classification:

> local inputs: **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**;  
> joint-torus lower bound: **PROVED** from exact inputs.

---

## 9. First-moment scaling and the frozen 598-prime baseline

For the first 598 smallest eligible primes, ending at \(p=9631\), exact rational arithmetic gives

\[
\Lambda_{598}
=
\prod_p\left(1-\frac{p-1}{p^2}\right)
=0.4486188544431750626764544279\ldots.
\]

For a frozen finite domain of size \(M=407\),

\[
\mathbb EU=407\Lambda_{598}
=182.5878737583722505\ldots,
\]

not remotely below 1. Also

\[
\sum_{p\in\mathcal P_{598}}\frac1p
=0.8229953579\ldots.
\]

A progression-Mertens calibration, explicitly labeled **HEURISTIC**, places the scale required for \(407\Lambda(x)<1\) near

\[
\log x\approx3.06\times10^5,
\qquad
\log_{10}x\approx1.33\times10^5.
\]

The calibrated constant is not a proof of a threshold. The only rigorous conclusion needed here is that the first 598 primes fail the criterion by a factor \(182.6\), and that the full-torus criterion is asymptotically impossible by the proved period-growth theorem.

This calculation does not search for a 598-prime cover and does not contradict the frozen lower bound; it shows that naive random first moment is vastly weaker than that combinatorial baseline.

---

## 10. Synthetic \(P_4\) calibration versus accepted historical landscape

The accepted frozen facts for the historical live landscape are:

\[
H_{8,\min}=32,\qquad H_{8,\max}=201,
\]

with 21 maximizing full masks and 5 live projections. The raw historical maximum \(G_{\max}=231\) is also part of the calibration target.

The package does **not** reconstruct the accepted active/live domain, filtering stages, masks, or provenance. It instead uses the transparent synthetic box

\[
0\le c<11,
\qquad
0\le d<37,
\qquad |\mathcal D|=407,
\]

only to test the moment formula and optimized-vs-random behavior. On that synthetic box:

\[
\min U=182,
\qquad
\max\text{ coverage}=225,
\]

with 24 optimizing tuples and lexicographically first tuple

\[
(8,5,54,22).
\]

These numbers do **not** explain or reproduce \(G_{\max}=231\), \(H_{8,\max}=201\), the 21 masks, or the 5 live projections. The discrepancy is expected because the domains and live filters are different. No new \(T(n)\) was computed to bridge them.

What the synthetic calibration does establish is narrower:

* the exact random-CRT first and second moment formulas are implemented correctly;
* duplicate exponent identities are counted correctly;
* optimized coverage lies far into a tail not controlled by the variance alone.

Classification:

> synthetic-box data: **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**;  
> relation to accepted live landscape: **UNKNOWN / NOT RECONSTRUCTED**.

---

## 11. LP relaxation experiment

On the synthetic \(P_4\) box, a floating-point HiGHS solve of the finite fractional anti-cover LP returned

\[
z^*=0.4860674177,
\]

compared with 0.6535626536 for uniform vertex weights. This suggests that nonuniform dual weights can materially strengthen a finite cardinality union bound.

However, no rational primal/dual certificate was exported, and the domain is synthetic. Therefore this is not a certified theorem and cannot trigger Gate E.

Classification:

> **COMPUTATIONAL OBSERVATION**.

---

## 12. Monte Carlo sanity check

A 50,000-sample Monte Carlo run with seed 20260716 on the synthetic \(P_4\) box produced a mean survivor count consistent with the exact mean; the mean discrepancy was approximately 0.1105 standard errors. Monte Carlo was used only as a software sanity check.

Classification:

> **COMPUTATIONAL OBSERVATION**, with no proof role.

---

## 13. Reproduction

From the package root:

```bash
bash scripts/run_all.sh
```

The script compiles both C++ programs, regenerates all listed results, runs the Python post-processing and sanity checks, and runs all independent verifiers. The heaviest verifier uses about 1.22 GB RSS in the recorded environment.

Key outputs:

```text
results/local_prime_statistics.csv
results/local_histograms_long.csv.gz
results/pair_correlation_statistics.csv
results/prime_family_moments.csv
results/calibration_P4.json
results/scaling_summary.json
results/independent_local_fft_verification.json
results/independent_family_numpy_verification.json
results/independent_pairwise_intersection_verification.json
results/independent_scaling_verification.json
```
