# Limitations and non-claims

## 1. Global non-claim

\[
\boxed{\text{OEIS A303656: UNRESOLVED}.}
\]

This package proves neither:

* that every \(n>1\) has a representation \(a^2+b^2+3^c+5^d\); nor
* that a counterexample exists.

No finite result in the package is promoted to a general proof.

---

## 2. Deliberately excluded computations

The study did not:

* compute any new \(T(n)\);
* test whether specific new remainders are sums of two squares;
* use a factorization-based integer census;
* generate a new prospective integer panel;
* scan any integer interval;
* run a P5/P6 adaptive search;
* enlarge the frozen order bound \(B=5000\);
* search for a 598-prime global cover;
* implement Gate V3;
* access or modify a repository.

Therefore none of the results can be interpreted as a counterexample search outcome.

---

## 3. Domain limitations

### 3.1 Finite boxes are not the exponent lattice

The synthetic \(11\times37\) box contains 407 exponent-pair identities. It is not the accepted historical active/live domain and is not a complete periodic torus for \(P_4\). Its exact moment and optimization data are finite calibration only.

The proved box-to-torus discrepancy bound can be order one when the box dimensions are smaller than the periods. No extrapolation is made without that error term.

### 3.2 Joint torus results are family-specific

A positive survivor fraction for all eligible primes \(p\le200\) rules out only that fixed family as a perfect cover. Adding new primes changes the colored hypergraph and can destroy the union-bound margin.

The two fully enumerated pairwise joint tori, \(\{7,11\}\) and \(\{11,23\}\), are sufficient to refute a general positive minimum-intersection conjecture, but they do not describe every prime pair.

### 3.3 \(p=3\) is calibration-only

Because 3 is not a unit modulo 9, \(\operatorname{ord}_9(3)\) is undefined. The family \(P_4=\{3,7,11,23\}\) is therefore used only on a finite box in Model A, never in the multiplicative periodic-torus framework.

---

## 4. Random-versus-optimized limitation

The exact first and second moments describe a uniformly random CRT residue tuple. They do not determine

\[
\min_{\mathbf t}U(\mathbf t).
\]

In particular:

* \(\Pr(U>0)\) close to 1 does not exclude a rare tuple with \(U=0\);
* Paley–Zygmund gives a lower bound on the fraction of tuples with survivors, not a no-cover theorem;
* Chebyshev bounds the mass at zero only from above and still permits a small exceptional set;
* a small coefficient of variation does not control the extremal tail;
* the expected minimum over an optimization algorithm is not determined by \(\mathbb EU\) and \(\operatorname{Var}U\).

The synthetic \(P_4\) calibration makes this concrete: mean coverage is about 162.76, while optimized coverage is 225.

---

## 5. Additive-energy limitations

The proved uncentered-energy barrier eliminates only bounds derived through

\[
\|1_H*1_K\|_\infty\le\sqrt{E_+(H,K)}.
\]

It does not rule out:

* a sharp centered Fourier theorem;
* a theorem exploiting the fixed generators 3 and 5 rather than arbitrary subgroups;
* cancellation special to a restricted order regime;
* a new \(p^2\)-level structural identity.

Thus “STOP” means the audited standard second-moment route lacks leverage, not that every conceivable additive-combinatorial approach is impossible.

---

## 6. Literature limitations

The web audit was broad but not mathematically exhaustive. A niche theorem may have been missed, especially for exponential sums over arbitrary cyclic subgroups of \((\mathbb Z/p^2\mathbb Z)^*\). The conclusions are based on the theorems located and on their stated regimes.

Known BGK-type constants are asymptotic and not supplied in a practical explicit form in the audited exposition. The package therefore does not claim that an explicit constant can never be extracted; it claims no extracted constant was found that beats the elementary order bound in the relevant finite regime.

No GRH-based theorem was used. Conditional literature was not needed for the route verdict.

---

## 7. Numerical and certification limitations

### 7.1 Local FFT verifier

The primary local convolution is exact modular NTT. The independent implementation uses floating complex FFT and rounds to integers. Its role is a high-margin independent verifier, not a formal proof assistant. The maximum observed rounding error was \(2.46\times10^{-11}\), and all exact identities matched.

### 7.2 C++/NumPy independence

The family implementations use different data layouts and transform algorithms, but they share the frozen mathematical specification. They are independent software implementations, not independently formalized proofs in a theorem prover.

### 7.3 LP result

The HiGHS LP optimum on the synthetic box is floating point. No rational primal/dual certificate was exported. It is therefore classified only as a computational observation.

### 7.4 Hashes and reproducibility

`SHA256SUMS.txt` authenticates the packaged files after generation. It does not certify the host operating system, compiler, or external literature. `environment.json` records the execution environment but is not a reproducible container image.

---

## 8. Scaling limitations

The first-598 survival product is exact. The extrapolated value of \(x\) needed to make a 407-point first moment drop below 1 is a calibrated Mertens-scale heuristic, not a certified threshold.

The full-periodic first-moment obstruction is rigorous, but it only says the sufficient condition \(\mathbb EU<1\) fails asymptotically. It does not prove that optimized finite covers do not exist.

---

## 9. Historical calibration limitations

The package does not reconstruct:

* the accepted 407-pair active/live universe;
* the historical 52-way direct run;
* the numeric input universe and chunk bounds;
* touched-set or exact-\(T\) stage ledger;
* the 21 full masks or 5 live projections.

Accordingly, it does not claim to explain the accepted values \(G_{\max}=231\) or \(H_{8,\max}=201\). It only explains why a random-CRT second moment is not expected to recover an optimized live landscape.

---

## 10. Publication limitation

The package contains rigorous lemmas and one scalable negative proposition, but no result is presented as a standalone publishable resolution or a major theorem. The exact moment theorem and full-torus obstruction could support a methodological section in a broader paper. The finite \(p\le200\) anti-cover certificate is reproducible but not a family theorem.

---

## 11. Final epistemic classification

* Original A303656 statement: **UNRESOLVED**.
* Existence of a finite bad-prime perfect cover: **UNKNOWN**.
* Nonexistence of every finite bad-prime cover: **UNKNOWN**.
* Exact random-CRT moments: **PROVED**.
* Full-torus failure of the first-moment sufficient criterion: **PROVED**.
* Standard uncentered-energy inability to beat the order bound: **PROVED**.
* Local and family numerical outputs in their frozen domains: **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION** or **CERTIFIED BY INDEPENDENT VERIFIER**, as individually labeled.
* Scalable anti-cover theorem: **NOT OBTAINED**.
* Route verdict: **STOP ANALYTIC BAD-PRIME ROUTE**.
