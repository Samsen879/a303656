# Candidate theorems and proof status

## Overview

Phase A produced several rigorous statements, but they are mainly structural or negative. None supplies a new scalable route from local bad-prime moments to the universal A303656 question. The most substantial statements are exact moment identities, an additive-energy barrier, and a proof that the full-torus first-moment cover criterion is asymptotically self-defeating.

---

## Candidate 1: exact random-CRT moment and association theorem

### Statement

Let \(\mathcal D\) be any finite multiset of exponent-pair identities and \(\mathcal P\) any finite prime family. For each \(p\), choose \(t_p\) independently and uniformly modulo \(p^2\). Put

\[
\lambda_p=\frac{p^2-p+1}{p^2}.
\]

For \(u,v\in\mathcal D\), define

\[
\gamma_p(u,v)=
\begin{cases}
(p^2-2p+2)/p^2,&s_u\not\equiv s_v\pmod p,\\
(p^2-p)/p^2,&s_u\equiv s_v\pmod p,
\ s_u\not\equiv s_v\pmod{p^2},\\
(p^2-p+1)/p^2,&s_u\equiv s_v\pmod{p^2}.
\end{cases}
\]

Then

\[
\mathbb E U=|\mathcal D|\prod_p\lambda_p,
\]

\[
\mathbb E U^2=
\sum_{u,v\in\mathcal D}\prod_p\gamma_p(u,v),
\]

and \(\operatorname{Var}(U)=\mathbb E U^2-(\mathbb E U)^2\).

Moreover, if \(f\) is the joint signature histogram in
\(\prod_p\mathbb Z/p^2\mathbb Z\), then

\[
U=\left(\bigotimes_p S_p\right)f,
\qquad
S_p=J-P+I,
\]

and \(S_p\) has exactly three eigenvalues

\[
p^2-p+1,
\qquad1-p,
\qquad1.
\]

### Proof

Complete. The local blocking fiber has size \(p-1\); the three two-point cases follow from whether two deleted fibers are disjoint, are different punctures of the same modulo-\(p\) fiber, or coincide. CRT independence multiplies local factors. The matrix formula follows because the blocking matrix is \(P-I\), where \(P\) records equality modulo \(p\). The three eigenspaces are constants, modulo-\(p\)-fiber-constant functions of total sum zero, and functions summing to zero inside each fiber.

### Status

> **PROVED**.

The pair formula was also matched exactly against exhaustive enumeration on the synthetic \(P_4\) box.

### Relevance

It identifies the correct random variable, exact correlations, duplicate-shift multiplicities, and the source of variance. It is the most valuable exact formula in the package.

### Limitation

It controls \(L^1/L^2\) averages over CRT tuples, not the optimized minimum \(\min_{\mathbf t}U(\mathbf t)\). It does not prove or disprove a perfect cover.

### Publication assessment

Useful as a lemma or technical framework in a broader paper; too elementary and too problem-specific to constitute a convincing standalone publication.

---

## Candidate 2: finite-box to torus discrepancy theorem

### Statement

Let \(F:\mathbb Z/R\mathbb Z\times\mathbb Z/S\mathbb Z\to[0,1]\). Write

\[
C=qR+r,
\qquad D=sS+t,
\]

with \(0\le r<R\), \(0\le t<S\), and put

\[
\delta_C=\frac{r(R-r)}{CR},
\qquad
\delta_D=\frac{t(S-t)}{DS}.
\]

Then

\[
\left|\mathbb E_{\mathcal D_{C,D}}F-
\mathbb E_{\mathbb Z/R\times\mathbb Z/S}F\right|
\le\delta_C+\delta_D-\delta_C\delta_D.
\]

For a statistic of two exponent-pair samples, the error is at most

\[
1-(1-\delta_C)^2(1-\delta_D)^2
\le2\delta_C+2\delta_D.
\]

### Proof

Complete. The one-dimensional residue distribution has exact total-variation distance \(r(R-r)/(CR)\) from uniform. Couple the two coordinates independently and then couple two independent copies for pair statistics.

### Status

> **PROVED**.

### Relevance

Prevents invalid extrapolation of finite-box moment data to the periodic exponent lattice.

### Limitation

When \(C<R\) or \(D<S\), the bound may be order one. It supplies discipline, not leverage toward A303656.

---

## Candidate 3: uncentered additive-energy barrier

### Statement

For finite nonempty sets \(H,K\) in any abelian group, with \(|H|=m\), \(|K|=n\),

\[
\frac{\sqrt{E_+(H,K)}}{mn}
\ge\frac1{\sqrt{mn}}
\ge\frac1{\max(m,n)}.
\]

Therefore an upper bound on \(\|1_H*1_K\|_\infty\) obtained only from

\[
\|1_H*1_K\|_\infty\le\sqrt{E_+(H,K)}
\]

can never improve the elementary convolution bound

\[
\|1_H*1_K\|_\infty\le\min(m,n).
\]

### Proof

There are \(mn\) diagonal energy quadruples \((h,k,h,k)\), so \(E_+(H,K)\ge mn\). The remaining inequalities are algebraic.

### Status

> **PROVED**.

### Relevance

It eliminates the most direct proposed second-moment/additive-energy route before large computation.

### Limitation

It does not exclude a centered Fourier estimate or a theorem using additional subgroup structure. It is a route-elimination theorem, not a positive bound.

### Publication assessment

Not independently publishable; it is a short but decisive methodological observation.

---

## Candidate 4: full-periodic first-moment obstruction

### Statement

Let \(\mathcal P_j\) be any sequence of expanding eligible prime families and

\[
x_j=\max\mathcal P_j\to\infty.
\]

Let

\[
R_j=\operatorname{lcm}_{p\in\mathcal P_j}\operatorname{ord}_{p^2}(3),
\qquad
S_j=\operatorname{lcm}_{p\in\mathcal P_j}\operatorname{ord}_{p^2}(5),
\]

and

\[
\Lambda_j=
\prod_{p\in\mathcal P_j}
\left(1-\frac{p-1}{p^2}\right).
\]

For the full joint exponent torus, the random-CRT expected survivor count is

\[
\mathbb E U_j=R_jS_j\Lambda_j.
\]

Then

\[
\boxed{\mathbb E U_j\to\infty.}
\]

More quantitatively, for all sufficiently large \(j\),

\[
\mathbb E U_j\gg\log x_j.
\]

Consequently the sufficient cover criterion \(\mathbb E U<1\) is not scalable on the full periodic exponent lattice.

### Proof

Let

\[
L_j=\sum_{p\in\mathcal P_j}\log p,
\qquad N_j=\prod_{p\in\mathcal P_j}p^2=e^{2L_j}.
\]

Since \(3^{R_j}\equiv1\pmod{p^2}\) for every \(p\in\mathcal P_j\), CRT gives

\[
N_j\mid3^{R_j}-1,
\]

so

\[
R_j\ge\frac{\log(N_j+1)}{\log3}.
\]

Similarly

\[
S_j\ge\frac{\log(N_j+1)}{\log5}.
\]

Thus \(R_jS_j\gg L_j^2\). Also

\[
1-\frac{p-1}{p^2}>1-\frac1p.
\]

Since \(\mathcal P_j\subseteq\{p:p\le x_j\}\),

\[
\Lambda_j>
\prod_{p\in\mathcal P_j}\left(1-\frac1p\right)
\ge
\prod_{p\le x_j}\left(1-\frac1p\right)
\asymp\frac1{\log x_j}
\]

by Mertens' product theorem. Finally \(L_j\ge\log x_j\), giving

\[
R_jS_j\Lambda_j\gg
\frac{L_j^2}{\log x_j}
\ge\log x_j.
\]

### Status

> **PROVED**, unconditional.

No GRH or independence assumption is used.

### Relevance

This is the strongest scalable conclusion of Phase A. It proves that adding primes cannot make the naive first-moment cover method solve the full periodic problem; period growth eventually dominates the survival-product decay.

### Limitation

It rules out one sufficient criterion, not the existence of an optimized finite cover. An optimized tuple could cover even when the random expected survivor count is enormous.

### Publication assessment

Potentially useful as a short proposition in a paper on modular-cover strategies, but not a standalone publishable theorem.

---

## Candidate 5: finite-family exact anti-cover theorem through \(p\le200\)

### Statement

Let \(\mathcal P_{200}\) be all eligible primes \(p\le200\). On their joint exponent torus, every residue tuple satisfies

\[
\frac{U(\mathbf t)}{|\mathcal T_{\mathcal P_{200}}|}
\ge
0.3855312313183401933866\ldots.
\]

### Proof

For every prime, compute the exact local maximum density \(\alpha_p^{\max}\) on its local torus. Projection from the joint torus has constant fibers. The deterministic union bound gives

\[
U/|\mathcal T|
\ge1-\sum_{p\le200}\alpha_p^{\max}.
\]

The exact rational sum is

\[
0.6144687686816598066133\ldots.
\]

The local values were independently reproduced by exact modular NTT and a separate all-coefficient FFT verifier with a large rounding margin.

### Status

> **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION**, plus a **PROVED** reduction.

### Relevance

It certifies a nontrivial anti-cover for a concrete prime family without constructing the astronomical joint torus.

### Limitation

It is a single finite-family result. The bound is not known to remain positive when primes are added, so it does not satisfy promotion Gate B and does not address all finite covers.

---

## Candidate 6: desired local Fourier theorem

### Target statement

A genuinely useful continuation would require an explicit theorem such as

\[
\alpha_p^{\max}
\le\frac1p+
C\,p^{-\delta}\frac1{\max(m,n)}
\]

or a comparable centered convolution bound, uniform over the order regimes realized by \(\langle3\rangle\) and \(\langle5\rangle\), together with a compatible \(p^2\)-fiber correction.

### Unresolved lemma

One needs explicit, effective control of

\[
\max_a
\left|(1_H*1_K)(a)-\frac{mn}{p}\right|
\]

that beats \(\min(m,n)\), for two potentially different multiplicative subgroups, and then control of the minimum \(p^2\)-lift coefficient inside the winning fiber.

### Computational evidence

For all eligible \(p\le200\), the sharp centered-energy bound failed to beat the elementary order bound. At \(p=67\), the exact local maximum nearly saturates the order bound, showing that no uniform \(1/p+o(1/p)\) estimate can hold without substantial order conditions.

### Status

> **UNKNOWN**. No proof skeleton with useful constants was found.

### Relevance

This is exactly the missing Gate A result.

---

## Final theorem assessment

The package contains rigorous and reusable lemmas, but no theorem that moves the global A303656 status. The positive exact moment theorem describes random tuples; the two strongest scalable theorems are negative route assessments. No standalone publishable intermediate theorem with direct leverage on optimized global covering was obtained.
