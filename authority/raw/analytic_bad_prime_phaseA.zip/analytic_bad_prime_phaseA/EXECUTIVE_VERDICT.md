# Executive verdict

## Route verdict

\[
\boxed{\textbf{STOP ANALYTIC BAD-PRIME ROUTE}}
\]

The exact random-CRT second moment is mathematically clean, but it controls the distribution of a **random** residue tuple. It does not control the optimized tuple that defines a perfect cover. Exact computation and the literature audit found no scalable bridge from the resulting \(L^2\) information to the required adversarial \(L^\infty\) statement.

Global project status remains

\[
\boxed{\text{OEIS A303656: UNRESOLVED}.}
\]

No general proof and no certified counterexample is claimed.

---

## Most valuable exact formula

For a finite exponent-identity multiset \(\mathcal D\), a finite prime family \(\mathcal P\), and independent uniform \(t_p\bmod p^2\), put

\[
\lambda_p=\frac{p^2-p+1}{p^2}.
\]

For \(u,v\in\mathcal D\), the exact two-point local survival factor is

\[
\gamma_p(u,v)=
\begin{cases}
\dfrac{p^2-2p+2}{p^2},
&s_u\not\equiv s_v\pmod p,\\[5pt]
\dfrac{p^2-p}{p^2},
&s_u\equiv s_v\pmod p,
\ s_u\not\equiv s_v\pmod{p^2},\\[5pt]
\dfrac{p^2-p+1}{p^2},
&s_u\equiv s_v\pmod{p^2}.
\end{cases}
\]

Hence

\[
\boxed{
\mathbb EU=|\mathcal D|\prod_{p\in\mathcal P}\lambda_p,
\qquad
\mathbb EU^2=
\sum_{u,v\in\mathcal D}
\prod_{p\in\mathcal P}\gamma_p(u,v).}
\]

Equivalently, for the joint signature histogram \(f\),

\[
U=\left(\bigotimes_pS_p\right)f,
\qquad
S_p=J-P+I,
\]

and \(S_p\) has eigenvalues \(p^2-p+1,1-p,1\). This fully resolves Task B for Model A, including duplicate exponent identities and the three correlation types.

Status: **PROVED**.

---

## Strongest rigorous inequalities

### Positive finite-family anti-cover

For every residue choice on the joint torus of all 23 eligible primes \(p\le200\),

\[
\boxed{
\frac{U(\mathbf t)}{|\mathcal T|}
\ge
1-\sum_{p\le200}\alpha_p^{\max}
=0.3855312313183401933\ldots.}
\]

The local inputs were independently reproduced exactly; the union inequality is elementary and rigorous.

Status: **INDEPENDENTLY REPRODUCIBLE EXACT FINITE COMPUTATION + PROVED reduction**.

Limitation: fixed finite family only; the margin is not stable under adding primes.

### Strongest scalable route-elimination theorem

For any expanding eligible prime families with maximum prime \(x\), on the full joint exponent torus,

\[
\boxed{
\mathbb EU=R_{\mathcal P}S_{\mathcal P}
\prod_{p\in\mathcal P}
\left(1-\frac{p-1}{p^2}\right)
\gg\log x\to\infty.}
\]

Thus the probabilistic sufficient criterion \(\mathbb EU<1\) becomes asymptotically impossible on the full periodic exponent lattice.

Status: **PROVED**, unconditional.

### Additive-energy barrier

For nonempty finite \(H,K\),

\[
\frac{\sqrt{E_+(H,K)}}{|H||K|}
\ge\frac1{\sqrt{|H||K|}}
\ge\frac1{\max(|H|,|K|)}.
\]

Therefore an uncentered Cauchy/energy bound can never improve the elementary local order bound.

Status: **PROVED**.

---

## Decisive route blockers

1. **Random versus optimized quantifier.** Paley–Zygmund, Chebyshev, Janson-type bounds, Chen–Stein, Suen, and LLL address random outcomes or existential avoidance. A no-cover theorem needs a survivor for every optimized residue tuple.
2. **Average overlap does not survive optimization.** On the exact joint tori \(\{7,11\}\) and \(\{11,23\}\), mean pairwise intersections are 4,909.09 and 11,000, while the exact minimum is zero; there are 539 and 5,819 zero-intersection residue pairs.
3. **Standard additive energy is too weak.** The uncentered bound is structurally inferior to the order bound; the tested centered bounds for every eligible \(p\le200\) never strictly improve it.
4. **Period growth defeats first moment.** The full torus grows at least quadratically in \(\sum\log p\), while the survival product decays only logarithmically.
5. **No useful literature theorem at \(p^2\).** Located subgroup results are over \(\mathbb F_p\), asymptotic/nonexplicit, or specialized to the Heilbronn subgroup; none yields the required explicit two-orbit persistent-coverage bound.

---

## Computational evidence

* 23 eligible primes \(p\le200\) were evaluated exactly by C++ modular NTT.
* A separate NumPy circular FFT checked all 292,271 \(p^2\)-coefficients; maximum rounding error was \(2.46\times10^{-11}\).
* Seven family instances, totaling 31,435,047 CRT tuples, were independently exhaustively verified by C++ and NumPy integer tensor transforms.
* Exact pairwise intersection distributions for \(\{7,11\}\) and \(\{11,23\}\) were reproduced by a direct independent C++ enumerator.
* For the first 598 eligible primes, ending at 9631,
  \[
  \prod_p\left(1-\frac{p-1}{p^2}\right)
  =0.4486188544431750627\ldots,
  \]
  so a 407-point domain still has expected survivor count \(182.5879\ldots\), far above 1.
* On a transparent synthetic 407-pair \(P_4\) box, mean coverage is \(162.76\), but optimized coverage is 225. This demonstrates the extremal tail gap. It does not reproduce the historical accepted live landscape.

All scopes and classifications are recorded in `computational_experiments.md`.

---

## Candidate theorem status

| candidate | status | theorem payoff |
|---|---|---|
| exact random-CRT moments and three-eigenspace operator | **PROVED** | correct framework, descriptive rather than extremal |
| finite-box/torus discrepancy bound | **PROVED** | prevents invalid extrapolation |
| uncentered additive-energy barrier | **PROVED** | decisively eliminates a standard route |
| full-periodic first-moment obstruction | **PROVED** | scalable negative proposition |
| anti-cover for all eligible \(p\le200\) | exact finite + proved union bound | nontrivial but non-scalable |
| explicit centered two-subgroup \(p^2\) bound | **UNKNOWN** | required for a positive local gate |
| optimized family anti-cover | **NOT OBTAINED** | Gate B fails |

No candidate gives new direct leverage toward proving or refuting A303656.

---

## Promotion gate

* Gate A — nontrivial local theorem: **FAIL**.
* Gate B — nontrivial family anti-cover bound along an expanding family: **FAIL**.
* Gate C — realistic probabilistic cover criterion: **FAIL**.
* Gate D — validated scalable improving signal: **FAIL**.
* Gate E — \(\le10^8\)-state exact subproblem with a clear pending theorem payoff: **FAIL**.

No promotion condition is met.

---

## Execution recommendation

Stop this route. Do not hand it to ordinary Codex or Codex Ultra. A new phase, only after a fresh mathematical specification, should remain on webpage GPT-5.6 Pro and assess a direct analytic sieve / two-square representation-density route, where the random variable counts actual representable remainders rather than proxy bad-prime coverage.
