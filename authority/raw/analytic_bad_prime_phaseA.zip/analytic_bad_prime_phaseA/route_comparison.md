# Route comparison

## 1. Evaluation standard

比较维度：

* **theorem leverage**：是否可能产生随 domain 扩展的 theorem；
* **computational cost**：是否需要 production-scale search；
* **assumptions**：是否依赖 GRH、independence 或 unproved distribution hypotheses；
* **scalability**：状态量是否随 prime/domain 爆炸；
* **logical proximity**：与原 universal statement 的逻辑距离；
* **finite-observation risk**：是否大概率只刷新一个有限 landscape；
* **verification**：是否可导出 independent exact certificate。

本表不是为了“平衡”；结论是 bad-prime second-moment route 应停止。

---

## 2. Comparative matrix

| route | theorem leverage | computational cost | assumptions | scalability | relation to A303656 | finite-only risk | exact verification | Phase-A judgment |
|---|---|---|---|---|---|---|---|---|
| 1. fixed \(P_4/P_5\) finite optimization | low | medium–high | none | poor beyond fixed family | indirect; only local masks | **very high** | feasible on frozen domains | archived finite tool, not analytic route |
| 2. global finite \((p^2)\)-cover | potentially decisive counterexample mechanism | extreme; frozen lower bound ≥598 primes | none | very poor | direct if entire exponent torus covered | high unless full proof object | in principle, but enormous | not primary; do not restart |
| 3. joint-prime exact search | medium only with theorem-guided state compression | high–extreme | none | generally exponential/tensor explosion | direct for a fixed family | high | feasible only for small families | no unguided expansion |
| 4. direct interval verification | essentially none for universal theorem | linear/large | none | no | tests original equation directly on finite interval | **maximal** | excellent | useful engineering, no theorem leverage |
| 5. clean-room prospective Gate V3 | provenance leverage, not mathematical leverage | high | none | finite panel only | direct on chosen integers, not global | high | potentially excellent | separate project; forbidden this phase |
| 6. circle method / additive combinatorics | medium for average/asymptotic statements | analytic + moderate computation | may require major/minor arc hypotheses in variants | better than covers for average results | closer to representation count | medium | proof audit feasible | worth theoretical screening, but universal exceptions remain hard |
| 7. modular local-to-global analysis | medium if a new invariant appears | low–medium initially | none ideally | unknown | structurally relevant | medium | finite local lemmas verifiable | possible pivot, but current bad-prime cover formalism exhausted |
| 8. direct two-square representation density | medium–high for average shift survival | analytic; moderate computation | classical theorems unconditional, fine-scale uniformity hard | potentially good | very close to the actual remainder condition | medium | theorem + finite constants auditable | best analytic pivot to assess next |
| 9. analytic sieve on \(n-3^c-5^d\) | potentially high | analytic and technically difficult | may need distribution estimates, but not necessarily GRH | potentially scalable if uniform in \(n\) | closest route to “at least one good shift” | lower than modular landscapes if theorem succeeds | proof verification feasible | highest-priority feasibility study after stopping this route |

---

## 3. Route-by-route adversarial assessment

### 3.1 Fixed-\(P_4/P_5\) finite optimization

The accepted fixed-\(P_4\) landscape is a high-quality exact finite result. It demonstrates strong overlap and optimized masks, but it does not create a mechanism that scales with additional primes or exponent periods. The failed historical provenance gate also prevents using the old live panel as a clean analytic calibration source.

**Judgment:** retain as archived calibration only. More optimization without a theorem would produce another finite landscape.

### 3.2 Global finite \((p^2)\)-cover

A genuine cover of the entire periodic exponent lattice would be logically decisive for constructing a counterexample residue class. However, the frozen baseline already certifies that any such cover needs at least 598 primes, including at least 135 with larger orders. The present first-moment analysis is not remotely strong enough to guide such a search, and period/state explosion is severe.

**Judgment:** do not restart. It becomes rational only after a new structural theorem compresses the optimized problem.

### 3.3 Joint-prime exact search

Small joint tori are valuable for falsifying candidate lemmas. This phase used them exactly for that purpose: pairwise minimum-intersection positivity was disproved. Beyond such theorem-targeted tests, exact joint search scales as the CRT state product or joint period and quickly becomes production computation.

**Judgment:** acceptable only under Gate E with a sharply stated lemma and state size \(\lesssim10^8\). No current lemma qualifies.

### 3.4 Direct interval verification

Direct verification is closest to the literal equation and can be independently certified, but no finite interval proves the universal statement. The existing \(1.6\times10^9\) consecutive verification is already much stronger as a finite record than anything this phase would add.

**Judgment:** no additional scan. It has essentially zero theorem leverage for the present question.

### 3.5 Clean-room prospective Gate V3

A clean prospective run could solve provenance defects for future finite experiments, but it would remain a finite integer panel. It cannot repair the analytic random-versus-optimized gap found here.

**Judgment:** not a continuation of this route. Reconsider only for a separately justified counterexample-search program.

### 3.6 Circle method / additive combinatorics

The set of sums of two squares has zero natural density, while the number of shifts \(3^c+5^d\le n\) is only polylogarithmic. Classical circle-method machinery may estimate averaged representation counts, but uniform positivity for every \(n\) is much harder. Still, this route attacks the actual additive equation rather than a sufficient local obstruction.

**Judgment:** more theorem leverage than bad-prime moments, but likely to yield “almost all \(n\)” before “all \(n\).” It deserves a literature/feasibility screen, not immediate coding.

### 3.7 Modular local-to-global analysis

A modular strategy could succeed if one identifies a finite set of local conditions that are both necessary and collectively sufficient for a sum of two squares after varying exponents. The current bad-prime events supply only sufficient obstructions and their optimized colored-cover geometry is hostile.

**Judgment:** current formalism is exhausted. A pivot must introduce a genuinely new invariant, not more moments of the same events.

### 3.8 Direct study of two-square representation density

This route studies the distribution of

\[
1_{\{x=a^2+b^2\}}(n-3^c-5^d)
\]

directly, including correlations between shifts. Landau–Ramanujan density, the Fermat two-square criterion, Selberg/Brun sieve, and shifted multiplicative-function technology are closer to the needed event than a finite bad-prime cover.

The difficulty is severe: one needs a lower bound for a union of sparse, arithmetically dependent events uniformly in \(n\), with only \(O((\log n)^2)\) candidate shifts. Nevertheless, this is where a second moment would control the right random variable: the actual number of representable remainders, not a proxy obstruction under random CRT residues.

**Judgment:** best next analytic direction to assess.

### 3.9 Analytic sieve on \(n-3^c-5^d\)

A sieve could attempt to show that among exponent pairs, at least one remainder has no prime \(q\equiv3\pmod4\) to an odd exponent. A naive sieve faces parity and square-divisibility issues, and the sequence \(3^c+5^d\) is highly structured. Yet a successful lower-bound sieve or weighted second moment would connect directly to the original representation condition.

Promising intermediate targets would be:

* a uniform lower bound for the number of exponent pairs avoiding odd valuations for primes up to \(z\);
* a controllable tail estimate for primes above \(z\);
* averaged-in-\(n\) theorems with explicit exceptional sets;
* a transference statement from a periodic exponent box to the actual active range.

**Judgment:** highest priority for a new webpage-level mathematical feasibility study. Do not send to Codex before a precise sieve lemma and parameter regime are frozen.

---

## 4. Why the present route ranks below the alternatives

The bad-prime moment route loses on the exact dimension that matters:

\[
\text{random-tuple }L^2
\quad\not\Rightarrow\quad
\text{optimized-tuple }L^\infty.
\]

The experiments did not merely fail to find a proof; they identified structural counterevidence to the proposed bridges:

1. uncentered additive energy cannot beat the elementary order bound;
2. centered bounds tested through \(p\le200\) never strictly beat that bound;
3. average pairwise intersections coexist with exact zero minimum intersections;
4. first-moment cover existence becomes worse on the expanding full torus;
5. finite LP improvements have no state compression or integral family theorem.

By comparison, direct two-square density and analytic sieve at least place the second moment on the actual representation indicators. Their technical difficulty is higher, but their logical leverage is also higher.

---

## 5. Recommended research allocation

1. **Stop analytic bad-prime second-moment/additive-energy/anti-cover work as an active route.**
2. **Do not use Codex or Codex Ultra for continuation.** There is no promoted computational lemma.
3. Use **webpage GPT-5.6 Pro** for a new, bounded feasibility study of direct two-square density / analytic sieve, with explicit stop conditions before computation.
4. Retain the present package as a negative-methodology reference and as a source of exact local formulas.

This is not a claim that analytic sieve will solve A303656. It is a judgment that it has a clearer logical connection and greater theorem leverage than further moments of random bad-prime residue tuples.
