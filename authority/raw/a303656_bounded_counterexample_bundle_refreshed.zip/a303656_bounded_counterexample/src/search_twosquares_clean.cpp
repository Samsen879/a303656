// Clean-room independent direct finite scanner for A303656.
//
// This implementation deliberately does not share the x-outer enumeration or
// integer-square-root code of search_twosquares_bitset.cpp.  It enumerates
// unordered square pairs with y as the outer variable, uses binary-search
// integer square root, and maintains the annulus x-boundaries in the opposite
// direction.  The candidate set is stored in a packed bit vector.
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

static uint64_t binary_isqrt(uint64_t n) {
    uint64_t lower = 0;
    uint64_t upper = uint64_t(1) << 32; // exclusive
    while (lower + 1 < upper) {
        const uint64_t middle = lower + (upper - lower) / 2;
        if (static_cast<__uint128_t>(middle) * middle <= n) lower = middle;
        else upper = middle;
    }
    return lower;
}

static uint64_t binary_ceil_sqrt(uint64_t n) {
    const uint64_t r = binary_isqrt(n);
    return static_cast<__uint128_t>(r) * r == n ? r : r + 1;
}

static uint64_t power_exact(uint64_t base, int exponent) {
    if (exponent < 0) throw std::runtime_error("negative exponent");
    __uint128_t value = 1;
    for (int k = 0; k < exponent; ++k) {
        value *= base;
        if (value > UINT64_MAX) throw std::runtime_error("power overflow");
    }
    return static_cast<uint64_t>(value);
}

int main(int argc, char** argv) {
    try {
        uint64_t low = 0, high = 0;
        int C = -1, D = -1;
        std::string json_path, candidates_path;
        bool quiet = false;
        for (int i = 1; i < argc; ++i) {
            const std::string arg = argv[i];
            auto next = [&]() -> std::string {
                if (++i >= argc) throw std::runtime_error("missing option value");
                return argv[i];
            };
            if (arg == "--low") low = std::stoull(next());
            else if (arg == "--high") high = std::stoull(next());
            else if (arg == "--C") C = std::stoi(next());
            else if (arg == "--D") D = std::stoi(next());
            else if (arg == "--json") json_path = next();
            else if (arg == "--candidates") candidates_path = next();
            else if (arg == "--quiet") quiet = true;
            else throw std::runtime_error("unknown argument: " + arg);
        }
        if (!low || !high || low > high || C < 0 || D < 0 || json_path.empty()) {
            throw std::runtime_error("missing required arguments");
        }
        const uint64_t next3 = power_exact(3, C + 1) + 1;
        const uint64_t next5 = power_exact(5, D + 1) + 1;
        if (high >= next3 || high >= next5) throw std::runtime_error("finite exponent-domain check failed");
        const uint64_t count64 = high - low + 1;
        if (count64 > SIZE_MAX) throw std::runtime_error("interval too large");
        const size_t count = static_cast<size_t>(count64);

        std::vector<uint64_t> powers3(C + 1), powers5(D + 1);
        powers3[0] = powers5[0] = 1;
        for (int c = 1; c <= C; ++c) powers3[c] = powers3[c - 1] * 3;
        for (int d = 1; d <= D; ++d) powers5[d] = powers5[d - 1] * 5;
        std::set<uint64_t> shift_set;
        size_t pair_count = 0;
        for (uint64_t a : powers3) {
            for (uint64_t b : powers5) {
                const __uint128_t s = static_cast<__uint128_t>(a) + b;
                if (s <= high) {
                    shift_set.insert(static_cast<uint64_t>(s));
                    ++pair_count;
                }
            }
        }

        std::vector<uint64_t> remaining((count + 63) / 64, ~uint64_t(0));
        if (count % 64) remaining.back() = (uint64_t(1) << (count % 64)) - 1;
        size_t survivors = count;
        size_t shifts_used = 0;
        uint64_t lattice_pairs = 0;
        const auto start_time = std::chrono::steady_clock::now();

        for (uint64_t shift : shift_set) {
            if (shift > high) break;
            const uint64_t lower_r = low > shift ? low - shift : 0;
            const uint64_t upper_r = high - shift;
            const uint64_t largest_y = binary_isqrt(upper_r);
            const uint64_t diagonal = binary_isqrt(upper_r / 2);
            uint64_t smallest_x = binary_ceil_sqrt(lower_r);
            uint64_t largest_x_after_diagonal = diagonal;
            size_t cleared_here = 0;

            // Every unordered pair 0 <= x <= y is visited once, now with y outer.
            for (uint64_t y = 0; y <= largest_y; ++y) {
                const uint64_t y2 = y * y;
                while (smallest_x > 0 &&
                       static_cast<__uint128_t>(smallest_x - 1) * (smallest_x - 1) + y2 >= lower_r) {
                    --smallest_x;
                }
                uint64_t largest_x;
                if (y <= diagonal) {
                    largest_x = y;
                } else {
                    while (largest_x_after_diagonal > 0 &&
                           static_cast<__uint128_t>(largest_x_after_diagonal) * largest_x_after_diagonal + y2 > upper_r) {
                        --largest_x_after_diagonal;
                    }
                    largest_x = largest_x_after_diagonal;
                }
                if (smallest_x > largest_x) continue;
                for (uint64_t x = smallest_x; x <= largest_x; ++x) {
                    const uint64_t n = x * x + y2 + shift;
                    const size_t index = static_cast<size_t>(n - low);
                    uint64_t& word = remaining[index / 64];
                    const uint64_t mask = uint64_t(1) << (index % 64);
                    word &= ~mask;
                    ++lattice_pairs;
                }
            }
            ++shifts_used;
            const size_t previous_survivors = survivors;
            survivors = 0;
            for (uint64_t word : remaining) survivors += __builtin_popcountll(word);
            cleared_here = previous_survivors - survivors;
            if (!quiet && (shifts_used <= 20 || shifts_used % 10 == 0 || survivors == 0)) {
                const double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - start_time).count();
                std::cout << "STEP shift=" << shift << " used=" << shifts_used
                          << " cleared=" << cleared_here << " survivors=" << survivors
                          << " elapsed_seconds=" << seconds << '\n' << std::flush;
            }
            if (survivors == 0) break;
        }

        std::vector<uint64_t> candidates;
        for (size_t word_index = 0; word_index < remaining.size(); ++word_index) {
            uint64_t word = remaining[word_index];
            while (word) {
                const unsigned bit = __builtin_ctzll(word);
                const size_t index = word_index * 64 + bit;
                if (index < count) candidates.push_back(low + index);
                word &= word - 1;
            }
        }
        if (candidates.size() != survivors) throw std::runtime_error("survivor mismatch");
        if (!candidates_path.empty()) {
            std::ofstream cfile(candidates_path);
            if (!cfile) throw std::runtime_error("cannot write candidate file");
            for (uint64_t n : candidates) cfile << n << '\n';
        }

        const double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - start_time).count();
        std::ofstream json(json_path);
        if (!json) throw std::runtime_error("cannot write JSON");
        json << "{\n"
             << "  \"method\": \"clean_room_direct_two_squares_y_outer\",\n"
             << "  \"arithmetic\": \"exact uint64/__uint128; binary-search integer square root; no floating point\",\n"
             << "  \"low\": \"" << low << "\",\n"
             << "  \"high\": \"" << high << "\",\n"
             << "  \"C\": " << C << ",\n"
             << "  \"D\": " << D << ",\n"
             << "  \"three_power_next_plus_one\": \"" << next3 << "\",\n"
             << "  \"five_power_next_plus_one\": \"" << next5 << "\",\n"
             << "  \"strict_domain_inequalities_checked\": true,\n"
             << "  \"admissible_rectangle_pair_count_at_high\": " << pair_count << ",\n"
             << "  \"distinct_shift_count_at_high\": " << shift_set.size() << ",\n"
             << "  \"duplicate_pair_count\": " << pair_count - shift_set.size() << ",\n"
             << "  \"integers_tested\": " << count64 << ",\n"
             << "  \"shifts_processed_before_termination\": " << shifts_used << ",\n"
             << "  \"unordered_square_pairs_enumerated\": " << lattice_pairs << ",\n"
             << "  \"candidate_count\": " << candidates.size() << ",\n"
             << "  \"candidates\": [";
        for (size_t i = 0; i < candidates.size(); ++i) {
            if (i) json << ',';
            json << '"' << candidates[i] << '"';
        }
        json << "],\n"
             << "  \"elapsed_seconds\": " << elapsed << ",\n"
             << "  \"classification\": \""
             << (candidates.empty()
                   ? "EXACT EXHAUSTIVE FINITE COMPUTATION: EVERY n IN INTERVAL HAS A REPRESENTATION"
                   : "EXACT CANDIDATES REQUIRE INDEPENDENT CERTIFICATE VERIFICATION")
             << "\"\n}\n";

        std::cout << "integers_tested=" << count64 << '\n'
                  << "admissible_pair_count_at_high=" << pair_count << '\n'
                  << "distinct_shift_count_at_high=" << shift_set.size() << '\n'
                  << "shifts_processed=" << shifts_used << '\n'
                  << "candidate_count=" << candidates.size() << '\n'
                  << "elapsed_seconds=" << elapsed << '\n'
                  << (candidates.empty() ? "EXACT_EMPTY" : "CANDIDATES_FOUND") << '\n';
        return candidates.empty() ? 1 : 0;
    } catch (const std::exception& e) {
        std::cerr << "ERROR " << e.what() << '\n';
        return 2;
    }
}
