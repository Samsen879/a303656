// Exact direct search for A303656 counterexamples on a finite interval.
//
// For every distinct shift s = 3^c + 5^d <= U, clear every n in [L,U]
// for which n-s = x^2+y^2 with 0 <= x <= y.  Remaining bits are exactly
// the integers with no representation a^2+b^2+3^c+5^d.
//
// This implementation uses an x-outer annulus enumeration and exact bitwise
// integer square root.  It does not use floating point or factorization.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

static uint64_t isqrt_u64(uint64_t n) {
    uint64_t result = 0;
    uint64_t bit = uint64_t(1) << 62;
    while (bit > n) bit >>= 2;
    while (bit != 0) {
        if (n >= result + bit) {
            n -= result + bit;
            result = (result >> 1) + bit;
        } else {
            result >>= 1;
        }
        bit >>= 2;
    }
    return result;
}

static uint64_t ceil_sqrt_u64(uint64_t n) {
    uint64_t r = isqrt_u64(n);
    return static_cast<__uint128_t>(r) * r == n ? r : r + 1;
}

static uint64_t checked_pow(uint64_t base, int exponent) {
    if (exponent < 0) throw std::runtime_error("negative exponent");
    __uint128_t value = 1;
    for (int i = 0; i < exponent; ++i) {
        value *= base;
        if (value > UINT64_MAX) throw std::runtime_error("power overflow");
    }
    return static_cast<uint64_t>(value);
}

static std::string json_array_u64(const std::vector<uint64_t>& values) {
    std::string out = "[";
    for (size_t i = 0; i < values.size(); ++i) {
        if (i) out += ',';
        out += '"' + std::to_string(values[i]) + '"';
    }
    out += ']';
    return out;
}

int main(int argc, char** argv) {
    try {
        uint64_t low = 0, high = 0;
        int C = -1, D = -1;
        std::string json_path, candidates_path;
        bool quiet = false;
        uint64_t progress_every = 0;

        for (int i = 1; i < argc; ++i) {
            std::string arg = argv[i];
            auto value = [&](const char* name) -> std::string {
                if (i + 1 >= argc) throw std::runtime_error(std::string("missing value for ") + name);
                return argv[++i];
            };
            if (arg == "--low") low = std::stoull(value("--low"));
            else if (arg == "--high") high = std::stoull(value("--high"));
            else if (arg == "--C") C = std::stoi(value("--C"));
            else if (arg == "--D") D = std::stoi(value("--D"));
            else if (arg == "--json") json_path = value("--json");
            else if (arg == "--candidates") candidates_path = value("--candidates");
            else if (arg == "--progress-every") progress_every = std::stoull(value("--progress-every"));
            else if (arg == "--quiet") quiet = true;
            else throw std::runtime_error("unknown argument: " + arg);
        }

        if (low == 0 || high == 0 || low > high || C < 0 || D < 0 || json_path.empty()) {
            throw std::runtime_error(
                "required: --low L --high U --C C --D D --json FILE [--candidates FILE]"
            );
        }
        const uint64_t cap3 = checked_pow(3, C + 1);
        const uint64_t cap5 = checked_pow(5, D + 1);
        if (high >= cap3 + 1) throw std::runtime_error("strict C-domain inequality fails");
        if (high >= cap5 + 1) throw std::runtime_error("strict D-domain inequality fails");
        const uint64_t length64 = high - low + 1;
        if (length64 > static_cast<uint64_t>(SIZE_MAX)) throw std::runtime_error("interval too large for address space");
        const size_t length = static_cast<size_t>(length64);

        std::vector<uint64_t> p3(C + 1), p5(D + 1);
        p3[0] = p5[0] = 1;
        for (int c = 1; c <= C; ++c) p3[c] = p3[c - 1] * 3;
        for (int d = 1; d <= D; ++d) p5[d] = p5[d - 1] * 5;

        std::map<uint64_t, std::vector<std::pair<int, int>>> by_shift;
        size_t admissible_rectangle_pairs = 0;
        for (int c = 0; c <= C; ++c) {
            for (int d = 0; d <= D; ++d) {
                __uint128_t sum = static_cast<__uint128_t>(p3[c]) + p5[d];
                if (sum <= high) {
                    by_shift[static_cast<uint64_t>(sum)].push_back({c, d});
                    ++admissible_rectangle_pairs;
                }
            }
        }
        std::vector<uint64_t> shifts;
        shifts.reserve(by_shift.size());
        for (const auto& entry : by_shift) shifts.push_back(entry.first);

        const size_t words = (length + 63) / 64;
        std::vector<uint64_t> alive(words, ~uint64_t(0));
        if (length % 64) alive.back() = (uint64_t(1) << (length % 64)) - 1;

        size_t survivors = length;
        uint64_t representation_pairs_enumerated = 0;
        size_t shifts_processed = 0;
        auto started = std::chrono::steady_clock::now();

        for (uint64_t shift : shifts) {
            if (shift > high) break;
            const uint64_t first_n = std::max(low, shift);
            if (first_n > high) continue;
            const uint64_t remainder_low = first_n - shift;
            const uint64_t remainder_high = high - shift;

            // Enumerate each unordered pair 0 <= x <= y exactly once.
            const uint64_t x_max = isqrt_u64(remainder_high / 2);
            uint64_t y_high = isqrt_u64(remainder_high);
            uint64_t y_low = ceil_sqrt_u64(remainder_low);
            size_t newly_cleared = 0;

            for (uint64_t x = 0; x <= x_max; ++x) {
                const __uint128_t x2 = static_cast<__uint128_t>(x) * x;
                while (y_high >= x && x2 + static_cast<__uint128_t>(y_high) * y_high > remainder_high) {
                    --y_high;
                }
                while (y_low > x && x2 + static_cast<__uint128_t>(y_low - 1) * (y_low - 1) >= remainder_low) {
                    --y_low;
                }
                const uint64_t begin_y = std::max(x, y_low);
                if (begin_y > y_high) continue;
                for (uint64_t y = begin_y; y <= y_high; ++y) {
                    const uint64_t n = static_cast<uint64_t>(x2 + static_cast<__uint128_t>(y) * y) + shift;
                    const size_t index = static_cast<size_t>(n - low);
                    uint64_t& word = alive[index >> 6];
                    const uint64_t mask = uint64_t(1) << (index & 63);
                    word &= ~mask;
                    ++representation_pairs_enumerated;
                }
            }
            ++shifts_processed;
            const size_t previous_survivors = survivors;
            survivors = 0;
            for (uint64_t word : alive) survivors += __builtin_popcountll(word);
            newly_cleared = previous_survivors - survivors;
            if (!quiet && (progress_every == 0 || shifts_processed <= 20 || shifts_processed % progress_every == 0 || survivors == 0)) {
                const double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
                std::cout << "SHIFT shift=" << shift
                          << " processed=" << shifts_processed
                          << " newly_cleared=" << newly_cleared
                          << " survivors=" << survivors
                          << " elapsed_seconds=" << seconds << '\n' << std::flush;
            }
            if (survivors == 0) break;
        }

        std::vector<uint64_t> candidates;
        candidates.reserve(survivors);
        for (size_t wi = 0; wi < alive.size(); ++wi) {
            uint64_t word = alive[wi];
            while (word) {
                const unsigned bit = __builtin_ctzll(word);
                const size_t index = wi * 64 + bit;
                if (index < length) candidates.push_back(low + index);
                word &= word - 1;
            }
        }
        if (candidates.size() != survivors) throw std::runtime_error("internal survivor count mismatch");

        if (!candidates_path.empty()) {
            std::ofstream out(candidates_path);
            if (!out) throw std::runtime_error("cannot write candidates file");
            for (uint64_t n : candidates) out << n << '\n';
        }

        const double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
        std::ofstream js(json_path);
        if (!js) throw std::runtime_error("cannot write JSON output");
        js << "{\n"
           << "  \"method\": \"direct_two_squares_bitset_x_outer\",\n"
           << "  \"arithmetic\": \"exact uint64/__uint128; bitwise integer square root; no floating point\",\n"
           << "  \"low\": \"" << low << "\",\n"
           << "  \"high\": \"" << high << "\",\n"
           << "  \"C\": " << C << ",\n"
           << "  \"D\": " << D << ",\n"
           << "  \"three_power_next_plus_one\": \"" << cap3 + 1 << "\",\n"
           << "  \"five_power_next_plus_one\": \"" << cap5 + 1 << "\",\n"
           << "  \"strict_domain_inequalities_checked\": true,\n"
           << "  \"admissible_rectangle_pair_count_at_high\": " << admissible_rectangle_pairs << ",\n"
           << "  \"distinct_shift_count_at_high\": " << shifts.size() << ",\n"
           << "  \"duplicate_pair_count\": " << admissible_rectangle_pairs - shifts.size() << ",\n"
           << "  \"integers_tested\": " << length64 << ",\n"
           << "  \"shifts_processed_before_termination\": " << shifts_processed << ",\n"
           << "  \"unordered_square_pairs_enumerated\": " << representation_pairs_enumerated << ",\n"
           << "  \"candidate_count\": " << candidates.size() << ",\n"
           << "  \"candidates\": " << json_array_u64(candidates) << ",\n"
           << "  \"elapsed_seconds\": " << elapsed << ",\n"
           << "  \"classification\": \""
           << (candidates.empty()
                 ? "EXACT EXHAUSTIVE FINITE COMPUTATION: EVERY n IN INTERVAL HAS A REPRESENTATION"
                 : "EXACT CANDIDATES REQUIRE INDEPENDENT CERTIFICATE VERIFICATION")
           << "\"\n}\n";

        std::cout << "integers_tested=" << length64 << '\n'
                  << "admissible_pair_count_at_high=" << admissible_rectangle_pairs << '\n'
                  << "distinct_shift_count_at_high=" << shifts.size() << '\n'
                  << "shifts_processed=" << shifts_processed << '\n'
                  << "candidate_count=" << candidates.size() << '\n'
                  << "elapsed_seconds=" << elapsed << '\n'
                  << (candidates.empty() ? "EXACT_EMPTY" : "CANDIDATES_FOUND") << '\n';
        return candidates.empty() ? 1 : 0;
    } catch (const std::exception& e) {
        std::cerr << "ERROR " << e.what() << '\n';
        return 2;
    }
}
