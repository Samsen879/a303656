# CIRCLE-METHOD AUDIT

## 1. Exact Fourier representation

Let

\[
P=\lfloor\sqrt n\rfloor,
\quad
F_n(\alpha)=\sum_{|x|\le P}e(\alpha x^2),
\]

\[
A_n(\alpha)=\sum_{3^c\le n}e(\alpha3^c),
\quad
B_n(\alpha)=\sum_{5^d\le n}e(\alpha5^d).
\]

Then

\[
\widetilde R(n)=\int_0^1
F_n(\alpha)^2A_n(\alpha)B_n(\alpha)e(-n\alpha)\,d\alpha.
\]

This identity is exact; endpoint truncation is harmless because any represented square is at most \(n\).

## 2. Major arcs

Near \(\alpha=a/q+\beta\), the quadratic sum has the usual structure

\[
F_n(a/q+\beta)
\approx q^{-1}S(q,a)V_n(\beta),
\]

with a quadratic Gauss sum \(S(q,a)\) and oscillatory integral \(V_n\).

The lacunary factors cannot generally be frozen at \(a/q\) over the whole major-arc width: the largest phases involve \(3^c,5^d\asymp n\). The safe operation is to expand

\[
A_n(\alpha)B_n(\alpha)=
\sum_{c,d}e(\alpha(3^c+5^d))
\]

and apply the two-square major-arc approximation separately to residuals

\[
m=n-3^c-5^d.
\]

This leads to an aggregate truncated singular series rather than a single smooth \(\mathfrak S(n)\).

## 3. Singular series can vanish

For a residual \(m\), the full two-square factor is zero when some \(p\equiv3\pmod4\) has odd valuation. Thus the major term is not uniformly positive term-by-term.

One can define

\[
\mathfrak S_H(n;Q)=
\sum_{\substack{q\le Q\\q\text{ odd}}}
\frac{\chi_4(q)}q
\sum_{(c,d)\in H_n^-}c_q(n-3^c-5^d).
\]

At a prime \(p\), its discrepancy contribution is

\[
\chi_4(p)\left(A_p(n)-\frac{W^-(n)}p\right).
\]

Letting \(Q\to\infty\) reconstructs the exact divisor obstruction. A fixed \(Q\) can miss a new large inert prime. Therefore a lower bound for \(\mathfrak S_H(n;Q)\) is not enough unless the tail is pointwise controlled.

## 4. Norms of the lacunary factor

Let \(C_n,D_n\asymp\log n\) be the numbers of powers. The rectangle has

\[
W_{\rm rect}=C_nD_n\asymp\log^2n.
\]

If \(\mu_n(s)\) counts representations \(s=3^c+5^d\), Parseval gives

\[
\int_0^1|A_nB_n|^2d\alpha
=\sum_s\mu_n(s)^2.
\]

The inherited global collision lemma gives bounded shift multiplicity apart from finitely many collisions, hence

\[
\int_0^1|A_nB_n|^2d\alpha\ll\log^2n,
\qquad
\|A_nB_n\|_1\ll\log n. \tag{4.1}
\]

Even without this strongest collision input, any elementary polynomial/logarithmic norm estimate leaves the same main obstruction below.

## 5. Even an optimistic square-root minor-arc bound is polynomially too large

A quadratic Weyl estimate can be stated as

\[
|F_n(\alpha)|
\ll_\varepsilon
P^{1+\varepsilon}
\left(q^{-1}+P^{-1}+qP^{-2}\right)^{1/2}
\]

when \(\alpha\) has a suitable rational approximation \(a/q\). Even granting an optimistic choice of major arcs whose complement enjoys the classical square-root Weyl scale, one would have only

\[
|F_n(\alpha)|^2\ll_\varepsilon P^{1+\varepsilon}
=n^{1/2+\varepsilon}.
\]

Combining with (4.1),

\[
\left|\int_{\mathfrak m}F_n^2A_nB_ne(-n\alpha)d\alpha\right|
\le
\sup_{\mathfrak m}|F_n|^2\,\|A_nB_n\|_1
\ll_\varepsilon n^{1/2+\varepsilon}\log n.
\]

The desired main term is only

\[
\pi W^-(n)\asymp\log^2n.
\]

Thus absolute-value minor-arc technology misses by a polynomial factor.

The fourth-moment alternative gives, schematically,

\[
\|F_n^2\|_2\ll n^{1/2}(\log n)^{1/2},
\qquad
\|A_nB_n\|_2\ll\log n,
\]

again far above \(\log^2n\).

## 6. Lacunary rational concentration

Uniform minor-arc smallness of \(A_n\) or \(B_n\) is false.

- At \(\alpha=1/2\), every power of 3 and 5 is odd, so both sums have maximal modulus.
- At \(\alpha=a/3^k\), all terms with exponent \(c\ge k\) in \(A_n\) equal 1. If \(3^k\) lies just above the denominator cutoff, a positive proportion of \(A_n\) remains coherent on a nominal minor arc.
- The analogous statement holds for \(B_n\) at denominators \(5^k\).

These spikes need tailored treatment. A measure estimate for their union is insufficient by itself because the integrand contains only one copy of each lacunary sum.

## 7. Why Goldbach–Linnik does not transfer

In Goldbach–Linnik, a power sum

\[
G(\alpha)=\sum_{\nu\le L}e(\alpha2^\nu)
\]

appears as \(G(\alpha)^K\) with several variables. A bound showing that \(|G|\) is below a fixed fraction of \(L\) away from a small exceptional set is amplified to the \(K\)-th power. Current results require several powers-of-two variables (for example six under GRH in the 2026 update).

Here the factor is only

\[
A_n(\alpha)B_n(\alpha),
\]

not a high power. There is no comparable amplification parameter.

## 8. Exact missing lemma

A promotable circle-method route requires, at minimum, a theorem of the following kind. For a major-arc system \(\mathfrak M(Q)\), prove uniformly for every sufficiently large \(n\) that there is a fixed \(\eta>0\) with

\[
\operatorname{Re}\int_{\mathfrak M(Q)}F_n^2A_nB_ne(-n\alpha)d\alpha
\ge \eta W^-(n),
\]

and

\[
\left|
\int_{\mathfrak m(Q)}F_n^2A_nB_ne(-n\alpha)d\alpha
\right|=o(W^-(n)). \tag{8.1}
\]

The stronger constant \(\pi-o(1)\) would require an additional uniform equidistribution theorem for the shifted two-square singular factors; it is not available merely from the average density of lattice points.

An equivalent sparse-shift formulation is to write a two-square circle remainder \(E_2(m;Q)\), choose \(Q=Q(N)\), and prove the dyadically uniform estimate

\[
\sup_{N\le n\le2N}
\left|\sum_{(c,d)\in H_n^-}E_2(n-3^c-5^d;Q(N))\right|
=o(\log^2N) \qquad(N\to\infty). \tag{8.2}
\]

Known shifted-convolution theorems average over \(m\) and do not imply (8.2). No source audited here supplies (8.1) or (8.2).

## Verdict

The circle method gives the correct exact framework and a plausible average main term, but the required uniform minor-arc cancellation is unsupported.

# STOP
