# 主报告：THETA-SERIES POINTWISE ROUTE PHASE A

## 1. 问题与 observable

定义

\[
\widetilde R(n)=
\sum_{\substack{c,d\ge0\\3^c+5^d\le n}}
r_2(n-3^c-5^d),
\]

其中

\[
r_2(m)=\#\{(x,y)\in\mathbb Z^2:x^2+y^2=m\},
\qquad r_2(0)=1.
\]

Fermat two-square criterion 与非负性给出

\[
r_2(m)>0\iff m\in\mathcal S_2,
\]

从而

\[
\widetilde R(n)>0
\iff
\exists(c,d):n-3^c-5^d\in\mathcal S_2.
\]

这是一条 exact support equivalence。它与此前 almost-all 路线不同：若本轮能得到 pointwise lower bound，就不需要 indicator covariance transfer。反过来，任何 summatory、mean-square 或 density statement 仍不能推出所有 sufficiently large \(n\)。

## 2. Theta-series identity

置

\[
\Theta(q)=\sum_{x\in\mathbb Z}q^{x^2},
\qquad
L_3(q)=\sum_{c\ge0}q^{3^c},
\qquad
L_5(q)=\sum_{d\ge0}q^{5^d}.
\]

formal power series coefficient extraction 给出

\[
G(q):=\Theta(q)^2L_3(q)L_5(q)
=\sum_{n\ge0}\widetilde R(n)q^n.
\]

其中

\[
\Theta(q)^2
=1+4\sum_{m\ge1}
\left(\sum_{a\mid m}\chi_4(a)\right)q^m
\in M_1(\Gamma_0(4),\chi_4).
\]

所以 modular object 只占一个 factor；两个 power sums 是 lacunary Mahler series：

\[
L_3(q)=q+L_3(q^3),
\qquad
L_5(q)=q+L_5(q^5).
\]

这些 functional equations 没有产生一个 coefficient recurrence，能够把 positivity 从有限 residue states 传播到所有指数。

## 3. Divisor switching 给出的“候选主项”

对 residual \(m\ge1\)，

\[
r_2(m)=4\sum_{q\mid m}\chi_4(q).
\]

定义

\[
Z(n)=\#\{(c,d):3^c+5^d=n\},
\]

\[
W^-(n)=\#\{(c,d):3^c+5^d<n\},
\]

\[
A_q(n)=\#\{(c,d):3^c+5^d<n,\ q\mid n-3^c-5^d\}.
\]

则

\[
\widetilde R(n)=Z(n)+4\sum_{q<n}\chi_4(q)A_q(n). \tag{3.1}
\]

令

\[
\Delta_q(n)=A_q(n)-\frac{W^-(n)}q,
\qquad
L_n=\sum_{q<n}\frac{\chi_4(q)}q.
\]

由于 \(\chi_4\) 的 partial sums bounded，

\[
L_n=L(1,\chi_4)+O(n^{-1})=\frac\pi4+O(n^{-1}).
\]

故 (3.1) exact 重写为

\[
\boxed{
\widetilde R(n)=Z(n)+\pi W^-(n)
+4\sum_{q<n}\chi_4(q)\Delta_q(n)
+O\!\left(\frac{W^-(n)}n\right).
} \tag{3.2}
\]

(3.2) 是本轮最接近 pointwise asymptotic 的公式。它同时暴露了不可忽略的 gap：discrepancy term 中没有 \(1/q\) 权重。小模数 equidistribution 不足以控制 \(q\) 一直到 \(n\) 的 signed incidences。

## 4. 为什么大 divisor tail 不是技术细节

若

\[
m=2^a\prod_{p\equiv1(4)}p^{u_p}
\prod_{p\equiv3(4)}p^{v_p},
\]

则

\[
\sum_{q\mid m}\chi_4(q)
=
\prod_{p\equiv1(4)}(u_p+1)
\prod_{p\equiv3(4)}\left(\sum_{j=0}^{v_p}(-1)^j\right).
\]

因此只要某个 \(p\equiv3\pmod4\) 出现 odd valuation，整个 divisor sum 精确变为 0。给定任意 cutoff \(Q\)，取 prime \(p\equiv3\pmod4\), \(p>Q\)：

\[
\sum_{\substack{q\mid p\\q\le Q}}\chi_4(q)=1,
\qquad
\sum_{q\mid p}\chi_4(q)=1-1=0.
\]

所以“保留小 divisors 得到正 main，证明 tail 较小”的逐 residual strategy 不成立。tail 不是 perturbation；它携带 exact two-square obstruction。

对 odd part \(u\) 还可作 hyperbola pairing。若 \(u\) 非平方，

\[
\sum_{d\mid u}\chi_4(d)
=(1+\chi_4(u))
\sum_{\substack{d\mid u\\d<\sqrt u}}\chi_4(d).
\]

若 \(u\) 为平方，

\[
\sum_{d\mid u}\chi_4(d)
=2\sum_{\substack{d\mid u\\d<\sqrt u}}\chi_4(d)+\chi_4(\sqrt u).
\]

这最多把 modulus range 降到 \(\sqrt n\)，仍远大于 shift family 的 \(\log^2 n\) cardinality，并且 cancellation 仍可精确为 0，例如 \(u=21\)。

## 5. Average main term：真实但不具 promotion 资格

令

\[
W(X)=\#\{(c,d):3^c+5^d\le X\}.
\]

若一对 powers 的和超过 \(X\)，至少一个 power 大于 \(X/2\)；每个 base 在 \((X/2,X]\) 中只有 \(O(1)\) 个 power。因此

\[
W(X)=
(\lfloor\log_3X\rfloor+1)
(\lfloor\log_5X\rfloor+1)+O(\log X)
=\frac{(\log X)^2}{\log3\log5}+O(\log X).
\]

Gauss circle elementary estimate 为

\[
\sum_{0\le m\le Y}r_2(m)=\pi Y+O(\sqrt Y).
\]

交换求和得到

\[
\sum_{n\le X}\widetilde R(n)
=\sum_{3^c+5^d\le X}
\sum_{0\le m\le X-3^c-5^d}r_2(m).
\]

又有

\[
\sum_{3^c+5^d\le X}(3^c+5^d)=O(X\log X),
\]

故

\[
\boxed{
\sum_{n\le X}\widetilde R(n)
=\frac{\pi X(\log X)^2}{\log3\log5}+O(X\log X).
} \tag{5.1}
\]

(5.1) 只说明 average coefficient 约为 \(\pi(\log X)^2/(\log3\log5)\)。即使存在 infinitely many zero coefficients，(5.1) 仍完全可能成立，因此不能 promotion。

## 6. Cusp growth 排除 classical modular identity

令 \(q=e^{-t}\), \(t\to0^+\)。Poisson summation 给出

\[
\Theta(e^{-t})
=\sqrt{\frac\pi t}
\left(1+O(e^{-\pi^2/t})\right),
\]

而 elementary dyadic/geometric splitting 给出，对 \(b=3,5\)，

\[
L_b(e^{-t})=\frac{\log(1/t)}{\log b}+O(1).
\]

故

\[
\boxed{
G(e^{-t})
=\frac{\pi}{\log3\log5}\frac{\log^2(1/t)}t
+O\!\left(\frac{\log(1/t)}t\right).
} \tag{6.1}
\]

若 \(G\) 是 congruence subgroup 上的 classical holomorphic weight-1 modular form，在 cusp 0 选 scaling matrix 后，其 expansion 必为

\[
t^{-1}\left(a_0+O(e^{-c/t})\right)
\]

或 \(t^{-1}O(e^{-c/t})\)，不可能出现 \(t^{-1}\log^2(1/t)\)。所以 (6.1) 严格排除 standard modular-form identification。

这并未逻辑排除所有 mock/nonholomorphic/Mahler identity，但这些对象也没有现成的 eventual coefficient positivity theorem。

## 7. Circle method 的 exact setup

令 \(P=\lfloor\sqrt n\rfloor\)，并置

\[
F_n(\alpha)=\sum_{|x|\le P}e(\alpha x^2),
\]

\[
A_n(\alpha)=\sum_{3^c\le n}e(\alpha3^c),
\qquad
B_n(\alpha)=\sum_{5^d\le n}e(\alpha5^d).
\]

则 Fourier orthogonality 给出

\[
\boxed{
\widetilde R(n)=
\int_0^1F_n(\alpha)^2A_n(\alpha)B_n(\alpha)e(-n\alpha)\,d\alpha.
} \tag{7.1}
\]

在 \(\alpha=a/q+\beta\) 的 major arcs，quadratic factor 有标准 Gauss-sum approximation。若先展开 \(A_nB_n\)，major term 变成对 residuals \(m=n-3^c-5^d\) 的 truncated two-square singular factors 之和。individual singular factor 可以为 0；aggregate singular factor 的 nonvanishing 正好等价于目标 coefficient 的 positivity，因而 singular series 没有独立解决问题。

## 8. Minor arcs 的量级失配

设 \(C\asymp\log n\), \(D\asymp\log n\)，则 power-pair 数 \(W\asymp\log^2n\)。由 inherited finite-collision lemma，

\[
\int_0^1|A_n(\alpha)B_n(\alpha)|^2\,d\alpha
=\sum_s\mu_n(s)^2\ll W,
\]

故

\[
\|A_nB_n\|_1\ll\sqrt W\ll\log n.
\]

即使乐观地选择 major arcs，使其补集达到 classical square-root quadratic Weyl scale，也至多得到

\[
\sup_{\alpha\in\mathfrak m}|F_n(\alpha)|^2
\ll_\varepsilon n^{1/2+\varepsilon}.
\]

因此绝对值 bound 仍为

\[
\left|
\int_{\mathfrak m}F_n^2A_nB_ne(-n\alpha)d\alpha
\right|
\ll_\varepsilon n^{1/2+\varepsilon}\log n, \tag{8.1}
\]

而候选 main 仅为 \(\asymp\log^2n\)。使用 fourth moment / Hölder 仍给出 polynomial-size bound，不能改变这一量级鸿沟。

要成功，必须利用 integral 中关于 shifts 的 cancellation，而不能取绝对值。需要的 theorem 形如

\[
\sup_{N\le n\le2N}
\left|
\int_{\mathfrak m_n}F_n(\alpha)^2A_n(\alpha)B_n(\alpha)e(-n\alpha)d\alpha
\right|
=o(\log^2N) \qquad(N\to\infty), \tag{8.2}
\]

或等价的 uniform sparse-shift circle-error estimate；同时 major arcs 还必须对每个 sufficiently large \(n\) 给出 \(\gg W^-(n)\) 的严格正下界。审计文献既没有提供 (8.2)，也没有提供该 uniform major-arc positivity。

## 9. Lacunary concentration 不允许廉价 minor-arc bound

对 \(A_n\)，若 \(\alpha=a/3^k\)，则所有 \(c\ge k\) 的 terms 都等于 1；所以存在长度约 \(C-k\) 的 coherent tail。即使 denominator \(3^k\) 已超过 major-arc cutoff，该 tail 仍可能占 \(A_n\) 的正比例。base 5 同理。

此外在 \(\alpha=1/2\)，所有 \(3^c,5^d\) 都为 odd，故

\[
|A_n(1/2)|=C,
\qquad
|B_n(1/2)|=D.
\]

小 denominator resonance 可纳入 major arcs，但 growing prime-power denominators 说明“lacunary sum 在 minor arcs uniformly small”是假的。Goldbach–Linnik 架构依靠 \(K\) 个 powers-of-two factors，使 near-maximal set 的 measure 经 \(|G(\alpha)|^K\) 被放大压制；本题只有 \(A_3A_5\) 一次幂，没有该 amplification。

## 10. Finite residue reductions

固定 modulus \(M\)。若 residue \(r\pmod M\) 局部可写为两个平方，即

\[
r\equiv x_0^2+y_0^2\pmod M,
\]

则 \((x_0+kM)^2+y_0^2\) 给出 arbitrarily large global norms in that class。

另一方面，对任意 \(r\pmod M\)，选 \(p\equiv3\pmod4\), \(p\nmid M\)，并由 CRT 取

\[
N\equiv r\pmod M,
\qquad
N\equiv p\pmod{p^2}.
\]

则 \(v_p(N)=1\)，故 \(N\notin\mathcal S_2\)。于是每个 locally representable residue class 同时含 arbitrarily large norms 与 non-norms。fixed residue data 不能判定 two-square support。

对 generating function 作 dissection

\[
G(q)=\sum_{r=0}^{M-1}q^rG_r(q^M)
\]

当然 exact，但要证明每个 \(G_r\) eventually positive，仍是有限个原 pointwise 问题，没有 reduction gain。

## 11. Literature quantifier audit

- Radomskii 的 Romanoff variants 给出可表示整数个数的 lower bound / density framework，不给 every sufficiently large integer。
- Chamizo 与 Hulse–Kuan–Lowry-Duda–Walker 研究 \(\sum_{m\le X}r_2(m)r_2(m+h)\) 或其 smoothed version；平均变量是 residual base variable，不是固定 \(n\) 上的 sparse shift sum。
- Crocker 与 Platt–Trudgian 证明 same-base 两个 powers 的 universal statement 失败；它们是重要警示，但不直接反驳 mixed bases 3 与 5。
- Fan–Lott 的 power-saving van der Corput property 控制 sets with no sum-of-two-squares differences；本题是假设一个 translate \(n-H\) 全部避开 \(\mathcal S_2\)，并不产生 difference-free set。其 \(N^{7/8+\varepsilon}\) bound 对 \(|H|\asymp\log^2N\) 也完全 vacuous。
- Goldbach–Linnik 最新架构使用多个 powers-of-two variables；它说明 high-power lacunary amplification 的有效性，但不提供两个单独 lacunary factors 的 minor-arc theorem。
- 2025 convolution manuscript 只重述 coefficient convolution，并含 ordinary real-axis theta convergence 与 representation normalization 错误，不能作为 positivity theorem。

## 12. Final promotion audit

五个 requested trigger 均失败：

1. pointwise asymptotic：只有 exact candidate decomposition；uniform error 缺失。
2. explicit lower bound：无。
3. finite reduction：fixed modulus 无法识别 \(\mathcal S_2\)。
4. modular identity：classical route 被 logarithmic cusp growth 排除。
5. divisor switching：exact，但 large-divisor negative cancellation 无 pointwise control。

剩余工作若仍以 unsupported assertion“minor arcs 对每个 \(n\) 足够小”为核心，即违反 promotion rule。故本轮必须停止。

# STOP THETA-SERIES TRIGGER

OEIS A303656: UNRESOLVED.
