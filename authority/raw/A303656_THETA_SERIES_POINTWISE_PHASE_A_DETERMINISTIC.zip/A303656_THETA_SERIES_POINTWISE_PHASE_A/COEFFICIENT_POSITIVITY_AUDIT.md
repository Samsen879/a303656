# COEFFICIENT POSITIVITY AUDIT

## 1. What the weight solves

Because every summand is nonnegative,

\[
\widetilde R(n)>0
\iff
\exists(c,d):r_2(n-3^c-5^d)>0.
\]

Thus pointwise weighted positivity is exactly support positivity. There is no covariance loss at this final logical step.

## 2. What the weight does not solve

The weight \(r_2(m)\) is highly nonuniform:

- it is zero on most integers;
- on represented integers it can be divisor-sized;
- its mean value is \(\pi\), even though the support has density about \(1/\sqrt{\log x}\).

Consequently an average asymptotic for \(\widetilde R\) can be carried by relatively rare residuals with larger representation multiplicity. It gives no control of the zero set of coefficients.

## 3. Abelian asymptotic is not eventual positivity

The radial estimate

\[
G(e^{-t})
\sim
\frac{\pi}{\log3\log5}\frac{\log^2(1/t)}t
\]

and the summatory estimate

\[
\sum_{n\le X}\widetilde R(n)
\sim
\frac{\pi X(\log X)^2}{\log3\log5}
\]

are compatible with infinitely many zero coefficients. Nonnegative coefficients permit Tauberian information in the forward direction, but no Tauberian theorem turns this average growth into gap-free support.

## 4. Why an almost-all theorem is still insufficient

Even a theorem of the form

\[
\#\{n\le X:\widetilde R(n)=0\}=o(X)
\]

would not imply eventual positivity. The project promotion criterion requires zero exceptional set beyond a finite threshold, not density zero.

## 5. Pointwise target scale

The exact divisor decomposition suggests a weighted main scale

\[
M(n)\asymp W^-(n)\asymp\log^2n.
\]

A successful proof must therefore bound a signed arithmetic error by strictly less than a logarithmic-square quantity for every \(n\). Standard circle errors are polynomial in \(n\); average shifted-convolution errors have the wrong quantifier.

## Verdict

The choice of observable is valid and exact for pointwise positivity. It does not create the required pointwise estimate.
