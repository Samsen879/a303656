# THEOREM GAP MAP

## Requested trigger 1: pointwise asymptotic

Candidate exact decomposition:

\[
\widetilde R(n)=Z(n)+\pi W^-(n)+E_{\rm div}(n)+O(W^-(n)/n),
\]

\[
E_{\rm div}(n)=4\sum_{q<n}\chi_4(q)\Delta_q(n).
\]

Required:

\[
E_{\rm div}(n)>-(\pi-\eta)W^-(n)
\]

uniformly for every large \(n\).

Status: **missing**. No decay in the exact discrepancy sum; large inert-prime cancellation remains.

## Requested trigger 2: explicit positive lower bound

Required example:

\[
\widetilde R(n)\ge c\log^\gamma n>0
\]

for all \(n\ge N_0\).

Status: **none**. Average lower bounds do not qualify.

## Requested trigger 3: finite residue-class reduction

Required: a fixed modulus/state space plus a theorem proving positivity in every terminal state.

Status: **failed**. Every locally representable residue class contains both arbitrarily large norms and non-norms. A theta dissection only restates finitely many copies of the original problem.

## Requested trigger 4: modular/theta identity

Required: a classical modular decomposition with a positive coefficient component dominating all remaining terms, or another identity with manifest eventual positivity.

Status:

- whole product classical weight-1 modularity: **rigorously impossible**, by \(t^{-1}\log^2(1/t)\) cusp growth;
- nonclassical identity: **not found**;
- no coefficient positivity theorem in primary literature.

## Requested trigger 5: divisor switching with controlled negative part

Exact switch obtained:

\[
\widetilde R(n)=Z(n)+4\sum_{q<n}\chi_4(q)A_q(n).
\]

Required: a pointwise bound on the \(q\equiv3\pmod4\) contribution or a nonnegative reorganization with a strict positive remainder.

Status: **missing**. Fixed truncations are defeated by a moving large inert prime; hyperbola switching retains sign cancellation to \(\sqrt n\).

## Circle-method subgap

Even under the optimistic square-root Weyl scale, the absolute minor-arc bound is:

\[
\ll n^{1/2+\varepsilon}\log n.
\]

Needed:

\[
o(\log^2n)
\]

uniformly for every \(n\).

The ratio is polynomial. A new sparse-shift cancellation theorem—not parameter optimization—is required.

## Direct universal leverage watch

Fan–Lott's power-saving van der Corput weight is a genuine strong theorem, but it controls difference-free sets, not coverage of a fixed translate by a logarithmic lacunary set. No implication to A303656 was established. It therefore stays on a speculative watch list and does not satisfy promotion.

## Final map

| Trigger | Status | Promotion |
|---|---|---|
| Pointwise asymptotic | exact candidate formula, no uniform error | NO |
| Positive lower bound | absent | NO |
| Finite reduction | fixed-modulus obstruction | NO |
| Classical modular identity | ruled out | NO |
| Divisor negative control | exact switch, uncontrolled tail | NO |
| Uniform minor arcs | polynomial gap | NO |

# STOP THETA-SERIES TRIGGER
