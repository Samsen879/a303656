# EXACT FORMULAE

全文使用

\[
e(\alpha)=e^{2\pi i\alpha},
\qquad
\chi_4(m)=
\begin{cases}
0,&2\mid m,\\
1,&m\equiv1\pmod4,\\
-1,&m\equiv3\pmod4.
\end{cases}
\]

## 1. Theta identity

\[
\Theta(q)=\sum_{x\in\mathbb Z}q^{x^2},
\]

\[
\Theta(q)^2
=\sum_{m\ge0}r_2(m)q^m
=1+4\sum_{m\ge1}
\left(\sum_{d\mid m}\chi_4(d)\right)q^m.
\]

As a modular form,

\[
\Theta^2\in M_1(\Gamma_0(4),\chi_4).
\]

## 2. Lacunary factors and Mahler equations

\[
L_b(q)=\sum_{j\ge0}q^{b^j},
\qquad b\in\{3,5\},
\]

\[
L_b(q)=q+L_b(q^b).
\]

## 3. Exact coefficient generating function

\[
G(q)=\Theta(q)^2L_3(q)L_5(q),
\]

\[
[q^n]G(q)
=\sum_{\substack{c,d\ge0\\3^c+5^d\le n}}
r_2(n-3^c-5^d)
=\widetilde R(n).
\]

## 4. Exact divisor switching

Define

\[
H_n^-:=\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d<n\},
\]

\[
W^-(n)=|H_n^-|,
\qquad
Z(n)=\#\{(c,d):3^c+5^d=n\},
\]

\[
A_q(n)=\#\{(c,d)\in H_n^-:3^c+5^d\equiv n\pmod q\}.
\]

Then

\[
\boxed{
\widetilde R(n)=Z(n)+4\sum_{1\le q<n}\chi_4(q)A_q(n).
}
\]

Set

\[
\Delta_q(n)=A_q(n)-\frac{W^-(n)}q,
\qquad
L_n=\sum_{q<n}\frac{\chi_4(q)}q.
\]

Then exactly

\[
\widetilde R(n)=Z(n)+4W^-(n)L_n
+4\sum_{q<n}\chi_4(q)\Delta_q(n).
\]

Since

\[
L_n=\frac\pi4+O(n^{-1}),
\]

we have

\[
\boxed{
\widetilde R(n)=Z(n)+\pi W^-(n)
+4\sum_{q<n}\chi_4(q)\Delta_q(n)
+O(W^-(n)/n).
}
\]

## 5. Multiplicative positivity/cancellation formula

If

\[
m=2^a\prod_{p\equiv1(4)}p^{u_p}
\prod_{p\equiv3(4)}p^{v_p},
\]

then

\[
\sum_{d\mid m}\chi_4(d)
=\prod_{p\equiv1(4)}(u_p+1)
\prod_{p\equiv3(4)}\frac{1+(-1)^{v_p}}2.
\]

Equivalently,

\[
r_2(m)=
4\mathbf 1_{\forall p\equiv3(4):\,v_p(m)\text{ even}}
\prod_{p\equiv1(4)}(v_p(m)+1).
\]

## 6. Divisor hyperbola pairing

Let \(u\) be the odd part of \(m\). Then

\[
\sum_{d\mid m}\chi_4(d)=\sum_{d\mid u}\chi_4(d).
\]

If \(u\) is not a square,

\[
\sum_{d\mid u}\chi_4(d)
=(1+\chi_4(u))
\sum_{\substack{d\mid u\\d<\sqrt u}}\chi_4(d).
\]

If \(u\) is a square,

\[
\sum_{d\mid u}\chi_4(d)
=2\sum_{\substack{d\mid u\\d<\sqrt u}}\chi_4(d)+\chi_4(\sqrt u).
\]

## 7. Shift-count asymptotic

\[
W(X)=\#\{(c,d):3^c+5^d\le X\}
=\frac{(\log X)^2}{\log3\log5}+O(\log X).
\]

Also

\[
\sum_{3^c+5^d\le X}(3^c+5^d)=O(X\log X).
\]

## 8. Summatory weighted coefficient

Using

\[
\sum_{0\le m\le Y}r_2(m)=\pi Y+O(\sqrt Y),
\]

one obtains

\[
\boxed{
\sum_{n\le X}\widetilde R(n)
=\frac{\pi X(\log X)^2}{\log3\log5}+O(X\log X).
}
\]

## 9. Radial generating-function asymptotic

For \(t\to0^+\),

\[
\Theta(e^{-t})^2
=\frac\pi t\left(1+O(e^{-\pi^2/t})\right),
\]

\[
L_b(e^{-t})=\frac{\log(1/t)}{\log b}+O(1),
\qquad b=3,5,
\]

therefore

\[
\boxed{
G(e^{-t})
=\frac{\pi}{\log3\log5}\frac{\log^2(1/t)}t
+O\!\left(\frac{\log(1/t)}t\right).
}
\]

## 10. Exact circle integral

Let

\[
P=\lfloor\sqrt n\rfloor,
\quad
F_n(\alpha)=\sum_{|x|\le P}e(\alpha x^2),
\]

\[
A_n(\alpha)=\sum_{3^c\le n}e(\alpha3^c),
\quad
B_n(\alpha)=\sum_{5^d\le n}e(\alpha5^d).
\]

Then

\[
\boxed{
\widetilde R(n)
=\int_0^1F_n(\alpha)^2A_n(\alpha)B_n(\alpha)e(-n\alpha)\,d\alpha.
}
\]

## 11. Ramanujan/singular-series formulation — summability warning

For \(m\ge1\), a precise boundary-value formulation is

\[
r_2(m)=\pi\lim_{\sigma\downarrow0}
\sum_{\substack{q\ge1\\q\text{ odd}}}
\frac{\chi_4(q)c_q(m)}{q^{1+\sigma}},
\]

where \(c_q(m)\) is the Ramanujan sum. Thus the expression with \(1/q\) is used only in this Dirichlet-regularized sense; no unproved ordinary convergence is assumed.

Indeed, for \(\sigma>0\) the series is absolutely convergent. Its Euler product has the baseline factor

\[
\prod_{p\text{ odd}}\left(1-\frac{\chi_4(p)}{p^{1+\sigma}}\right)
=\frac1{L(1+\sigma,\chi_4)}.
\]

If \(p^a\parallel m\), the ratio of the modified local factor to this baseline tends, as \(\sigma\downarrow0\), to

\[
1+\chi_4(p)+\cdots+\chi_4(p)^a.
\]

Since \(L(1,\chi_4)=\pi/4\), the boundary value is exactly \(4\sum_{d\mid m}\chi_4(d)=r_2(m)\).

Consequently the aggregate truncated series is

\[
\mathfrak S_{H}(n;Q)=
\sum_{\substack{q\le Q\\q\text{ odd}}}
\frac{\chi_4(q)}q
\sum_{(c,d)\in H_n^-}c_q(n-3^c-5^d).
\]

For an odd prime \(p\),

\[
\sum_{(c,d)\in H_n^-}c_p(n-3^c-5^d)
=pA_p(n)-W^-(n),
\]

so the prime-\(p\) contribution is

\[
\chi_4(p)\left(A_p(n)-\frac{W^-(n)}p\right).
\]

The full individual singular factor vanishes precisely when the residual fails the two-square parity condition. Hence aggregate singular-series nonvanishing is not a separate local theorem; it is another encoding of the original target.
