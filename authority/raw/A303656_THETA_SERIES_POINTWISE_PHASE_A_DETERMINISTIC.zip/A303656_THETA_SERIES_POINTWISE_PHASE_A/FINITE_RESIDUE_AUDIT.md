# FINITE RESIDUE-CLASS AUDIT

## 1. Fixed modulus cannot recognize sums of two squares

### Lemma

Fix \(M\ge1\).

1. If a residue \(r\pmod M\) is representable as \(x^2+y^2\pmod M\), then it contains arbitrarily large integers in \(\mathcal S_2\).
2. Every residue \(r\pmod M\) contains arbitrarily large integers not in \(\mathcal S_2\).

### Proof

For (1), choose \(x_0,y_0\) with

\[
x_0^2+y_0^2\equiv r\pmod M.
\]

Then

\[
(x_0+kM)^2+y_0^2\equiv r\pmod M
\]

and tends to infinity.

For (2), choose a prime \(p\equiv3\pmod4\) with \(p\nmid M\). By CRT solve

\[
N\equiv r\pmod M,
\qquad
N\equiv p\pmod{p^2}.
\]

Every solution has \(v_p(N)=1\), hence is not a sum of two squares. Adding multiples of \(Mp^2\) gives arbitrarily large examples. \(\square\)

## 2. Consequence for the present problem

A finite table assigning to each \(n\pmod M\) a pair \((c,d)\) such that

\[
n-3^c-5^d
\]

falls in a locally representable residue class does not prove global representability. That class still contains infinitely many non-norms caused by primes not dividing \(M\).

To make a finite reduction rigorous, one would need an additional statement that controls all primes outside the fixed modulus. That additional statement is essentially a uniform global theorem, not a residue check.

## 3. Theta dissection is tautological

For any fixed \(M\),

\[
G(q)=\sum_{r=0}^{M-1}q^rG_r(q^M),
\]

where \(G_r\) collects coefficients in residue class \(r\). Proving all sufficiently large coefficients of each \(G_r\) positive is simply a finite family of the original pointwise problem.

## 4. Growing modulus is not a finite reduction

One could let \(M=M(n)\) include more inert primes. To exclude an odd valuation obstruction for every residual, \(M(n)\) must eventually see primes of growing size. Such a procedure is a sieve/circle-method argument with an expanding modulus range, not a finite residue-class reduction. It inherits the parity and uniformity gaps of the divisor route.

## Verdict

No strict finite residue-class reduction was found.
