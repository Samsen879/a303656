# DIVISOR-SWITCHING AUDIT

## 1. Exact switch

For residuals \(m>0\),

\[
r_2(m)=4\sum_{q\mid m}\chi_4(q).
\]

Separating the zero residual gives

\[
\widetilde R(n)=Z(n)+4\sum_{(c,d)\in H_n^-}
\sum_{q\mid n-3^c-5^d}\chi_4(q).
\]

Interchanging two finite sums gives

\[
\boxed{
\widetilde R(n)=Z(n)+4\sum_{q<n}\chi_4(q)A_q(n).
} \tag{1.1}
\]

This is rigorous and exact.

## 2. Apparent main term

Write

\[
A_q(n)=\frac{W^-(n)}q+\Delta_q(n).
\]

Then

\[
\widetilde R(n)
=Z(n)+4W^-(n)\sum_{q<n}\frac{\chi_4(q)}q
+4\sum_{q<n}\chi_4(q)\Delta_q(n).
\]

Since

\[
\sum_{q<n}\frac{\chi_4(q)}q=\frac\pi4+O(n^{-1}),
\]

we get

\[
\widetilde R(n)=Z(n)+\pi W^-(n)+E_{\rm div}(n)+O(W^-(n)/n),
\]

where

\[
\boxed{
E_{\rm div}(n)=4\sum_{q<n}\chi_4(q)\Delta_q(n).
} \tag{2.1}
\]

The key defect is visible in (2.1): the discrepancy is not weighted by \(1/q\). Uniform distribution of \(3^c+5^d\) for fixed or polylogarithmic moduli would not control the full sum.

## 3. Large-prime cancellation refutes truncated positivity

For every cutoff \(Q\), choose a prime \(p\equiv3\pmod4\) with \(p>Q\). Then

\[
4\sum_{\substack{q\mid p\\q\le Q}}\chi_4(q)=4,
\qquad
r_2(p)=4(1-1)=0.
\]

Therefore no assertion of the form

\[
r_2(m)\ge 4\sum_{\substack{q\mid m\\q\le Q(m)}}\chi_4(q)
\]

can hold uniformly for any truncation rule with \(Q(p)<p\) for infinitely many primes \(p\equiv3\pmod4\). This includes every fixed cutoff and every rule \(Q(m)=o(m)\). A moving large inert prime contains exactly the information omitted by the truncation.

## 4. Hyperbola switch does not solve the sign problem

Let \(u\) be the odd part of \(m\). Pair \(d\) with \(u/d\). If \(u\) is nonsquare,

\[
\sum_{d\mid u}\chi_4(d)
=(1+\chi_4(u))
\sum_{\substack{d\mid u\\d<\sqrt u}}\chi_4(d).
\]

This gives immediate zero when \(u\equiv3\pmod4\), but for \(u\equiv1\pmod4\) the shorter divisor sum can still vanish. Example:

\[
u=21,
\qquad
\sum_{d\mid21}\chi_4(d)=1-1-1+1=0.
\]

Thus complementary-divisor switching only lowers the modulus ceiling to \(\sqrt n\); it does not create a positive minorant.

## 5. Singular-series vanishing

For \(m\ge1\), the Dirichlet-regularized Ramanujan boundary value

\[
r_2(m)=\pi\lim_{\sigma\downarrow0}
\sum_{q\text{ odd}}\frac{\chi_4(q)c_q(m)}{q^{1+\sigma}}
\]

has a full factor equal to zero whenever an inert prime has odd valuation. Therefore the individual two-square singular series can vanish.

For the aggregate shifts,

\[
\sum_{(c,d)\in H_n^-}r_2(n-3^c-5^d)
=\pi\sum_{(c,d)\in H_n^-}\mathfrak S(n-3^c-5^d).
\]

The aggregate is zero exactly when every individual residual singular factor is zero. Hence proving aggregate singular-series positivity is equivalent to the original problem; there is no automatic local nonvanishing principle.

## 6. What a promotable divisor theorem would need

Any one of the following would suffice:

1. a uniform bound
   \[
   E_{\rm div}(n)>-(\pi-\eta)W^-(n)
   \]
   for some fixed \(\eta>0\);
2. a decomposition of \(E_{\rm div}\) into a controlled small-modulus part and a nonnegative large-modulus part;
3. a large-divisor pairing across the whole shift set that leaves a strictly positive unmatched contribution;
4. a parity-breaking sieve theorem for the residual family \(n-3^c-5^d\), uniform in every \(n\).

No such result was found or proved. Standard distribution of powers modulo \(q\) controls only selected modulus ranges and does not overcome the parity/large-divisor obstruction.

## Verdict

The exact formula is useful diagnostically, but it does not yield a pointwise lower bound.

**No divisor-switching promotion.**
