#!/usr/bin/env python3
"""Verify package membership, hashes, checksum ledger, and tiny formula checks."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_FROM_MANIFEST = {"MANIFEST.json", "SHA256SUMS.txt"}
EXCLUDED_FROM_LEDGER = {"SHA256SUMS.txt"}
SHA_RE = re.compile(r"^[0-9a-f]{64}$")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def relative_files() -> list[str]:
    return sorted(
        p.relative_to(ROOT).as_posix()
        for p in ROOT.rglob("*")
        if p.is_file()
    )


def run_json(script: str) -> dict:
    out = subprocess.check_output(
        [sys.executable, str(ROOT / "scripts" / script)], text=True
    )
    return json.loads(out)


def parse_ledger(path: Path) -> dict[str, str]:
    records: dict[str, str] = {}
    for lineno, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not raw:
            continue
        if "  " not in raw:
            raise ValueError(f"malformed SHA256SUMS line {lineno}")
        digest, rel = raw.split("  ", 1)
        if not SHA_RE.fullmatch(digest):
            raise ValueError(f"malformed digest on SHA256SUMS line {lineno}")
        if rel in records:
            raise ValueError(f"duplicate SHA256SUMS path: {rel}")
        records[rel] = digest
    return records


def main() -> None:
    errors: list[str] = []
    actual = relative_files()

    manifest = json.loads((ROOT / "MANIFEST.json").read_text(encoding="utf-8"))
    items = manifest.get("files", [])
    manifest_paths = [item.get("path") for item in items]
    expected_manifest_paths = sorted(set(actual) - EXCLUDED_FROM_MANIFEST)

    if manifest_paths != sorted(manifest_paths):
        errors.append("manifest paths are not sorted")
    if len(manifest_paths) != len(set(manifest_paths)):
        errors.append("manifest contains duplicate paths")
    if manifest_paths != expected_manifest_paths:
        missing = sorted(set(expected_manifest_paths) - set(manifest_paths))
        extra = sorted(set(manifest_paths) - set(expected_manifest_paths))
        errors.append(f"manifest membership mismatch; missing={missing}, extra={extra}")

    for item in items:
        rel = item.get("path")
        if not isinstance(rel, str):
            errors.append("manifest item has invalid path")
            continue
        path = ROOT / rel
        if not path.is_file():
            errors.append(f"missing: {rel}")
            continue
        if path.stat().st_size != item.get("size"):
            errors.append(f"size: {rel}")
        if sha256(path) != item.get("sha256"):
            errors.append(f"sha256: {rel}")

    try:
        ledger = parse_ledger(ROOT / "SHA256SUMS.txt")
    except ValueError as exc:
        errors.append(str(exc))
        ledger = {}
    expected_ledger_paths = sorted(set(actual) - EXCLUDED_FROM_LEDGER)
    if sorted(ledger) != expected_ledger_paths:
        missing = sorted(set(expected_ledger_paths) - set(ledger))
        extra = sorted(set(ledger) - set(expected_ledger_paths))
        errors.append(f"SHA256SUMS membership mismatch; missing={missing}, extra={extra}")
    for rel, digest in ledger.items():
        path = ROOT / rel
        if path.is_file() and sha256(path) != digest:
            errors.append(f"SHA256SUMS digest mismatch: {rel}")

    live_candidate = run_json("check_candidate_formula.py")
    stored_candidate = json.loads(
        (ROOT / "results" / "candidate_formula_check.json").read_text(encoding="utf-8")
    )
    if live_candidate != stored_candidate:
        errors.append("candidate formula result mismatch")


    if errors:
        print(json.dumps({"status": "FAIL", "errors": errors}, indent=2))
        raise SystemExit(1)
    print(
        json.dumps(
            {
                "status": "PASS",
                "manifest_files_checked": len(items),
                "checksum_records_checked": len(ledger),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
