#!/usr/bin/env python3
"""Tiny normalization audit for a candidate A303656 convolution manuscript."""
from __future__ import annotations

import json
import math
from pathlib import Path


def chi4(n: int) -> int:
    if n % 2 == 0:
        return 0
    return 1 if n % 4 == 1 else -1


def divisors(n: int):
    for d in range(1, int(math.isqrt(n)) + 1):
        if n % d == 0:
            yield d
            if d * d != n:
                yield n // d


def r2_divisor_signed(n: int) -> int:
    if n == 0:
        return 1
    return 4 * sum(chi4(d) for d in divisors(n))


def r2_signed_enum(n: int) -> int:
    b = math.isqrt(n)
    return sum(1 for x in range(-b, b + 1) for y in range(-b, b + 1)
               if x * x + y * y == n)


def r2_nonnegative_ordered(n: int) -> int:
    b = math.isqrt(n)
    return sum(1 for x in range(b + 1) for y in range(b + 1)
               if x * x + y * y == n)


def r2_nonnegative_unordered(n: int) -> int:
    b = math.isqrt(n)
    return sum(1 for x in range(b + 1) for y in range(x, b + 1)
               if x * x + y * y == n)


def diagonal_indicator(n: int) -> int:
    if n % 2:
        return 0
    a2 = n // 2
    a = math.isqrt(a2)
    return int(a * a == a2)


def main() -> None:
    rows = []
    formula_matches_signed = True
    for n in range(1, 33):
        signed = r2_signed_enum(n)
        divisor = r2_divisor_signed(n)
        nonneg_ord = r2_nonnegative_ordered(n)
        actual_unord = r2_nonnegative_unordered(n)
        manuscript_after_substitution = (divisor + diagonal_indicator(n)) / 2
        formula_matches_signed &= signed == divisor
        rows.append({
            "m": n,
            "signed_Z2": signed,
            "divisor_formula": divisor,
            "nonnegative_ordered": nonneg_ord,
            "nonnegative_unordered": actual_unord,
            "candidate_unordered_after_divisor_substitution": manuscript_after_substitution
        })

    result = {
        "purpose": "normalization refutation only; not an A303656 search",
        "theta_real_axis_ordinary_convergence": False,
        "reason": "terms have modulus 1 and do not tend to zero",
        "divisor_formula_matches_signed_Z2_for_m_1_to_32": formula_matches_signed,
        "counterexamples": {
            "m=1": rows[0],
            "m=2": rows[1]
        },
        "all_rows": rows
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
