#!/usr/bin/env python3
"""Build a byte-reproducible ZIP from a frozen package directory."""
from __future__ import annotations

import argparse
import stat
import zipfile
from pathlib import Path

FIXED_TIME = (1980, 1, 1, 0, 0, 0)


def build(source: Path, output: Path) -> None:
    source = source.resolve()
    output = output.resolve()
    if not source.is_dir():
        raise ValueError(f"source directory does not exist: {source}")
    try:
        output.relative_to(source)
    except ValueError:
        pass
    else:
        raise ValueError("output ZIP must be outside the source directory")

    root_name = source.name
    paths = sorted(p for p in source.rglob("*") if p.is_file())
    output.parent.mkdir(parents=True, exist_ok=True)

    # ZIP_STORED avoids compressor-version variance; all other metadata is fixed.
    with zipfile.ZipFile(
        output, "w", compression=zipfile.ZIP_STORED, strict_timestamps=True
    ) as zf:
        for path in paths:
            rel = path.relative_to(source).as_posix()
            arcname = f"{root_name}/{rel}"
            data = path.read_bytes()
            info = zipfile.ZipInfo(arcname, date_time=FIXED_TIME)
            info.create_system = 3
            mode = 0o755 if (path.stat().st_mode & 0o111) else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.compress_type = zipfile.ZIP_STORED
            info.extra = b""
            info.comment = b""
            zf.writestr(info, data)
        zf.comment = b""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    build(args.source, args.output)


if __name__ == "__main__":
    main()
