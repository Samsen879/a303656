# CANDIDATE FORMULA REFUTATION

Target: O. Basta, *A Convolutional Characterization of the Sun–OEIS A303656 Conjecture* (2025 manuscript).

This audit uses only tiny symbolic checks; it is not a search over \(T(n)\).

## 1. Real-axis theta convergence claim is false

The manuscript writes

\[
\Theta(\theta)=\sum_{x\in\mathbb Z}e^{ix^2\theta}
\]

and claims ordinary convergence for real \(\theta\ne0\pmod{2\pi}\).

For every real \(\theta\),

\[
|e^{ix^2\theta}|=1.
\]

The summands therefore do not tend to zero. The series cannot converge in the ordinary sense at any real \(\theta\). A valid treatment needs \(\operatorname{Im}z>0\), Abel regularization, or distribution theory; ordinary Fourier inversion as written is invalid.

## 2. Representation normalization mismatch

Let

\[
r_{\mathbb Z^2}(m)=\#\{(x,y)\in\mathbb Z^2:x^2+y^2=m\},
\]

\[
r_{\mathbb N_0^2}^{\rm ord}(m)
=\#\{(a,b)\in\mathbb Z_{\ge0}^2:a^2+b^2=m\},
\]

and let \(r_{\le}(m)\) count nonnegative pairs with \(a\le b\).

The classical formula

\[
4\sum_{d\mid m}\chi_4(d)
\]

equals \(r_{\mathbb Z^2}(m)\), not \(r_{\mathbb N_0^2}^{\rm ord}(m)\).

### Counterexample \(m=1\)

\[
r_{\mathbb Z^2}(1)=4,
\quad
r_{\mathbb N_0^2}^{\rm ord}(1)=2,
\quad
r_{\le}(1)=1.
\]

Substituting the divisor formula into the manuscript's unordered conversion gives 2, not 1.

### Counterexample \(m=2\)

\[
r_{\mathbb Z^2}(2)=4,
\quad
r_{\mathbb N_0^2}^{\rm ord}(2)=1,
\quad
r_{\le}(2)=1.
\]

The manuscript's final substitution gives

\[
\frac{4+1}{2}=\frac52,
\]

which is not even an integer.

## 3. The convolution identity is tautological

The valid statement

\[
T(n)=\sum_{c,d}r_{\le}(n-3^c-5^d)
\]

simply partitions representations by the pair \((c,d)\). It is equivalent to the definition and supplies no lower bound on the right-hand side.

The conclusion “under Sun's conjecture, \(T(n)>0\)” is conditional on the conjecture itself, not a proof.

## 4. Reproducible check

Run

```bash
python3 scripts/check_candidate_formula.py
```

and compare with `results/candidate_formula_check.json`.

## Verdict

The manuscript is not a pointwise coefficient positivity theorem and cannot trigger promotion.
