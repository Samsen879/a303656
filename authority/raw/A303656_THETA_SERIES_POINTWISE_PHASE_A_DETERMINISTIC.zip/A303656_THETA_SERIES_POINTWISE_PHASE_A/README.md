# A303656 THETA-SERIES / DIVISOR-SUM / POINTWISE POSITIVITY — PHASE A

## 项目结论

**STOP THETA-SERIES TRIGGER**

本包审计如下 pointwise 问题：

\[
\widetilde R(n)=
\sum_{\substack{c,d\ge 0\\3^c+5^d\le n}}
r_2(n-3^c-5^d),
\qquad
r_2(m)=\#\{(x,y)\in\mathbb Z^2:x^2+y^2=m\}.
\]

由于每一项非负且

\[
r_2(m)>0\iff m\in\mathcal S_2,
\]

故

\[
\widetilde R(n)>0\iff
\exists c,d\ge0:\ n-3^c-5^d\in\mathcal S_2.
\]

因此，raw \(r_2\)-weighted coefficient 在 **pointwise positivity** 层面确实避免了 indicator covariance：若能对单个 \(n\) 证明 \(\widetilde R(n)>0\)，便已直接解决 support 问题。问题不在权重到 support 的转换，而在于没有足够强的 uniform coefficient estimate。

## 本包获得的严格结果

1. **Exact theta coefficient identity**：
   \[
   \Theta(q)^2L_3(q)L_5(q)=\sum_{n\ge0}\widetilde R(n)q^n.
   \]

2. **Exact divisor-switching identity**：
   \[
   \widetilde R(n)
   =Z(n)+4\sum_{1\le q<n}\chi_4(q)A_q(n),
   \]
   并可精确重写为
   \[
   \widetilde R(n)=Z(n)+\pi W^-(n)
   +4\sum_{q<n}\chi_4(q)\Delta_q(n)
   +O\!\left(\frac{W^-(n)}n\right).
   \]
   这里 discrepancy sum 没有 \(1/q\) 衰减；大模数 divisor cancellation 是核心障碍。

3. **Abelian / summatory main term**：
   \[
   \sum_{n\le X}\widetilde R(n)
   =\frac{\pi X(\log X)^2}{\log3\log5}+O(X\log X).
   \]
   这是 average asymptotic，不能推出任何 pointwise positivity。

4. **Classical modular-form trigger 排除**：令 \(q=e^{-t}\)，则
   \[
   \Theta(e^{-t})^2L_3(e^{-t})L_5(e^{-t})
   =\frac{\pi}{\log3\log5}\frac{\log^2(1/t)}t
   +O\!\left(\frac{\log(1/t)}t\right).
   \]
   classical holomorphic modular form 在 cusp 的展开不产生 \(t^{-1}\log^2(1/t)\) 项，故该 generating function 不是任何 congruence subgroup 上的 classical holomorphic weight-1 modular form；有限 classical modular/quasimodular identity 也不能产生此 logarithmic cusp factor。

5. **Circle-method gap 定量化**：即使采用乐观的 classical square-root quadratic Weyl scale，绝对值估计仍只给出约
   \[
   O_\varepsilon(n^{1/2+\varepsilon}\log n)
   \]
   量级的 minor-arc bound，而候选主项仅为 \(\asymp(\log n)^2\)。需要一个全新的、对每个 \(n\) uniform 的 sparse-shift cancellation lemma；文献审计未发现此 theorem。

## 文件导航

- `EXECUTIVE_VERDICT.md`：最终 referee verdict。
- `REPORT.md`：完整主报告。
- `EXACT_FORMULAE.md`：所有 exact formulae 与推导。
- `MODULAR_FORM_AUDIT.md`：weight-1 / cusp-growth 审计。
- `DIVISOR_SWITCHING_AUDIT.md`：divisor switch、large-divisor cancellation、singular-series vanishing。
- `CIRCLE_METHOD_AUDIT.md`：major/minor arcs 与缺失 lemma。
- `FINITE_RESIDUE_AUDIT.md`：fixed-modulus reduction 的严格限制。
- `COEFFICIENT_POSITIVITY_AUDIT.md`：weighted positivity、average 与 pointwise quantifier 区分。
- `LITERATURE_AUDIT.md`：primary literature quantifier audit。
- `CANDIDATE_FORMULA_REFUTATION.md`：对 2025 convolution manuscript 的小型 symbolic 反驳。
- `THEOREM_GAP_MAP.md`：五类 promotion trigger 的逐项状态。
- `INPUT_PROVENANCE.md`：四个 frozen input 包及 SHA256。
- `PROMOTION_VERDICT.json`：machine-readable verdict。
- `SOURCE_LOCK.json`：文献版本锁。
- `scripts/`、`results/`：candidate-formula 小型反驳与 deterministic build/verification。

本包没有执行长区间 \(T(n)\) search；所有 finite computation 仅用于核验 exact identity 或反驳 normalization formula。

OEIS A303656: UNRESOLVED.
