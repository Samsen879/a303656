# INPUT PROVENANCE

The following frozen packages were audited before this phase.

| Input archive | SHA256 | Relevant inherited conclusion |
|---|---|---|
| `A303656_GLOBAL_ROUTE_RESET.zip` | `b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13` | Project paused; no all-sufficiently-large route promoted. |
| `A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN.zip` | `aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2` | Positive-density theorem only; average/second-moment route does not eliminate exceptional integers. Includes finite-collision and additive-energy lemmas for the shift set. |
| `A303656_GAUSSIAN_NORM_PHASE_A_DETERMINISTIC(1)(1).zip` | `2f9b1323805d03e47e6edc4a4766073ac8d610d6a555a5778d39196583fedc6a` | No mixed-base Gaussian-norm descent or finite-state recurrence. |
| `A303656_WEIGHTED_MINORANT_PHASE_A(1)(1).zip` | `f5fc3c8a4563c2e46060244fe33567018ac367cc852b76393c61bc2b97101ce4` | Bounded support minorants exist, but weighted concentration/pointwise transfer was missing. |

This phase does not modify those archives. It uses the inherited bounded collision statement only as an optional strengthening in the minor-arc norm estimate; the final STOP verdict remains valid even with weaker elementary bounds.
The inherited collision statement is proved in `LEMMA_COLLISIONS.md` of the positive-density archive from Evertse–Győry, Theorem 1, *Compositio Mathematica* 66 (1988), via a nondegenerate weighted unit equation in \(\langle3,5\rangle\). Its source lock is included in `SOURCE_LOCK.json`.

## Scope controls

- No repository integration.
- No large computational search.
- No claim based on unverified average-to-pointwise conversion.
- Literature access date: 2026-07-21.
