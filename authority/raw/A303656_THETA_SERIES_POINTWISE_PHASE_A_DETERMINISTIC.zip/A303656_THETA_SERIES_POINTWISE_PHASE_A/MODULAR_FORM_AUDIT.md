# MODULAR-FORM AND THETA-SERIES AUDIT

## 1. What is genuinely modular

The standard Jacobi theta function satisfies

\[
\Theta(q)^2
=1+4\sum_{n\ge1}\left(\sum_{d\mid n}\chi_4(d)\right)q^n,
\]

and is a holomorphic weight-1 Eisenstein series with nebentypus \(\chi_4\) on \(\Gamma_0(4)\).

This gives an exact divisor formula for each residual coefficient. It does **not** provide a smooth positive main term for each coefficient: weight 1 is critical, the coefficients are divisor-sized, and they vanish on every integer having an inert prime \(p\equiv3\pmod4\) to odd valuation.

## 2. The lacunary factors are not modular decorations

Define

\[
L_b(q)=\sum_{j\ge0}q^{b^j},\qquad b=3,5.
\]

They satisfy Mahler equations

\[
L_b(q)=q+L_b(q^b),
\]

but this self-similarity does not preserve the modular transformation of \(\Theta^2\). In particular, it introduces logarithmic radial growth at \(q=1\).

## 3. Cusp-growth lemma

### Lemma

As \(t\to0^+\),

\[
L_b(e^{-t})=\frac{\log(1/t)}{\log b}+O(1).
\]

### Proof

Let \(J=\lfloor\log_b(1/t)\rfloor\). For \(j\le J\),

\[
0\le 1-e^{-tb^j}\le tb^j,
\]

and therefore

\[
\sum_{j=0}^{J}e^{-tb^j}
=J+1+O\!\left(t\sum_{j=0}^{J}b^j\right)
=J+1+O_b(1),
\]

because \(tb^J\le1\). For \(j>J\), write \(j=J+r\). Since \(tb^J>b^{-1}\),

\[
\sum_{j>J}e^{-tb^j}
\le\sum_{r\ge1}e^{-b^{r-1}}
=O_b(1).
\]

Finally \(J=\log(1/t)/\log b+O(1)\), proving the claim.

Poisson summation gives

\[
\Theta(e^{-t})=\sqrt{\frac\pi t}\left(1+O(e^{-\pi^2/t})\right).
\]

Therefore

\[
G(e^{-t})
=\frac{\pi}{\log3\log5}\frac{\log^2(1/t)}t
+O\!\left(\frac{\log(1/t)}t\right). \tag{3.1}
\]

## 4. Nonmodularity theorem

### Theorem

Set \(\mathcal G(\tau)=G(e^{2\pi i\tau})\). Then \(\mathcal G\) is not a classical holomorphic modular form of weight 1 on any congruence subgroup with finite-order multiplier. In fact, the same radial argument excludes any single fixed classical weight.

### Proof

Every rational boundary point, in particular \(\tau=0\), which corresponds to \(q=1\), is a cusp for a finite-index congruence group. After choosing a cusp scaling matrix, a holomorphic weight-1 modular form has a Fourier expansion at that cusp. Returning to the original variable, its radial behavior is either

\[
t^{-1}(a_0+O(e^{-c/t}))
\]

or, if the constant term vanishes,

\[
t^{-1}O(e^{-c/t}).
\]

No \(t^{-1}\log^2(1/t)\) term can occur. This contradicts (3.1). For a different fixed weight \(k\), the radial power would be \(t^{-k}\), again incompatible with \(t^{-1}\log^2(1/t)\).

The same argument rules out any finite derivative-free linear combination of classical holomorphic modular forms of fixed finite weights as an identity for \(G\): cusp expansions yield finite sums of powers of \(t^{-1}\), not logarithmic squares. Classical quasimodular corrections also yield polynomials in \(t^{-1}\), not \(\log^2(1/t)\).

## 5. Consequence for coefficient positivity

The most tempting route—identify the whole generating function as a weight-1 Eisenstein series plus a smaller cusp form and prove Eisenstein dominance—cannot start. There is no such classical modular decomposition.

Even hypothetically, weight 1 offers no automatic polynomial-scale dominance: Eisenstein coefficients themselves can be zero and are only divisor-sized. Thus a modular identity would still need an arithmetic nonvanishing theorem.

## 6. What is not ruled out

This audit does not rule out:

- a nonholomorphic automorphic transform;
- a mock/quantum modular relation;
- an infinite Mahler-modular functional system;
- an ad hoc theta identity with manifestly nonnegative coefficient blocks.

No primary source located in this phase supplies an eventual coefficient-positivity theorem for any such structure, and none gives a finite positivity reduction. These possibilities remain speculative, not promotable.

## Verdict

**Classical weight-1 modular-form trigger: rigorously closed.**

**Nonclassical theta/Mahler trigger: no theorem; speculative only.**
