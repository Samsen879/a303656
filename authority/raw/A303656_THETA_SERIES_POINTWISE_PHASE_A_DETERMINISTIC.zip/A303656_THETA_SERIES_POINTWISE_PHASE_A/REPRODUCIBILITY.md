# REPRODUCIBILITY

## Formula checks

From the package root:

```bash
python3 scripts/check_candidate_formula.py
```

The script uses only the Python standard library and inspects \(1\le m\le32\), solely to refute the candidate manuscript's representation normalization.

It is not a search for a zero of A303656. No coefficient scan is included in the delivered package.

## Bundle verification

```bash
python3 scripts/verify_bundle.py
```

This checks the payload manifest, stored results, and reruns the candidate-formula refutation script.

## Deterministic ZIP build

```bash
python3 scripts/build_deterministic_zip.py \
  . ../A303656_THETA_SERIES_POINTWISE_PHASE_A_DETERMINISTIC.zip
```

The builder:

- sorts all archive paths;
- fixes ZIP timestamps to 1980-01-01 00:00:00;
- fixes Unix permissions;
- uses `ZIP_STORED`, avoiding compressor-version variance;
- omits host-specific metadata.

The delivered archive was built twice from the frozen payload and byte-compared.
