# EXECUTIVE VERDICT

## Verdict

# STOP THETA-SERIES TRIGGER

## Referee finding

本轮没有满足任何 promotion condition：

- 没有得到
  \[
  \widetilde R(n)=\mathfrak S(n)M(n)+E(n),
  \qquad \mathfrak S(n)M(n)>|E(n)|
  \]
  对所有 sufficiently large \(n\) 的 theorem；
- 没有 explicit positive pointwise lower bound；
- 没有严格 finite residue-class reduction；
- standard modular-form identity route 被 cusp-growth obstruction 排除；
- divisor switching 虽然 exact，但负贡献不能被 pointwise 控制；
- 文献中的 shifted convolution、mean-square、positive-density、difference-set 结果均具有错误的 quantifier 或错误的 observable。

## 最重要的逻辑澄清

\(r_2\)-weighted observable 对 pointwise positivity 是完全合适的：

\[
\widetilde R(n)>0\iff T(n)>0.
\]

所以本轮失败不是“weighted-to-support gap”。失败点是：要在一个固定的 \(n\) 上，从只有 \(\asymp\log^2 n\) 个 lacunary shifts 中强制至少一个 residual 为 Gaussian norm，仍需 uniform arithmetic cancellation。

## Exact candidate main term and exact obstruction

令

\[
W^-(n)=\#\{(c,d):3^c+5^d<n\},
\]

\[
A_q(n)=\#\{(c,d):3^c+5^d<n,\ 3^c+5^d\equiv n\pmod q\},
\]

\[
\Delta_q(n)=A_q(n)-\frac{W^-(n)}q.
\]

则 exact divisor switching 给出

\[
\widetilde R(n)
=Z(n)+\pi W^-(n)
+4\sum_{q<n}\chi_4(q)\Delta_q(n)
+O\!\left(\frac{W^-(n)}n\right).
\]

表面主项为 \(\pi W^-(n)\asymp\log^2 n\)，但 error 是 **unweighted** discrepancy sum。对大 \(q\)，\(A_q(n)\) 为稀疏的 0/1 arithmetic incidence；没有任何可用 equidistribution theorem 给出

\[
\left|\sum_{q<n}\chi_4(q)\Delta_q(n)\right|
<\left(\frac\pi4-o(1)\right)W^-(n)
\]

uniformly in every \(n\)。一个新出现的 \(p\equiv3\pmod4\) 的 odd valuation 可以在任意 fixed truncation 之后把 divisor sum 精确抵消为 0。

## Modular trigger verdict

\(\Theta^2\) 本身是 weight-1 Eisenstein theta series，但

\[
L_3(e^{-t})L_5(e^{-t})
=\frac{\log^2(1/t)}{\log3\log5}+O(\log(1/t)).
\]

故总 generating function 在 cusp 0 具有

\[
t^{-1}\log^2(1/t)
\]

growth。classical holomorphic modular forms 的 cusp Fourier expansion 只有 power growth 乘 exponentially small corrections，不含此 logarithmic factor。因此“把整个 product 识别为 weight-1 modular form，再由 Eisenstein dominance 强制 coefficient positivity”的 trigger 不存在。

## Circle-method verdict

exact integral 为

\[
\widetilde R(n)=\int_0^1F_n(\alpha)^2A_n(\alpha)B_n(\alpha)e(-n\alpha)\,d\alpha.
\]

即使乐观地采用 classical square-root quadratic minor-arc scale，并与 inherited bounded-collision estimate

\[
\int_0^1|A_nB_n|^2\,d\alpha\ll\log^2 n
\]

结合，也只产生 polynomial-size upper bound，远大于 \(\log^2 n\) 主项。Linnik–Goldbach 型方法通过多个 lacunary factors 的高次幂放大 exceptional-set measure；此处只有一个 base-3 sum 与一个 base-5 sum，不能移植该 amplification。

## Stop condition

剩余路线最终仍要求：

> minor arcs 对每个 \(n\) 都足够小，或 divisor discrepancies 对每个 \(n\) 都有足够 cancellation。

当前没有 theorem 支持该 uniform assertion。依项目规则，必须 STOP。

OEIS A303656: UNRESOLVED.
