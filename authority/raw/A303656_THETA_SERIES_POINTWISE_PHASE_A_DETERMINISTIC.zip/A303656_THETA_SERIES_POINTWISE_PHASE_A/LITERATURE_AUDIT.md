# PRIMARY LITERATURE AUDIT

Access/version lock: 2026-07-21. Bibliographic identifiers are also recorded in `SOURCE_LOCK.json`.

## 1. OEIS A303656

The current OEIS entry still labels

\[
a(n)>0\quad(n>1)
\]

as a conjecture and records computational verification through \(2.4\times10^{11}\). This is status/computation, not proof.

**Quantifier:** finite verification.

**Promotion:** none.

## 2. Artyom Radomskii, *Variants of Romanoff's theorem*, arXiv:2504.09954v6

The paper gives lower bounds for the number of integers \(n\le x\) representable as a sum from two sequences and includes sums-of-two-squares examples. Its theorem is a counting/density framework.

Even under a specialization relevant to powers, the conclusion concerns how many integers are represented, not every sufficiently large integer.

**Quantifier:** density / counting lower bound.

**Promotion:** rejected for pointwise target.

## 3. Fernando Chamizo, *The Additive Problem for the Number of Representations as a Sum of Two Squares*, Mediterranean Journal of Mathematics 19 (2022), article 44, DOI 10.1007/s00009-021-01959-3

Chamizo studies

\[
S(x,m)=\sum_{n\le x}r(n)r(n+m)
\]

with the shift \(m\) allowed to vary. This is a shifted convolution averaged over the base variable \(n\).

Our target fixes the outer integer \(N\) and sums \(r_2(N-h)\) over a logarithmic lacunary shift set. There is no averaging over a long base interval.

**Quantifier:** average over \(n\le x\).

**Promotion:** no.

## 4. Hulse–Kuan–Lowry-Duda–Walker, *The Laplace Transform of the Second Moment in the Gauss Circle Problem*, arXiv:1705.04771v3

They prove a smoothed shifted-correlation asymptotic of the form

\[
\sum_{n\ge1}r_2(n)r_2(n+h)e^{-n/X}
=C_hX+O_\varepsilon(X^{1/2+\varepsilon}e^{h/X}h^\Theta).
\]

The paper also explains that an additional average over \(h\) removes spectral poles present for individual shifted Dirichlet series. Both the displayed theorem and that extra cancellation still average over a long base variable \(n\).

Neither statement implies a uniform sparse-shift pointwise estimate at one prescribed \(N\).

**Quantifier:** smoothed/long average.

**Promotion:** no.

## 5. R. C. Crocker, *On the sum of two squares and two powers of k*, Colloquium Mathematicum 112 (2008), 235–267

For every fixed base \(k\ge2\), Crocker proves infinitely many positive integers are not representable as a sum of two squares and two or fewer powers of \(k\).

This shows that “two lacunary power variables should automatically fill all gaps” is false in the same-base setting. It does not decide the mixed-base pair \((3,5)\).

**Quantifier:** infinitely many counterexamples for same base.

**Promotion:** negative warning only.

## 6. Dave Platt and Tim Trudgian, *On the sum of two squares and at most two powers of 2*, arXiv:1610.01672v2 / American Mathematical Monthly 124 (2017)

They demonstrate infinitely many integers not expressible as two squares plus at most two nonnegative powers of 2.

**Quantifier:** same-base negative theorem.

**Promotion:** no direct mixed-base consequence.

## 7. Steve Fan and Andrew Lott, *The van der Corput property for sums of two squares*, arXiv:2606.29185v2

They construct nonnegative coefficients \(c_d\), supported on sums of two squares, with

\[
\sum c_d=1,
\qquad
\Re\sum c_de(d\theta)\ge -C_\varepsilon N^{-1/8+\varepsilon}
\]

uniformly in \(\theta\). A consequence is a Sárközy-type theorem: a set with no nonzero sum-of-two-squares differences has size \(O_\varepsilon(N^{7/8+\varepsilon})\).

This is the strongest nearby new harmonic-analysis result, but its combinatorial input is

\[
(A-A)\cap\mathcal S_2=\varnothing.
\]

A hypothetical A303656 failure gives only

\[
(n-H_n)\cap\mathcal S_2=\varnothing,
\]

a translate-avoidance statement. It does not imply that \(H_n\cup\{n\}\) or any logarithmic-size subset is sum-of-two-squares-difference-free. Moreover \(|H_n|\asymp\log^2N\) is far below \(N^{7/8+\varepsilon}\), so the cardinality corollary is vacuous here.

**Quantifier/structure:** difference sets, not fixed translate coverage.

**Promotion:** speculative watch only; no direct universal leverage established.

## 8. Johnston–Trudgian, *An update on the Linnik–Goldbach and Romanov problems*, arXiv:2605.17825v1

The paper proves, under GRH, that every sufficiently large even integer is the sum of two primes and six powers of 2; it reviews an unconditional admissible value of eight powers. The circle-method mechanism uses repeated powers-of-two factors and a high-power large-values estimate.

This supports the methodological diagnosis: lacunary minor arcs become controllable after power amplification. It does not give a theorem for one base-3 factor times one base-5 factor.

**Quantifier:** pointwise, but with two prime variables and many repeated lacunary variables.

**Promotion:** architecture comparison only.

## 9. Oussama Basta, *A Convolutional Characterization of the Sun–OEIS A303656 Conjecture* (2025 manuscript)

The main convolution identity is tautological coefficient partitioning. It does not prove positivity. The manuscript also contains two decisive technical errors:

1. It defines \(\sum_{x\in\mathbb Z}e^{ix^2\theta}\) as an ordinarily convergent real-axis series. Its terms have modulus 1 and therefore do not tend to zero; ordinary convergence fails for every real \(\theta\).
2. It defines \(r_2\) as an ordered nonnegative representation count, then inserts the classical divisor formula \(4\sum_{d\mid m}\chi_4(d)\), which counts signed ordered \(\mathbb Z^2\) representations. At \(m=1\), these counts are 2 and 4 respectively; the final unordered formula is misnormalized. At \(m=2\), the manuscript's substitution gives a noninteger \(5/2\) instead of 1.

**Status:** non-peer-reviewed manuscript with invalid analytic and normalization steps.

**Promotion:** rejected.

## 10. Overall literature verdict

No audited primary source provides any of the following for

\[
[q^n]\Theta(q)^2L_3(q)L_5(q):
\]

- uniform pointwise asymptotic with dominant positive main term;
- explicit eventual lower bound;
- finite coefficient positivity reduction;
- classical modular identity;
- divisor-switching tail bound;
- sparse-shift minor-arc estimate uniform in every \(n\).

The closest results are either average/density theorems, same-base negative constructions, high-variable Linnik-type theorems, or difference-set harmonic analysis.
