#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, stat, zipfile
from pathlib import Path

def build(root: Path, output: Path) -> None:
    root = root.resolve()
    files = sorted(p for p in root.rglob('*') if p.is_file() and p.name != 'MANIFEST.sha256')
    manifest_lines=[]
    for p in files:
        rel=p.relative_to(root).as_posix()
        manifest_lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {rel}")
    (root/'MANIFEST.sha256').write_text('\n'.join(manifest_lines)+'\n',encoding='utf-8',newline='\n')
    entries=sorted(p for p in root.rglob('*') if p.is_file())
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_STORED) as z:
        for p in entries:
            rel=(Path(root.name)/p.relative_to(root)).as_posix()
            info=zipfile.ZipInfo(rel,(2000,1,1,0,0,0))
            mode=0o755 if p.parent.name=='scripts' else 0o644
            info.external_attr=(stat.S_IFREG|mode)<<16
            info.create_system=3
            info.flag_bits|=0x800
            z.writestr(info,p.read_bytes())

def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',required=True)
    ap.add_argument('--output',required=True)
    a=ap.parse_args()
    build(Path(a.root),Path(a.output))

if __name__=='__main__':
    main()
