# AUTHORITY HIERARCHY UPDATE

## Accepted

### Canonical certificate package

1. `CC-A` — critical square-root canonical record saturation:
   
   \[
   |\mathscr C_X^{\mathrm{pvt}}|=\Theta(X(\log X)^{3/2}).
   \]
   
   Classification: `PROVED DERIVATIVE OF FROZEN PW-A AUTHORITY`.

2. `HC-A` — aggregate high-cutoff bad-tail bound:
   
   \[
   \sum_{X\le n\le2X}B_{X,\delta}(n)
   \ll X(\log X)^{3/2}\sqrt{\delta+1/\log X}.
   \]
   
   Classification: `PROVED`.

3. `HC-A + HC-LT => |E_X|=o(X)`.
   
   Classification: `CORRECT CONDITIONAL IMPLICATION`; `HC-LT NOT ESTABLISHED`.

### Finite-state package

1. Terminal-soundness requirement.
   
   Classification: `PROVED LOGICAL REQUIREMENT`.

2. Affine S-unit axis-fiber classification for fixed \((K,C)\).
   
   Classification: `PROVED USING PRIMARY ESS THEOREM`.

3. Entropy–Sparsity Finite-State No-Go Theorem.
   
   Classification: `PROVED NEGATIVE STRUCTURAL THEOREM`.

4. Full-rank affine Gaussian transformations reduce to pure norm scaling.
   
   Classification: `PROVED / RECONFIRMED`.

## Not established

- HC-LT lower-tail theorem;
- any low-fiber canonical record theorem giving \(o(X)\);
- any unconditional almost-all theorem;
- any non-affine representation-independent one-norm descent;
- any finite reduction for A303656;
- any universal proof or counterexample.

## Route governance

```text
CANONICAL CERTIFICATE COMPRESSION:
SPECULATIVE WATCH ONLY

FINITE-STATE EXACT AFFINE DESCENT:
STOP

ACTIVE PROMOTED ROUTE:
NONE

PROJECT:
PAUSED

CODEX:
NOT AUTHORIZED

CODEX ULTRA:
NOT AUTHORIZED

A303656:
UNRESOLVED
```
