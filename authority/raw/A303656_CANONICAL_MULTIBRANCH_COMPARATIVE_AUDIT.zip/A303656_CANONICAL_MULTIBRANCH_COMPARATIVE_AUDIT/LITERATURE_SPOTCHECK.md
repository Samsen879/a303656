# LITERATURE SPOT-CHECK

## 1. Evertse–Schlickewei–Schmidt

Primary source: J.-H. Evertse, H. P. Schlickewei, W. M. Schmidt, *Linear equations in variables which lie in a multiplicative group*, Annals of Mathematics 155 (2002), 807–836.

The primary theorem gives an explicit bound for nondegenerate solutions of a fixed linear equation in a finite-rank multiplicative group. This supports the package's normalized minimal-block/projective-family reduction. The axis-fiber classification itself is task-specific and is proved in the package rather than quoted from the source.

## 2. Canonical witness compression analogue

Primary source: Eric Li, *A Resolution of Erdős Problem 768: the Sylow Divisor Condition*, arXiv:2606.24872v2 (13 July 2026).

The paper explicitly uses canonical witness divisors, majority-halving, deletion of a squarefree factor, deterministic compression, reconstruction of fibers, and growing divisor moments. Its mechanism depends on witnesses attached to divisors of one common integer and on a self-indexed congruence relation. The A303656 certificates instead divide different translates \(n-h\). The package is correct not to claim a direct transfer.

## 3. Combinatorial large sieve

Primary source: E. Croot, J. Mao, C. Pohoata, A. Sheffer, C. H. Yip, *A combinatorial large sieve for Sidon sets, distances, and norm forms*, arXiv:2606.17487v2 (24 June 2026).

The method requires local algebraic branching together with global bounded multiplicity. The canonical package does not establish either a fixed residue-class deficit for the exceptional set or the required bounded multiplicity for a fixed certificate incidence map. The non-application verdict is supported.

## 4. Square-condition sieve

Primary source: R. Dietmann, C. Elsholtz, I. Ruzsa, *Sieving with square conditions and applications to Hilbert cubes in arithmetic sets*, arXiv:2603.17132v1 (17 March 2026).

The paper converts certain modulo-prime-square restrictions into useful modulo-prime restrictions for fixed Hilbert-cube/additive structures. A303656 odd-valuation certificates form multiple p-adic shells and vary cell-by-cell with the translated remainder. The package correctly identifies missing hypotheses.

## 5. Current problem status

OEIS A303656 continued to list the universal positivity statement as a conjecture in the current entry checked during this audit. No general proof or certified counterexample was found in this spot-check.

## Literature decision

```text
NO PRIMARY SOURCE INVALIDATES THE TWO PACKAGE VERDICTS.
NO PRIMARY SOURCE CLOSES HC-LT.
NO PRIMARY SOURCE SUPPLIES A NON-AFFINE STATEFUL DESCENT.
```
