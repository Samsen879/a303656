# REPRODUCE

## Validate source packages

The audit used the validators and replay scripts included in each source package, then rebuilt both ZIPs with their own deterministic builders and compared them byte-for-byte with the uploaded files.

Expected source hashes:

```text
51efabb8b7f6d9dad65021be11cdda4316da91f9530abb7ddef8d648b4d9fd71  A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A(2).zip
ddfeb79af1046e5f44245e192341f35a43103627a6af1ef8ba6940dc6a4be34c  A303656_FINITE_STATE_MULTIBRANCH_DESCENT_PHASE_A(2).zip
```

## Rebuild this audit ZIP

From the parent directory of the audit directory:

```bash
python3 A303656_CANONICAL_MULTIBRANCH_COMPARATIVE_AUDIT/scripts/build_deterministic_zip.py \
  --root A303656_CANONICAL_MULTIBRANCH_COMPARATIVE_AUDIT \
  --output A303656_CANONICAL_MULTIBRANCH_COMPARATIVE_AUDIT.rebuilt.zip
```
