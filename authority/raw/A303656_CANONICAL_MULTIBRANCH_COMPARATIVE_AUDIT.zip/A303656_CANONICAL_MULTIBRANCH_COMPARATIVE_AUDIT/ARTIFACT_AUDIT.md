# ARTIFACT AUDIT

## Source packages

### Canonical certificate compression

- Uploaded filename: `A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A(2).zip`
- SHA256: `51efabb8b7f6d9dad65021be11cdda4316da91f9530abb7ddef8d648b4d9fd71`
- Size: 216680 bytes
- ZIP integrity: PASS
- Entries: 49
- Entry order: sorted
- Timestamp policy: all entries `1980-01-01 00:00:00`
- Compression: `ZIP_STORED`
- Unsafe paths: none
- Duplicate paths: none
- C0/DEL control-character scan: PASS
- Internal validator: PASS
- Experiment replay: PASS
- Theorem sanity replay: PASS
- Deterministic rebuild: byte-identical PASS

### Finite-state multibranch descent

- Uploaded filename: `A303656_FINITE_STATE_MULTIBRANCH_DESCENT_PHASE_A(2).zip`
- SHA256: `ddfeb79af1046e5f44245e192341f35a43103627a6af1ef8ba6940dc6a4be34c`
- Size: 136087 bytes
- ZIP integrity: PASS
- Entries: 41
- Entry order: sorted
- Timestamp policy: all entries `2000-01-01 00:00:00`
- Compression: `ZIP_STORED`
- Unsafe paths: none
- Duplicate paths: none
- C0/DEL control-character scan: PASS
- Internal validator: PASS
- Experiment replay: PASS
- Deterministic rebuild: byte-identical PASS

## Trust boundary

Successful replay certifies the finite computations, manifests, and packaging. It does not by itself certify the mathematical proofs. Those were audited separately in `MATHEMATICAL_AUDIT.md`.
