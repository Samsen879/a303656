# MATHEMATICAL AUDIT

# I. Canonical certificate compression

## 1. Theorem CC-A

### Decision

```text
ACCEPTED AS A DERIVATIVE OF THE FROZEN PRIVATE-WITNESS AUTHORITY
```

At the square-root cutoff, a bad survivor has a unique odd-valuation bad prime above the cutoff, with valuation one. Therefore each private survivor vertex corresponds to one canonical record

\[
(c,d,q,s),\qquad n=3^c+5^d+qs.
\]

Using the previously accepted aggregate lower bound for private vertices and the complete-survivor aggregate upper bound gives

\[
|\mathscr C_X^{\mathrm{pvt}}|
=\Theta\!\bigl(X(\log X)^{3/2}\bigr).
\]

The record-count theorem correctly shows that raw one-record incidence charging is critical: assigning only \(\Theta((\log X)^{3/2})\) such records per target yields at best an \(O(X)\) exceptional-set bound.

## 2. Theorem HC-A

### Decision

```text
ACCEPTED
```

For \(z=X^{1-\delta}>\sqrt{2X}\), each bad high-cutoff survivor remainder has the unique form

\[
m=qs,
\qquad q>z,
\quad q\equiv3\pmod4,
\quad v_q(m)=1,
\quad s\in\mathcal S_2,
\quad s\le2X^\delta.
\]

For a fixed shift and fixed \(s\), a fixed-progression prime upper bound gives

\[
\#q\ll \frac{X}{s\log X}.
\]

The Landau–Ramanujan upper bound and partial summation give

\[
\sum_{\substack{s\le 2X^\delta\\s\in\mathcal S_2}}\frac1s
\ll \sqrt{\delta\log X+1}.
\]

After summing over \(O((\log X)^2)\) exponent pairs, this yields

\[
\sum_{X\le n\le2X}B_{X,\delta}(n)
\ll
X(\log X)^{3/2}
\sqrt{\delta+\frac1{\log X}}.
\]

The proof is uniform for \(0<\delta\le\delta_0<1/2\).

## 3. HC-LT conditional bridge

### Decision

```text
LOGICALLY CORRECT BUT UNPROVED
```

If the full high-cutoff survivor count satisfies a uniform lower-tail theorem

\[
\#\{n\in[X,2X]:U_{X,\delta}(n)<\kappa(\log X)^{3/2}\}
\le \rho(\delta)X+o_\delta(X),
\qquad \rho(\delta)\to0,
\]

then HC-A implies \(|E_X|=o(X)\).

This implication is correct. The hypothesis is not a minor technical lemma: it requires indicator-level lower-tail control for a truncated parity-survivor condition across a growing two-dimensional lacunary shift family. It is close in strength to the unresolved almost-all/covariance barrier. No bounded Phase B follows from the package.

## Canonical route verdict

```text
NEW PROVED RESULT:
HC-A

PROMOTION:
NO

STATUS:
LOW-PRIORITY SPECULATIVE WATCH ONLY

CODEX / ULTRA:
NOT AUTHORIZED
```

# II. Finite-state multi-branch descent

## 1. Terminal-soundness correction

### Decision

```text
ACCEPTED
```

For a proper sublanguage \(\mathcal H_\sigma\subsetneq\mathcal H\), state-badness

\[
P_\sigma(n):n\notin\mathcal S_2+\mathcal H_\sigma
\]

is weaker than original badness. A path ending in bounded \(P_\sigma(m)\) does not automatically produce a bounded original counterexample. Any valid stateful finite reduction needs state-specific terminal verification, an explicit decoder, or a return to an equivalent copy of the initial state. Empty-language states are vacuous.

## 2. Affine S-unit Fiber Classification

### Decision

```text
ACCEPTED, USING THE STANDARD EVERTSE–SCHLICKEWEI–SCHMIDT THEOREM
```

For fixed \(K\ge2\) and \(C\), consider

\[
K3^c+K5^d+C-3^u-5^v=0.
\]

Partitioning degenerate solutions into minimal zero-sum blocks and applying the finite-rank nondegenerate unit-equation theorem to each normalized block gives finitely many projective ratio families.

If \(c\) varies in one family, the term \(K3^c\) cannot have fixed ratio with a constant or a power of 5. Its minimal block must therefore be

\[
K3^c-3^u=0,
\]

so \(K=3^r\), while \(d\) is fixed. This gives a horizontal fiber. Symmetrically, variation in \(d\) forces \(K=5^s\) and a vertical fiber. Both coordinates cannot vary for \(K\ge2\), because that would force \(K\) to be both a power of 3 and a power of 5.

Thus, outside finitely many accidental source pairs, every infinite branch is axis-aligned. If \(K\) is neither a power of 3 nor a power of 5, only finitely many source pairs occur. The finite-axis-fiber claim follows from the relevant 3-adic or 5-adic valuation of \(C\).

## 3. Entropy–Sparsity Finite-State No-Go Theorem

### Decision

```text
ACCEPTED NEGATIVE STRUCTURAL THEOREM
```

Assume a finite nonvacuous exact affine shift-language system, with edges

\[
\phi_e(x)=K_ex+C_e,
\qquad K_e\ge2,
\]

exact closure

\[
\phi_e(\mathcal H_\tau)\subseteq\mathcal H_\sigma,
\]

and complete sufficiently-large integer coverage at every reachable state.

For every fixed depth \(r\), sufficiently large starting integers admit length-\(r\) paths. A path domain lies in one residue cylinder modulo

\[
K_p=\prod_{e\in p}K_e\ge2^r,
\]

so every cylinder has upper density at most \(2^{-r}\). Covering a tail requires at least \(2^r\) distinct cylinders and therefore at least \(2^r\) distinct composed affine maps.

Every reachable nonvacuous state contains at least two shifts; singleton states cannot have finite outgoing congruence domains covering a tail. Fix two shifts \(x_\tau\ne y_\tau\) in each endpoint state. A depth-\(r\) composed map ending at \(\tau\) is uniquely determined by

\[
\bigl(\phi_p(x_\tau),\phi_p(y_\tau)\bigr).
\]

These image shifts lie in \(\mathcal H\) and have size at most exponential in \(r\). Since

\[
|\mathcal H\cap[1,Y]|=O((\log Y)^2),
\]

there are only \(O(r^2)\) possibilities for each image and \(O(r^4)\) image pairs. Summing over finitely many endpoint states yields only \(O_\Sigma(r^4)\) distinct maps, contradicting the \(2^r\) lower bound.

The theorem is independent of the S-unit classification and is robust under mixed scales, mixed offsets, overlapping domains, arbitrary subsets of the integrality classes, finite state languages, cycles, and arbitrary state languages contained in \(\mathcal H\).

## 4. Scope boundary

The no-go theorem does not rule out:

- non-affine representation-independent transformations;
- a semantic hybrid that covers only state-bad integers and separately proves all uncovered integers representable;
- closure at the full representability-set level that does not induce shift-language inclusion;
- analytic or sieve routes.

## Finite-state route verdict

```text
FINITE-STATE EXACT AFFINE MULTI-BRANCH DESCENT:
STOP

NEW AUTHORITY:
TERMINAL-SOUNDNESS REQUIREMENT
AFFINE S-UNIT AXIS-FIBER CLASSIFICATION
ENTROPY–SPARSITY FINITE-STATE NO-GO

PROMOTION:
NO

CODEX / ULTRA:
NOT AUTHORIZED
```

# III. Comparative result

The finite-state package has the stronger theorem-level output, but it is route-closing rather than route-opening. The canonical package leaves one conditional almost-all bridge, but its missing lower-tail theorem is too close to the central unresolved parity/correlation barrier to justify a new active phase.

```text
COMPARATIVE PROMOTION VERDICT:
PROMOTE NONE
```
