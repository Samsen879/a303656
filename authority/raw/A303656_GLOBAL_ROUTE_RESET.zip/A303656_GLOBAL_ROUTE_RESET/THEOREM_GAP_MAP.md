# THEOREM-GAP MAP

## 1. Setup

Let

\[
\mathcal S_2=\{a^2+b^2:a,b\in\mathbb Z_{\ge0}\},
\qquad
\mathcal D_X=\{(c,d):3^c+5^d\le X/2\}.
\]

For a shift value `s`, let

\[
w_X(s)=\#\{(c,d)\in\mathcal D_X:3^c+5^d=s\},
\]

and write `W_X=Σ_s w_X(s)=|D_X|`, where exponent-pair identities are counted with multiplicity. For `I_X=[X,2X]∩Z`,

\[
R_X(n)=\sum_s w_X(s)\mathbf 1_{\mathcal S_2}(n-s).
\]

The logical ladder is

\[
\text{positive density}
\;\Longrightarrow?\;
\text{almost all}
\;\Longrightarrow?\;
\text{all sufficiently large}
\;\Longrightarrow?\;
\text{all }n>1.
\]

None of the arrows is automatic.

---

## 2. Current level: positive density

### What is established

There exist `c0,c1,X0>0` such that every `X≥X0` satisfies

\[
\#\{n\in[X,2X]:R_X(n)\ge c_0(\log X)^{3/2}\}\ge c_1X.
\]

The distinct-shift version is also proved.

### Exact limitation

A lower bound `c1X` leaves a complementary set of positive density. It does not imply that the exceptional density tends to zero, let alone that the exceptional set is finite or empty.

Classification: **PROVED at positive-density level; universal gap remains structural.**

---

## 3. Gap 1: positive density → almost all

Define

\[
A_s(X)=\sum_{n\in I_X}\mathbf 1_{\mathcal S_2}(n-s),
\qquad
C_{s,t}(X)=\sum_{n\in I_X}
\mathbf 1_{\mathcal S_2}(n-s)\mathbf 1_{\mathcal S_2}(n-t).
\]

With `μ_X=|I_X|^{-1}Σ_{n∈I_X}R_X(n)`, finite expansion gives the exact identity

\[
\sum_{n\in I_X}(R_X(n)-\mu_X)^2
=
\sum_{s,t}w_X(s)w_X(t)
\left(C_{s,t}(X)-\frac{A_s(X)A_t(X)}{|I_X|}\right).
\tag{3.1}
\]

### Precise missing theorem: weighted signed covariance cancellation

A sufficient theorem is

\[
\boxed{
\sum_{s,t}w_X(s)w_X(t)
\left(C_{s,t}(X)-\frac{A_s(X)A_t(X)}{|I_X|}\right)
=o\!\left(\frac{XW_X^2}{\log X}\right)
}
\tag{COV-D}
\]

as `X→∞`, with the actual dyadic boundaries and the exact structured family of shifts.

Together with the established first moment, `(COV-D)` would imply

\[
\#\{n\in I_X:R_X(n)=0\}=o(X)
\]

by Chebyshev.

### Why current results do not cross the gap

1. FKR/Nowak-type bounds give an **upper bound** for `C_{s,t}`, not a signed approximation to the product term.
2. A bounded second-moment ratio yields positive density, not a ratio tending to one.
3. Sidon-scale additive energy controls how often the same difference occurs; it gives no cancellation in the covariance attached to that difference.
4. Estimates for `Σ r_2(n)r_2(n+h)` concern a weighted representation function, not the 0–1 indicator.
5. Fixed-shift theorems do not provide uniformity over a family of size about `(log X)^4` with shifts growing with `X` and nonuniform multiplicities.
6. Moving-short-interval almost-all theorems average over interval positions, not over the required structured sparse difference measure.

### Gap classification

- **technical?** Not merely. Improving constants or summation ranges in existing upper bounds does not create a signed main term.
- **conceptual?** Yes: the observable and sign structure are different.
- **structural?** Yes: the family grows and is adversarially structured.
- **likely inaccessible with current theory?** Strategic assessment: **yes**, absent a new indicator-correlation theorem.

### Identifiable intermediate theorem

`(COV-D)` is an exact intermediate theorem. It would reach almost all, but no farther. This is the only surviving low-cost literature-watch target.

---

## 4. Gap 2: almost all → all sufficiently large

Suppose one somehow proves

\[
E(X):=\#\{n\le X:T(n)=0\}=o(X).
\]

This permits infinitely many exceptions. No contradiction follows from density zero.

### Precise missing theorem A: effective exception descent

There exist an effectively computable `N0` and an explicit map `F` such that, for every exceptional `n>N0`,

\[
2\le F(n)<n
\quad\text{and}\quad
T(F(n))=0.
\tag{DESC}
\]

If exact finite verification proves no exception in `[2,N0]`, repeated descent would rule out every exception.

### Precise missing theorem B: effective structural elimination

An alternative is an effective finite classification

\[
\{n>N_0:T(n)=0\}\subseteq \bigcup_{j=1}^{J}\mathcal E_j,
\tag{STRUCT}
\]

where every `E_j` is explicitly defined and one can prove that each member admits a valid shift, yielding a contradiction. The classes must be finite in number and the contradiction must be uniform and effective.

### Why current results do not cross the gap

- Density estimates do not give descent.
- Pair covariance, even if optimal, controls cardinality rather than arithmetic structure of individual exceptions.
- Modular local information does not synchronize one exponent pair across all bad prime powers.
- No theorem in the audited literature confines the exceptional set to finitely many progressions, algebraic sets, or multiplicative families that can be eliminated.

### Gap classification

**Conceptual and structural; likely inaccessible with current theory.** No credible missing lemma smaller than `(DESC)` or `(STRUCT)` was identified.

---

## 5. Gap 3: all sufficiently large → all `n>1`

### Exact required theorem

An effective theorem must state:

\[
\exists\;\text{explicit computable }N_0
\quad\forall n>N_0,
\quad T(n)>0.
\tag{EFF-LARGE}
\]

Then exact finite verification of `[2,N0]` completes the universal statement.

### Current status

No `(EFF-LARGE)` theorem exists. The existing 1.853B verified integers are not linked to a proven threshold. Therefore the finite computation cannot serve as the final finite tail.

### Gap classification

The finite tail would be **technical and auditable** after an effective threshold. Obtaining the threshold is not technical; it contains the unresolved universal mechanism.

---

## 6. Certified-counterexample gap

For a fixed candidate `n`, certification is finite:

1. enumerate all exponent pairs with `3^c+5^d≤n`;
2. for each remainder apply the exact two-square criterion;
3. run an independent theorem verifier;
4. preserve complete provenance and hashes.

The strategic missing theorem is a finite reduction:

\[
\boxed{
(\exists n>1:T(n)=0)
\Longrightarrow
(\exists n\le N_*:T(n)=0)
}
\tag{FIN-RED}
\]

for an explicit computable `N_*`, or an equivalent finite-state/modulus certificate whose validity covers the entire exponent domain.

No `(FIN-RED)` theorem is known from the artifacts or the audited literature. Consequently, enlarging a bounded search interval is not a complete counterexample route.

Classification: **candidate verification is technical; candidate existence and finite reduction are structural and unresolved.**

---

## 7. Overall theorem-gap judgment

The project has a rigorous result at the first rung and rigorous finite obstructions/computations around several side routes. It has no bridge for the first two logical arrows and no finite reduction for the counterexample direction. The decisive deficit is not computing power but theorem structure.
