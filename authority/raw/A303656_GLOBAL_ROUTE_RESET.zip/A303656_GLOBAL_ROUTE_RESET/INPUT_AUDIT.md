# INPUT AUDIT

Audit date: 2026-07-17. All sizes are exact bytes. All ZIPs passed `unzip -t` integrity testing. All available internal SHA manifests passed. No filename was treated as authority without byte-level checking.

## 1. Files actually received

| Actual upload | Size | SHA256 | ZIP entries | Integrity | Classification |
|---|---:|---|---:|---|---|
| `A303656_GLOBAL_ROUTE_RESET_LOCAL_INVENTORY(3).md` | 17,964 | `0b76b806f5d4524f80c650483e4ebb3f264ef8af52823a2abb2bc9386ab2e207` | — | text read | local provenance inventory |
| `A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(4).zip` | 282,646 | `aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2` | 59 | PASS | repaired final authority |
| `A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(2)(2).zip` | 282,646 | `aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2` | 59 | PASS | byte-identical duplicate of repaired final authority |
| `analytic_bad_prime_phaseA(3).zip` | 563,522 | `9dd538f5d47a4d2327159b619af7db752f241421caef926207e623be6a8b1ec2` | 92 | PASS | Phase A route authority/supporting analysis |
| `a303656_p2cover_bundle(4).zip` | 93,403 | `4dadb8ce07cd0ccf56575ef0882d6bb02284a02c61e05cd1424e070d83b22ff3` | 40 | PASS | certified finite `p^2`-cover authority |
| `a303656_gate_v2_final_independent_audit(3).zip` | 886,302 | `fedbfd4d5079d1ccd23cb6fca61c23a61b7419a01bd7b278168e6bc2750cc49b` | 103 | PASS | final independent audit |
| `a303656_bounded_counterexample_bundle_refreshed(3).zip` | 8,599,075 | `f877561680531f448e90d38bb097a8d05379d3b25f993e44289ed8f82baa0316` | 9,447 | PASS | bounded-verification authority |
| `A303656_P4_MOD8_LIVE_INDEPENDENT_AUDIT_Samsen_20260715(3).zip` | 273,713 | `cc917a6f7f04f6a4f6264775d63129c4fd7f18af40116b27291b3226014c570d` | 49 | PASS | accepted independent-audit derivative |
| `分工规则.txt` | 4,366 | `94261338e1d2e0a348ff264e9a98322b647918eeca74b0932dcd90bac980b5f6` | — | text read | execution-governance instruction |
| `项目简介.txt` | 510 | `42903e1adb5731d195786538a1072aa5b54a5c2adbf7fe6b963226fa74a139ae` | — | text read | project-scope instruction |

## 2. Expected-hash reconciliation

All six canonical expected ZIP hashes match exactly. Seven ZIP upload instances were received because the repaired positive-density package was uploaded twice. The repaired positive-density hash is

`aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2`.

The superseded hash

`1d8bb9b45cb556d4693b568d42b10af386de88e734094d1af5f0396c9c243ff8`

was not received and is not used as authority. The two positive-density uploads are byte-identical, not two independent proofs.

## 3. Main entry points

| Package | Main entry files |
|---|---|
| Positive-density frozen | `EXECUTIVE_VERDICT.md`, `FINAL_REPORT.md`, `FINAL_VERDICT.json`, `THEOREM_POSITIVE_DENSITY.md`, proof/lemma files, `RADOMSKII_CONDITION_CROSSWALK.md`, `ALMOST_ALL_BLOCKER.md` |
| Analytic bad-prime Phase A | `EXECUTIVE_VERDICT.md`, `REPORT.md`, `ROUTE_VERDICT.json`, `candidate_theorems.md`, `route_comparison.md`, exact-moment and anti-cover notes |
| `p^2` cover | `REPORT_zh.md`, `README.md`, exact verifier source/log, `output/primes_B5000_verified_by_order.csv`, certificates |
| Gate V2 audit | `AUDIT_VERDICT.json`, `REPORT.md`, registry/replay/provenance audits, independent scripts and logs |
| Bounded verification | `README.md`, `REPORT_zh.md`, `output/formal_results_audit.json`, `output/final_packaging_audit.json`, `cert/NO_COUNTEREXAMPLE_CERTIFICATE.txt` |
| Fixed-P4 audit | `AUDIT_VERDICT.json`, `REPORT.md`, standalone Python/C++ verifiers, recomputed histograms, mask/projection crosswalks, provenance audit |

## 4. Internal verification

- Positive-density package: internal `SHA256SUMS.txt` PASS; frozen-core verifier PASS; scientific-core SHA256 `8f7708954cb3e89f159bb01173b4160e1423bb7c7fc96d528b45a558a5de2220`; nested draft/formal-audit archive manifests PASS; symbolic constant check PASS with primitive-set constant `1/(4K)`.
- Analytic, `p^2`, Gate V2, bounded, and P4 internal checksum manifests: PASS.
- Independent small exact cross-checks reproduced the accepted `p^2`, bounded, P4, Gate V2, and counting-convention facts. See `SANITY_CHECKS.json`.

## 5. Authority distinctions

### Final authority

- repaired positive-density frozen package;
- certified `p^2`-cover bundle;
- refreshed bounded-verification bundle.

### Independent audit

- Gate V2 final independent audit;
- fixed-P4 independent-audit derivative.

### Supporting evidence

- analytic bad-prime Phase A package;
- local inventory and execution/project instructions.

### Superseded or duplicate

- old positive-density hash: superseded and absent;
- second repaired positive-density upload: byte-identical duplicate, not additional evidence.

### Missing exact legacy bytes

The fixed-P4 audit reports an original source archive `A303656_P4_MOD8_LIVE_AUDIT_BUNDLE_6efcf58.tar.zst` with reported SHA256 `60664f3ce1e9f7c7326b3387fd559aeee0da215c1ee2f76b87d2c42a0ede6a3a`, but those original bytes were not uploaded. The accepted finite landscape is independently reproduced by the derivative package; this package therefore treats the mathematics as accepted while explicitly refusing to call the derivative the exact legacy archive.
