# ROUTE SCORECARD NOTES

Scales are 0–5. For `progress_probability`, `universal_leverage`, `counterexample_leverage`, `novelty_confidence`, and `auditability`, higher is better. For `cost` and `closed_route_overlap_risk`, higher is worse. Scores are strategic assessments, not probabilities of the conjecture being true.

- **Route A:** some chance of external literature progress, but even success reaches only almost all and depends on a major new theorem.
- **Route B:** maximal universal leverage, negligible current mechanism.
- **Route C:** candidate certification is highly auditable, but finite-reduction probability is low and computation cost/overlap risk is maximal.
- **Route D:** high formal leverage but essentially restates the universal obstruction and repeats closed prime-power work.
- **Route E:** modern literature exists, but hypotheses mismatch the sparse binary setting.
- **Route F:** cheap to formulate and audit, but supplies no compression beyond the original statement.
- **Route G:** finite slices are easy to study, but likely reproduce density-level prior art and do not eliminate exceptions.
- **Route H:** deliberately left unpromoted until an exact theorem target appears.
- **Route I:** finite-state payoff would be strong for counterexamples, but structural evidence is weak and the two-square indicator is nonmorphic.
