# PROJECT PAUSE PROTOCOL

## 1. Artifacts that must be preserved

Preserve by exact SHA256:

1. repaired positive-density frozen package `aa0392a5…`;
2. analytic bad-prime Phase A `9dd538f5…`;
3. `p^2` authority `4dadb8ce…`;
4. Gate V2 independent audit `fedbfd4d…`;
5. bounded authority `f8775616…`;
6. fixed-P4 independent-audit derivative `cc917a6f…`;
7. local inventory `0b76b806…`;
8. this global reset package and its outer ZIP hash.

The duplicate positive-density upload may be deduplicated by hash, but its upload provenance should remain recorded. Preserve the explicit statement that the P4 package is an independent-audit derivative and that exact original legacy bytes are missing.

## 2. Restart triggers

Restart only after one of the following external events:

1. a primary theorem proves signed 0–1 covariance with growing-shift uniformity strong enough to derive `(COV-D)`;
2. a primary theorem gives an effective exceptional-set descent or finite structural elimination applicable to this shift family;
3. a theorem synchronizes mixed-base exponent choices across a growing set of prime powers for every target;
4. a finite-reduction/decidability theorem bounds the least counterexample or supplies a finite modulus/state certificate;
5. an independently supplied concrete counterexample candidate comes with complete exponent activation, exact two-square checks, independent verification, and provenance;
6. a genuinely different theorem target is proposed with a formal statement, proof mechanism, and direct payoff beyond density.

A new paper is not itself a trigger. It must pass the full condition crosswalk.

## 3. Literature-watch cadence and keywords

Cadence: quarterly, or immediately after a clearly relevant preprint alert.

Primary keywords:

- `sums of two squares indicator correlation signed covariance`;
- `norm-form indicator shifted convolution growing shifts`;
- `pair correlation sums of two squares singular series asymptotic uniform`;
- `exceptional set additive complement sums of two squares`;
- `effective local-global lacunary summands`;
- `simultaneous multiplicative orders two bases prime powers`;
- `finite reduction exponential Diophantine automata semilinear`;
- `sparse additive complement Romanoff theorem complete coverage`;
- `van der Corput sums of two squares transference`;
- author alerts: Radomskii, Freiberg, Kurlberg, Rosenzweig, Kimmel, Kuperberg, Matomäki, Radziwiłł, Ramaré, Fan, Lott.

## 4. Prohibited pseudo-progress

Do not count any of the following as project progress:

- a larger no-counterexample interval;
- a lower observed `T(n)`;
- another mask histogram or prime enumeration;
- stronger random-model evidence;
- improved constants in the frozen density theorem;
- a density theorem without a new bridge;
- a solver-produced modular pattern without a finite-reduction theorem;
- a literature analogy lacking an exact condition crosswalk;
- machine-learning pattern discovery;
- repackaging already subsumed results for novelty.

## 5. Future restart audit

Any restart must redo:

1. exact hash and provenance audit of all input authority packages;
2. version check for all cited preprints, especially Radomskii v6 and later versions;
3. theorem-number and hypothesis verification from primary PDFs;
4. the theorem-gap map, including the independent Gap 2;
5. overlap check against closed Gate V2, bad-prime, `p^2`, P4, and positive-density work;
6. a Phase A STOP/GO gate before any repository or large-scale computation.

## 6. Execution environment on restart

Default: web GPT-5.6 Pro for literature, mathematics, and small exact checks. Ordinary Codex CLI is considered only after a theorem-level Phase A gate requires repository implementation. Ultra remains unauthorized unless the mathematical payoff is frozen and ordinary resources are demonstrably insufficient.
