# LIMITATIONS

## Literature coverage

- The search was broad and primary-source oriented, but no web search can prove that no relevant theorem exists anywhere.
- Coverage is current through 2026-07-17 and must be rechecked because preprints can be revised.
- arXiv exact versions and primary PDFs were obtained for the principal sources used in the decision: Radomskii v6, FKR, Nowak, Kimmel–Kuperberg, Matomäki–Radziwiłł, Chamizo, Crocker, and several recent arXiv papers.
- The exact Baluyot–Gonek PDF was not obtained because the publisher endpoint was inaccessible in this environment. Only publisher metadata/abstract was recorded, and no decision-critical theorem statement was reconstructed from it.
- MathSciNet/Zentralblatt full records were not consistently accessible and are not used as theorem authority.
- Search-engine summaries were used only to locate primary sources.

## Artifact limitations

- The fixed-P4 exact original source archive and legacy `p4_live300_*` bytes were not uploaded. The accepted result is supported by an independent audit derivative and complete independent enumeration, not exact legacy-byte identity.
- The positive-density package was uploaded twice with identical bytes; this is duplicate provenance, not independent confirmation.
- Local inventory statements about the user's WSL repository were not rechecked against that repository because repository access was prohibited in this round.

## Mathematical limitations

- The judgment `NO CURRENT ROUTE HAS SUFFICIENT LEVERAGE` is a strategic research assessment, not a theorem that future progress is impossible.
- Scores in `ROUTE_SCORECARD.csv` are governance estimates, not probabilities that A303656 is true or false.
- No truth probability for the conjecture is inferred from 1.853B bounded checks.
- No almost-all or universal statement is claimed.
- The proposed target theorems `(COV-D)`, `(DESC)`, `(STRUCT)`, `(FIN-RED)`, `(SIM-EXP)`, and `(TRANS-POINT)` are gap specifications, not established results.

## Computational limitations

- Only SHA256, archive integrity, internal manifest checks, and small exact sanity checks were run.
- No new `T(n)` computation, candidate search, P5/P6 search, large mask search, prime expansion, or large symbolic computation was performed.
- No Codex, Ultra, WSL repository, Git, or external solver integration was used.

## Package limitations

- This package contains reports and machine-readable decisions, not the authority ZIPs themselves. Their exact hashes and filenames are recorded so the archives can be preserved separately.
- URLs in `WEB_SOURCES_LOCK.json` are a research lock, not an offline snapshot of every PDF.
