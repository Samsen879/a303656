# LITERATURE AUDIT

Cutoff: **2026-07-17**. Priority was given to arXiv exact versions, journal/publisher pages, and author/publisher PDFs. Search snippets were used for discovery only, never as theorem authority. Exact source URLs and access status are locked in `WEB_SOURCES_LOCK.json`.

## 1. Condition crosswalk required by A303656

A theorem capable of proving `(COV-D)` would need all of the following:

1. 0–1 **indicator-level** correlation, not `r_2` weights;
2. a signed asymptotic or signed average, not only an upper bound;
3. uniformity for shifts growing with `X`;
4. compatibility with a growing sparse family of differences
   `3^c+5^d-3^{c'}-5^{d'}`;
5. weighted averaging with the exact multiplicities `w_X(s)w_X(t)`;
6. boundary uniformity on dyadic moving translates;
7. an error `o(XW_X^2/log X)`;
8. preferably effectivity—although even this would yield only almost all.

No audited theorem satisfies this crosswalk.

## 2. Directly relevant sources

| Source and exact version | Theorem used | Indicator-level? | Shift uniformity | Growing sparse family? | Effective? | A303656 relevance verdict |
|---|---|---:|---|---:|---:|---|
| Artyom Radomskii, *Variants of Romanoff's theorem*, arXiv:2504.09954v6, 13 Jul 2026 | Theorem 1.1; Example 2; Corollary 1.1 | yes for the base sequence support | pair **upper** bound uniform in fixed `r` through `r/φ(r)` | allows a sequence `B`, but conclusion is positive-density many representations | constants existential | **Subsumes headline positive density; no concentration or universal coverage.** |
| Tristan Freiberg, Pär Kurlberg, Lior Rosenzweig, *Poisson distribution for gaps between sums of two squares and level spacings for toral point scatterers*, arXiv:1701.01157v1; CNTP 11 (2017) | Conjecture 2.1; fixed-`k` Selberg-sieve upper bound in §2.1; Proposition 1.3 on average singular series | yes for fixed tuple upper bounds | fixed finite tuple; singular-series averaging over geometric regions | no growing A303656 family theorem | upper bound effective in principle; central asymptotics conjectural | **Provides the indicator upper bound used in positive-density proof; not signed covariance. Conjecture open for `k≥4`.** |
| W. G. Nowak, *On the distribution of M-tuples of B-numbers*, arXiv:math/0410010v1, 1 Oct 2004; Publ. Inst. Math. 77 (2006) | unnumbered main Theorem in §2 | yes | fixed `M` arithmetic progressions; constants depend on `M` | no | upper bound | **General fixed-family upper bound only.** |
| Noam Kimmel, Vivian Kuperberg, *Positive density for consecutive runs of sums of two squares*, arXiv:2406.04174v2, 26 Mar 2025; JIMJ 24 (2025) | Theorem 1 | final conclusion uses standard sums-of-two-squares set, but proof explicitly replaces unavailable standard-indicator correlations by Hooley's `ρ` | fixed modulus and fixed run pattern | no | qualitative positive density | **Shows sophisticated sieve methods still avoid the missing indicator two-point correlation; does not produce coverage.** |
| Kaisa Matomäki, Maksym Radziwiłł, *Multiplicative functions in short intervals II*, arXiv:2007.04290v1, 8 Jul 2020 | Corollaries 1.1, 1.2; norm-form applications in §1.3 and Theorems 1.4/1.5 | yes | almost all moving intervals, normalized interval length | not the structured difference family | quantitative exceptional-set bounds; some constants implicit | **Strong almost-all local-distribution result, but different averaging variable and still permits infinitely many exceptional intervals.** |
| Fernando Chamizo, *The additive problem for the number of representations as a sum of two squares*, arXiv:2009.01667v1, 3 Sep 2020 | Theorem 1.1; Corollaries 1.3 and 1.6 | **no**, uses `r(n)r(n+m)` | growing `m`, with unconditional range including `m=O(x^η)`, `η<64/39` | a single growing shift, not structured weighted indicator family | yes in stated asymptotic ranges | **Wrong observable: representation weights cannot replace indicator covariance.** |
| Siegfred Baluyot, Steven M. Gonek, *Fractional moments of L-functions and sums of two squares in short intervals*, Mathematika 71(4), 2025, DOI 10.1112/mtk.70047 | publisher abstract and metadata checked; exact theorem formula not used | indicator variance in moving intervals according to publisher abstract | moving intervals | no verified A303656 crosswalk | some results conditional on RH-type assumptions | **Potentially relevant background only; exact PDF was not obtained, so no theorem-level dependence in this decision.** |
| Olivier Ramaré, G. K. Viswanadham, *The trigonometric polynomial on sums of two squares, an additive problem and generalisation*, arXiv:2509.23260v1, 27 Sep 2025; Trans. AMS DOI 10.1090/tran/9598 | Theorem 1.6 and main exponential-sum bound | support of odd primitive two-square set | major/minor arc control for dense relative subsets | no: theorem is ternary with two positive-relative-density subsets | stated effectivity for part of exponential-sum range | **Transference is available in a dense ternary setting, not for `O((log X)^2)` lacunary shifts.** |
| Steve Fan, Andrew Lott, *The van der Corput property for sums of two squares*, arXiv:2606.29185v2, 12 Jul 2026 | Theorem 1.1; Corollary 1.2 | yes through Fourier weights/difference set | global difference-set statement | not for A303656 shift convolution | quantitative power saving | **If `A-A` avoids nonzero two-square differences then `|A|≪N^{7/8+ε}`. A303656 exceptions have no such difference-avoidance property.** |
| Roger Clement Crocker, *On the sum of two squares and two powers of k*, Colloq. Math. 112 (2008) | main proposition on p.236; Theorem 1 for `k=2` | yes, nonrepresentation | each fixed single base `k` | two powers of the same base, not mixed bases 3 and 5 | constructive/infinitude | **Does not decide A303656, but refutes the analogy that adding two lacunary powers should automatically eliminate all exceptions.** |

## 3. Gap and short-interval literature

| Source | Exact result used | Relevance |
|---|---|---|
| Antal Balog, Trevor D. Wooley, *Sums of Two Squares in Short Intervals*, Canad. J. Math. 52 (2000), 673–694, DOI 10.4153/CJM-2000-029-6 | infinitely many short intervals have substantially more and infinitely many have substantially fewer sums of two squares than the expected local mean | demonstrates deterministic local irregularity; warns against upgrading almost-all local laws to every interval |
| Peter Shiu, *On a result of Bambah and Chowla*, Integers 19 (2019) | for every `α>2√2`, every sufficiently large `n` has a sum of two squares in `[n,n+αn^{1/4})` | an upper bound on forward maximal gaps; does not force an exact hit among the nonuniform set `n-(3^c+5^d)` |
| A. B. Kalmynin, S. V. Konyagin, *Large gaps between sums of two squares*, arXiv:1906.09100v2, 26 Apr 2022 | `g(X)≥(390/449-o(1))log X` | confirms logarithmic-scale empty intervals exist; neither this lower bound nor the known `X^{1/4}` upper scale aligns with a deterministic lacunary-grid hitting theorem |

## 4. Universal-basis and finite-state screens

| Source | Exact result | Relevance |
|---|---|---|
| Artyom Radomskii, *On sums of two squares and a basis of order 2*, arXiv:2604.20653v4, 25 May 2026 | constructs long paired strings with primitive two-square avoidance properties while preserving a basis-of-order-2 relation | shows flexible additive-basis constructions and large local irregularities, but does not provide a local-to-global theorem for the fixed shift set `3^c+5^d` |
| Shuo Li, *The characteristic sequence of the integers that are the sum of two squares is not morphic*, arXiv:2404.08822v1, 12 Apr 2024 | Theorem 5: the two-square characteristic sequence is not morphic | rules out a simple morphic encoding of `S2`; does not prove that every conceivable finite-state reduction is impossible, but gives no support for semilinearity/automata route |

## 5. Route-level literature conclusions

### Indicator covariance

**No match found.** Fixed-tuple indicator upper bounds exist; moving-interval almost-all results exist; weighted shifted convolutions exist. The missing combination—signed, indicator-level, growing structured family, weighted average, sufficient little-`o` error—was not found.

### Exceptional-set elimination

**No match found.** No primary theorem found turns density zero into a finite exceptional set for this additive problem, nor supplies an effective descent or finite algebraic/progression classification.

### Local-to-global exponent selection

**No match found.** Multiplicative-order and CRT methods describe local orbit structure, but no theorem found synchronizes one pair `(c,d)` across all relevant prime-power obstructions for every target integer.

### Additive combinatorics/transference

**No match found.** The recent transference theorem is ternary and dense. The Fan–Lott difference-set theorem requires a property not inherited by the exceptional set. Neither gives pointwise positivity of `1_{S2}*1_D`.

### Gap route

**No match found.** Known maximal-gap results concern contiguous intervals. A303656 requires a deterministic intersection with a sparse, curved, nonuniform grid of translates. No theorem converts the former into the latter.

### Counterexample finite reduction

**No match found.** Nonautomatic/nonmorphic results do not create a finite verifier for existential counterexamples. No compactness, semilinearity, periodicity, or mixed-base covering theorem was found that bounds the least exception.

## 6. Recent-work verdict, 2024–2026

The 2024–2026 literature is active and mathematically nontrivial: Kimmel–Kuperberg prove positive-density run patterns; Ramaré–Viswanadham provide Fourier/transference results in a dense ternary setting; Radomskii supplies a general Romanoff-type theorem and basis constructions; Fan–Lott prove a new power-saving van der Corput property. These are genuine advances. None closes an A303656 theorem gap. Their main value here is diagnostic: they clarify that current tools achieve density, moving-average regularity, or difference-set consequences under hypotheses absent from this problem.
