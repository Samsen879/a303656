# NO ROUTE PROMOTED

## Decision

No candidate satisfies the promotion standard. The project decision is **PAUSE PROJECT**.

## Why Route A is not promoted

Route A is the mathematically strongest surviving target because `(COV-D)` is precise and would imply almost-all representability. It nevertheless fails promotion for three reasons:

1. no matching signed indicator-level theorem was found;
2. proving it would still leave the independent Gap 2 from density-zero exceptions to finitely many/no exceptions;
3. the main missing lemma is not a bounded Phase A derivation but a new correlation theorem at or beyond current literature.

It is retained only as a secondary literature watch.

## Why no counterexample route is promoted

A candidate can be certified, but candidate existence has not been reduced to a finite domain. The exact bounded computations are therefore archival evidence, not a strategic complete search. More primes, moduli, solver time, or intervals do not repair this logical defect.

## Why no local-to-global or transference route is promoted

The local-to-global proposal requires one exponent pair to satisfy all prime-power constraints at once; separate modular solutions do not CRT together in exponent space. Existing transference results either use dense summands or difference-avoidance assumptions not verified here. Neither route currently has a smaller missing lemma with a plausible Phase A gate.

## Why PAUSE rather than STOP ACTIVE RESEARCH

The field is active: 2025–2026 primary literature produced new Romanoff-type, Fourier/transference, and van der Corput results for sums of two squares. Those results do not solve the gap, but they make a low-cost external-theorem watch rational. Active internal campaigns have low expected value; archival preservation plus a watch is therefore more appropriate than a permanent closure.
