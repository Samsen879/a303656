# HISTORICAL SYNTHESIS

## Accepted

1. **PROVED:** direct dyadic positive-density theorem, including the distinct-shift variant.
2. **PROVED:** the structural shift-domain, collision, multiplicity, energy, and singular-factor lemmas, with novelty not established for the latter two.
3. **VERIFIED FROM PRIMARY SOURCE:** Radomskii v6 substantially subsumes the headline positive-density phenomenon.
4. **CERTIFIED FINITE COMPUTATION:** `p^2` baseline facts `527 / 598 / 135`.
5. **CERTIFIED FINITE COMPUTATION:** bounded search facts `1.6B` consecutive and `1.853B` distinct, no candidate.
6. **CERTIFIED FINITE COMPUTATION:** fixed-P4 landscape `32 / 201 / 468 / 21 / 5 / t3=2`.
7. **VERIFIED INDEPENDENT AUDIT:** Gate V2 is closed/failed and new `T(n)` is not authorized.

## Rejected or deprecated

- Universal inference from finite verification.
- Almost-all inference from a bounded second-moment ratio.
- Replacement of signed indicator covariance by an upper pair bound, additive energy, or an `r_2`-weighted convolution.
- Random-CRT `L^2` evidence as control of an adversarial optimized tuple.
- `registry_v2` and the claim that 384/384 historical non-reuse is established.
- Reopening Gate V2, executing Design A, or creating Gate V3.
- Treating the P4 audit derivative as exact original legacy bytes.
- Treating the old positive-density hash as final authority.

## Frozen

- Positive-density route: correct, independent alternative proof, substantially subsumed, `FREEZE AND STOP`.
- Bounded-order `p^2` route: retain baseline, do not expand `B=5000`.
- Fixed-P4 landscape: retain exact finite result, do not escalate to P5/P6 or a new census.
- Counterexample scanning: retain authority record, no enlargement without finite-reduction theorem.

## Stopped

- Standard analytic bad-prime second-moment/additive-energy route.
- Larger periodic tori and random-CRT moment expansion.
- Broad bad-prime mask searches and 598-prime optimization.
- Active almost-all covariance campaign without a new theorem.

## Unresolved

- Almost-all representation.
- All sufficiently large integers.
- Universal representation for all `n>1`.
- Existence of a certified counterexample.
- Existence or nonexistence of an unrestricted finite `p^2` cover.
- Any finite reduction of counterexample existence.
