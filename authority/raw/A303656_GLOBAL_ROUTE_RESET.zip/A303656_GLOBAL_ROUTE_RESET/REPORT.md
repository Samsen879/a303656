# A303656 GLOBAL ROUTE RESET — FULL REPORT

## 0. Mandate and final decision

This review takes the role of mathematical research supervisor, independent additive number theorist, global route-selection referee, adversarial proof auditor, stop/go authority, and computational research-governance reviewer.

**FINAL DECISION: PAUSE PROJECT.**

No route is promoted. The global problem remains **OEIS A303656: UNRESOLVED**. The conclusion is not a judgment that the conjecture is false, true, or permanently inaccessible. It is the narrower and actionable judgment that, after the accepted closures and freezes, no current route has enough theorem-level leverage to justify another active execution round.

The project should preserve all authority packages and maintain only a low-cost primary-source literature watch. No Codex, Ultra, new `T(n)` computation, prime expansion, mask optimization, or counterexample interval expansion is authorized.

---

## 1. Input authority audit

Six canonical authority ZIPs were expected, and all six were received. There were seven ZIP upload instances because the repaired positive-density package appeared twice with identical bytes and hash `aa0392a5…`; every expected SHA256 matched exactly and every ZIP passed integrity testing; the old superseded hash was absent. All internal SHA manifests passed. The positive-density package's frozen-core verifier, nested archive checks, and symbolic constant check also passed.

The authority hierarchy is therefore stable:

- repaired positive-density package: final mathematical authority;
- `p^2` and bounded packages: certified finite-computation authorities;
- Gate V2 and fixed-P4 packages: independent audits;
- analytic bad-prime package: route analysis supporting a STOP conclusion;
- P4 exact legacy bytes: missing, while the finite mathematical result is independently reproduced and accepted.

This distinction matters. Missing exact legacy bytes do not erase independently certified mathematics. Conversely, a content-equivalent audit derivative is not the original archive and is not described as one.

---

## 2. Accepted mathematical and finite facts

### 2.1 Positive density

The direct dyadic theorem is accepted. For all sufficiently large `X`, a positive proportion of `n∈[X,2X]` have at least a constant times `(log X)^{3/2}` exponent-pair representations; the distinct-shift version is also proved. The proof uses the curved shift-domain count, finite nontrivial collisions, bounded multiplicity, Sidon-scale additive energy, first moment, indicator-level pair upper bounds, a structured singular-factor average, second moment, and Paley–Zygmund.

The direct proof is an independent alternative proof, but Radomskii's arXiv:2504.09954v6 substantially subsumes the headline positive-density phenomenon. The route is correctly frozen. Optimizing constants or repackaging the result would not reduce the universal theorem gap.

### 2.2 `p^2` finite-cover baseline

The exact bounded-order authority enumerates 527 eligible primes with `max(ord_p(3),ord_p(5))≤5000`. Their exact capacity sum is below one, so all 527 cannot cover. The verified cardinality lower bound is 598, and any possible cover must contain at least 135 primes with max order exceeding 5000.

These are strong necessary conditions. They do not prove that an unrestricted finite cover is impossible. They do prove that the natural bounded-order route has already crossed into a regime where larger enumeration would be expensive and strategically ungrounded.

### 2.3 Bounded verification

The consecutive interval `[240000000001,241600000000]`, containing 1.6B integers, has no candidate. Aggregated independent historical implementations cover at least 1.853B distinct integers with no candidate. These facts are certified finite computation only. They do not estimate the truth of the universal conjecture.

### 2.4 Fixed-P4 landscape

For `P4={3,7,11,23}`, the exact finite landscape has `H8,min=32`, `H8,max=201`, 468 maximizers, lex-first maximizer `(2,13,50,5)`, 21 distinct full masks, five live projections, and every maximizer has `t3=2`. Independent Python and C++ enumerations agree bin-by-bin and mask-by-mask.

This is a modular finite landscape. It neither authorizes a new census nor proves any integer theorem.

### 2.5 Gate V2 and analytic bad-prime closures

Gate V2 is closed/failed. New `T(n)` is not authorized, `registry_v2` is rejected, 384/384 historical non-reuse is not established, and Design A remains an archived Level 1 conditional candidate.

The standard bad-prime route is stopped. Random-CRT second moments describe a random residue tuple, whereas a perfect cover is an adversarial `L^∞` optimization. Uncentered additive energy, full-periodic first-moment criteria, and fixed-family anti-cover inequalities do not bridge this quantifier gap for growing prime families.

---

## 3. The logical theorem ladder

The project must not merge four distinct claims:

1. positive density;
2. almost all;
3. all sufficiently large;
4. all `n>1`.

The current proof establishes only the first.

### 3.1 Gap 1: concentration

The exact variance identity expands into the weighted signed covariance sum in `(3.1)` of `THEOREM_GAP_MAP.md`. A sufficient theorem is `(COV-D)`, requiring a little-`o` bound of order `XW_X^2/log X`.

No current input proves it. The decisive issue is sign. An upper bound on pair correlations can control the second moment up to a constant factor and produce positive density. It cannot show the variance is little-`o` of the squared mean. Additive energy organizes repeated differences but does not force positive and negative covariance errors to cancel. `r_2`-weighted correlations do not control the support indicator because representation weights are highly nonuniform.

The recent Kimmel–Kuperberg paper is especially diagnostic: it explicitly says estimates for two-point correlations of the standard sums-of-two-squares indicator are not known and substitutes Hooley's `ρ`-function. Matomäki–Radziwiłł prove strong almost-all short-interval regularity, but their averaging is over interval locations and still admits exceptional locations. Chamizo permits growing shifts in a weighted theta-coefficient convolution, but the observable is wrong for support covariance.

Thus Gap 1 is conceptual and structural, not a constants problem.

### 3.2 Gap 2: exceptional-set elimination

Even if `(COV-D)` were proved, an exceptional set of density zero could remain infinite. A universal program needs an independent theorem such as effective descent `(DESC)` or finite structural elimination `(STRUCT)`.

No artifact or paper supplies such a mechanism. Local prime-factor restrictions are not inherited in a way that creates descent. A covariance theorem counts exceptions; it does not classify them. This is a second, logically independent hard gap.

### 3.3 Gap 3: finite tail

An explicit theorem `(EFF-LARGE)` would make the remaining finite verification routine. Without an explicit threshold, the current 1.853B verified set is not the finite tail of a proof.

### 3.4 Counterexample finite reduction

A fixed candidate is easy to place under complete certification. What is missing is `(FIN-RED)`: a computable upper bound for the least exception or an equivalent finite-state/modulus certificate. No such reduction was found. Therefore unlimited bounded search is not a strategic route.

---

## 4. Literature findings

### 4.1 Radomskii v6

Radomskii's Theorem 1.1 is a general Romanoff-type result. Under one-point density, pair upper bounds, regularity of the sparse summand sequence, and a small-prime collision condition, it proves that many integers have many representations. Example 2 supplies the primitive odd two-square set with density scale `sqrt(log x)`. This directly explains why the project's positive-density headline is substantially subsumed.

The theorem is not a concentration theorem. Its proof is designed for a Paley–Zygmund/second-moment lower-density conclusion. It does not show the uncovered proportion tends to zero.

### 4.2 FKR and Nowak

FKR formulate the full `k`-tuple asymptotic as a conjecture. They note the qualitative conjecture is open for `k≥4`; unconditional Selberg-sieve bounds give fixed-tuple indicator upper bounds. Nowak generalizes such upper bounds to fixed `M` arithmetic progressions and normal-field norm sets. Neither gives signed covariance or growing-family uniformity.

### 4.3 Short intervals and irregularity

Matomäki–Radziwiłł establish indicator-level asymptotics in almost all appropriately normalized short intervals and power-saving exceptional-set bounds. Balog–Wooley show infinitely many intervals with unexpectedly high and low counts. Together these results support a careful distinction: excellent moving-average laws can coexist with deterministic exceptional intervals.

### 4.4 Recent transference and additive combinatorics

Ramaré–Viswanadham prove an exponential-sum estimate and a ternary additive theorem where two summands are positive-relative-density subsets of the primitive two-square set. A303656 has a binary convolution with a shift set of only order `(log N)^2`, so the density and pseudorandomness hypotheses are absent.

Fan–Lott prove that a set whose nonzero differences avoid sums of two squares has size `O(N^{7/8+ε})`. This is a strong new theorem, but the A303656 exceptional set is not known to be difference-free in that sense. No implication from exception status to difference avoidance exists.

### 4.5 Crocker and the danger of lacunary analogies

Crocker proves that for every fixed base `k≥2`, infinitely many integers are not a sum of two squares and at most two powers of that same base. This does not cover the mixed bases `3` and `5`. It does invalidate a soft analogy that “two lacunary powers should be enough for complete coverage.” Mixed-base universality needs its own mechanism.

### 4.6 Gap bounds

Shiu's forward gap bound and Kalmynin–Konyagin's logarithmic lower gap construction concern contiguous intervals. The points `n-3^c-5^d` are a sparse curved set. Cardinality and spacing comparisons do not make one of those points land in `S2`.

### 4.7 Finite-state screen

Li proves the two-square characteristic sequence is not morphic. This does not formally rule out every finite-reduction model, but it removes a simple automatic/morphic route. No semilinearity or pumping theorem for the combined predicate was found.

---

## 5. Adversarial route elimination

### Route A

It has the best exact theorem target, but only reaches almost all and depends on a major unavailable signed indicator theorem. Retain as secondary watch, freeze active work.

### Route B

Effective exception descent would be decisive, but no invariant or first lemma exists. Stop rather than invite vague “study the exceptional set” work.

### Route C

A finite-reduction theorem would justify a complete search. No such theorem exists, and the route strongly overlaps closed modular work. Freeze.

### Route D

The required simultaneous exponent theorem is nearly the original conjecture in valuation language. Separate local solutions do not combine. Stop.

### Route E

Known transference machinery does not handle this sparse binary convolution pointwise. Stop.

### Route F

The proposed hitting theorem is equivalent to the original problem, while generic gap bounds add no bridge. Stop.

### Route G

Finite slices would be a stronger theorem than the original in one exponent coordinate. Current evidence reaches only density. Freeze.

### Route H

No distinct exact partial theorem meets the promotion standard.

### Route I

No finite-state structure is known and simple morphicity fails. Freeze.

---

## 6. STOP/GO authority decision

### Why not PROMOTE ONE NEW ROUTE

Promotion requires a precise target theorem, a credible missing lemma, evidence beyond analogy, a Phase A gate, and direct payoff. No route meets all conditions. Route A has a precise target and some related literature but no credible derivation and only partial payoff. All higher-leverage routes lack even a first mechanism.

### Why PAUSE rather than STOP ACTIVE RESEARCH

Internal active work should stop. However, the 2025–2026 literature shows rapid external development around two-square Fourier analysis, Romanoff-type theorems, transference, and difference sets. A quarterly literature watch has low cost and a nonzero chance of detecting a new bridge. This justifies pause rather than permanent closure.

### Next authorized action

No new execution round. Preserve the archives, the hashes, this theorem-gap map, and the route closures. On a future literature trigger, run a new web-only Phase A condition crosswalk before any code or repository work.

---

## 7. Final status

- Positive density: **PROVED; FROZEN; SUBSTANTIALLY SUBSUMED AT HEADLINE LEVEL**.
- Almost all: **NOT ESTABLISHED**.
- All sufficiently large: **UNKNOWN**.
- All `n>1`: **UNRESOLVED**.
- Certified counterexample: **NONE**.
- New route: **NONE PROMOTED**.
- Project decision: **PAUSE PROJECT**.

**OEIS A303656: UNRESOLVED.**
