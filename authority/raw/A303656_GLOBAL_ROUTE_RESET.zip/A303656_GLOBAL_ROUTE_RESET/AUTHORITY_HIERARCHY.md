# AUTHORITY HIERARCHY

The hierarchy below separates mathematical proof, certified finite computation, independent audit, supporting evidence, and unresolved strategic claims.

| Claim | Status | Source artifact | Evidence type | Limitations | Reusable? |
|---|---|---|---|---|---|
| Global A303656 statement for every `n>1` | **UNRESOLVED** | all packages | global status | no proof; no certified counterexample | yes, as governing status |
| Direct dyadic positive-density many-representation theorem | **PROVED** | repaired positive-density frozen package, SHA `aa0392…` | mathematical proof + formal package audit | positive density only | yes, frozen theorem |
| Distinct-shift positive-density version | **PROVED** | same | mathematical proof | still positive density only | yes |
| Curved shift-domain count, finite nontrivial collisions, bounded multiplicity | **PROVED** | same | mathematical proof | no claim of independent novelty | yes |
| Sidon-scale additive energy and structured singular-factor average | **PROVED; NOVELTY NOT ESTABLISHED** | same | mathematical proof | does not yield signed covariance | yes as lemmas, not novelty claims |
| Headline positive-density novelty | **SUBSTANTIALLY SUBSUMED BY RADOMSKII v6** | same + arXiv:2504.09954v6 | primary-source theorem crosswalk | Radomskii v6 is a preprint; direct dyadic proof remains independent | yes with correct classification |
| Almost-all representability | **NOT ESTABLISHED** | `ALMOST_ALL_BLOCKER.md` + literature audit | exact variance decomposition | missing signed indicator covariance | no theorem claim |
| All sufficiently large integers | **UNKNOWN** | theorem-gap review | strategic assessment | almost-all would not suffice | no |
| 527 eligible primes with `max(ord_p(3),ord_p(5))≤5000` | **CERTIFIED FINITE COMPUTATION** | `p^2` bundle, SHA `4dad…` | exact enumeration + verifier | bounded-order family only | yes |
| The 527 eligible primes cannot form a global finite `p^2` cover | **CERTIFIED FINITE COMPUTATION** | same | exact rational-capacity certificate | does not rule out high-order primes | yes |
| Any possible global finite `p^2` cover needs at least 598 primes | **CERTIFIED FINITE COMPUTATION** | same | exact rational-capacity verifier | necessary, not sufficient | yes |
| At least 135 primes in any such cover must have max order `>5000` | **CERTIFIED FINITE COMPUTATION** | same | exact verifier | does not prove nonexistence | yes |
| Existence/nonexistence of an unrestricted finite `p^2` cover | **UNRESOLVED** | same | — | no finite reduction | no |
| No candidate in `[240000000001,241600000000]` | **CERTIFIED FINITE COMPUTATION** | bounded bundle, SHA `f877…` | exact consecutive 1.6B computation + independent audit | finite interval only | yes as finite fact |
| At least 1.853B distinct historical integers checked, no candidate | **CERTIFIED FINITE COMPUTATION** | same | aggregated independent computation audit | finite only; no truth probability | yes as finite fact |
| Fixed `P4={3,7,11,23}` landscape: `H8` min/max `32/201`, 468 argmax | **CERTIFIED FINITE COMPUTATION** | P4 independent audit, SHA `cc917…` | independent complete Python/C++ enumeration | finite modular landscape only | yes |
| P4 lex-first `(2,13,50,5)`, 21 full masks, 5 projections, all max `t3=2` | **CERTIFIED FINITE COMPUTATION** | same | bin-by-bin and mask-by-mask agreement | not an integer theorem | yes |
| P4 package is exact original legacy archive | **NOT ESTABLISHED** | local inventory + P4 audit | provenance audit | original source bytes absent | no; describe only as audit derivative |
| Gate V2 | **CLOSED / FAIL** | Gate V2 audit, SHA `fedb…` | independent audit | registry and historical non-reuse defects | yes as closure |
| New `T(n)` authorization under Gate V2 | **NOT AUTHORIZED** | same | governance audit | none | yes as prohibition |
| Design A | **ARCHIVED LEVEL 1 CONDITIONAL CANDIDATE** | same | independent audit | not execution-authorized | no execution |
| `registry_v2` | **REJECTED** | same | semantic/provenance audit | 384/384 non-reuse not established | no |
| Standard analytic bad-prime second-moment/additive-energy route | **STOP** | analytic Phase A, SHA `9dd5…` | mathematical route audit + exact small experiments | `L^2` random tuple does not control optimized `L^∞` tuple | no active reuse |
| Random-CRT moments, larger periodic torus, broad mask optimization without a theorem bridge | **STOP / PROHIBITED** | analytic and governance records | route closure | repeats closed work | no |
| Certified counterexample | **NONE** | bounded authority | exact verifier status | no candidate and no finite reduction | no claim |

## Reuse rule

A finite result is reusable only at the finite scope certified by its package. A proof is reusable only with its stated hypotheses and conclusion. No density theorem, solver output, modular landscape, or absence of bounded counterexamples may be promoted to a universal statement.
