# SMALL EXPERIMENTS

所有 experiments 均为 deterministic、tiny、falsification-oriented。它们不搜索 low-\(T\) records，不作 conjectural extrapolation。

脚本：`scripts/small_experiments.py`  
输出：`results/small_experiments.json`

## Experiment A — actual-mask Helly failure

- Target：bounded Helly / pairwise intersection inference。
- Input：pairs \((0,0),\ldots,(5,0)\)，shifts `2,4,10,28,82,244`。
- Private primes：`7,11,19,23,31,43`。
- Deterministic n：`1439416843471413`。
- Result：每个 good mask删去恰一个 point；所有 5-mask intersections非空，6-mask intersection为空。
- Limitation：finite selected sample；不是 A303656 counterexample。

## Experiment A2 — fixed-order moment indistinguishability

- Target：任意 proper-order joint statistics决定 global intersection。
- Group：\(\mathbf F_2^6\)，7 affine masks。
- Checked：126 proper subfamilies；maximum count discrepancy 0。
- Result：plus system有 all-good point 0；minus system无 all-good point。
- Limitation：abstract affine masks，不声称每个 pattern由 exponent masks实现。

## Experiment B — density versus cover

- Box：\(0\le c,d<8\)，64 points。
- Primes：3,7,11；exact valuation one modulo \(p^2\)。
- Common n modulus：53,361。
- Result：minimum uncovered 27，maximum 57，mean 40.0724；没有 residue给 complete cover。各 prime local density range依赖 n residue，例如 p=11从0到0.15625。
- Limitation：tiny box、三 primes、valuation-one truncation。

## Experiment C — LLL applicability

- Primes：7,11,19,23。
- Dependency rule：c- or d-periods share nontrivial factor。
- Actual maximum degree：2。
- Symmetric criterion：`1.1649779264824478 > 1`，失败。
- Asymmetric criterion：即使用 complete graph仍成功；log margin `0.22087392071906908`，minimum slack `0.01074635560157182`。
- Limitation：finite/truncated abstract torus；无 tail或active bound。

## Experiment D — active representative failure

- Primes：7,11。
- Global periods：C=210, D=2310。
- Selected good state：\((209,2309)\)。
- Least shift：1614 decimal digits。
- n：1,000,000。
- Result：locally good but inactive；其它 representatives更大。

## Experiment E — small/large incidence sanity

对 n=1000,12345,50000 与 z=19记录 small-prime survivors、large witnesses、private/shared edges。private与shared均实际出现；例如 n=50000 中 29 private large-prime edges、2 shared edges。

- Limitation：三 fixed n，只作 incidence sanity check。

## Experiment E2 — constructed private large tail

- z=19，m=5，alignment step L=90。
- pairs：\((2,0),(92,0),(182,0),(272,0),(362,0)\)。
- private witnesses：23,43,47,59,67。
- Result：全部 pairs对 3,7,11,19 good；每个有 distinct private exact-one q>19；全部 active。
- Limitation：constructed subset，不是 full survivor set。

## Experiment F — profinite compactness

verified finite-stage least reps \(k!-1\) for k=1,...,8 严格发散；full condition无 ordinary nonnegative integer。

## Experiment G — collision incidence

- n=10000，53 distinct shifts。
- shared pair mass LHS：172。
- shift divisor capacity RHS：1390。
- degree-one private edges：20；reused edges：40。
- Result：general inequality crosscheck PASS；private edges不受 LHS控制。

## Replay and hashes

- `scripts/small_experiments.py` SHA256: `0c3b0d20ccef707e8fbbb241bbc89a3e4977c4465e5038b81984b25c615a9f85`
- `results/small_experiments.json` SHA256: `760520e60d48c49b7b5e29f51eb8061da1ef21c963af10019c5c89b3d9658fd3`
- replay output byte comparison: PASS。

完整 machine-readable records 在 JSON 中。
