#!/usr/bin/env python3
"""Deterministic, falsification-oriented exact experiments for A303656 Phase A.

This script deliberately uses only tiny prime sets and small tori.  It does not
search for low-T records, counterexamples, or large covering systems.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
from sympy import factorint, ilcm, nextprime, n_order
from sympy.ntheory.modular import crt

SCHEMA = "a303656-simultaneous-selection-small-experiments-v1"


def valuation(m: int, p: int) -> int:
    """Return v_p(m), with a sentinel for m=0 (which is never used as bad)."""
    if m == 0:
        return 10**9
    m = abs(m)
    v = 0
    while m % p == 0:
        m //= p
        v += 1
    return v


def primes_3mod4_upto(z: int) -> List[int]:
    out = []
    for p in range(3, z + 1):
        if p % 4 != 3:
            continue
        if len(factorint(p)) == 1 and next(iter(factorint(p).values())) == 1:
            out.append(p)
    return out


def choose_private_prime(h: int, other_h: Sequence[int], used: set[int], lower: int, avoid_modulus: int = 1) -> int:
    q = int(nextprime(max(lower, 2)))
    while True:
        if q % 4 == 3 and q not in used and avoid_modulus % q != 0 and all((h - hj) % q != 0 for hj in other_h if hj != h):
            return q
        q = int(nextprime(q))


def experiment_a_helly(m: int = 6) -> Dict:
    """Construct an actual-mask Helly obstruction using exact valuation-one witnesses."""
    pairs = [(i, 0) for i in range(m)]
    shifts = [3**c + 5**d for c, d in pairs]
    if len(set(shifts)) != m:
        raise AssertionError("shifts are not distinct")
    used: set[int] = set()
    qs: List[int] = []
    for i, h in enumerate(shifts):
        q = choose_private_prime(h, shifts, used, lower=3 + i)
        used.add(q)
        qs.append(q)
    moduli = [q * q for q in qs]
    residues = [h + q for h, q in zip(shifts, qs)]
    n0, modulus = crt(moduli, residues, check=True)
    n0 = int(n0)
    modulus = int(modulus)
    # Take a positive representative above all shifts.
    if n0 <= max(shifts):
        n0 += ((max(shifts) - n0) // modulus + 1) * modulus

    singleton_bad = []
    for i, q in enumerate(qs):
        bad_indices = [j for j, h in enumerate(shifts) if valuation(n0 - h, q) % 2 == 1]
        singleton_bad.append(bad_indices)
        if bad_indices != [i]:
            raise AssertionError((i, q, bad_indices))

    good_sets = [set(range(m)) - {i} for i in range(m)]
    proper_intersections = {}
    for omit in range(m):
        inter = set(range(m))
        for i, g in enumerate(good_sets):
            if i != omit:
                inter &= g
        proper_intersections[str(omit)] = sorted(inter)
    global_inter = set(range(m))
    for g in good_sets:
        global_inter &= g

    return {
        "falsification_target": "Any bounded-Helly inference from nonempty proper local intersections to a global common exponent pair.",
        "m": m,
        "pairs": pairs,
        "shifts": shifts,
        "private_primes": qs,
        "n": n0,
        "crt_modulus": modulus,
        "bad_indices_by_prime": singleton_bad,
        "m_minus_1_subfamily_intersections": proper_intersections,
        "global_good_intersection": sorted(global_inter),
        "deterministic_result": "Every (m-1)-subfamily of actual good masks intersects, but the global intersection is empty.",
        "limitation": "Finite selected sample only; this is a no-go for bounded Helly data, not an A303656 counterexample.",
    }


def experiment_a2_fixed_order_moments(m: int = 7) -> Dict:
    """Two affine-hyperplane systems with identical proper-subfamily data and opposite global survival."""
    dim = m - 1
    omega = list(range(1 << dim))

    def bits(x: int) -> List[int]:
        return [(x >> i) & 1 for i in range(dim)]

    def forms(x: int, shifted: bool) -> Tuple[int, ...]:
        b = bits(x)
        last = (sum(b) + (1 if shifted else 0)) & 1
        return tuple(b + [last])

    plus = [forms(x, False) for x in omega]
    minus = [forms(x, True) for x in omega]

    max_discrepancy = 0
    checked_subsets = 0
    # Compare full joint pattern distributions for every proper subset.
    for mask in range(1, (1 << m) - 1):
        idx = [i for i in range(m) if (mask >> i) & 1]
        cp = Counter(tuple(row[i] for i in idx) for row in plus)
        cm = Counter(tuple(row[i] for i in idx) for row in minus)
        keys = set(cp) | set(cm)
        discrepancy = max(abs(cp[k] - cm[k]) for k in keys)
        max_discrepancy = max(max_discrepancy, discrepancy)
        checked_subsets += 1

    plus_survivors = [x for x, row in zip(omega, plus) if all(v == 0 for v in row)]
    minus_survivors = [x for x, row in zip(omega, minus) if all(v == 0 for v in row)]
    if max_discrepancy != 0 or plus_survivors != [0] or minus_survivors:
        raise AssertionError((max_discrepancy, plus_survivors, minus_survivors))

    return {
        "falsification_target": "Any theorem using only moments/intersections of a fixed proper order to decide global avoidance.",
        "group": f"F_2^{dim}",
        "number_of_bad_masks": m,
        "proper_subfamilies_checked": checked_subsets,
        "maximum_count_discrepancy": max_discrepancy,
        "system_plus_all_good_points": plus_survivors,
        "system_minus_all_good_points": minus_survivors,
        "deterministic_result": "All proper-subfamily joint distributions are identical, yet one system has a common good point and the other has none.",
        "limitation": "Abstract affine masks, not a claim that every such pattern is realized by A303656 orbit masks.",
    }


def experiment_b_density_cover(box_side: int = 8) -> Dict:
    """Enumerate tiny exact-valuation-one masks on a fixed exponent box."""
    primes = [3, 7, 11]
    moduli = [p * p for p in primes]
    M = math.prod(moduli)
    pairs = [(c, d) for c in range(box_side) for d in range(box_side)]
    shifts = np.array([pow(3, c) + pow(5, d) for c, d in pairs], dtype=np.int64)
    uncovered_hist = Counter()
    min_uncovered = len(pairs) + 1
    max_uncovered = -1
    argmin = None
    total_uncovered = 0
    cover_count = 0
    for n in range(M):
        covered = np.zeros(len(pairs), dtype=bool)
        for p in primes:
            p2 = p * p
            rem = (n - shifts) % p2
            covered |= (rem % p == 0) & (rem != 0)
        u = int((~covered).sum())
        uncovered_hist[u] += 1
        total_uncovered += u
        if u < min_uncovered:
            min_uncovered = u
            argmin = n
        max_uncovered = max(max_uncovered, u)
        if u == 0:
            cover_count += 1

    n = int(argmin)
    masks: Dict[int, List[int]] = {}
    for p in primes:
        rem = (n - shifts) % (p * p)
        masks[p] = np.flatnonzero((rem % p == 0) & (rem != 0)).astype(int).tolist()
    intersections = {}
    for i, p in enumerate(primes):
        for q in primes[i + 1 :]:
            intersections[f"{p},{q}"] = len(set(masks[p]) & set(masks[q]))

    # Local density ranges over all residues at each p^2.
    local_ranges = {}
    for p in primes:
        p2 = p * p
        vals = []
        smod = shifts % p2
        for nloc in range(p2):
            rem = (nloc - smod) % p2
            vals.append(int(((rem % p == 0) & (rem != 0)).sum()))
        local_ranges[str(p)] = {
            "min_count": min(vals),
            "max_count": max(vals),
            "mean_count": sum(vals) / len(vals),
            "box_density_min": min(vals) / len(pairs),
            "box_density_max": max(vals) / len(pairs),
        }

    return {
        "falsification_target": "Marginal-density-only prediction of coverage for actual tiny odd-valuation masks.",
        "primes": primes,
        "modulus": M,
        "box": f"0<=c,d<{box_side}",
        "box_size": len(pairs),
        "truncation": "exact valuation one only, detected modulo p^2",
        "minimum_uncovered": min_uncovered,
        "argmin_n_mod_M": n,
        "maximum_uncovered": max_uncovered,
        "mean_uncovered": total_uncovered / M,
        "complete_cover_residue_count": cover_count,
        "uncovered_histogram": dict(sorted(uncovered_hist.items())),
        "mask_sizes_at_argmin": {str(p): len(masks[p]) for p in primes},
        "pair_intersections_at_argmin": intersections,
        "local_density_ranges": local_ranges,
        "deterministic_result": "The same local masks have residue-dependent densities and overlaps; the three-prime family does not cover this box.",
        "limitation": "Tiny box, three primes, and valuation-one truncation; no extrapolation to the full problem.",
    }


def complete_graph_asymmetric_lll_margin(probabilities: Sequence[float]) -> Tuple[float, float]:
    """Return max log feasibility margin for complete dependency graph.

    For a complete graph, asymmetric LLL feasibility is equivalent to existence
    of t in (0,1) with t^(m-1) >= prod_i(t+p_i).  The returned margin is the
    maximum logarithm of lhs/rhs over a deterministic dense grid.
    """
    ps = np.asarray(probabilities, dtype=float)
    ts = np.geomspace(1e-12, 1.0, 300000, endpoint=False)
    margins = (len(ps) - 1) * np.log(ts) - np.log(ts[:, None] + ps[None, :]).sum(axis=1)
    k = int(np.argmax(margins))
    return float(margins[k]), float(ts[k])


def experiment_c_lll() -> Dict:
    primes = [7, 11, 19, 23]
    rows = []
    periods = {}
    probabilities = []
    for p in primes:
        p2 = p * p
        C = int(n_order(3, p2))
        D = int(n_order(5, p2))
        periods[p] = (C, D)
        hist = np.zeros(p2, dtype=np.int64)
        for c in range(C):
            a = pow(3, c, p2)
            for d in range(D):
                hist[(a + pow(5, d, p2)) % p2] += 1
        bad_counts = np.zeros(p2, dtype=np.int64)
        for k in range(1, p):
            bad_counts += np.roll(hist, k * p)
        max_prob = float(bad_counts.max() / (C * D))
        min_prob = float(bad_counts.min() / (C * D))
        probabilities.append(max_prob)
        rows.append({
            "p": p,
            "C_ord_p2_3": C,
            "D_ord_p2_5": D,
            "min_exact_v1_probability": min_prob,
            "max_exact_v1_probability": max_prob,
        })

    adjacency = {}
    edges = 0
    for p in primes:
        nbrs = []
        Cp, Dp = periods[p]
        for q in primes:
            if p == q:
                continue
            Cq, Dq = periods[q]
            if math.gcd(Cp, Cq) > 1 or math.gcd(Dp, Dq) > 1:
                nbrs.append(q)
                if p < q:
                    edges += 1
        adjacency[str(p)] = nbrs
    delta = max(len(v) for v in adjacency.values())
    symmetric_lhs = math.e * max(probabilities) * (delta + 1)
    margin, t_at_max = complete_graph_asymmetric_lll_margin(probabilities)
    complete = edges == len(primes) * (len(primes) - 1) // 2
    x_witness = [p_i / (t_at_max + p_i) for p_i in probabilities]
    Q = math.prod(1.0 - x for x in x_witness)
    lll_slacks = [x_witness[i] * math.prod(1.0 - x_witness[j] for j in range(len(x_witness)) if j != i) - probabilities[i] for i in range(len(x_witness))]

    return {
        "falsification_target": "Naive application of symmetric/asymmetric LLL after declaring prime masks independent.",
        "primes": primes,
        "local_rows": rows,
        "dependency_rule": "Events adjacent if their c-periods or d-periods share a nontrivial factor.",
        "adjacency": adjacency,
        "complete_dependency_graph": complete,
        "maximum_degree": delta,
        "symmetric_LLL_e_p_DeltaPlus1": symmetric_lhs,
        "symmetric_LLL_condition_holds": symmetric_lhs <= 1.0,
        "complete_graph_asymmetric_log_margin": margin,
        "complete_graph_asymmetric_best_t_grid": t_at_max,
        "complete_graph_asymmetric_x_witness": x_witness,
        "complete_graph_asymmetric_min_slack": min(lll_slacks),
        "asymmetric_LLL_condition_holds_even_with_complete_graph": min(lll_slacks) >= -1e-12,
        "deterministic_result": "Prime events are not independent and the symmetric LLL test fails, but the asymmetric LLL criterion succeeds even after replacing the actual graph by a complete graph for this tiny valuation-one family.",
        "limitation": "This is local and truncated: it avoids only exact valuation one for four fixed primes on an abstract torus; it gives neither full odd-valuation avoidance, an active representative, nor a large-prime tail theorem.",
    }


def experiment_d_active_representative() -> Dict:
    primes = [7, 11]
    moduli = [p * p for p in primes]
    C = math.lcm(*(int(n_order(3, m)) for m in moduli))
    D = math.lcm(*(int(n_order(5, m)) for m in moduli))
    # Search near the top of the torus for a state good at n=0 modulo both p^2.
    selected = None
    for u in range(C - 1, max(-1, C - 80), -1):
        for v in range(D - 1, max(-1, D - 80), -1):
            ok = True
            for p in primes:
                val = valuation(-(pow(3, u) + pow(5, v)), p)
                if val % 2 == 1:
                    ok = False
                    break
            if ok:
                selected = (u, v)
                break
        if selected:
            break
    if selected is None:
        raise AssertionError("no high good state found")
    u, v = selected
    least_shift = 3**u + 5**v
    n_active = 10**6
    if least_shift <= n_active:
        raise AssertionError("selected state unexpectedly active")
    local_status = {}
    for p in primes:
        local_status[str(p)] = {
            "v_p(n_minus_shift)": valuation(-least_shift, p),
            "good": valuation(-least_shift, p) % 2 == 0,
        }
    return {
        "falsification_target": "Inference from existence of a good product-torus state to existence of an active ordinary representative.",
        "primes": primes,
        "global_c_period": C,
        "global_d_period": D,
        "selected_state": [u, v],
        "n": n_active,
        "least_representative_shift_decimal_digits": len(str(least_shift)),
        "least_representative_shift_sha256": hashlib.sha256(str(least_shift).encode()).hexdigest(),
        "local_status_at_n_congruent_0": local_status,
        "active_representative_exists": False,
        "deterministic_result": "The state is locally good, but its coordinatewise least representative already violates 3^c+5^d<=n; every other representative is larger.",
        "limitation": "A single illustrative state; the theorem in the report gives the exact general criterion.",
    }


def experiment_e_small_large_incidence() -> Dict:
    ns = [1000, 12345, 50000]
    z = 19
    small_primes = primes_3mod4_upto(z)
    cases = []
    for n in ns:
        pairs = []
        for c in range(int(math.log(n, 3)) + 2):
            for d in range(int(math.log(n, 5)) + 2):
                h = 3**c + 5**d
                if h <= n:
                    pairs.append((c, d, h, n - h))
        survivors = []
        for c, d, h, r in pairs:
            if r == 0:
                survivors.append((c, d, h, r, []))
                continue
            bad_small = any(valuation(r, p) % 2 == 1 for p in small_primes)
            if not bad_small:
                fac = factorint(r)
                large_bad = sorted(int(p) for p, e in fac.items() if p > z and p % 4 == 3 and e % 2 == 1)
                survivors.append((c, d, h, r, large_bad))
        degrees = Counter()
        for _, _, _, _, ps in survivors:
            for p in ps:
                degrees[p] += 1
        survivors_with_large = sum(bool(ps) for *_, ps in survivors)
        private_edges = sum(1 for *_, ps in survivors for p in ps if degrees[p] == 1)
        shared_edges = sum(1 for *_, ps in survivors for p in ps if degrees[p] > 1)
        cases.append({
            "n": n,
            "active_pair_count": len(pairs),
            "survivor_count_after_p_le_z": len(survivors),
            "survivors_with_large_bad_witness": survivors_with_large,
            "distinct_large_bad_primes": len(degrees),
            "private_large_prime_edges": private_edges,
            "shared_large_prime_edges": shared_edges,
            "maximum_large_prime_degree": max(degrees.values(), default=0),
        })
    return {
        "falsification_target": "Assumption that large bad witnesses in small-prime survivors must exhibit substantial reuse.",
        "z": z,
        "small_primes": small_primes,
        "cases": cases,
        "deterministic_result": "Private and shared large-prime edges both occur; reuse is not automatic even in tiny exact incidence checks.",
        "limitation": "Sanity checks at three fixed n only; no low-T search and no conjectural inference.",
    }


def experiment_e2_private_tail(z: int = 19, m: int = 5) -> Dict:
    """Construct orbit-aligned small-prime survivors, each with a private large witness."""
    small_primes = primes_3mod4_upto(z)
    unit_small = [p for p in small_primes if p not in (3, 5)]
    L = 1
    for p in unit_small:
        L = math.lcm(L, int(n_order(3, p)))
    c0 = 2
    d = 0
    pairs = [(c0 + i * L, d) for i in range(m)]
    shifts = [3**c + 5**d for c, d in pairs]
    M = math.prod(small_primes)
    # All h_i agree mod each unit small prime by construction; for p=3, c>=1 gives h_i=1 mod 3.
    residues = []
    for p in small_primes:
        hres = shifts[0] % p
        if any(h % p != hres for h in shifts):
            raise AssertionError((p, [h % p for h in shifts]))
        residues.append((hres + 1) % p)
    a, crt_M = crt(small_primes, residues, check=True)
    a, crt_M = int(a), int(crt_M)
    if crt_M != M:
        raise AssertionError((crt_M, M))

    used: set[int] = set()
    qs = []
    for i, h in enumerate(shifts):
        q = choose_private_prime(h, shifts, used, lower=z, avoid_modulus=M)
        used.add(q)
        qs.append(q)
    moduli = [M] + [q * q for q in qs]
    congruences = [a] + [h + q for h, q in zip(shifts, qs)]
    n, period = crt(moduli, congruences, check=True)
    n, period = int(n), int(period)
    if n <= max(shifts):
        n += ((max(shifts) - n) // period + 1) * period

    small_bad = {}
    private_bad = {}
    for i, h in enumerate(shifts):
        small_bad[str(i)] = [p for p in small_primes if valuation(n - h, p) % 2 == 1]
        private_bad[str(i)] = {
            "q": qs[i],
            "valuation": valuation(n - h, qs[i]),
            "divides_other_remainders": [j for j, hj in enumerate(shifts) if j != i and (n - hj) % qs[i] == 0],
        }
        if small_bad[str(i)] or private_bad[str(i)]["valuation"] != 1 or private_bad[str(i)]["divides_other_remainders"]:
            raise AssertionError((i, small_bad[str(i)], private_bad[str(i)]))

    return {
        "falsification_target": "A uniform TAIL theorem based only on survival of all p<=z and generic one-dimensional orbit alignment.",
        "z": z,
        "small_primes": small_primes,
        "alignment_step_L": L,
        "pairs": pairs,
        "shift_decimal_digits": [len(str(h)) for h in shifts],
        "small_bad_primes_by_point": small_bad,
        "private_large_witnesses": private_bad,
        "n_decimal_digits": len(str(n)),
        "n_sha256": hashlib.sha256(str(n).encode()).hexdigest(),
        "all_pairs_active": all(h <= n for h in shifts),
        "deterministic_result": "Every selected pair survives every bad prime <=z, yet each has a distinct private exact-valuation-one witness q>z.",
        "limitation": "The set is constructed, not the full survivor set S(n,z); the result blocks hypotheses that use only small-prime survival and this coarse orbit structure.",
    }


def experiment_f_profinite(kmax: int = 8) -> Dict:
    reps = []
    nested = []
    for k in range(1, kmax + 1):
        mod = math.factorial(k)
        rep = mod - 1
        reps.append(rep)
        nested.append({"k": k, "modulus": mod, "least_nonnegative_representative": rep})
    compatible = True
    for K in range(1, kmax + 1):
        x = math.factorial(K) - 1
        for k in range(1, K + 1):
            if x % math.factorial(k) != (math.factorial(k) - 1) % math.factorial(k):
                compatible = False
    return {
        "falsification_target": "Compactness claim that finite ordinary compatibility yields one ordinary nonnegative exponent.",
        "conditions": "C_k={x in Z_hat: x=-1 mod k!}",
        "finite_stage_representatives": nested,
        "finite_stage_compatibility_verified": compatible,
        "least_representatives_strictly_diverge": all(reps[i] < reps[i + 1] for i in range(len(reps) - 1)),
        "ordinary_nonnegative_integer_in_full_intersection": False,
        "profinite_limit": "-1 in Z_hat",
        "deterministic_result": "Every finite subfamily has ordinary representatives, but the full intersection contains no nonnegative integer.",
        "limitation": "Abstract profinite congruences; it pinpoints the logical gap rather than modeling every A303656 mask.",
    }


def experiment_g_collision_incidence() -> Dict:
    # Use one fixed modest n and all active pairs, solely to cross-check the exact inequality.
    n = 10000
    pairs = []
    for c in range(20):
        for d in range(12):
            h = 3**c + 5**d
            if h < n:
                pairs.append((c, d, h))
    # Distinct shifts only for the theorem; keep one representative per shift.
    by_h = {}
    for c, d, h in pairs:
        by_h.setdefault(h, (c, d, h))
    pairs = list(by_h.values())
    degrees = Counter()
    witness_points = defaultdict(list)
    for idx, (_, _, h) in enumerate(pairs):
        r = n - h
        for p, e in factorint(r).items():
            p = int(p)
            if p % 4 == 3 and int(e) % 2 == 1:
                degrees[p] += 1
                witness_points[p].append(idx)
    lhs = sum(math.comb(r, 2) for r in degrees.values())
    rhs = 0
    for i in range(len(pairs)):
        hi = pairs[i][2]
        for j in range(i + 1, len(pairs)):
            hj = pairs[j][2]
            rhs += sum(1 for p in factorint(abs(hi - hj)) if int(p) % 4 == 3)
    if lhs > rhs:
        raise AssertionError((lhs, rhs))
    degree_one_edges = sum(r for r in degrees.values() if r == 1)
    reused_edges = sum(r for r in degrees.values() if r > 1)
    return {
        "falsification_target": "Claim that shift-difference energy alone controls all witness edges.",
        "n": n,
        "distinct_shift_count": len(pairs),
        "shared_pair_mass_lhs": lhs,
        "shift_divisor_capacity_rhs": rhs,
        "inequality_verified": lhs <= rhs,
        "degree_one_private_edges": degree_one_edges,
        "reused_edges": reused_edges,
        "deterministic_result": "The collision inequality controls shared pairs, while degree-one witness edges remain outside its left-hand side.",
        "limitation": "One finite cross-check; the report supplies the general proof.",
    }


def run_all() -> Dict:
    experiments = {
        "A_actual_mask_helly": experiment_a_helly(),
        "A2_fixed_order_moment_indistinguishability": experiment_a2_fixed_order_moments(),
        "B_density_versus_cover": experiment_b_density_cover(),
        "C_LLL_applicability": experiment_c_lll(),
        "D_active_representative_failure": experiment_d_active_representative(),
        "E_small_large_incidence": experiment_e_small_large_incidence(),
        "E2_private_large_tail": experiment_e2_private_tail(),
        "F_profinite_compactness": experiment_f_profinite(),
        "G_collision_incidence": experiment_g_collision_incidence(),
    }
    return {
        "schema": SCHEMA,
        "purpose": "falsification and theorem-condition testing only",
        "python": sys.version,
        "platform": platform.platform(),
        "experiments": experiments,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = run_all()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"schema": data["schema"], "experiments": list(data["experiments"]), "output": str(args.output)}, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
