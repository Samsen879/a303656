#!/usr/bin/env python3
"""Build a deterministic ZIP from the phase root."""
from __future__ import annotations
import argparse, os, stat, zipfile
from pathlib import Path

FIXED=(2000,1,1,0,0,0)
EXCLUDE={'A303656_SIMULTANEOUS_SELECTION_PHASE_A.zip'}

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',required=True)
    ap.add_argument('--output',required=True)
    ns=ap.parse_args()
    root=Path(ns.root).resolve(); out=Path(ns.output).resolve()
    files=[p for p in root.rglob('*') if p.is_file() and p.name not in EXCLUDE and p.resolve()!=out]
    files.sort(key=lambda p:p.relative_to(root).as_posix())
    prefix=root.name
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:
            rel=p.relative_to(root).as_posix()
            zi=zipfile.ZipInfo(f'{prefix}/{rel}',date_time=FIXED)
            zi.compress_type=zipfile.ZIP_DEFLATED
            zi.create_system=3
            mode=0o755 if rel.startswith('scripts/') or os.access(p,os.X_OK) else 0o644
            zi.external_attr=(stat.S_IFREG|mode)<<16
            zi.flag_bits|=0x800
            z.writestr(zi,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return 0
if __name__=='__main__': raise SystemExit(main())
