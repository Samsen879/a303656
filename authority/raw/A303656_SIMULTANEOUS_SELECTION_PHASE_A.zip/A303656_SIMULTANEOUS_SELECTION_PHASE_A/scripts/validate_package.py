#!/usr/bin/env python3
"""Read-only package validator: required files, JSON, manifest, experiment replay."""
from __future__ import annotations
import argparse, csv, hashlib, json, subprocess, sys, tempfile
from pathlib import Path

REQUIRED=[
'EXECUTIVE_VERDICT.md','INPUT_AUDIT.md','LOCAL_ORBIT_FORMALISM.md',
'SIMULTANEOUS_SELECTION_CANDIDATES.md','SMALL_PRIME_SIEVE.md','LARGE_PRIME_TAIL.md',
'ACTIVE_BOX_AND_REPRESENTATIVES.md','COMPACTNESS_AND_PROFINITE_NO_GO.md',
'COVERAGE_INVERSE_THEOREMS.md','LITERATURE_AUDIT.md','NO_GO_RESULTS.md',
'SMALL_EXPERIMENTS.md','CANDIDATE_SCORECARD.csv','PROMOTION_VERDICT.json',
'NO_ROUTE_PROMOTED.md','REPORT.md','LIMITATIONS.md','SHA256SUMS.txt',
'PACKAGE_FILE_LIST.txt','ENVIRONMENT_RECORD.json','WEB_SOURCES_LOCK.json',
'scripts/small_experiments.py','results/small_experiments.json']

def sha(p:Path)->str:
 h=hashlib.sha256();
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def main()->int:
 ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ns=ap.parse_args()
 root=Path(ns.root); errors=[]
 for rel in REQUIRED:
  if not (root/rel).is_file(): errors.append(f'missing {rel}')
 for rel in ['PROMOTION_VERDICT.json','ENVIRONMENT_RECORD.json','WEB_SOURCES_LOCK.json','results/input_audit.json','results/small_experiments.json']:
  try: json.loads((root/rel).read_text(encoding='utf-8'))
  except Exception as e: errors.append(f'json {rel}: {e}')
 try:
  with (root/'CANDIDATE_SCORECARD.csv').open(encoding='utf-8',newline='') as f:
   rows=list(csv.DictReader(f))
  if not rows: errors.append('empty scorecard')
 except Exception as e: errors.append(f'csv: {e}')
 if (root/'SHA256SUMS.txt').is_file():
  for line in (root/'SHA256SUMS.txt').read_text().splitlines():
   if not line.strip(): continue
   digest,rel=line.split('  ',1)
   p=root/rel
   if not p.is_file() or sha(p)!=digest: errors.append(f'manifest {rel}')
 with tempfile.TemporaryDirectory() as td:
  out=Path(td)/'replay.json'
  cp=subprocess.run([sys.executable,str(root/'scripts/small_experiments.py'),'--output',str(out)],capture_output=True,text=True)
  if cp.returncode!=0: errors.append('experiment replay failed: '+cp.stderr)
  elif out.read_bytes()!=(root/'results/small_experiments.json').read_bytes(): errors.append('experiment replay mismatch')
 print('PASS' if not errors else 'FAIL')
 for e in errors: print(e)
 return 1 if errors else 0
if __name__=='__main__': raise SystemExit(main())
