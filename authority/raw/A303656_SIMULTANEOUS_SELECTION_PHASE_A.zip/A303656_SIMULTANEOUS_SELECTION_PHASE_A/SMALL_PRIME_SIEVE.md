# SMALL PRIME SIEVE

## 1. Frozen objective

对 \(z=z(n)\)，目标不是只证明 finite intersection 非空，而是构造一个 sufficiently large active survivor family

\[
S(n,z)=D_0(n)\cap\bigcap_{\substack{p\le z\\p\equiv3(4)}}G_p(n),
\]

并保留足够结构以处理 \(p>z\)。任何只输出一个 abstract torus state、一个 profinite point 或一个 inactive representative 的 theorem 均不够。

## 2. CRT audit

CRT 能拼接指定 congruence classes。当 allowed set 是 complement of a union of p-adic orbit shells 时，必须先选择每个 local coordinate；这些 choices 之间由 exponent period gcd/lcm 兼容。CRT 不说明某个 compatible choice 存在，也不控制 least representative。

**Verdict: CRT alone — FALSE as a selection theorem.**

## 3. Lovász Local Lemma / lopsided LLL

Moser–Tardos Theorem 1.1 使用真实 dependency graph：若 \(A_i\) 与 graph 之外 events independent，且存在 \(x_i\) 满足

\[
\Pr(A_i)\le x_i\prod_{j\in\Gamma(i)}(1-x_j),
\]

则 complements intersection positive。variable-model algorithm 还要求 events 由 mutually independent base variables 的 subsets 决定。

对 A303656 finite torus，可把 global periods 分解为 primary components；两个 prime masks 若依赖同一 component 就相邻。不同 obstruction primes 经常因 \(p-1\) order factors共享 2-adic 等 components，dependency graph 不稀疏。active curved box 的 uniform measure又不是 product measure。

Tiny test `[7,11,19,23]`：actual dependency maximum degree 2；symmetric test

\[
e\,p_{\max}(\Delta+1)=1.16497792648>1
\]

失败；asymmetric criterion 在 complete graph majorant 上仍有 positive margin `0.2208739207`。因此 LLL 不是 universally impossible，但当前只给 **finite, valuation-one, abstract-torus avoidance**。

**Verdict: LOCAL ONLY.**

## 4. Hypergraph transversals, Rödl nibble, entropy compression

把 local allowed residues视为 choices、bad masks视为 forbidden hyperedges时：

- Rödl nibble/near-perfect matching theory需要近似 uniform degrees与small codegrees；actual orbit masks的 degrees依赖 \(n\bmod p^e\)，periods非独立，且目标是完全避免 events 而非近似 matching；
- entropy compression通常是 constructive LLL 的编码版本，仍需要 bounded local dependencies与finite variable model；
- hypergraph transversal upper bounds提供 hitting set，而此处需要一个 vertex 不被任何 bad edge hit。

没有已验证 degree/codegree hypotheses，也没有 large-prime completion。

**Verdict: NOT ESTABLISHED / LOCAL ONLY.**

## 5. Combinatorial, Selberg and fundamental-lemma sieves

这些 sieves 控制 forms 被 small primes 整除的频率，通常产生 rough/almost-prime values。A303656 要求对每个 \(p\equiv3\pmod4\) 的 exponent parity 为 even；“不被 small prime 整除”不能决定 large-prime factorization，更不能决定 parity。Heath-Brown 的 sieve lectures 明确展示 parity phenomenon：standard sieve 无法区分 even 与 odd number of prime factors in the required way。

此外 sequence \(n-3^c-5^d\) 在一个 \(O((\log n)^2)\) curved exponent box 上，available sample 极小，而 sieve dimension 随 bad primes增长。没有 level of distribution theorem uniform in adversarial \(n\)。

**Verdict: PARITY-BARRIER FAILURE.**

## 6. Large sieve

需要估计 exponent points 对许多 residue classes 的 distribution，例如

\[
\sum_{q\le Q}\max_a
\left|\#\{(c,d)\in D_0(n):h(c,d)\equiv a\pmod q\}-\frac{|D_0(n)|}{q}\right|^2.
\]

multiplicative orders导致短周期、collisions 与 shared factors；active sample只有 polylog size。即使 average large-sieve bound 成立，也通常是 average-over-residues/average-over-moduli，不足以对 fixed adversarial \(n\) 与 exact odd layers给出 positive survivor。

**Verdict: NOT ESTABLISHED.**

## 7. Affine/orbit sieve

Salehi Golsefidy–Sarnak 的 affine sieve在 finitely generated affine-linear group orbit上对 polynomial values实施 Brun sieve，并在 Levi-semisimple Zariski closure 等 hypotheses下得到 saturation/almost-prime results。Hong–Kontorovich 等工作改进特定 thin Pythagorean orbits 的 exponent of distribution。

A303656 exponent map \((c,d)\mapsto3^c+5^d\) 不是该框架中的 polynomial on a growing group orbit；target 也不是 bounded number of prime factors，而是 all \(3\bmod4\) valuations even。即使获得 almost-prime remainder，仍可能有一个 bad prime valuation one。

**Verdict: PARITY-BARRIER FAILURE / object mismatch.**

## 8. Covering-system and finite-group anti-cover theorems

Hough、Balister et al. 处理 single arithmetic progressions with distinct moduli；Lettl–Sun 与 Szegedy 处理 cosets/subgroups。A303656的 divisibility mask是 multiplicative-subgroup sum fiber，odd mask是多个 p-adic shells的 union/difference。把它拆成 single residue classes可能产生大量 repeated/dependent moduli，违反 distinctness 或 weighted-size hypotheses；并且 theorem conclusion在 ambient torus，未解决 active representative。

**Verdict: direct application FALSE.**

## 9. Additive-combinatorial transference

transference 通常需要一个 pseudorandom majorant、positive relative density 与 linear-forms condition。这里 survivor set 的 ambient exponent box只有 \(O((\log n)^2)\) points，local masks随 \(n\) 变动，且 final two-square predicate是 multiplicative parity condition。没有可验证 majorant 或 dense model。

Fan–Lott 的 sums-of-two-squares difference theorem控制 large subsets avoiding S2 differences；它不选择 \((c,d)\) 使一个 translated remainder落入 S2。

**Verdict: NOT ESTABLISHED.**

## 10. Quantitative outcome

本轮没有证明 S1a。tiny exact computations显示 local densities与 overlaps强烈依赖 \(n\bmod M\)，但没有 complete tiny cover；这既不证明 asymptotic survival，也不否定可能的 structured theorem。

任何下一步 small-prime theorem 至少必须同时给出：

1. deterministic lower bound uniform in \(n\)；
2. actual active-box representatives，而非 uniform torus points；
3. preserved regularity sufficient to bound private large witnesses；
4. explicit \(z(n)\) compatible with sample size \(O((\log n)^2)\)。

当前没有 primary-source theorem满足这四点。
