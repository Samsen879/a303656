# A303656 SIMULTANEOUS EXPONENT-SELECTION — PHASE A

本包记录 OEIS A303656 的一次受控 theorem-discovery 轮次。研究目标不是重新运行 finite cover、bad-prime moment 或 CRW 搜索，而是审计：能否从各 prime 的 actual multiplicative-orbit valuation masks 中直接选择同一个 ordinary exponent pair \((c,d)\)，并同时满足

\[
3^c+5^d\le n,
\qquad
v_p(n-3^c-5^d)\text{ 为偶数，对每个 }p\equiv3\pmod4.
\]

## 最终结论

**NO PROMOTABLE ROUTE — RETAIN AS SPECULATIVE WATCH.**

本轮没有建立 common ordinary exponent pair、all-prime completion、large-prime tail 或 uniform active-box representative。因而不满足 promotion gates。保留的唯一正向 watch candidate 是一个严格的 hybrid incidence criterion：如果 small-prime survivor family 的 private large-prime mass 与 shift-difference divisor capacity 之和严格小于 survivor 数，则得到一个 all-prime good pair。该 criterion 已证明，但所需的 uniform private-point suppression 未证明。

本轮同时得到四类可复用 exact no-go / structural results：

1. actual exact-valuation-one masks 可实现任意大的 Helly obstruction；
2. 任意 fixed-order intersection/moment data 即使对 affine hyperplane masks 也不能决定 global intersection；
3. finite-stage compatibility 的 compactness 极限可只是 profinite exponent，而非普通非负整数；
4. small-prime survivors 可被 arbitrarily large private primes 逐点赋予 odd witness，因此不能仅凭 small-prime survival 推出 TAIL。

## 导航

- `EXECUTIVE_VERDICT.md`：两页以内的 promotion verdict。
- `REPORT.md`：完整 synthesis、theorems、proofs 与 gate audit。
- `LOCAL_ORBIT_FORMALISM.md`：prime-power exponent orbits、valuation layers、compatibility maps。
- `SIMULTANEOUS_SELECTION_CANDIDATES.md`：S1–S6 candidate 审计。
- `LARGE_PRIME_TAIL.md`：private witnesses、collision inequality、parity barrier。
- `ACTIVE_BOX_AND_REPRESENTATIVES.md`：torus state 到 active ordinary pair 的 exact criterion。
- `COMPACTNESS_AND_PROFINITE_NO_GO.md`：inverse-limit no-go。
- `LITERATURE_AUDIT.md`：primary-source theorem crosswalk。
- `NO_GO_RESULTS.md`：严格终止的错误推理与适用范围。
- `scripts/small_experiments.py`：独立 deterministic falsification experiments。
- `results/small_experiments.json`：deterministic outputs。

## 重放

```bash
python3 scripts/small_experiments.py --output /tmp/small_experiments.json
cmp /tmp/small_experiments.json results/small_experiments.json
python3 scripts/validate_package.py --root .
```

计算只用于 falsification、small exact crosscheck 和 theorem-condition testing；没有执行 low-\(T\) search、large prime enumeration、large torus search 或 598-prime optimization。

OEIS A303656: **UNRESOLVED**.
