# ACTIVE BOX AND REPRESENTATIVES

## 1. Pure periodic state criterion

固定 positive periods \(C,D\)。对 state

\[
\sigma=(u\bmod C,v\bmod D)
\]

令 \(u_0\in[0,C-1]\)、\(v_0\in[0,D-1]\) 为 least nonnegative representatives。

### Theorem A1

\(\sigma\) 有 ordinary active representative \((c,d)\) 满足

\[
3^c+5^d\le n
\]

当且仅当

\[
3^{u_0}+5^{v_0}\le n.
\]

### Proof

所有 nonnegative representatives 为 \((u_0+rC,v_0+sD)\)，\(r,s\ge0\)。两坐标增加都严格增加 shift，因此 coordinatewise least representative 唯一最小。∎

这说明 geometry-of-numbers 不产生额外自由：ambient congruence lattice虽有 infinitely many points，objective 是 separable exponential and monotone，最小点已显式。

## 2. Full-torus threshold

### Corollary A2

每个 state of \(\mathbf Z/C\times\mathbf Z/D\) 都有 active representative的充要条件是

\[
n\ge3^{C-1}+5^{D-1}.
\]

因此若 global periods来自越来越多 primes 的 lcm，而 \(C\) 或 \(D\gg\log n\)，full-torus existence与 active existence之间可以有指数级乃至超指数级 gap。

## 3. Occupied-state count

active exponents满足

\[
c\le\lfloor\log_3(n-1)\rfloor,
\qquad
d\le\lfloor\log_5(n-1)\rfloor.
\]

所以

\[
|D(n)|
\le
(\lfloor\log_3(n-1)\rfloor+1)
(\lfloor\log_5(n-1)\rfloor+1)
=O((\log n)^2).
\]

不论 abstract torus 多大，active box最多占据这么多 states。一个 positive *fraction* of a huge torus可以完全错过 active image。

## 4. p=3 tail combined with unit-prime periods

假设 c-coordinate同时需满足 unit-prime congruence \(c\equiv r\pmod C\) 与 p=3 tail condition \(c\ge e\)。least feasible c 是

\[
c_0=e+((r-e)\bmod C).
\]

再结合 d-coordinate least representative \(d_0\)，active criterion仍为

\[
3^{c_0}+5^{d_0}\le n.
\]

因此 augmented p=3 state没有消除 representative issue；它只改变 least c 的计算。

## 5. Active-state versus local-good-state

finite product torus上的 good state只说明 residue compatibility。要把它用于 A303656，必须额外证明其 least representative位于 curved box。以下 implications 均不成立：

\[
\text{good local state}
\not\Rightarrow
\text{small representative},
\]

\[
\text{positive torus density}
\not\Rightarrow
\text{active representative},
\]

\[
\text{finite-prime common state}
\not\Rightarrow
\text{same state remains active as primes grow}.
\]

Experiment D 使用 primes 7,11 得 global periods \(C=210,D=2310\)。state \((209,2309)\) 对选择的 local masks为 good，但 least shift有 1614 decimal digits；对 \(n=10^6\) 不 active，且所有其它 representatives更大。

## 6. Covering radius audit

传统 covering-radius / geometry-of-numbers theorem估计 Euclidean convex body何时碰到 lattice coset。这里 feasible set

\[
\{(c,d)\ge0:3^c+5^d\le n\}
\]

在 exponent coordinates 中确实是 convex-downward curved region，但每个 residue coset的最小 nonnegative point已给出 exact answer。没有 averaging over translations 的 theorem能对 adversarial selected state改进 A1。若允许在多个 good states中选择，则需要证明 good set与 active image相交；这正是 common-selection problem，而非 independent geometry lemma。

## 7. Quantitative obstruction to growing P

对 finite prime set \(P\)，设

\[
C_P=\operatorname{lcm}_{p\in P}\operatorname{ord}_{p^{e_p}}(3),
\qquad
D_P=\operatorname{lcm}_{p\in P}\operatorname{ord}_{p^{e_p}}(5).
\]

要由 full product torus anti-cover theorem自动得到 active pair，至少需

\[
C_P\le1+\log_3 n,
\qquad
D_P\le1+\log_5 n
\]

在最坏 state尺度上成立。随着 P 增长，这与一般 lcm growth不相容，除非 theorem同时选择 unusually small residue coordinates。known covering/LLL theorems不提供这种 bias toward origin。

## 8. Verdict

- Exact active criterion：**PROVED**。
- Abstract good state \(\Rightarrow\) active pair：**FALSE**。
- Geometry-of-numbers generic repair：**NO QUANTIFIER COMPRESSION**。
- Uniform active representative for S1–S4：**NOT ESTABLISHED**。
