# EXECUTIVE VERDICT

## FINAL VERDICT

\[
\boxed{\text{NO PROMOTABLE ROUTE — RETAIN AS SPECULATIVE WATCH}}
\]

项目状态维持：

```text
PROJECT: PAUSED
ACTIVE PROMOTED ROUTE: NONE
DESCENT / FINITE REDUCTION: NOT PROMOTED
CRW(Q,E): SPECULATIVE WATCH ONLY
A303656: UNRESOLVED
```

## Promotion-gate 结论

| Gate | 结果 | 核心原因 |
|---|---|---|
| Exact theorem | PARTIAL | 证明了 actual-mask no-go、profinite no-go、private-tail countermodel 与 hybrid collision criterion；没有 S1–S5 universal positive theorem。 |
| Common ordinary exponents | FAIL | 没有对任意 counterexample \(n\) 产生同一个 finite \((c,d)\)。 |
| All-prime completion | FAIL | small-prime avoidance 可以局部完成；uniform large-prime tail 不成立于现有 hypotheses。 |
| Non-circularity | PASS for retained lemma | hybrid incidence criterion 的 hypotheses 可独立陈述，但关键 private-point suppression 未证明。 |
| Nontrivial support | PARTIAL | collision/private decomposition 为 proved lemma；它没有压缩掉最困难的 degree-one witnesses。 |
| Active-box control | FAIL globally | 单一 torus state 的 active criterion 已精确证明，但没有 uniform theorem 保证 selected state 落入 active curved box。 |
| Closed-route separation | PASS | 本轮未扩大 p²-cover、未重做 random CRT/moments、未证明 CRW。 |
| Finite next phase | LIMITED | 仅可授权 bounded theorem-only audit；不授权大型计算。 |

## 最强 proved lemma

令 \(\mathcal A\) 为 finite active exponent pairs，并先合并相同 shift。对每个 \(p>z\), \(p\equiv3\pmod4\)，令

\[
r_p=\#\{(c,d)\in\mathcal A:v_p(n-3^c-5^d)\text{ odd}\}.
\]

定义

\[
R_z(\mathcal A)=\sum_{x<y}\omega_{>z,\,3(4)}(|h_x-h_y|),
\]

以及 \(\operatorname{Pvt}_z(\mathcal A,n)\) 为至少拥有一个 degree-one large-prime witness 的 vertices 数。则

\[
\sum_{p>z}\binom{r_p}{2}\le R_z(\mathcal A),
\]

且若所有 vertices 都被 large bad primes 覆盖，必有

\[
|\mathcal A|\le \operatorname{Pvt}_z(\mathcal A,n)+2R_z(\mathcal A).
\]

因此，只要

\[
\operatorname{Pvt}_z(\mathcal A,n)+2R_z(\mathcal A)<|\mathcal A|,
\]

就存在一个 survivor 避开全部 \(p>z\)。这是 exact S4/S5 hybrid criterion。它控制 shared witnesses，但 private-witness CRT 表明 degree-one mass 可以达到 \(|\mathcal A|\)，所以尚无 completion。

## 最强 no-go theorem

对任意 \(m\ge2\) 与任意 \(m\) 个 distinct active shifts，可选 distinct primes \(q_i\equiv3\pmod4\) 及 arbitrarily large \(n\)，使

\[
B_{q_i}(n)\cap X=\{h_i\}.
\]

故 \(G_{q_i}(n)\cap X=X\setminus\{h_i\}\)：每个 proper subfamily 的 good intersection 非空，而 global intersection 为空。该构造使用 actual exact-valuation-one masks，严格排除任何 bounded Helly、pairwise-intersection 或 fixed finite-subfamily criterion 作为 universal common-selection theorem。

## Retained speculative candidate

`S4-HYBRID-PRIVATE-DEFICIT`：先构造 structured small-prime survivor family \(\mathcal A=S(n,z)\)，再证明

\[
\operatorname{Pvt}_z(\mathcal A,n)+2R_z(\mathcal A)<|\mathcal A|.
\]

其中 collision 部分已完成；真正缺失的是 **uniform private-point suppression**。该缺失 lemma 需要利用 full survivor structure，而不能只使用 small-prime survival、marginal densities、pairwise moments 或 generic lacunarity。当前没有 primary-source theorem 提供它。

## Authority decision

- Common ordinary pair established: **NO**.
- All bad primes handled: **NO**.
- Large-prime tail solved: **NO**.
- Active representative solved uniformly: **NO**.
- 下一轮：仅授权 bounded theorem-only watch，目标是证伪或证明一个 frozen private-point suppression hypothesis；不得做 large enumeration。
- Codex authorized: **NO**.
- Codex Ultra authorized: **NO**.

OEIS A303656: **UNRESOLVED**.
