# INPUT AUDIT

## 1. 实际收到的输入

| 文件 | bytes | SHA256 | ZIP integrity | classification |
|---|---:|---|---|---|
| `A303656_GLOBAL_ROUTE_RESET(1)(1)(1).zip` | 47,597 | `b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13` | PASS | final authority input |
| `A303656_GLOBAL_ROUTE_RESET(3).zip` | 47,597 | `b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13` | PASS | byte-identical duplicate; not an independent authority |
| `A303656_DESCENT_FINITE_REDUCTION_PHASE_A(2)(1)(1).zip` | 62,529 | `bebf5f5735fb476bb8d1859f297203715e07bc4de94f56bbf880f6763936205d` | PASS | final authority input |
| `analytic_bad_prime_phaseA(1).zip` | 563,522 | `9dd538f5d47a4d2327159b619af7db752f241421caef926207e623be6a8b1ec2` | PASS | final closed-route authority input |
| `Pasted text(1).txt` | 24,606 | `e6906423cfceaf3bb7dd3af1575d9d04eca31c76060371bfda84f4d73a22307d` | n/a | controlling task specification |
| `分工规则.txt` | 4,366 | `94261338e1d2e0a348ff264e9a98322b647918eeca74b0932dcd90bac980b5f6` | n/a | execution-environment rule |
| `项目简介.txt` | 510 | `42903e1adb5731d195786538a1072aa5b54a5c2adbf7fe6b963226fa74a139ae` | n/a | project scope |

两份 Global Route Reset 的 bytes 完全相同。它们不构成两次 independent verification。

## 2. 未直接收到的预期 authority

预期 `a303656_p2cover_bundle.zip`，SHA256

```text
4dadb8ce07cd0ccf56575ef0882d6bb02284a02c61e05cd1424e070d83b22ff3
```

本轮 active container 中没有该 archive bytes，因此没有把它列为 current-run directly audited ZIP。先前 authenticated inventory 记录了一个 93,403-byte exact match、ZIP integrity PASS 与 internal `SHA256SUMS` PASS，并记录 527 / 598 / 135 结论；本轮将这些数字只作为 inherited authority statement，不声称重新读取或重放该 ZIP。

## 3. 主要入口文件

### Global Route Reset

`EXECUTIVE_VERDICT.md`, `HISTORICAL_SYNTHESIS.md`, `THEOREM_GAP_MAP.md`, `ROUTE_CANDIDATE_MATRIX.md`, `PROJECT_PAUSE_PROTOCOL.md`, `AUTHORITY_HIERARCHY.md`。

### Descent / finite reduction

`THEOREMS_AND_PROOFS.md`, `FINITE_CERTIFICATE_ANALYSIS.md`, `MINIMAL_COUNTEREXAMPLE_CONSTRAINTS.md`, `NO_GO_RESULTS.md`, `REPORT.md`。

### Analytic bad-prime Phase A

`REPORT.md`, `EXECUTIVE_VERDICT.md`, `candidate_theorems.md`, `random_crt_moments.md`, `local_additive_energy.md`, `route_comparison.md`。

所有三个 distinct ZIP payload 均通过 CRC/integrity test。内部 manifests 的 verification 结果保存在 `results/input_audit.json`。

## 4. Authority extraction

本轮采用以下 authority corrections：

1. complete finite state certificate 可实施 pointwise descent；
2. explicit `CRW(Q,E)` 若成立，则得到 explicit finite reduction；
3. `UBVC(Q,E) => CRW(Q,E)` 已证明；
4. `CRW` 在形式要求上少于 `UBVC`，但 strict logical non-equivalence **NOT ESTABLISHED**；
5. 没有 explicit fixed `(Q,E)` 满足 `CRW`；
6. 没有 uniform numerical witness-prime bound 或 valuation-depth bound；
7. designated private-witness CRT、fixed-modulus indistinguishability、non-semilinearity、finite affine anti-lifting 与 common-square no-go 均为可用 barriers；
8. random CRT、independent-mask first/second moment、uncentered energy 和 larger periodic torus route 均处于 closed state。

## 5. p²-cover inherited authority boundary

只继承以下 certified statements：bounded-order eligible primes 为 527；这 527 个 primes 不足以形成 global cover；任意 global finite p²-cover 若存在至少需要 598 primes；至少 135 个 primes 必须超出 order bound 5000。没有在本轮重新搜索、优化或扩大该 computation。

## 6. 安全与 provenance

- ZIP names 经检查无 absolute path、`..` traversal 或 symlink entry。
- 不信任文件名后缀；authority 由 exact hash 决定。
- duplicate archive 不增加 proof weight。
- missing p² archive bytes 被明确标为 unavailable，而不是由 prior inventory 静默替代。
- 本包没有 repository integration、Git state 或 WSL claim。
