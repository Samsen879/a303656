# REPORT — A303656 SIMULTANEOUS EXPONENT-SELECTION PHASE A

## 1. Research question and verdict

研究问题是：对 counterexample candidate n，能否从每个 local admissible exponent-orbit mask 中直接选择同一个 ordinary active pair \((c,d)\)，使

\[
n-3^c-5^d\in\mathcal S_2?
\]

等价地，是否可证明

\[
D(n)\cap\bigcap_{p\equiv3(4)}G_p(n)\ne\varnothing
\]

而不先固定 complete witness prime set。

本轮 verdict：

\[
\boxed{\text{NO PROMOTABLE ROUTE — RETAIN AS SPECULATIVE WATCH}}.
\]

没有建立 common ordinary pair、all-prime completion、large-prime tail或 uniform active representative。最强正向成果是一个 exact shared/private incidence completion criterion；最强负向成果是 actual-mask unbounded Helly obstruction。

## 2. Authority state and route separation

Global Route Reset规定项目 paused、无 active promoted route。上一轮 state-certificate theorem证明：若每个 canonical state有 bounded odd witness，可点wise descent；若 explicit `CRW(Q,E)` 成立，则得到 explicit finite reduction。`UBVC=>CRW`，但 strict logical non-equivalence未建立。没有任何 explicit `(Q,E)` 被证明满足 CRW。

本轮没有重新证明或搜索 CRW，也没有扩大 p²-cover。analytic bad-prime random CRT/moment/energy route保持 closed。所有 computation只作 falsification与 theorem-condition testing。

## 3. Exact orbit formalism

对 unit prime \(p\nmid15\)，depth e local torus为

\[
\Omega_{p,e}=\mathbf Z/\operatorname{ord}_{p^e}(3)
\times\mathbf Z/\operatorname{ord}_{p^e}(5),
\]

orbit map \(\phi(c,d)=3^c+5^d\bmod p^e\)。divisibility mask是 fiber \(\phi^{-1}(n)\)；exact valuation k是 depth-k fiber pullback减去 depth-(k+1) pullback；truncated odd mask是 odd exact layers union。full bad mask需要所有 odd depths。

local fiber density可精确写成 two multiplicative subgroups的 additive convolution：

\[
\delta_{p,e}(n)=rac{\#\{x\in\langle3\rangle,y\in\langle5\rangle:x+y=n\}}{
\operatorname{ord}_{p^e}(3)\operatorname{ord}_{p^e}(5)}.
\]

它依赖 n residue；只知 average \(1/p^e\) 与 pointwise upper bound \(1/\max(C,D)\)。这些不产生 independence。

p=3必须使用 stable-tail state \(\{0,\ldots,e-1,\tau_e\}\)，其中 \(\tau_e\)代表 c≥e。product object必须是 ordinary exponents的 diagonal image，而非 full independent product。

## 4. Local density and dependency audit

Experiment B对 8×8 exponent box、p=3,7,11 exact-one masks遍历 n modulo 53,361。uncovered count从27到57变化，p=11 local density可从0到0.15625。这验证：actual local density强烈依赖 n与box；marginal product heuristic没有 deterministic force。

在 finite torus中可以定义 LLL dependency graph：events若共享 global period的 primary components则 dependent。tiny four-prime instance不是 complete graph，symmetric LLL失败，asymmetric LLL成功。这说明 LLL不是逻辑上不可能，但只解决一个 fixed finite/truncated probability space；它不触及 full odd layers、p=3 active weighting、large primes或 representative。

## 5. Theorem: actual valuation masks have unbounded Helly obstruction

给定 distinct shifts \(h_1,\ldots,h_m\)，选择 distinct \(q_i\equiv3\pmod4\) 避开全部 differences。CRT解

\[
n\equiv h_i+q_i\pmod{q_i^2}.
\]

则 \(v_{q_i}(n-h_i)=1\)，而 \(v_{q_i}(n-h_j)=0\) for j≠i。因此在 finite sample X上，\(G_{q_i}=X\setminus\{h_i\}\)。每个 proper subfamily intersection有遗漏 index对应的 point，全 family intersection empty。n可加 total modulus倍数使 arbitrarily large、pairs active。

这不是 abstract set-system counterexample；它使用 actual A303656 exact valuation-one masks。故不存在 universal bounded Helly number，pairwise/local intersection data也不够。

## 6. Theorem: fixed-order moments are information-theoretically insufficient

在 \(\mathbf F_2^{m-1}\) 上，前 m−1 events由 coordinates定义，最后 event由 parity hyperplane或其 affine translate定义。所有 proper subfamilies对应 linearly independent affine forms，joint distributions完全一致；但一个 system有 all-zero common good point，另一个没有。因而任何只依赖 fixed-order moments/intersections的 theorem不能决定 global intersection，即使 masks是最规则的 affine hyperplanes。

actual-mask Helly theorem与 affine-moment theorem互补：前者证明 arithmetic masks自身破坏 bounded Helly；后者证明高对称 structured masks也不能由 low-order statistics决定。

## 7. Small-prime stage

S1a要求 uniform lower bound \(|S(n,z)|\ge(\log n)^\delta\)。known covering-system theorems不适用，因为 bad masks不是 cosets/single classes；standard sieve受 parity problem阻挡；affine sieve只给 almost primes；large sieve缺少 active-box level of distribution。没有 theorem保证 survivors。

即使 finite torus有 positive uncovered density，也可能所有 uncovered states的 least representatives超出 active box。full torus size由 lcm periods决定，active pairs仅 O((log n)^2)。

## 8. Active representative theorem

对 state \((u mod C,v mod D)\)，least reps \(u_0,v_0\) give minimum shift。active iff

\[
3^{u_0}+5^{v_0}\le n.
\]

所以 every-state active threshold恰为 \(3^{C-1}+5^{D-1}\)。这一 exact result终止“torus state自动可用”推理。Experiment D给 C=210,D=2310 的 good state，其 least shift有1614 digits而 n=10^6。

## 9. Compactness no-go

conditions \(x\equiv-1\pmod{k!}\) nested且每个 finite stage有 rep k!−1，但 full inverse limit为 profinite −1，无 ordinary nonnegative integer。finite-stage representative发散。A303656 finite prime compatibility若通过 inverse limit，只得到 residue-compatible profinite exponents；没有普通 powers 3^c,5^d与active bound。

fixed n时 active domain finite，FIP确实推出 global point，但这是 trivial：若 bad sets覆盖有限域，就有 finite subcover。prime set与depth可随 n增长，没有 quantifier compression。

## 10. Large-prime tail decomposition

对 large witness degree r_p，任意两点共享 p时 p整除 shift difference。因此

\[
\sum_p\binom{r_p}{2}\le
\sum_{x<y}\omega_{>z,3(4)}(|h_x-h_y|)=R_z.
\]

shared incidences ≤2R_z。若所有 survivors被 large primes覆盖，则除 private vertices外的所有 vertices必须由 shared incidences覆盖，故

\[
|A|\le\operatorname{Pvt}_z(A,n)+2R_z(A).
\]

这给 exact all-prime completion criterion TAIL-DEFICIT。

但 designated private-witness CRT允许每个 vertex拥有不同 exact-one prime。更强地，对任意 z,m，可选 aligned exponents使全部 shifts在每个 small bad prime modulo p相同，再选 n避开该 residue；随后用 q_i>z逐点赋予 private witnesses。故 small-prime survival本身不压低 Pvt。

## 11. Why p>sqrt(n) does not solve the tail

p>sqrt n时每个 positive remainder至多有一个这样的 prime且 valuation=1。这个 observation限制每个 vertex的 witness数量，却不限制 across vertices的 distinct primes；m survivors可拥有 m private primes。union bound最多给 |A|，不能得到 strict inequality。

## 12. Coverage inverse theorem

collision bound可改写为：若 R_z small而 coverage成立，则至少 |A|−2R_z vertices拥有 private large witness。它是一种 exact inverse structure：coverage被迫是 private，而非 high-degree core。然而 private结构本身没有 contradiction；CRT说明它可在任意 fixed n residue signature下 designatedly实现。

要推进，必须证明 **actual full survivor family** 的 private exact-one congruences因 n-size、orbit distribution或 witness alternatives而不能接近 saturated。当前没有这样的 theorem。

## 13. Literature synthesis

covering/coset theorems提供强 anti-cover/inverse bounds，但对象要求失败；LLL需要真实 product variables与finite family；affine sieve给 almost primes而非 valuation parity；sieve parity phenomenon正中核心；recent Romanoff/sums-of-two-squares结果给 positive density或 difference bounds，不给 every-n common exponent selection。没有 primary source同时处理 same ordinary pair、all primes、tail与active box。

## 14. Candidate decision

`S4-HYBRID-PRIVATE-DEFICIT` 是最强 candidate：completion theorem已证明，missing lemma明确为 private-point suppression。它形式上比直接证明 all bad sets不覆盖更结构化，因为 shared part已被 shift differences完全控制；但无法确认 missing lemma显著弱于原问题。

`S1`还需 survivor lower bound；`S2`对象不匹配；`S3`局部；`S5`只得 private fringe alternative。S6 no-go results是本轮主要 rigorous progress。

## 15. Promotion gates

- Gate 1 exact positive S1–S5: FAIL。
- Gate 2 common ordinary exponents: FAIL。
- Gate 3 all-prime completion: conditional only, universal FAIL。
- Gate 4 non-circularity: retained criterion PASS。
- Gate 5 support: proved incidence lemma，但 core open。
- Gate 6 active box: conditional family active，selection theorem absent。
- Gate 7 separation: PASS。
- Gate 8 finite next phase: only bounded theorem audit。

因此不 promote。

## 16. Next authorized action

只保留一个 bounded objective：冻结一个明确 survivor regularity hypothesis H，要求 H可独立验证且不等价于 T(n)>0，然后证明或构造 countermodel for

\[
H\Longrightarrow
\operatorname{Pvt}_z(S(n,z),n)+2R_z(S(n,z))<|S(n,z)|.
\]

优先 theorem falsification，不启动 enumeration。若 H仅由 local densities、fixed moments、pairwise intersections或 finite Helly data组成，本轮 no-go已足以拒绝。

Codex与Ultra均不授权。

## 17. Final status

本轮没有找到local-to-global theorem，但产生了可复用 precise no-go results与一个 exact shared/private decomposition。未 promotion不等于项目失败；它严格缩小了可行 theorem的必要信息量。

OEIS A303656: **UNRESOLVED**.
