# LITERATURE AUDIT

## Method

检索以 primary sources 与 exact versions 为优先。每个 theorem只按原文 hypotheses使用；“相关主题”不视为可应用。2024–2026 sources 若未导入其完整 theorem statement，只记录 screening verdict，不把 abstract 推广为结论。

## Exact theorem crosswalk

| Source | Exact version / theorem | Hypotheses | Conclusion | Effectivity | A303656 mismatch | Verdict |
|---|---|---|---|---|---|---|
| Bob Hough, *Solution of the minimum modulus problem for covering systems*, Ann. Math. 181 (2015) | Theorem 1 | finite distinct covering system of single congruence classes | least modulus \(\le10^{16}\) | explicit, with computation | A303656 masks不是 single classes；moduli/depths重复且依赖；不产生 exponent representative | no direct application |
| Balister–Bollobás–Morris–Sahasrabudhe–Tiba, *On the Erdős Covering Problem: the density of the uncovered set*, arXiv:1811.03547v1 / Invent. Math. | Theorem 1.1 | arithmetic progressions with distinct sufficiently large moduli; weighted sum \(C=\sum\mu(d_i)/d_i\) | uncovered density \(\ge e^{-4C}/2\) | effective in principle; threshold not used here | odd-valuation orbit masks are unions/differences of fibers, not one progression; no active box or tail | object mismatch |
| Günter Lettl–Zhi-Wei Sun, *On covers of abelian groups by cosets*, arXiv:math/0411144v2, Acta Arith. 131 (2008) | Theorem 1.3 | finite m-cover of abelian group by subgroup cosets; one coset irredundant | index bound \([G:G_t]\le2^{k-m}\), and \(k\ge m+f([G:G_t])\) | explicit combinatorial | A303656 masks not cosets; theorem is inverse bound on a cover, not an uncovered active state | local analogy only |
| Balázs Szegedy, *Coverings of abelian groups and vector spaces*, arXiv:math/0411244v1 | Theorem 5 / Corollary 6 | irredundant covers/all-but-one covers by cosets/subspaces | lower bounds governed by prime factors; \(k\ge1+\log_2\) index in stated corollary | explicit | mask geometry and active representative mismatch | local analogy only |
| Robin Moser–Gábor Tardos, *A constructive proof of the general Lovász Local Lemma*, arXiv:0903.0544v3 | Theorem 1.1 and variable-model Theorem 1.2 | finite events; genuine independence outside dependency graph; LLL x-criterion; independent base variables for algorithm | positive probability / constructive resampling | constructive finite model | no independent prime variables, active-box measure not product, no all-prime tail | LOCAL ONLY |
| D. R. Heath-Brown, *Lectures on sieves*, arXiv:math/0209360v1 | Section 5 parity phenomenon | standard combinatorial sieve data | exhibits inability to distinguish parity-type factorization patterns | conceptual barrier | target is exact parity of \(3\bmod4\) valuations | PARITY-BARRIER FAILURE |
| Salehi Golsefidy–Sarnak, *Affine Sieve*, arXiv:1109.6432v1 | main saturation theorem | orbit of affine linear group; Levi-semisimple Zariski closure; polynomial function | bounded saturation/almost-prime points | effective only with quantitative inputs | exponential two-parameter shift is not this polynomial orbit; almost-prime is not two-square parity | no direct application |
| Hong–Kontorovich, *Almost Prime Coordinates for Anisotropic and Thin Pythagorean Orbits*, arXiv:1401.4701v1 | main theorem(s) on exponent of distribution/saturation | specified Pythagorean thin orbits and polynomial coordinates | improved almost-prime saturation numbers | quantitative in that setting | wrong orbit and wrong parity target | no direct application |
| A. Rumyantsev, *Infinite computable version of Lovász Local Lemma*, arXiv:1012.0557 | computable infinite LLL theorem | countable finite-range independent variables, computable events, effective slack | computable infinite assignment | constructive | output is product assignment; residue inverse limit need not be ordinary exponent | profinite/ambient mismatch |

## Recent literature 2024–2026

### Artyom Radomskii, *Variants of Romanoff's theorem*, arXiv:2504.09954v6, 13 July 2026

Theorem 1.1 / Corollary 1.1 in the version-locked paper give positive-density/lower-bound results for sums \(a_i+b_j\) under counting and pair-correlation hypotheses, allowing repeated sequence terms. This supports positive-density results for two-square numbers plus \(3^c+5^d\), but it is cumulative/average and does not assert every \(n\), common local exponent selection, all-prime tail, or an active representative for adversarial \(n\).

**Verdict: relevant global density context; no simultaneous-selection trigger.**

### Steve Fan–Andrew Lott, *The van der Corput property for sums of two squares*, arXiv:2606.29185v2, 12 July 2026

Main theorem/abstract consequence: if \(A\subset[N]\) has no nonzero difference in the sums-of-two-squares set, then \(|A|\ll_\varepsilon N^{7/8+\varepsilon}\). This is a difference-set theorem in a dense interval, not a translated sparse exponent-box theorem. It gives no control of \(n-h(c,d)\) pointwise.

**Verdict: no direct trigger.**

### Francisco Araújo, *Sarnak's Program for Erdős Sieves. Part II*, arXiv:2602.24034v1

The paper constructs compact abelian rotation systems for sets avoiding specified congruence classes of ideals and studies sumsets/R-free values. Its ambient admissible sets are congruence sieves with measure-system hypotheses. A303656 masks depend nonlinearly on exponent orbits and exact valuation parity; the active ordinary representative issue remains.

**Verdict: conceptual compact-group relevance, but profinite/ordinary gap persists.**

### Noam Kimmel–Vivian Kuperberg, *Positive density for consecutive runs of sums of two squares*, arXiv:2406.04174v2; JIMJ 24 (2025)

Main theorem gives positive density of prescribed consecutive runs of sums of two squares in reduced classes modulo odd squarefree \(q\). It controls distribution within fixed congruence classes, not every translated sparse shift family and not all-prime exact parity for a chosen exponent pair.

**Verdict: no universal local-to-global selection theorem.**

### Ramaré–Viswanadham, 2025 preprint on trigonometric-polynomial/additive density methods

Screened for signed indicator correlations and additive transference. The available theorem concerns dense additive configurations/ternary representation, not multiplicative exponent orbit masks or active-box common selection. No theorem imported.

**Verdict: no direct trigger; theorem numbering not relied upon.**

## Tool-by-tool conclusion

1. **Simultaneous avoidance / coset covers:** exact theorems require cosets/classes; actual masks fail object hypothesis.
2. **Orbit sieve:** almost-prime saturation does not resolve valuation parity or translated adversarial n.
3. **LLL / lopsided LLL:** finite truncated torus can satisfy criteria, but dependency/product/active/tail gaps remain.
4. **Large-prime divisor literature:** provides results for specific recurrence terms or average greatest prime factors, not uniform private-witness suppression for \(n-3^c-5^d\) over all n.
5. **Local-global orbit principles:** known theorems often close orbits in profinite/topological spaces; no ordinary exponent bound follows.
6. **Recent sums-of-two-squares literature:** strengthens density/difference results, not universal pointwise selection.

## Literature verdict

No primary source located supplies an exact S1–S5 theorem with all of:

- same ordinary finite \((c,d)\);
- all \(p\equiv3\pmod4\) completion;
- large-prime private-witness control;
- active-box bound \(3^c+5^d\le n\);
- uniformity in adversarial \(n\).

因此 literature support 不足以 promote。

## Source URLs and locks

Machine-readable exact-version URLs、access date、claim scope 与 source IDs 保存在 `WEB_SOURCES_LOCK.json`。
