# COVERAGE INVERSE THEOREMS

## 1. Incidence graph

对 finite active family \(\mathcal A\)，left vertices 为 exponent pairs（重复 shift先合并），right vertices 为 \(p\equiv3\pmod4\)，edge条件为 odd valuation。counterexample condition等价于每个 left vertex degree至少 1。

需要从 coverage 推出比原命题更 restrictive 的 arithmetic conclusion，而不是“某 prime覆盖至少一个 pair”。

## 2. Shared-core theorem

对 threshold z，记 large-prime right degree为 \(r_p\)，定义

\[
R_z(\mathcal A)=\sum_{x<y}\omega_{>z,3(4)}(|h_x-h_y|).
\]

### Theorem I1

shared incidences满足

\[
\sum_{p>z:r_p\ge2}r_p\le2R_z(\mathcal A).
\]

若 large primes覆盖 \(\mathcal A\)，则至少

\[
|\mathcal A|-2R_z(\mathcal A)
\]

个 vertices 属于 private fringe，即拥有某个 degree-one large witness。

### Proof

由 \(r\le2\binom r2\) for \(r\ge2\) 与 collision theorem。未由 shared incidences覆盖的 covered vertices只能由 degree-one prime覆盖。∎

这是 genuinely restrictive decomposition：low difference-divisor capacity迫使覆盖高度 private，而不是 high-degree core。

## 3. Why high-degree-prime averaging fails

从 coverage只得总 incidence至少 \(|\mathcal A|\)。若 right vertices数无 uniform bound，平均不能推出 high degree。private-witness CRT允许 \(|\mathcal A|\) 个 degree-one right vertices，且可保持任意 fixed congruence signature of n。

要推出某 prime覆盖 positive proportion，必须先证明可用 witness primes数量 \(o(|\mathcal A|)\) 或 private mass \(o(|\mathcal A|)\)。现有 divisor bounds只给每个 remainder的 prime count upper bound，不给全 family 的 distinct-prime upper bound。

## 4. Bounded-core candidate

若能证明：对 actual \(S(n,z)\)，所有 degree-one large witnesses落入一个集合 \(Q_{\rm exc}(n,z)\) 且

\[
|Q_{\rm exc}(n,z)|+2R_z(S(n,z))<|S(n,z)|,
\]

则 coverage不可能。private witness prime与vertex一一对应时 \(|Q_{\rm exc}|\) 可等于 survivor数，所以该 conclusion必须来自更强 arithmetic structure，例如：

- many remainders共享一个 constrained interval of possible primes；
- survivor shifts对 each large q有 forbidden local multiplicity pattern；
- n 的 CRT residues不能同时支持太多 private exact-one congruences due an independent size constraint。

第三项在 unrestricted n上被 CRT击破；若使用 n-size 与 q-product，需注意只指定 \(q_i^2\) congruences的 least positive solution可以远小于或大于 product，且 n itself是 adversarial，不存在固定 upper bound relative to chosen witnesses。

## 5. Abnormal order relations

coverage by small/medium primes可能迫使 many masks具有较大 overlap。overlap意味着一个 prime同时整除多个 shift differences，进而产生

\[
3^c-3^{c'}\equiv -(5^d-5^{d'})\pmod p.
\]

这可能关联 multiplicative orders，但单个 congruence不要求异常小 order；对任意 difference的 prime divisors，本就是该 relation的定义。要得到 contradiction，必须证明 incidence multiplicity超过所有 differences可承载的 distinct prime-divisor mass。Theorem I1正是该 reduction，但当前 bounds不够强。

## 6. Minimal-counterexample/descent link

若 coverage inverse theorem能推出一个 bounded prime core与 bounded odd valuation depths，则会接近 UBVC/CRW closed route。本轮禁止把这一目标重新命名为 simultaneous selection。一个新 inverse theorem必须直接产生：

- strict tail deficit；或
- n属于 explicit thin set；或
- a smaller counterexample map。

I1目前只产生 private-fringe alternative，没有 descent。

## 7. Classification

- collision/shared-core theorem：**PROVED**。
- coverage迫使 high-degree prime：**FALSE without private control**。
- coverage迫使 bounded core：**NOT ESTABLISHED**。
- coverage迫使 exceptional order alignment：**NOT ESTABLISHED**。
- private-fringe alternative：**PROVED**, 但目前 **LOCAL ONLY**。
