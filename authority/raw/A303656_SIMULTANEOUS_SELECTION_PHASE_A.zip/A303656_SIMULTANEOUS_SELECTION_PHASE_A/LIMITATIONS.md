# LIMITATIONS

## Mathematical limitations

1. 没有证明 A303656，也没有 certified counterexample。
2. hybrid tail criterion虽 exact，但 private-point suppression完全开放。
3. local density公式对 uniform local torus成立；没有证明 active-box equidistribution或 adversarial-n uniformity。
4. p=3 stable-tail formalism已建立，但没有 asymptotic weighted density theorem。
5. no-go constructions针对 bounded Helly、fixed-order moments、profinite compactness与 coarse small-prime survival；它们不排除利用 full arithmetic witness graph 的新 theorem。
6. candidate S1 survivor lower bound与 S1b tail都未证明。
7. active representative criterion是 pointwise exact，但没有 mechanism选择 origin-near good state。
8. duplicate shifts在 incidence theorem中需先合并；这不改变 existence conclusion，但 raw exponent-pair multiplicities不可直接代入 distinct-shift divisor sums。

## Literature limitations

1. literature search优先 primary arXiv/journal sources，但不声称 exhaustive覆盖所有语言、未数字化论文或 2026-07-18 后版本。
2. recent preprints可能继续修订；`WEB_SOURCES_LOCK.json` 固定本轮使用版本与 access date。
3. Radomskii v6、Fan–Lott v2、Araújo v1 等 recent preprints的 publication status不同；本轮只使用其明确 theorem/abstract scope，不据此推广 universal statement。
4. large-prime divisors of two-variable exponential translates文献极其分散；未发现 uniform theorem不等于不存在。
5. 某些 theorem numbering只在 PDF中确认；未导入的 recent screening entries明确标记“不 relied upon”。

## Input limitations

1. expected `a303656_p2cover_bundle.zip` bytes未在本轮收到；只继承 prior authenticated inventory与 user-specified authority facts。
2. 两份 Global Route Reset 是 duplicate，不构成 independent evidence。
3. no repository/WSL/Git access was used or claimed。

## Computational limitations

1. experiments限于 tiny exact tori、small boxes 与 hand-constructed CRT instances。
2. 没有 large-scale prime enumeration、598-prime search、low-T search、P5/P6、Gate V3 或 large torus scan。
3. Experiment B只检查 exact valuation one，不等于 full odd mask。
4. Experiment E只是 sanity check，不能用作 statistical evidence。
5. LLL grid search仅用于验证一个 tiny sufficient condition；不是 general optimizer proof。

## Strategic uncertainty

`S4-HYBRID-PRIVATE-DEFICIT` 的 missing lemma可能显著弱于原问题，也可能在 actual survivors上仍与原问题同等困难。目前没有证明 strict logical separation。因而 verdict选择 SPECULATIVE WATCH，而不是 promotion。
