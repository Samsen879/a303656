# NO-GO RESULTS

## NG-1 — actual masks have unbounded Helly number

### Theorem

对任意 \(m\ge2\)，取 distinct active shifts \(X=\{h_1,\ldots,h_m\}\)。存在 arbitrarily large \(n\) 与 distinct \(q_i\equiv3\pmod4\) 使

\[
B_{q_i}(n)\cap X=\{h_i\}.
\]

故

\[
G_{q_i}(n)\cap X=X\setminus\{h_i\}.
\]

每个 proper subfamily intersection 非空，而全体 intersection 空。

### Proof

应用 designated private-witness CRT：\(q_i\parallel n-h_i\)，且 \(q_i\nmid n-h_j\) for \(j\ne i\)。因此 i点 valuation 1，其他点 valuation 0。n可任意大，从而给定 exponent pairs 全部 active。∎

### Terminates

- local nonemptiness fallacy；
- pairwise intersection fallacy；
- any bounded Helly number；
- checking every subfamily of fixed size h independent of number of primes。

它不否定使用 full arithmetic structure的 theorem。

## NG-2 — fixed-order moments cannot decide intersection

### Theorem

对每个 \(m\ge3\)，在 \(\Omega=\mathbf F_2^{m-1}\) 上存在两套 m个 affine-hyperplane bad masks，使所有 proper-subfamily joint distributions相同，但一套 complements global intersection非空，另一套为空。

### Construction

对 \(i<m\)，令 \(\ell_i(x)=x_i\)。最后一式取

\[
\ell_m^+(x)=\sum_{i<m}x_i,
\qquad
\ell_m^-(x)=1+\sum_{i<m}x_i,
\]

并定义 \(B_i=\{\ell_i=1\}\)。任意 proper subset of forms linearly independent，故 joint values uniform，constants不影响 distribution。plus system 的 all-good point是 0；minus system中 coordinates good强迫 x=0，但 \(\ell_m^-(0)=1\)，故无 all-good point。∎

### Terminates

marginal densities、pairwise intersections、fixed k-wise intersections/moments、uncentered finite-order energy，若没有额外 global structure，均不足以决定 common selection。

## NG-3 — profinite exponent fallacy

nested sets \(x\equiv-1\pmod{k!}\) 每个 finite stage有 ordinary representative，full compact intersection只有 profinite \(-1\)，没有 nonnegative integer。详见 `COMPACTNESS_AND_PROFINITE_NO_GO.md`。

### Terminates

finite local compatibility \(\Rightarrow\) ordinary exponent；inverse-limit point \(\Rightarrow\) active pair。

## NG-4 — torus representative fallacy

state \((u\bmod C,v\bmod D)\) active当且仅当 least representative满足 \(3^{u_0}+5^{v_0}\le n\)。存在 good state但 least shift远大于 n；所有其他 representatives更大。

### Terminates

abstract torus anti-cover \(\Rightarrow\) A303656 solution，除非 theorem含 quantitative representative bound。

## NG-5 — small-prime survival does not suppress private tail

对任意 z,m，有 active pairs全部避开 \(p\le z\) bad masks，却各自拥有 distinct private \(q_i>z\) exact-one witness。详见 Theorem L4。

### Terminates

small-prime sieve completion fallacy；large-prime reuse fallacy；粗 pigeonhole。

## NG-6 — shift-difference energy controls only reuse

collision inequality约束 \(\sum\binom{r_p}{2}\)，degree-one edges不出现在左侧。private CRT可使全部 edges degree one。因此 additive/Sidon energy alone不能给 TAIL。

## NG-7 — fixed-modulus two-square test is impossible

若 residue class modulo M 可表示为 sum of two squares mod M，则该 class含 infinitely many genuine sums of two squares，也含 infinitely many integers with a \(3\bmod4\) prime exact valuation one。故 no fixed modulus decides \(\mathcal S_2\) globally。

## NG-8 — ordinary semilinearity is unavailable

shift set \(\{3^c+5^d\}\) counting function为 \(O((\log X)^2)\)，而 infinite one-dimensional semilinear set含 infinite arithmetic progression并有 linear tail growth。因此 shift set非 semilinear / non-Presburger。

## NG-9 — finite affine repair is not universal

对任意 finite family of nontrivial affine corrections \(x\mapsto\lambda_i x+k_i\) with nonzero offsets，可用 distinct \(3\bmod4\) primes与 CRT 选择 arbitrarily large \(x\in\mathcal S_2\)，使每个 image有 designated exact-one obstruction。故 finite affine menu不能 universal lift。

## NG-10 — common-square descent fails immediately

shifts 2与4 active时，\(\gcd(n-2,n-4)\mid2\)，没有 square \(q^2>1\) 同时整除全部 remainders。

## NG-11 — density-product fallacy

即使 \(\prod_p(1-\delta_p)>0\)，若 local coordinates非独立、active image非uniform、events随 n变化，不能推出 actual intersection非空。NG-2给出 fixed-order indistinguishable countermodels。

## NG-12 — parity denial

standard sieve的 upper/lower bounds不能一般地区分 odd/even valuation pattern。任何只得 rough/almost-prime remainder 的 theorem未完成 two-square criterion。

## Scope boundary

上述 no-go theorems不证明 A303656 false，也不排除一个 genuinely arithmetic theorem利用 full witness graph、n-size、orbit compatibility与active geometry。它们严格终止的是指定低信息量 mechanisms。
