# LARGE PRIME TAIL

## 1. Witness incidence graph

固定 finite active family \(\mathcal A\subseteq D(n)\)。若不同 exponent pairs 给出相同 shift，则它们的 remainder 与所有 witness sets 完全相同；先合并重复 shifts，并在最后选择任一 active preimage。

令 left vertices 为 distinct shifts \(h_x\)。对 \(p>z\), \(p\equiv3\pmod4\)，当

\[
v_p(n-h_x)\text{ odd}
\]

时连接 edge \((x,p)\)。记 right degree 为 \(r_p\)。

## 2. Collision incidence theorem

### Theorem L1

\[
\sum_{\substack{p>z\\p\equiv3(4)}}\binom{r_p}{2}
\le
R_z(\mathcal A)
:=
\sum_{x<y}\omega_{>z,\,3(4)}(|h_x-h_y|).
\]

### Proof

若同一 \(p\) 邻接 \(x,y\)，则 \(p\mid n-h_x\) 与 \(p\mid n-h_y\)，故 \(p\mid h_x-h_y\)。对固定 \(p\)，\(\binom{r_p}{2}\) 计算被该 prime 同时覆盖的 unordered vertex pairs；交换求和，每个 pair至多贡献其 shift difference 中 \(>z\)、\(3\bmod4\) distinct prime divisors 数。∎

该 inequality 是 exact，不依赖 independence、randomness 或 valuation depth。它只控制 right degree至少 2 的 reuse。

## 3. Hybrid tail criterion

令 \(\operatorname{Pvt}_z(\mathcal A,n)\) 为至少拥有一个 degree-one right neighbor \(p>z\) 的 vertices 数。

### Theorem L2

若 large bad primes 覆盖全部 \(\mathcal A\)，则

\[
|\mathcal A|
\le
\operatorname{Pvt}_z(\mathcal A,n)+2R_z(\mathcal A).
\]

因而若

\[
\operatorname{Pvt}_z(\mathcal A,n)+2R_z(\mathcal A)<|\mathcal A|,
\tag{TAIL-DEFICIT}
\]

则存在 vertex 没有任何 \(p>z\) odd witness。

### Proof

不属于 private-vertex set 但被覆盖的 vertex 必须邻接某个 \(r_p\ge2\) 的 prime。shared incidences 总数不超过

\[
\sum_{r_p\ge2}r_p
\le2\sum_p\binom{r_p}{2}
\le2R_z(\mathcal A).
\]

加上 private vertices 得第一式。严格反式即结论。∎

若 \(\mathcal A\subseteq\cap_{p\le z}G_p(n)\)，TAIL-DEFICIT 产生一个 all-prime good pair；由 Fermat theorem，其 remainder 属于 \(\mathcal S_2\)。

## 4. Designated private-witness theorem

### Theorem L3

给定 distinct integers \(h_1,\ldots,h_m\)、任意 fixed congruence \(n\equiv a\pmod M\) 与 lower bound \(Z\)，存在 distinct primes \(q_i>Z\), \(q_i\equiv3\pmod4\)，以及 infinitely many \(n\)，满足

\[
q_i\parallel n-h_i,
\qquad
q_i\nmid n-h_j\quad(j\ne i).
\]

### Proof

选择 \(q_i\) 避开 \(M\) 与所有 nonzero differences \(h_i-h_j\)。用 CRT 同时解

\[
n\equiv a\pmod M,
\qquad
n\equiv h_i+q_i\pmod{q_i^2}.
\]

第二式给 exact valuation one；对 \(j\ne i\)，模 \(q_i\) 余数为 \(h_i-h_j\ne0\)。加上总 modulus 的 multiples 得 infinitely many arbitrarily large solutions。∎

该 theorem 不构造 A303656 counterexample，也不排除 alternative shared witnesses；它严格说明 designated/private mass 不能由 pigeonhole 自动消失。

## 5. Small-prime-survivor private-tail countermodel

### Theorem L4

对任意 \(z\) 与 \(m\)，存在 \(m\) 个 active exponent pairs 与 arbitrarily large \(n\)，使每个 pair 对全部 \(p\le z\), \(p\equiv3\pmod4\) 都有 valuation 0，却分别拥有 distinct private exact-valuation-one witnesses \(q_i>z\)。

### Construction

固定 \(d=d_0\)，令

\[
L=\operatorname{lcm}_{\substack{p\le z\\p\equiv3(4),\ p\ne3}}
\operatorname{ord}_p(3),
\quad c_i=c_0+iL,
\]

并取 \(c_0\ge1\)。对每个 small \(p\ne3\)，所有 shifts modulo \(p\)相同；对 p=3，\(3^{c_i}\equiv0\pmod3\)，也相同。选择 \(n\) 在每个 small p 上避开该 common residue，再应用 Theorem L3。取足够大的 CRT solution 使所有 pairs active。∎

这严格否定任何只依赖 “survives all \(p\le z\)” 与 coarse one-dimensional orbit alignment 的 uniform TAIL theorem。

## 6. Crude divisor bounds

每个 \(1\le r\le n\) 具有至多

\[
\frac{\log n}{\log z}
\]

个 distinct prime divisors \(>z\)。于是 incidence union bound 至多

\[
|\mathcal A|\frac{\log n}{\log z}.
\]

要严格小于 \(|\mathcal A|\) 需要 \(z>n\)，此时 small-prime stage 已失去意义。

若 \(p>\sqrt n\)，任何 positive remainder \(\le n\) 至多含一个这样的 prime，且 valuation 必为 1。但每个 survivor仍可拥有不同 private prime，故总数上界只是 \(|\mathcal A|\)，不是 strict deficit。

## 7. Shift-difference capacity

若 \(|h_x-h_y|\le n\)，则

\[
\omega_{>z}(|h_x-h_y|)\le\frac{\log n}{\log z}.
\]

从而

\[
R_z(\mathcal A)\le\binom{|\mathcal A|}{2}\frac{\log n}{\log z},
\]

远大于 linear scale。Sidon-type low additive energy可减少 repeated differences，但 Theorem L1使用的是 prime-divisor mass，不是 equality energy；一个 unique difference仍可含多个 large prime factors。

## 8. Parity barrier

ordinary sieve可以减少 divisibility events，但 final predicate要求 \(v_p\) parity。large prime \(p>\sqrt n\) 的 valuation-one obstruction最尖锐：它既逃离高-depth analysis，也完全落在 sieve parity barrier 中。任何 almost-prime theorem若允许一个 \(3\bmod4\) prime factor valuation one，仍不足以证明 two-square membership。

## 9. Tail verdict

- Shared witness control：**PROVED**，由 collision incidence。
- Private witness suppression：**NOT ESTABLISHED**。
- TAIL from small-prime survival alone：**FALSE**。
- \(p>\sqrt n\) observation：**LOCAL ONLY**，没有 strict counting contradiction。
- Standard sieve completion：**PARITY-BARRIER FAILURE**。

最关键 open lemma 不是再优化 \(R_z\)，而是证明 actual survivor family 无法给几乎每个 vertex 分配 private large witness。当前没有 theorem 支持该断言。
