# LOCAL ORBIT FORMALISM

## 1. Global objects

令

\[
h(c,d)=3^c+5^d,\qquad r_n(c,d)=n-h(c,d),
\]

\[
D(n)=\{(c,d)\in\mathbf Z_{\ge0}^2:h(c,d)\le n\}.
\]

对 \(p\equiv3\pmod4\)，定义 full bad mask

\[
B_p(n)=\{(c,d)\in D(n):0<|r_n(c,d)|,\ v_p(r_n(c,d))\text{ odd}\},
\]

并令 \(G_p(n)=D(n)\setminus B_p(n)\)。若 remainder 为 \(0\)，它属于 \(\mathcal S_2\)，并不视为 odd valuation。Fermat two-square theorem 给出

\[
r\in\mathcal S_2
\iff
v_p(r)\text{ even for every }p\equiv3\pmod4.
\]

本轮的 global target 是同一个 ordinary \((c,d)\in D(n)\) 落入全部 \(G_p(n)\)。

## 2. Unit primes \(p\nmid15\)

固定 \(e\ge1\)，记

\[
C_{p,e}=\operatorname{ord}_{p^e}(3),\qquad
D_{p,e}=\operatorname{ord}_{p^e}(5),
\]

\[
\Omega_{p,e}=\mathbf Z/C_{p,e}\mathbf Z\times
                \mathbf Z/D_{p,e}\mathbf Z.
\]

定义 orbit map

\[
\phi_{p,e}(\bar c,\bar d)=3^c+5^d\pmod{p^e}.
\]

这是 well-defined。令

\[
V_{p,e}(n)=\phi_{p,e}^{-1}(n\bmod p^e)
\]

为 **divisibility mask**。它只表示 \(p^e\mid r_n(c,d)\)，不表示 exact valuation。

### Compatibility maps

当 \(E\ge e\) 时，order divisibility 给出 canonical projection

\[
\pi_{E,e}:\Omega_{p,E}\to\Omega_{p,e}.
\]

并且

\[
\pi_{E,e}^{-1}V_{p,e}(n)
=
\{\omega\in\Omega_{p,E}:p^e\mid n-\phi_{p,E}(\omega)\}.
\]

对 \(0\le k<E\)，在 common depth \(E\) 定义 **exact-valuation mask**

\[
X_{p,k}^{(E)}(n)=
\pi_{E,k}^{-1}V_{p,k}(n)
\setminus
\pi_{E,k+1}^{-1}V_{p,k+1}(n),
\]

其中 \(V_{p,0}=\Omega_{p,0}\)。于是

\[
B_{p,<E}^{(E)}(n)
=
\bigcup_{\substack{1\le k<E\\k\text{ odd}}}
X_{p,k}^{(E)}(n)
\]

是 **truncated odd-valuation mask**。full bad set 是所有 odd exact layers 的 union，不能被任意 fixed depth 无条件替代。

## 3. Exact local density audit

令

\[
H_{3,p,e}=\langle3\rangle\subset(\mathbf Z/p^e\mathbf Z)^\times,
\qquad
H_{5,p,e}=\langle5\rangle.
\]

指数坐标分别 biject 到这两个 cyclic subgroups。故

\[
N_{p,e}(n)
=
\#\{(x,y)\in H_{3,p,e}\times H_{5,p,e}:x+y\equiv n\pmod{p^e}\}
\]

满足

\[
|V_{p,e}(n)|=N_{p,e}(n),
\qquad
\delta_{p,e}(n)=\frac{N_{p,e}(n)}{C_{p,e}D_{p,e}}.
\]

对每个固定 \(x\) 至多有一个 \(y\)，反之亦然，因此

\[
N_{p,e}(n)\le\min(C_{p,e},D_{p,e}),
\qquad
\delta_{p,e}(n)\le\frac1{\max(C_{p,e},D_{p,e})}.
\]

对 \(n\bmod p^e\) 平均时，所有 \(C_{p,e}D_{p,e}\) pairs 恰落入一个 residue，故

\[
\frac1{p^e}\sum_{n\bmod p^e}\delta_{p,e}(n)=\frac1{p^e}.
\]

这只是 average-in-\(n\) identity；它不提供 adversarial fixed \(n\) 的 uniform density，也不提供不同 primes 间 independence。

在 common depth \(E\)，令 \(\widetilde\delta_{p,k}^{(E)}\) 为 \(V_{p,k}\) 的 pullback density，则

\[
\frac{|X_{p,k}^{(E)}(n)|}{|\Omega_{p,E}|}
=
\widetilde\delta_{p,k}^{(E)}(n)
-
\widetilde\delta_{p,k+1}^{(E)}(n).
\]

高 prime powers 的 density 对固定 \(p\) 通常随 order lifting 衰减，但把 \(p\) 再求和并不自动 summable；更重要的是 sieve 需要 actual active-box distribution，而非 uniform local torus density。

### Order lifting

令 \(a\) 为 odd prime \(p\) 的 unit，\(r=\operatorname{ord}_p(a)\)，\(t=v_p(a^r-1)\)。由 LTE，

\[
\operatorname{ord}_{p^e}(a)=
\begin{cases}
r,&e\le t,\\
rp^{e-t},&e>t.
\end{cases}
\]

该公式给出 exponent-period compatibility；它不消除不同 primes 的共享 factors，也不控制 global lcm。

## 4. The exceptional prime \(p=3\)

因为 base \(3\) 不是 unit，纯 periodic torus 不正确。对 modulus \(3^e\)，使用 augmented state

\[
\mathcal C_{3,e}=\{0,1,\ldots,e-1,\tau_e\},
\]

其中 \(\tau_e\) 表示全部 \(c\ge e\)，且 \(3^c\equiv0\pmod{3^e}\)。令

\[
\Omega_{3,e}=\mathcal C_{3,e}\times
\mathbf Z/D_{3,e}\mathbf Z,
\qquad D_{3,e}=\operatorname{ord}_{3^e}(5).
\]

从 depth \(e+1\) 到 \(e\) 的 compatibility map 把 \(c=e\) 与 \(\tau_{e+1}\) 都送到 \(\tau_e\)，而 \(c<e\) 保持。该系统是 stable-tail inverse system，不是 finite cyclic c-coordinate。

uniform state measure 对 active exponents 没有 canonical meaning：tail state \(\tau_e\) 代表随 \(n\) 增长的多个 ordinary exponents，而每个 small state 只代表一个 \(c\)。任何 density theorem 必须指定 active-box weighting。

## 5. The base prime \(p=5\)

\(5\not\equiv3\pmod4\)，所以它不是 two-square obstruction prime。但在任何把 shift 代数化、除以 base、或同时研究 all prime powers 的步骤中，d-coordinate 对 \(5^e\) 也具有 stable tail，不能误用 \(\operatorname{ord}_{5^e}(5)\)。

## 6. Product tori and actual global image

对 finite prime-depth family \(\mathscr P=\{(p,e_p)\}\)，形式 product

\[
\prod_{(p,e_p)\in\mathscr P}\Omega_{p,e_p}
\]

通常大于 ordinary exponent image。正确对象是 diagonal compatibility image

\[
\Omega_{\mathscr P}^{\mathrm{act}}
=
\operatorname{im}\left(
\mathbf Z_{\ge0}^2\to
\prod_{(p,e_p)}\Omega_{p,e_p}
\right),
\]

并在 p=3 坐标使用 augmented state。不同 local periods 的 gcd/lcm 关系全部编码在此 image；把 product coordinates 宣称 independent 是错误的。

若所有 primes 都是 units 且深度固定，可用 global periods

\[
C_{\mathscr P}=\operatorname{lcm}_{p}C_{p,e_p},
\qquad
D_{\mathscr P}=\operatorname{lcm}_{p}D_{p,e_p},
\]

把 image 写成一个 quotient of \(\mathbf Z/C_{\mathscr P}\times\mathbf Z/D_{\mathscr P}\)。但 lcm growth 正是 active representative obstruction 的来源。

## 7. Active representative

对 pure state \((u\bmod C,v\bmod D)\)，取 least nonnegative representatives \(u_0,v_0\)。所有 ordinary representatives 为

\[
(u_0+rC,v_0+sD),\qquad r,s\ge0.
\]

因指数函数严格递增，最小 shift 是 \(3^{u_0}+5^{v_0}\)。所以该 state 有 active representative 当且仅当

\[
3^{u_0}+5^{v_0}\le n.
\]

这不是 density issue，而是 exact monotonicity criterion。full torus 每个 state 都 active 的充要 threshold 为

\[
n\ge3^{C-1}+5^{D-1}.
\]

当 \(C,D\) 是 growing lcm 时，这一 threshold 通常远超原问题允许的 \(O(\log n)\) exponent scale。

## 8. Formalism verdict

- Local divisibility/exact/odd masks：**PROVED exact formalism**。
- High-depth local density identities：**PROVED**, 但 adversarial uniformity 不成立。
- Product-torus independence：**FALSE**；必须用 diagonal image。
- p=3 pure periodicity：**FALSE**；必须用 stable tail。
- fixed-depth odd mask等于 full bad mask：**FALSE**。
- torus good state自动给 active pair：**FALSE**；见 exact representative criterion。
