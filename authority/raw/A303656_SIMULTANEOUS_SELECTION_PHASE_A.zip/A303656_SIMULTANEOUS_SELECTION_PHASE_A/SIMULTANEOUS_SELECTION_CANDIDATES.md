# SIMULTANEOUS SELECTION CANDIDATES

## Evaluation protocol

每个 candidate 回答：exact statement、local objects、ordinary pair、all-prime completion、large-prime tail、active representative、uniformity、effectivity、known support、core missing lemma、small-test status 与 overlap risk。分类只使用本轮许可 taxonomy。

---

## S1-ORBIT-SIEVE-SURVIVORS

### Exact candidate

寻找 explicit \(z(n)\)、active subdomain \(D_0(n)\subseteq D(n)\) 与 \(\delta>0\)，使

\[
|S(n,z)|
=
\left|D_0(n)\cap\bigcap_{\substack{p\le z\\p\equiv3(4)}}G_p(n)\right|
\ge(\log n)^\delta,
\]

并对该 **actual survivor set** 证明

\[
\operatorname{Pvt}_z(S(n,z),n)+2R_z(S(n,z))<|S(n,z)|.
\]

后式由 proved hybrid lemma 推出至少一个 survivor 无任何 \(p>z\) odd witness。

### Audit

- Same ordinary pair: 若两条 inequality 成立，则 YES。
- All primes: 条件式 YES。
- Active box: 由定义 YES。
- Uniform/effective: 要求是，但未证明。
- Core missing lemma: 同时需要 nontrivial survivor lower bound 与 private-point suppression。
- Small tests: density 随 \(n\bmod M\) 明显变化；没有 complete tiny cover，但这不提供 asymptotic lower bound。
- Closed-route overlap: 若仅用 random product/moments，则回到已关闭 route；必须有 deterministic orbit distribution theorem。

**Classification: PLAUSIBLE BUT CORE LEMMA OPEN.**

---

## S2-PRODUCT-TORUS-ANTI-COVER

### Candidate form

对 finite prime-depth family \(\mathscr P\)，在 diagonal image \(\Omega_{\mathscr P}^{\rm act}\) 上，试图从 mask geometry 推出

\[
\Omega_{\mathscr P}^{\rm act}\setminus\bigcup_{p\in P}B_{p,<E_p}(n)\ne\varnothing.
\]

### Exact mismatch

Lettl–Sun、Szegedy、Hough 与 Balister–Bollobás–Morris–Sahasrabudhe–Tiba 的 theorems 处理 cosets 或 single residue classes。A303656 divisibility masks是 additive preimages

\[
\{(x,y)\in H_3\times H_5:x+y=n\},
\]

odd masks又是 alternating p-adic shells；一般既非 subgroup coset，也非一个 residue class。即使 finite torus 有 uncovered state，也仍缺：

1. full odd valuation depths；
2. primes outside \(P\)；
3. active representative。

### Verdict

Direct application of known coset anti-cover theorem: **FALSE**。作为 finite/truncated structural program：**LOCAL ONLY**。若只处理 fixed \(P\)，没有 universal route。

---

## S3-LLL-ORBIT

### Exact finite theorem

在一个已冻结 finite product probability space上，若 bad events \(A_i\) 具有真实 dependency graph \(\Gamma\)，并存在 \(x_i\in(0,1)\) 满足

\[
\Pr(A_i)\le x_i\prod_{j\in\Gamma(i)}(1-x_j),
\]

则 finite intersection of complements 具有正概率。

### A303656 mapping

- variables：global c- and d-primary components，不能按 prime 假设 independent；
- event：一个 fixed prime 的 truncated odd mask；
- dependency：共享 period prime-power components；
- probability：必须相对于指定 uniform finite torus，而非 active-box distribution。

Tiny exact test `[7,11,19,23]` 上 symmetric condition 失败，asymmetric condition 即便用 complete graph 仍成功。它只证明该 tiny valuation-one family 在 abstract torus 上可避开。

### Missing pieces

full odd layers、p=3 stable-tail weighting、growing prime family、large-prime tail 与 active representative 全部缺失。Moser–Tardos 的 algorithmic conclusion也只返回 product-space assignment，不自动返回 active ordinary exponents。

**Classification: LOCAL ONLY.**

---

## S4-HYBRID-PRIVATE-DEFICIT

### Proved theorem

令 \(\mathcal A\subseteq D(n)\) 为 finite family，先合并相同 shifts。若 \(\mathcal A\subseteq\cap_{p\le z}G_p(n)\)，且

\[
\operatorname{Pvt}_z(\mathcal A,n)+2R_z(\mathcal A)<|\mathcal A|,
\]

则存在 \((c,d)\in\mathcal A\) 使 \(r_n(c,d)\) 对所有 \(p\equiv3\pmod4\) 均有 even valuation。因此 remainder 属于 \(\mathcal S_2\)。

该 statement 是 exact、non-circular、all-prime conditional theorem，并自动保留 active box。

### Core open lemma

需要对 actual small-prime survivors 证明

\[
\operatorname{Pvt}_z(\mathcal A,n)
\le (1-\eta)|\mathcal A|-2R_z(\mathcal A)
\]

或任何足够的严格 deficit。private-witness CRT 与本轮 E2 construction 表明，small-prime survival、固定一维 orbit alignment 与 bounded local data 均不足以推出该 inequality。

**Theorem classification: PROVED.**  
**Universal route classification: PLAUSIBLE BUT CORE LEMMA OPEN.**

---

## S5-COVERAGE-INVERSE-CORE

### Proved inverse statement

若 large bad primes 覆盖 \(\mathcal A\)，则

\[
\operatorname{Pvt}_z(\mathcal A,n)
\ge |\mathcal A|-2R_z(\mathcal A).
\]

所以当 shift-difference divisor capacity 小时，coverage 强迫接近全体 vertices 拥有 private large witness。该结论把“coverage”分解为 shared core 与 private fringe。

### Why it is not yet restrictive enough

private-witness CRT 精确展示 private fringe 可以是全部 vertices。没有 theorem 证明 actual full witness graph 不允许这种结构，也没有由此导出的 descent、thin set of \(n\)、bounded core 或 exceptional order relation。

**Classification: LOCAL ONLY.**

---

## S6-ACTUAL-MASK-HELLY-NO-GO

### Theorem

对每个 \(m\ge2\)，存在 actual A303656 shifts、ordinary \(n\) 与 primes \(q_1,\ldots,q_m\equiv3\pmod4\)，使每个 proper subfamily of good masks intersect，而 full intersection empty。

### Consequence

任何只查看 bounded Helly data、pairwise intersections、individual nonemptiness 或 fixed subfamily size 的 universal common-selection theorem 均不成立，即使 local masks 是 exact valuation-one actual masks。

**Classification: PROVED.**

---

## S6-FIXED-ORDER-MOMENT-NO-GO

在 \(\mathbf F_2^{m-1}\) 上构造两套 affine hyperplane bad masks，它们所有 proper-subfamily joint distributions 完全相同，但一套有 common good point，另一套没有。故 marginal densities、pairwise intersections、任意 fixed-order moments不足以决定 global intersection。

**Classification: PROVED.**

---

## S6-PROFINITE-NO-GO

nested congruence conditions \(x\equiv-1\pmod{k!}\) 每个 finite stage 有 ordinary representative，full inverse-limit intersection 只有 profinite \(-1\)，没有 nonnegative integer。故 compactness/FIP 不产生 finite exponent；若强制 fixed active box，FIP 只是在 finite set 上的 triviality。

**Classification: PROVED.**

---

## Candidate ranking

1. `S4-HYBRID-PRIVATE-DEFICIT`：最清晰、non-circular、all-prime conditional route；缺失 lemma 仍可能与原问题接近，但已分离 shared/private obstruction。
2. `S1-ORBIT-SIEVE-SURVIVORS`：需要两个独立重大 theorem，风险高。
3. `S3-LLL-ORBIT`：finite local mechanism可行，无法跨越 all-prime/active-box。
4. `S5-COVERAGE-INVERSE-CORE`：proved structure，但 private fringe 未受控。
5. `S2-PRODUCT-TORUS-ANTI-COVER`：known coset theorems object mismatch。

没有 candidate 通过全部 promotion gates。
