# COMPACTNESS AND PROFINITE NO-GO

## 1. The tempting compactness argument

一种常见 proposal 是：若每个 finite prime set \(P\) 都存在 exponent pair满足全部 local conditions，则在 inverse limit 或 compact product 中取一个 common point。问题是 compact space中的 point通常是 profinite exponent，不是 ordinary nonnegative integer；finite-stage representatives还可能发散。

## 2. Precise countermodel

令 \(\widehat{\mathbf Z}\) 为 profinite integers，并定义

\[
C_k=\{x\in\widehat{\mathbf Z}:x\equiv-1\pmod{k!}\}.
\]

### Theorem C1

1. 每个 \(C_k\) 是 nonempty clopen；
2. \(C_{k+1}\subseteq C_k\)；
3. 每个 finite intersection 含 ordinary nonnegative representative \(k!-1\)；
4. full intersection 为 profinite point \(-1\)；
5. full intersection 不含任何 ordinary nonnegative integer。

### Proof

前两点由 divisibility \(k!\mid(k+1)!\)。对 finite stage K，\(K!-1\) 同时满足所有 \(k\le K\) congruences。inverse limit compatibility唯一指定 \(-1\)。若普通 \(x\ge0\) 属于全部 \(C_k\)，则每个 \(k!\mid x+1\)；取 \(k!>x+1\) 矛盾。∎

对 two exponents 可取 \(C_k\times\{0\}\)。least ordinary representatives \((k!-1,0)\) 发散，故任何 fixed active bound最终失败。

## 3. Application to exponent orbits

multiplicative orders给出 congruence quotients of \(c,d\)。若 finite prime families有 compatible states，compactness最多给

\[
(\hat c,\hat d)\in\widehat{\mathbf Z}^2
\]

或更复杂 augmented inverse limit。一般没有定义把 \(3^{\hat c}\) 解释为 ordinary integer power；即使 p-adic exponentiation在某些 unit neighborhoods定义，也不同时给实数大小与 nonnegative integer exponent。

因此

\[
\text{finite local solvability}
\not\Rightarrow
\text{ordinary exponent pair}.
\]

## 4. Fixed-n finite intersection property

对 fixed \(n\)，active domain \(D(n)\) 是 finite set。若 family \(\{G_p(n)\cap D(n)\}\) 的每个 finite subfamily intersection非空，那么 whole intersection非空：若 whole intersection空，每个 point选一个排除它的 prime，得到 finite subcover。

该 observation完全正确，但没有 quantifier compression。它等价于：fixed finite active domain中所有 witness primes的某个 finite subset已经覆盖。该 subset、prime sizes与 valuation depths都可随 \(n\) 增长。

## 5. Active constraint is not closed in the relevant limit

固定 n 时，ordinary active set finite，嵌入 profinite space后是 closed；compactness then trivial。若 n随 finite stage增长，条件

\[
3^c+5^d\le n
\]

没有形成一个 single compact closed subset containing all stages。representatives可趋于无穷，而 profinite coordinates收敛。C1就是这种 divergence的最小模型。

## 6. Infinite LLL and computability

infinite LLL results在 countable independent-variable systems中可通过 compactness或algorithmic conditions给出 infinite assignment；其 output仍属于 ambient product alphabet。A303656 ambient object若取 residue-coordinate product，则 assignment是 compatible residue sequence，不自动是 one integer exponent。要恢复 ordinary c,d，需要额外 boundedness/coherence theorem，正是缺失的 active representative control。

## 7. No-go classification

- finite-subfamily solvability \(\Rightarrow\) profinite point：在适当 compact inverse system中可成立；**LOCAL ONLY**。
- profinite point \(\Rightarrow\) ordinary nonnegative exponent：**FALSE**。
- fixed-n FIP：**PROVED but NO QUANTIFIER COMPRESSION**。
- compactness作为 A303656 universal trigger：**ACTIVE-BOX FAILURE**。
