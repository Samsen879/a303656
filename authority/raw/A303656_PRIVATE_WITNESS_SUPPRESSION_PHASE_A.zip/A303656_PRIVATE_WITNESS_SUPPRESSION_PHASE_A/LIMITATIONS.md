# LIMITATIONS

1. Theorem PW-A is an analytic existence theorem along a sequence of \(n\), not an explicit counterexample to A303656.
2. It treats the natural cutoff \(z=\lfloor\sqrt n\rfloor\), and the same construction extends to fixed polynomial cutoffs between \(\sqrt n\) and \(n^{1-\delta}\). It does not rule out every possible mechanism using much smaller \(z\).
3. The constants in the dyadic argument are not optimized or made effective; effectiveness is irrelevant to the negative uniform conclusion.
4. The result does not provide a new lower bound for the number of two-square remainders for each fixed adversarial \(n\).
5. No unproved two-point correlation, independence heuristic, random model, or large computation is used.
6. The exact square-root identity is a structural theorem, but using it to prove existence still requires controlling either genuine good survivors or the private term. It does not solve the original problem by itself.
7. The STOP verdict applies to the private-witness suppression trigger in its present uniform form, not to every conceivable analytic, algebraic, or computational route for A303656.
