# EXACT SQUARE-ROOT CUTOFF IDENTITY

Let \(S_{\rm pair}=S(n,z)\) be the complete exponent-pair survivor set. Merge equal numerical shifts and write \(\overline S\) for the quotient. For a quotient shift \(h\), let \(m_h\) be its exponent-pair multiplicity and put

\[
D_{\rm mult}=|S_{\rm pair}|-|\overline S|
=\sum_{h\in\overline S}(m_h-1).
\]

Use the convention that the zero remainder is good. Assume

\[
z=\lfloor\sqrt n\rfloor.
\]

## Lemma SQ

Every bad survivor remainder has exactly one bad prime \(q>z\), and

\[
v_q(n-h)=1.
\]

### Proof

Fermat's two-square criterion supplies at least one \(3\bmod4\) prime of odd valuation. Small bad primes have even valuation by survival, so every such prime exceeds \(z\), hence exceeds \(\sqrt n\). Two distinct such primes have product greater than \(n\), and the square of one is greater than \(n\), whereas \(0<n-h\le n\). Thus there is exactly one and its valuation is one. ∎

## Clean identity on distinct numerical shifts

Let

- \(\overline G\) be the number of quotient shifts whose remainder is a sum of two squares;
- \(r_q\) be the degree of \(q\) on the quotient graph;
- \(\overline P=\operatorname{Pvt}_z(\overline S,n)\);
- \(\overline J=\sum_{q:r_q\ge2}r_q\).

The unique-prime fibers partition the bad quotient vertices, so

\[
|\overline S|=\overline G+\overline P+\overline J.
\tag{SQ1}
\]

The collision-incidence theorem gives

\[
\overline J
\le2\sum_q\binom{r_q}{2}
\le2R_z(\overline S).
\tag{SQ2}
\]

Hence

\[
|\overline S|-\overline G-2R_z(\overline S)
\le\overline P
\le|\overline S|-\overline G.
\tag{SQ3}
\]

## Pair-multiplicity correction

On the unmerged pair graph, write \(G_{\rm pair},P_{\rm pair},J_{\rm pair}\) for the analogous three vertex counts. The same unique-prime partition gives the exact identity

\[
|S_{\rm pair}|=G_{\rm pair}+P_{\rm pair}+J_{\rm pair}.
\tag{SQ4}
\]

A quotient-shared fiber contributes at most its quotient vertices plus the duplicate excess in that fiber. A quotient-private fiber becomes pair-shared only when its sole shift has multiplicity at least two, in which case its contribution is at most twice its duplicate excess. Summing gives

\[
J_{\rm pair}
\le \overline J+2D_{\rm mult}
\le2R_z(\overline S)+2D_{\rm mult}.
\tag{SQ5}
\]

Therefore

\[
P_{\rm pair}
\ge |S_{\rm pair}|-G_{\rm pair}
-2R_z(\overline S)-2D_{\rm mult}.
\tag{SQ6}
\]

The high-\(c\) lemma gives the deterministic active-domain bound

\[
D_{\rm mult}=O(\log n\log\log n).
\tag{SQ7}
\]

## Consequences

1. **Counterexample geometry on the quotient.** If \(\overline G=0\), then
   \[
   \overline P\ge|\overline S|-2R_z(\overline S).
   \]
   Thus \(R_z=o(|\overline S|)\) forces \(\overline P=(1-o(1))|\overline S|\).

2. **Counterexample geometry with multiplicity.** If \(G_{\rm pair}=0\) and
   \[
   R_z(\overline S)+D_{\rm mult}=o(|S_{\rm pair}|),
   \]
   then \(P_{\rm pair}=(1-o(1))|S_{\rm pair}|\).

3. **Suppression is target-strength.** On the quotient, if both \(\overline P=o(|\overline S|)\) and \(R_z=o(|\overline S|)\), then
   \[
   \overline G=(1-o(1))|\overline S|.
   \]
   This proves much more than existence; it is not a cheap tail lemma.

4. **Hybrid deficit cannot hold under a counterexample.** From \(\overline G=0\) and (SQ1)–(SQ2),
   \[
   \overline P+2R_z\ge\overline P+\overline J=|\overline S|.
   \]

5. **Smooth/rough decomposition.** Every positive survivor remainder is exactly of one of the forms
   \[
   r\in\mathcal E,
   \qquad
   r=q s,
   \quad q>\sqrt n,
   \quad q\equiv3\pmod4,
   \quad s\in\mathcal E.
   \]
   This is a complete deterministic decomposition, including valuation parity.
