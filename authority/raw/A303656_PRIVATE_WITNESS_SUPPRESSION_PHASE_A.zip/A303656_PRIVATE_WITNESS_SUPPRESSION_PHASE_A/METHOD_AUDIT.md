# METHOD AUDIT AGAINST THE COMPLETE SURVIVOR SET

## 1. Large-prime incidence

The collision theorem

\[
\sum_{q>z}\binom{r_q}{2}\le R_z
\]

is exact and valuable, but controls only right degrees at least two. Theorem PW-A shows that the complete survivor set itself can support a positive-density degree-one fringe.

## 2. Smooth/rough decomposition

At the square-root cutoff the decomposition is exact:

\[
S=\{r\in\mathcal E\}\cup\{r=qs:q>\sqrt n,\ q\equiv3(4),\ s\in\mathcal E\}.
\]

The second component is not negligible uniformly. It creates the private-density obstruction.

## 3. Product-size and squarefree kernels

Private primes may all be different. Their product lower bound is only \(n^{P/2}\), while the remainder product has capacity \(n^P\). Squarefree kernels preserve the same obstruction and do not produce a contradiction.

## 4. Primitive divisor theory

Primitive-divisor theorems normally manufacture fresh prime divisors in a fixed recurrence or divisibility sequence. That tendency is anti-aligned with suppression. The two-parameter, adversarially shifted values \(n-3^c-5^d\) are not a fixed divisibility sequence uniform in \(n\), so standard primitive-divisor theorems do not supply a private-prime upper bound.

## 5. Entropy and information bounds

A private prime gives a singleton fiber over the single residue \(n\bmod q\). It does not imply that the whole shift set occupies few residue classes modulo \(q\), nor that its residue entropy is low. The congruences are selected after seeing \(n\), so a naive information sum \(\sum\log q\) double-counts self-generated data.

## 6. Large sieve and determinant method

Classical/inverse large-sieve results require residue-class omission or ill-distribution for many prescribed primes, often together with bounded difference or algebraic multiplicity. Complete small-prime survival imposes a valuation-parity condition on translated remainders, not a global bound on the number of shift residues modulo the private primes. The determinant method similarly needs many points satisfying a common algebraic congruence; degree-one fibers provide no such multiplicity.

## 7. Multiplicative orders and period translations

For fixed small prime powers, exponent-period translations preserve local residues. But the lcm of periods grows, the active curved domain truncates translations, and a large private prime is destroyed only by an exact divisibility relation

\[
q\mid h(c,d)-h(c',d').
\]

Theorem PW-A bounds all such possible sharing over the entire active domain and still leaves \(\gg XL^{3/2}\) aggregate private incidences. Local closure therefore does not imply private suppression.

## 8. Active curved domain and sparse survivors

The proof uses an interior rectangle only to generate certified vertices, with \(h\le X/4\). Privacy is tested against **every** active shift up to \(n\), and the denominator is the **complete** survivor set. No lower-density assumption on \(S(n,z)\) is used; a weighted dyadic argument handles the possibility that the survivor set is sparse or highly nonuniform in \(n\).

## 9. Parity

Every constructed private witness has exact valuation one. Its cofactor is a sum of two squares, so all other \(3\bmod4\) valuations are even. This meets, rather than relaxes, the parity condition and isolates the sharpest sieve-parity obstruction.

## 10. Deterministic substitute

The exact identity in `SQUARE_ROOT_CUTOFF_IDENTITY.md` is the strongest deterministic substitute found. It is structural, not a renamed unknown function. But its direction is negative for the proposed route: under low collision, coverage implies an almost-perfect private matching, not a contradiction or descent.
