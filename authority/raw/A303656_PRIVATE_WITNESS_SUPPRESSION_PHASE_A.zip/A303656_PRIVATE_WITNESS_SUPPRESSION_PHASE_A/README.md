# A303656 PRIVATE LARGE-PRIME WITNESS SUPPRESSION — PHASE A

## Status

**Project:** PAUSED  
**Problem:** A303656 UNRESOLVED  
**Phase verdict:** **STOP PRIVATE-WITNESS TRIGGER**

This archive audits deterministic suppression of private large-prime witnesses on the **complete actual survivor set**

\[
S(n,z)=\{(c,d)\in D(n):v_p(n-3^c-5^d)\text{ is even for every }p\le z,\ p\equiv3\pmod4\}.
\]

It does not replace this set by an arbitrarily selected finite subset. The main theorem is proved first on the literal unmerged exponent-pair set above, and then inherited by the distinct-shift quotient used in the preceding collision-incidence theorem.

## Main result

For \(z_n=\lfloor\sqrt n\rfloor\), there are absolute \(\eta,c>0\) and an unbounded sequence \(n_j\) for which

\[
\operatorname{Pvt}_{z_{n_j}}(S(n_j,z_{n_j}),n_j)
\ge \eta\,|S(n_j,z_{n_j})|,
\]

and

\[
\operatorname{Pvt}_{z_{n_j}}(S(n_j,z_{n_j}),n_j)
\ge c(\log n_j)^{3/2}.
\]

The same sequence has positive private density after merging equal shifts. Shift multiplicities are handled by an elementary quantitative high-\(c\) lemma: after removing only \(O(\log X\log\log X)\) collision-prone pairs from an interior rectangle, \(\asymp(\log X)^2\) globally unique shifts remain.

Thus a uniform deterministic assertion

\[
\operatorname{Pvt}_z(S(n,z),n)=o(|S(n,z)|)
\]

is false in the natural square-root tail regime on the complete actual survivor set.

## Exact square-root identity

After equal shifts are merged, at \(z=\lfloor\sqrt n\rfloor\) every bad survivor remainder has exactly one bad prime, with exact valuation one. If \(G\) counts survivor shifts whose remainder is a sum of two squares and \(J\) counts vertices in shared bad-prime fibers, then

\[
|\overline S|=G+\operatorname{Pvt}+J,
\qquad J\le 2R_z.
\]

Consequently

\[
\operatorname{Pvt}\ge |\overline S|-G-2R_z.
\]

In a hypothetical counterexample, \(G=0\), so low collision forces private witnesses to occupy almost every distinct survivor shift. Private-witness suppression plus low collision is therefore not a cheap auxiliary statement; at this cutoff it is already target-strength.

## Reproduction

No large prime enumeration, no new \(T(n)\) search, no Codex, and no Ultra were used.

Run:

```bash
python3 scripts/verify_lemmas.py
python3 scripts/validate_package.py .
python3 scripts/build_deterministic_zip.py . ../rebuild.zip
sha256sum ../rebuild.zip
```

The ZIP builder sorts members, fixes every timestamp to `1980-01-01 00:00:00`, fixes Unix mode bits, and uses deterministic DEFLATE settings.
