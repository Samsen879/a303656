# EXECUTIVE VERDICT

## Verdict

**STOP PRIVATE-WITNESS TRIGGER**

## Reason

The central suppression target is not merely unproved. It fails on the complete actual unmerged exponent-pair survivor family at the natural cutoff \(z=\lfloor\sqrt n\rfloor\): private exact-valuation-one witnesses have positive limsup density along an unbounded sequence with survivor size tending to infinity. The same statement holds after equal shifts are merged.

At this cutoff, the distinct-shift survivor graph has the exact decomposition

\[
|\overline S|=\overline G+\overline{\operatorname{Pvt}}+\overline J,
\qquad \overline J\le2R_z.
\]

For the literal exponent-pair graph, the analogous shared term is at most

\[
2R_z+2D_{\rm mult},
\qquad
D_{\rm mult}=O(\log n\log\log n).
\]

Hence, under the counterexample hypothesis, low collision forces an almost-private matching whenever the multiplicity fringe is lower order. The proposed suppression route is anti-aligned with counterexample geometry.

Product, discriminant, resultant, determinant, and shift-difference tools control the shared term, not the private term. The literature audit found no primary-source theorem that supplies the missing complete-family private-incidence upper bound.

This verdict stops this trigger only. It is not a proof or disproof of A303656.
