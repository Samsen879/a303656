# STRONGEST LEMMA

## Theorem PW-A — complete-survivor private-density obstruction

Let

\[
h(c,d)=3^c+5^d,
\qquad
D(n)=\{(c,d)\in\mathbf Z_{\ge0}^2:h(c,d)\le n\},
\]

and let the **unmerged exponent-pair survivor set** be

\[
S(n,z)=\{(c,d)\in D(n):
 v_p(n-h(c,d))\text{ is even for every }p\le z,
\ p\equiv3\pmod4\}.
\]

For a large bad prime \(q>z\), its degree is counted on exponent-pair vertices. Write

\[
P_{\rm pair}(n,z)=\operatorname{Pvt}_z(S(n,z),n)
\]

for the number of pair vertices possessing a degree-one large bad-prime neighbor. Let \(\overline S(n,z)\) be the quotient obtained by merging equal numerical shifts, and define \(P_{\rm shift}(n,z)\) analogously on that quotient.

Put \(z_n=\lfloor\sqrt n\rfloor\). There are absolute constants \(\eta,c>0\) and infinitely many integers \(n\) such that

\[
P_{\rm pair}(n,z_n)\ge \eta |S(n,z_n)|,
\qquad
P_{\rm pair}(n,z_n)\ge c(\log n)^{3/2}.
\tag{PW-A1}
\]

The same integers satisfy

\[
P_{\rm shift}(n,z_n)\ge \eta |\overline S(n,z_n)|.
\tag{PW-A2}
\]

In particular, both complete survivor sizes tend to infinity along this sequence, and

\[
\limsup_{n\to\infty}
\frac{\operatorname{Pvt}_{\lfloor\sqrt n\rfloor}(S(n,\lfloor\sqrt n\rfloor),n)}
{|S(n,\lfloor\sqrt n\rfloor)|}>0.
\]

Therefore no uniform deterministic estimate \(\operatorname{Pvt}=o(|S|)\) can hold throughout the square-root tail regime on the complete actual survivor set, whether multiplicities are retained or equal shifts are merged.

## Proof

Let \(X\) be large, \(L=\log X\), and fix \(\varepsilon=1/8\). Let \(\mathcal E\) denote the positive integers representable as a sum of two squares. The Landau–Ramanujan theorem and partial summation give

\[
B(Y):=|\mathcal E\cap[1,Y]|\asymp \frac{Y}{\sqrt{\log Y}},
\qquad
\sum_{\substack{s\le Y\\s\in\mathcal E}}\frac1s\asymp\sqrt{\log Y}.
\tag{1}
\]

### 1. A quadratic-logarithmic globally unique pair core

Set

\[
K_X=1+\left\lfloor\log_3\log_5(2X)\right\rfloor,
\qquad C_X=K_X+1,
\]

and begin with the pair rectangle

\[
\mathcal R_X=
\left\{(c,d):
C_X\le c\le\lfloor\log_3(X/8)\rfloor,
\ 0\le d\le\lfloor\log_5(X/8)\rfloor
\right\}.
\]

Every represented shift is at most \(X/4\), and the high-\(c\) injectivity lemma in `HIGH_C_INJECTIVITY.md` shows that different pairs in \(\mathcal R_X\) have different shifts.

Now delete a pair from \(\mathcal R_X\) if its shift has any second representation among all pairs with shift at most \(2X\). In any such collision the competing exponent has \(c'\le K_X\). There are only

\[
O\bigl((K_X+1)\log X\bigr)=O(L\log L)
\]

such low-\(c\) pairs, and each can eliminate at most one member because the shifts inside \(\mathcal R_X\) are already distinct. The remaining set \(\mathcal U_X\) therefore satisfies

\[
|\mathcal U_X|\asymp L^2,
\tag{2}
\]

and every pair in \(\mathcal U_X\) has a numerical shift of multiplicity one in the entire active domain \(D(2X)\). This explicitly handles shift collisions rather than assuming global injectivity.

### 2. Many certified survivor remainders per pair

For each \(s\in\mathcal E\) with \(s\le X^{1/3}\), take every prime

\[
q\equiv3\pmod4,
\qquad
\frac Xs\le q\le(1+\varepsilon)\frac Xs.
\tag{3}
\]

The prime number theorem in the fixed progression \(3\pmod4\), uniformly because \(X/s\ge X^{2/3}\), gives

\[
\#\{q\text{ satisfying (3)}\}
\gg \frac{X}{sL}.
\]

Summing with (1), the number of products \(r=qs\) is

\[
\gg \frac{X}{L}
\sum_{\substack{s\le X^{1/3}\\s\in\mathcal E}}\frac1s
\gg \frac{X}{\sqrt L}.
\tag{4}
\]

These products are distinct: \(q>X^{2/3}\), whereas \(s\le X^{1/3}\), so the large prime factor is uniquely recoverable from \(r\).

For \((c,d)\in\mathcal U_X\), put \(h=h(c,d)\) and \(n=h+r\). Then

\[
X\le n\le(1+\varepsilon+1/4)X<2X.
\]

Also \(q>X^{2/3}>\sqrt n\) for all sufficiently large \(X\). Since \(s\in\mathcal E\), every prime \(p\equiv3\pmod4\) occurs in \(s\) to even exponent. Thus the actual exponent pair belongs to the complete set

\[
S(n,\lfloor\sqrt n\rfloor),
\]

and \(q\) is an exact-valuation-one large bad witness.

By (2) and (4), the total number of these candidate pair incidences over \(X\le n\le2X\) is

\[
\gg X L^{3/2}.
\tag{5}
\]

### 3. Sharing against the entire active curved domain is negligible

A candidate witness \(q\) fails to be private in the unmerged pair graph only if there is another active exponent pair \((c',d')\in D(n)\) with numerical shift \(h'\) and

\[
q\mid(n-h')-(n-h)=h-h'.
\tag{6}
\]

The global uniqueness of the selected core rules out \(h'=h\). There are \(O(L^2)\) active exponent pairs with shift at most \(2X\), and \(|\mathcal U_X|=O(L^2)\), so there are \(O(L^4)\) ordered choices of the candidate pair and its possible competitor.

For a fixed nonzero difference \(|h-h'|\le2X\), there is at most one prime \(q>X^{2/3}\) dividing it, since the product of two such primes exceeds \(2X\) for large \(X\). For that prime, the number of \(n\in[X,2X]\) satisfying \(n\equiv h\pmod q\) is

\[
O(X/q+1)=O(X^{1/3}).
\]

Therefore the total number of nonprivate candidate pair incidences is

\[
O(X^{1/3}L^4)=o(XL^{3/2}).
\tag{7}
\]

No valuation assumption was lost here: divisibility by \(q\) is only a necessary condition for a second odd-valuation edge, so (7) is an upper bound on every possible failure of privacy.

Combining (5) and (7), for some absolute \(a>0\),

\[
\sum_{X\le n\le2X}P_{\rm pair}(n,z_n)
\ge aXL^{3/2}
\tag{8}
\]

for all sufficiently large \(X\).

### 4. The complete unmerged survivor denominator

If a positive remainder \(r=n-h\le n\) survives all bad primes up to \(\sqrt n\), then either

1. \(r\in\mathcal E\); or
2. \(r=qs\), where \(q\equiv3\pmod4\), \(q>\sqrt n\), and \(s\in\mathcal E\).

Indeed, any bad odd-valuation prime must exceed \(\sqrt n\); two such primes, or the square of one, would exceed \(r\le n\). Removing the unique prime leaves a two-square integer.

For \(n\in[X,2X]\), every possible positive survivor remainder is therefore contained in

\[
\mathcal E\cap[1,2X]
\quad\cup\quad
\{qs\le2X:q>\sqrt X,
\ q\equiv3\pmod4,
\ s\in\mathcal E\}.
\]

The first set has \(O(X/\sqrt L)\) elements. For the second, split at \(s=\sqrt X\). For \(s\le\sqrt X\), a fixed-progression prime upper bound and (1) give

\[
\sum_{\substack{s\le\sqrt X\\s\in\mathcal E}}
O\!\left(\frac{X}{sL}\right)
=O\!\left(\frac{X}{\sqrt L}\right).
\]

For \(\sqrt X<s\le2\sqrt X\), there are \(O(\sqrt X/\sqrt L)\) possible \(s\), and only \(O(\sqrt X/L)\) primes in \((\sqrt X,2\sqrt X]\), contributing \(O(X/L^{3/2})\). The possible zero remainder contributes at most one further \(n\) for each fixed pair. Thus each fixed exponent pair has at most \(O(X/\sqrt L)\) survivor values of \(n\) in the dyadic interval.

Since there are \(O(L^2)\) active exponent pairs with shift at most \(2X\), for

\[
M_{\rm pair}(n)=|S(n,z_n)|
\]

we obtain

\[
\sum_{X\le n\le2X}M_{\rm pair}(n)
\le AXL^{3/2}
\tag{9}
\]

for an absolute \(A>0\). This is the complete unmerged denominator; no subset replaces it.

### 5. Extracting a positive-ratio sequence

Let \(\eta=a/(2A)\), and let

\[
\mathcal N_X=\{n\in[X,2X]:
P_{\rm pair}(n,z_n)\ge\eta M_{\rm pair}(n)\}.
\]

From (8) and (9),

\[
\sum_{n\in\mathcal N_X}P_{\rm pair}(n,z_n)
\ge aXL^{3/2}-\eta AXL^{3/2}
=\frac a2XL^{3/2}.
\]

Hence some \(n_X\in\mathcal N_X\) satisfies

\[
P_{\rm pair}(n_X,z_{n_X})\gg L^{3/2}.
\]

Taking disjoint dyadic intervals gives an increasing sequence with (PW-A1), and the survivor size tends to infinity because it dominates the private count. Every pair-private vertex has a unique numerical shift and remains private after equal shifts are merged, while \(|\overline S|\le|S|\). Thus (PW-A2) holds for the same sequence. ∎

## What this theorem does and does not say

It disproves the proposed **uniform** private-density suppression in a central tail regime on the literal exponent-pair set appearing in the question, and also on the distinct-shift quotient used by the collision theorem. It does not prove that every cutoff \(z<\sqrt n\) has positive private density, and it does not decide A303656. It shows that increasing the small-prime cutoff to the square-root threshold does not make the private fringe negligible; it exposes an actual complete-family private-matching obstruction.
