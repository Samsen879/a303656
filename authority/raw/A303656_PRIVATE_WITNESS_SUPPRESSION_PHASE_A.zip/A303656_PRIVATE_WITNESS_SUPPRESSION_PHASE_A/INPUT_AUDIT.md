# INPUT AUDIT

## Supplied inputs

| Input | SHA256 | ZIP test | Internal manifest |
|---|---|---:|---:|
| `分工规则.txt` | `94261338e1d2e0a348ff264e9a98322b647918eeca74b0932dcd90bac980b5f6` | n/a | n/a |
| `项目简介.txt` | `42903e1adb5731d195786538a1072aa5b54a5c2adbf7fe6b963226fa74a139ae` | n/a | n/a |
| `A303656_GLOBAL_ROUTE_RESET(8).zip` | `b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13` | PASS | PASS |
| `a303656_p2cover_bundle(1).zip` | `4dadb8ce07cd0ccf56575ef0882d6bb02284a02c61e05cd1424e070d83b22ff3` | PASS | PASS |
| `A303656_SIMULTANEOUS_SELECTION_PHASE_A(2).zip` | `95736761e3211a35682cc034d2d13d6f13bce6a5281e8c90bb2d56097ce631a2` | PASS | PASS |

## Content-integrity findings

- Global route-reset ZIP: deterministic timestamp `1980-01-01`, no forbidden control bytes found in audited text files.
- Simultaneous-selection ZIP: deterministic timestamp `2000-01-01`; `REPORT.md` contains form-feed byte `0x0c` at byte offset 1950 in place of the backslash of `\frac`.
- p2-cover ZIP: mixed source timestamps; `REPORT_zh.md` contains form-feed byte `0x0c` at byte offset 3288 in place of the backslash of `\frac`.
- Both defective files still match their supplied SHA manifests. Hash validity authenticates the bytes; it does not make the formulas defect-free.

## Provenance use

The prior collision theorem and private-witness definition were taken from the authenticated simultaneous-selection package. Its scope corrections are preserved. No claim in this archive depends on treating that ZIP as a defect-free final archive.
