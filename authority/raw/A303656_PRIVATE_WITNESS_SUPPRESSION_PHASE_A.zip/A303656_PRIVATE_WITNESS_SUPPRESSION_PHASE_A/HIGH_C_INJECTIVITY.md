# HIGH-\(c\) INJECTIVITY AND SHIFT MULTIPLICITIES

## Lemma HC

Suppose

\[
3^c+5^d=3^{c'}+5^{d'},
\qquad c>c'.
\]

Then \(d<d'\), and with \(v=d'-d\),

\[
c'=v_3(5^v-1)=
\begin{cases}
0,&v\text{ odd},\\
1+v_3(v/2),&v\text{ even}.
\end{cases}
\tag{HC}
\]

### Proof

Monotonicity forces \(d<d'\). Rearranging gives

\[
3^{c'}(3^{c-c'}-1)=5^d(5^{d'-d}-1).
\]

The factor \(3^{c-c'}-1\) and \(5^d\) are prime to \(3\), so

\[
c'=v_3(5^v-1).
\]

If \(v\) is odd, \(5^v\equiv-1\pmod3\), so the valuation is zero. If \(v=2w\), LTE applied to \(25^w-1\) gives

\[
v_3(5^{2w}-1)=v_3(25-1)+v_3(w)=1+v_3(w).
\]

This proves (HC). ∎

## Corollary HC-X

Among shifts at most \(2X\), every nontrivial collision has

\[
\min(c,c')\le1+\left\lfloor\log_3\log_5(2X)\right\rfloor.
\]

Consequently all pairs whose \(c\)-exponents exceed this bound have pairwise distinct shifts.

More strongly, let \(K_X=1+\lfloor\log_3\log_5(2X)\rfloor\). In any high-\(c\) rectangle containing \(\asymp(\log X)^2\) pairs, remove every pair whose shift also has a representation with \(c'\le K_X\). There are only

\[
O(\log X\log\log X)
\]

such low-\(c\) pairs, and high-\(c\) shifts are mutually distinct, so only that many members are removed. The remainder still has \(\asymp(\log X)^2\) pairs, each with a globally unique numerical shift throughout the active box up to \(2X\).

## Quantitative multiplicity bound

Every repeated-shift equivalence class contains at least one low-\(c\) pair and at most one high-\(c\) pair. Therefore the total number of exponent-pair vertices lying in non-singleton shift classes, and hence the difference between the unmerged and merged active counts, is

\[
O(\log X\log\log X).
\]

No universal injectivity claim is made. Theorem PW-A uses the globally unique core for its numerator and the full unmerged exponent-pair set for its denominator, so multiplicity cannot manufacture the claimed private density.
