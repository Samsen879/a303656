# LITERATURE AUDIT

Audit date: **2026-07-21**. The search emphasized primary papers and official sequence records.

## 1. Problem status and origin

The official OEIS entry A303656 still labels positivity for every \(n>1\) as a conjecture and records computational verification through \(2.4\times10^{11}\). Zhi-Wei Sun's paper `Restricted sums of four squares`, arXiv:1701.05868, poses the representation conjecture involving \(a^2+b^2+3^c+5^d\).

**Applicability:** status/origin only; no complete private-incidence theorem.

## 2. Combinatorial and entropy large sieve

E. Croot, J. Mao, C. Pohoata, A. Sheffer, and C. H. Yip, `A combinatorial large sieve for Sidon sets, distances, and norm forms`, arXiv:2606.17487v2 (2026), develops local-to-global and entropy methods for sets that are ill-distributed modulo every relevant prime and have bounded difference or algebraic multiplicity.

A private witness in the A303656 graph says only that one residue fiber at \(n\bmod q\) is a singleton. It does not bound the total number of residues occupied by \(\{3^c+5^d\}\bmod q\), and the complete survivor set is not known to satisfy the required bounded-multiplicity/ill-distribution hypotheses uniformly in adversarial \(n\).

**Verdict:** no direct application.

## 3. Large prime factors of well-distributed sequences

Abhishek Bharadwaj and Brad Rodgers, `Large prime factors of well-distributed sequences`, arXiv:2402.11884v4 (2026), studies random elements of sequences with explicit index, congruence-uniformity, and positive level-of-distribution hypotheses; examples include shifted primes and values of one-variable irreducible polynomials.

The A303656 object is a two-parameter, \(n\)-dependent complete survivor mask with only \(O((\log n)^2)\) active terms and no established level of distribution uniform in fixed adversarial \(n\). Even a distribution theorem for large prime factors would describe average factor sizes, not degree-one incidence across the simultaneous shift family.

**Verdict:** object and quantifier mismatch.

## 4. Largest prime factor of polynomial values

- J. Cuevas Barrientos and H. Pasten, `On the greatest prime factor of polynomial values and subexponential Szpiro in families`, arXiv:2504.15971 (2025; published 2026), treats fixed quadratic and special cubic polynomial values.
- I. Ermoshin, `The largest prime factor of an irreducible cubic polynomial`, arXiv:2602.03642 (2026), proves a positive-proportion result for values of a fixed monic irreducible cubic.

Neither theorem concerns a growing-degree product \(\prod_h(n-h)\), a two-dimensional exponential shift family, valuation parity, or private-versus-shared incidence.

**Verdict:** no direct application.

## 5. Correlations of sums of two squares

N. Kimmel and V. Kuperberg, `Positive density for consecutive runs of sums of two squares`, arXiv:2406.04174v2 (2025), explicitly notes that estimates for two-point correlations of the standard indicator of sums of two squares are not known and instead uses Hooley's weighted \(\rho\)-function.

This blocks a tempting attempt to estimate the complete survivor denominator or the good subset by unproved uniform two-point correlations. The present negative theorem avoids that issue by using only the one-point Landau–Ramanujan count and a prime-in-progression count.

## 6. S-unit equations

J.-H. Evertse, H. P. Schlickewei, and W. M. Schmidt, `Linear equations in variables which lie in a multiplicative group`, Annals of Mathematics 155 (2002), 807–836, gives uniform finiteness for nondegenerate S-unit equations.

This could imply finiteness of nontrivial global shift collisions after a suitable reduction. It is not needed here: the elementary \(3\)-adic high-\(c\) lemma is quantitative in the active box.

## 7. Primitive divisors

Classical primitive-divisor theory is designed to prove existence of new prime divisors in recurrence terms. It supplies no theorem suppressing distinct degree-one primes across \(n-3^c-5^d\); its qualitative direction is the opposite.

## 8. Audit conclusion

No primary-source theorem located by 2026-07-21 directly bounds

\[
\operatorname{Pvt}_z(S(n,z),n)
\]

uniformly for the complete actual survivor set in fixed adversarial \(n\). More importantly, Theorem PW-A proves that the desired \(o(|S|)\) conclusion is false at \(z=\lfloor\sqrt n\rfloor\).

## Source identifiers

- OEIS A303656: `https://oeis.org/A303656`
- Sun: `https://arxiv.org/abs/1701.05868`
- Croot–Mao–Pohoata–Sheffer–Yip: `https://arxiv.org/abs/2606.17487`
- Large prime factors of well-distributed sequences: `https://arxiv.org/abs/2402.11884`
- Cuevas Barrientos–Pasten: `https://arxiv.org/abs/2504.15971`
- Ermoshin: `https://arxiv.org/abs/2602.03642`
- Kimmel–Kuperberg: `https://arxiv.org/abs/2406.04174`
- Evertse–Schlickewei–Schmidt: `https://annals.math.princeton.edu/2002/155-3/p04`
