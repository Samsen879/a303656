#!/usr/bin/env python3
"""Small exact sanity checks. This is not a proof search and does not enumerate large primes."""
from __future__ import annotations
from collections import defaultdict, Counter
from pathlib import Path
import json, math

ROOT = Path(__file__).resolve().parents[1]


def v_p(x: int, p: int) -> int:
    if x == 0:
        raise ValueError('v_p(0) is not used')
    v = 0
    while x % p == 0:
        x //= p
        v += 1
    return v


def factor(n: int) -> dict[int, int]:
    out: dict[int, int] = {}
    p = 2
    while p * p <= n:
        while n % p == 0:
            out[p] = out.get(p, 0) + 1
            n //= p
        p = 3 if p == 2 else p + 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def is_two_square(n: int) -> bool:
    if n == 0:
        return True
    return all(not (p % 4 == 3 and e % 2 == 1) for p, e in factor(n).items())


def check_lte(limit: int = 200) -> dict:
    for v in range(1, limit + 1):
        actual = v_p(pow(5, v) - 1, 3)
        predicted = 0 if v % 2 else 1 + v_p(v // 2, 3)
        if actual != predicted:
            raise AssertionError((v, actual, predicted))
    return {'name': 'LTE formula', 'limit': limit, 'status': 'PASS'}


def check_high_c_injectivity(X: int = 10**8) -> dict:
    C = 2 + math.floor(math.log(math.log(2 * X, 5), 3))
    pairs = []
    cmax = math.floor(math.log(2 * X, 3))
    dmax = math.floor(math.log(2 * X, 5))
    seen = {}
    for c in range(C, cmax + 1):
        for d in range(dmax + 1):
            h = 3**c + 5**d
            if h <= 2 * X:
                if h in seen:
                    raise AssertionError((h, seen[h], (c, d), C))
                seen[h] = (c, d)
                pairs.append((c, d))
    return {'name': 'high-c injectivity finite sanity', 'X': X, 'C_X': C, 'pair_count': len(pairs), 'status': 'PASS'}


def check_unique_core(X: int = 10**8) -> dict:
    K = 1 + math.floor(math.log(math.log(2 * X, 5), 3))
    C = K + 1
    cmax = math.floor(math.log(2 * X, 3))
    dmax = math.floor(math.log(2 * X, 5))
    by_shift: dict[int, list[tuple[int, int]]] = defaultdict(list)
    active_pairs = []
    for c in range(cmax + 1):
        for d in range(dmax + 1):
            h = 3**c + 5**d
            if h <= 2 * X:
                by_shift[h].append((c, d))
                active_pairs.append((c, d, h))
    rectangle = []
    for c in range(C, math.floor(math.log(X / 8, 3)) + 1):
        for d in range(math.floor(math.log(X / 8, 5)) + 1):
            h = 3**c + 5**d
            rectangle.append((c, d, h))
    unique_core = [x for x in rectangle if len(by_shift[x[2]]) == 1]
    removed = len(rectangle) - len(unique_core)
    low_pairs = sum(c <= K for c, d, h in active_pairs)
    duplicate_vertices = sum(len(v) for v in by_shift.values() if len(v) > 1)
    if removed > low_pairs:
        raise AssertionError((removed, low_pairs))
    if duplicate_vertices > 2 * low_pairs:
        raise AssertionError((duplicate_vertices, low_pairs))
    if len({h for _, _, h in unique_core}) != len(unique_core):
        raise AssertionError('unique core has repeated shifts')
    return {
        'name': 'globally unique high-c core finite sanity',
        'X': X,
        'K_X': K,
        'rectangle_pairs': len(rectangle),
        'removed_collision_prone': removed,
        'unique_core_pairs': len(unique_core),
        'low_c_pairs': low_pairs,
        'duplicate_class_vertices': duplicate_vertices,
        'status': 'PASS',
    }


def complete_graph_stats(n: int) -> dict:
    z = math.isqrt(n)
    shifts = set()
    c = 0
    while 3**c + 1 <= n:
        d = 0
        while 3**c + 5**d <= n:
            shifts.add(3**c + 5**d)
            d += 1
        c += 1
    survivors = []
    for h in sorted(shifts):
        r = n - h
        if r == 0:
            survivors.append((h, r, []))
            continue
        fs = factor(r)
        small_bad = [p for p, e in fs.items() if p <= z and p % 4 == 3 and e % 2]
        if not small_bad:
            large_bad = [p for p, e in fs.items() if p > z and p % 4 == 3 and e % 2]
            survivors.append((h, r, large_bad))
    degrees = Counter(p for _, _, ps in survivors for p in ps)
    G = sum(is_two_square(r) for _, r, _ in survivors)
    P = sum(any(degrees[p] == 1 for p in ps) for _, _, ps in survivors)
    J = sum(degrees[p] for p in degrees if degrees[p] >= 2)
    if len(survivors) != G + P + J:
        raise AssertionError((n, len(survivors), G, P, J, survivors, degrees))
    for _, r, ps in survivors:
        if not is_two_square(r):
            if len(ps) != 1 or factor(r)[ps[0]] != 1 or ps[0] <= z:
                raise AssertionError((n, r, ps, factor(r)))
    return {'n': n, 'z': z, 'S': len(survivors), 'G': G, 'Pvt': P, 'J': J, 'identity': True}


def check_square_root_identity() -> dict:
    rows = [complete_graph_stats(n) for n in (1000, 12345, 99991)]
    return {'name': 'square-root identity finite sanity', 'rows': rows, 'status': 'PASS'}


def check_product_derivative() -> dict:
    shifts = [2, 5, 11, 20]
    tests = []
    for n in (32, 35, 47, 77):
        factors = [n - h for h in shifts]
        F = math.prod(factors)
        Fp = sum(math.prod(factors[:i] + factors[i+1:]) for i in range(len(factors)))
        primes = set()
        for x in factors:
            primes.update(factor(abs(x)).keys())
        for q in primes:
            degree = sum(x % q == 0 for x in factors)
            if (F % q == 0 and Fp % q != 0) != (degree == 1):
                raise AssertionError((n, q, degree, F, Fp))
            if (F % q == 0 and Fp % q == 0) != (degree >= 2):
                raise AssertionError((n, q, degree, F, Fp))
        tests.append({'n': n, 'factor_count': len(factors), 'prime_count': len(primes)})
    return {'name': 'product-derivative dichotomy', 'tests': tests, 'status': 'PASS'}


def main() -> None:
    checks = [check_lte(), check_high_c_injectivity(), check_unique_core(), check_square_root_identity(), check_product_derivative()]
    result = {'status': 'PASS', 'scope': 'small exact sanity only; no T(n) search; no large prime enumeration', 'checks': checks}
    out = ROOT / 'results' / 'verification.json'
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
