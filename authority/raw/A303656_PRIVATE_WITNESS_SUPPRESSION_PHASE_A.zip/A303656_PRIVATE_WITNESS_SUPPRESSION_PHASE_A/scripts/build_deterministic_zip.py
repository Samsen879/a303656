#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import sys, zipfile

FIXED_TIME = (1980, 1, 1, 0, 0, 0)


def build(root: Path, output: Path) -> None:
    root = root.resolve()
    output = output.resolve()
    files = sorted(p for p in root.rglob('*') if p.is_file() and p.resolve() != output)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=True) as zf:
        for p in files:
            arc = f'{root.name}/{p.relative_to(root).as_posix()}'
            info = zipfile.ZipInfo(arc, FIXED_TIME)
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100644 << 16)
            info.flag_bits |= 0x800
            zf.writestr(info, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('usage: build_deterministic_zip.py ROOT OUTPUT.zip')
    build(Path(sys.argv[1]), Path(sys.argv[2]))
