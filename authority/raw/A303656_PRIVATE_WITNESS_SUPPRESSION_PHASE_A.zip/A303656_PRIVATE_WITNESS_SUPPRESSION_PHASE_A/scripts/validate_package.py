#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import hashlib, json, sys


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def main(root: Path) -> None:
    root = root.resolve()
    failures = []
    for line in (root / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        digest, rel = line.split('  ', 1)
        p = root / rel
        if not p.is_file() or sha256(p) != digest:
            failures.append(rel)
    controls = []
    for p in root.rglob('*'):
        if p.is_file() and p.suffix.lower() in {'.md', '.txt', '.json', '.csv', '.tsv', '.tex', '.py'}:
            for i, b in enumerate(p.read_bytes()):
                if b < 32 and b not in (9, 10, 13):
                    controls.append({'file': str(p.relative_to(root)), 'offset': i, 'byte': b})
    verdict = json.loads((root / 'PROMOTION_VERDICT.json').read_text(encoding='utf-8'))['verdict']
    if verdict != 'STOP PRIVATE-WITNESS TRIGGER':
        failures.append('promotion verdict mismatch')
    result = {'sha256_failures': failures, 'forbidden_control_bytes': controls, 'verdict': verdict}
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    if failures or controls:
        raise SystemExit(1)


if __name__ == '__main__':
    main(Path(sys.argv[1] if len(sys.argv) > 1 else '.'))
