# PRODUCT, GCD, RESULTANT, AND DISCRIMINANT AUDIT

Let \(H\) be a set of distinct shifts and

\[
F(T)=\prod_{h\in H}(T-h).
\]

For a prime \(q\), the following dichotomy is exact.

## Lemma PR

- \(q\) divides exactly one remainder \(n-h\) if and only if
  \[
  q\mid F(n),\qquad q\nmid F'(n).
  \]
- \(q\) divides at least two distinct remainders if and only if
  \[
  q\mid F(n),\qquad q\mid F'(n).
  \]

### Proof

Modulo \(q\), in

\[
F'(n)=\sum_{h\in H}\prod_{k\in H\setminus\{h\}}(n-k),
\]

exactly one term survives when exactly one factor of \(F(n)\) vanishes. If at least two factors vanish, every summand vanishes. ∎

Since

\[
\operatorname{Res}(F,F')=\pm\operatorname{Disc}(F)
=\pm\prod_{h<k}(h-k)^2,
\]

every prime in \(\gcd(F(n),F'(n))\) is a shift-difference/discriminant prime. A Bézout identity for \(F,F'\) therefore bounds only **shared** divisibility. A private witness is precisely a separable simple root of \(F\bmod q\) at \(T=n\); it is deliberately absent from the discriminant and resultant.

## Consequences for proposed tools

- **Product of all survivor remainders:** records private primes but gives no cancellation or upper bound on their count.
- **gcd/resultant and shift differences:** equivalent in content to shared-incidence control; they cannot see degree-one fibers.
- **determinant method:** a determinant built from common congruences likewise detects multiple points on the same residue fiber. Singleton fibers supply no pair or low-degree incidence to count.
- **squarefree kernel:** a private exact-one prime appears once in the bad squarefree kernel, but no relation forces different kernels to share factors.

## Product-size barrier

At \(z=\lfloor\sqrt n\rfloor\), if there are \(P\) private vertices, their private primes are distinct and exceed \(\sqrt n\), so

\[
\prod_{i=1}^P q_i>n^{P/2}.
\]

The corresponding remainders satisfy

\[
\prod_{i=1}^P(n-h_i)\le n^P.
\]

There is a full factor-of-two exponent gap, not a contradiction. Replacing each remainder by its squarefree kernel does not close this gap. The congruences \(n\equiv h_i\pmod{q_i}\) are also self-selected by the factorization of the actual remainders; treating them as independent externally imposed CRT information is invalid.
