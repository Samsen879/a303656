# COUNTERMODELS AND SCOPE CORRECTIONS

## A. Complete-actual-set obstruction — promoted as a negative theorem

Theorem PW-A concerns the full set \(S(n,\lfloor\sqrt n\rfloor)\). A collision-free interior core supplies candidate survivors, but:

- membership is checked using the actual valuation mask;
- privacy is checked against every active shift in \(D(n)\);
- the denominator is the full unmerged exponent-pair survivor set;
- no CRT chooses or deletes survivor vertices.

It therefore answers the arbitrary-subset objection directly.

## B. Arbitrary-subset private-witness CRT — retained only as a boundary model

The preceding phase proved that a selected finite list of distinct shifts can be assigned distinct exact-one private primes by CRT. That theorem remains correct, but it is not evidence about the complete survivor set and is not used to prove PW-A. Its only role here is to explain why a theorem based on arbitrary subsets would be false.

## C. Helly scope correction

The previous Helly no-go applies to finite active-shift restrictions and finite chosen mask families. It is not a universal Helly theorem for the complete infinite exponent domain or for every realization of \(\mathcal D(n)\).

## D. Fixed-order moment scope correction

The fixed-order moment indistinguishability example is an abstract finite-torus countermodel. It is not claimed to be an actual A303656 valuation-mask realization.

## E. Simultaneous-selection archive defect

The supplied simultaneous-selection ZIP passes its internal SHA256 manifest, but `REPORT.md` contains byte `0x0c` at offset 1950, replacing the backslash in `\frac`. It must not be described as a defect-free final archive. The supplied p2-cover ZIP has the same class of defect in `REPORT_zh.md` at offset 3288. These are content/encoding defects, not hash mismatches.

## F. Shift collisions and multiplicities

Theorem PW-A is proved on the unmerged pair graph. Its high-\(c\) lemma removes the \(O(\log X\log\log X)\) collision-prone fringe and leaves \(\asymp(\log X)^2\) shifts that have multiplicity one against the whole active domain. The distinct-shift quotient version follows automatically. No universal injectivity claim is made.
