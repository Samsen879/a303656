# LITERATURE AUDIT

Search date: `2026-07-17`.  Search priority was primary sources and exact
versions.  The audit covered minimal-counterexample descent, S-unit and
exponential Diophantine finiteness, primitive divisors, Skolem–Mahler–Lech,
finite-state/Presburger structures, covering systems, and sums of two squares
plus powers.

## Crosswalk

| source | exact version / theorem | hypotheses and conclusion | effectivity | variables / prime support may grow? | actual quantifier compression for A303656? | exact mismatch |
|---|---|---|---|---|---|---|
| Roger Clement Crocker, *On the Sum of Two Squares and Two Powers of k*, Colloq. Math. 112 (2008), DOI `10.4064/cm112-2-3` | Lemma 1, pp. 236ff | For `k=2`, if `t=0 mod 36` is nonrepresentable by two squares plus at most two powers of 2, then every `2^alpha t` is likewise nonrepresentable | explicit descent family | fixed same base `2`; no moving prime set | comparator only | proof uses homogeneous scaling that lowers both powers of 2 simultaneously; mixed bases `3,5` have no common nontrivial scale |
| J.-H. Evertse, H. P. Schlickewei, W. M. Schmidt, *Linear equations in variables which lie in a multiplicative group*, Ann. Math. 155 (2002), arXiv `math/0409604v1` (30 Sep 2004) | Theorem 1.1 | For a fixed linear equation `a_1x_1+...+a_nx_n=1` in a finite-rank multiplicative group, the number of nondegenerate solutions is bounded explicitly in terms of `n,r` | explicit count, not height bound for arbitrary moving data | rank fixed in the theorem; equation fixed | NO | A303656 has moving `n`, a growing family of pairs, arbitrary cofactor support, and no fixed finite-rank group containing all remainders |
| Yann Bugeaud, Kálmán Győry, *Bounds for the solutions of unit equations*, Acta Arith. 74.1 (1996), 67–80 | unnumbered theorem in §2 for `alpha x+beta y=1`, plus corollary | fixed number field, fixed finite place set `S`, fixed coefficients; gives explicit height bounds for `S`-unit solutions | YES | `S` is fixed input; does not grow with a candidate solution | NO | Fermat obstruction supplies one odd bad prime, not a complete fixed `S`-support; `n` and all other factors move |
| Paul M. Voutier, *Primitive divisors of Lucas and Lehmer sequences, II*, JTNB 8.2 (1996), 251–274 | Theorem 1 | under bounded-height hypothesis, Lucas/Lehmer term number `n>30` has a primitive divisor | effective in its fixed-sequence setting | fixed one-index divisibility sequence | NO | primitive divisor need not be `3 mod 4`, need not occur to odd valuation, and divides a sequence term/difference rather than every moving remainder |
| Seymour Ginsburg, Edwin H. Spanier, *Semigroups, Presburger formulas, and languages*, Pacific J. Math. 16.2 (1966) | Theorem 1.3 | Presburger-definable subsets of `N^d` are exactly semilinear sets; descriptions are effectively interconvertible | YES | fixed formula / finite periods | negative leverage | `{3^c+5^d}` has `O(log^2 X)` growth and is not semilinear; ordinary Presburger arithmetic cannot supply the desired global state system |
| Bob Hough, *Solution of the minimum modulus problem for covering systems*, Ann. Math. 181 (2015), 361–382 | Theorem 1 | the least modulus of an already existing distinct covering system is at most `10^16` | explicit | starts from one finite covering system | NO | does not prove that the moving exponent grid has a finite bad-prime cover or bound its witness support |
| Shuo Li, *The characteristic sequence of the integers that are the sum of two squares is not morphic*, arXiv `2404.08822v1` (12 Apr 2024) | Theorem 5 | the characteristic sequence of `S_2` is not morphic | qualitative | one fixed global sequence | negative leverage | rules out a direct morphic exact encoder; does not rule out certificate-dependent finite automata after fixing `Q,E` |
| Toghrul Karimov, Florian Luca, Joris Nieuwveld, Joël Ouaknine, James Worrell, *On the Decidability of Presburger Arithmetic Expanded with Powers*, arXiv `2407.05191v2` (20 Jul 2025) | Theorem 1; Theorem 2 | existential theory of addition/order with two unary power predicates is decidable; replacing predicates by power functions has strong digit-pattern hardness consequences | algorithmic for the predicate language | fixed formula, two fixed bases | NO | language is linear and does not contain `x=a^2+b^2`; counterexample existence also has universal coverage over all active pairs |
| Piotr Bacik, *Completing the Picture for the Skolem Problem on Order-4 Linear Recurrence Sequences*, TheoretiCS 4 (2025), Article 28, published 2 Dec 2025 | Theorem 4.1 | Skolem problem decidable for algebraic LRS with at most four distinct characteristic roots, hence order at most four | YES in this restricted class | fixed one-dimensional LRS | NO | no fixed order-4 LRS encodes the bivariate moving-`n` two-square obstruction; general order five remains open |
| Piotr Bacik, Joël Ouaknine, David Purser, James Worrell, *On the p-adic Skolem Problem*, arXiv `2504.14413v4` (11 May 2026), STACS 2026 Article 51 | Theorems 4 and 5 | p-adic Skolem decision/function problems and coprime simultaneous Skolem are decidable/computable assuming p-adic Schanuel | output correctness unconditional; termination conditional | fixed LRS and fixed prime `p` | NO | hypothesis is conjectural; authors state it does not solve classical Skolem; no encoding of all A303656 pairs or odd valuations is supplied |
| OEIS A303656, current entry accessed 17 Jul 2026 | conjecture metadata | records the universal representation conjecture and current public computational notes | not a theorem | not applicable | NO | computational verification, irrespective of range, is not a least-exception theorem |

## Search-area findings

### 1. Minimal counterexample and descent

The closest exact structural comparator found was Crocker's same-base powers-
of-two descent.  Its proof divides both power terms and the two-square term by
`2` after parity analysis.  The mixed pair `3^c,5^d` has no common nontrivial
scale, and the first active shifts already forbid a common square divisor.
No primary theorem was found that turns failure of a sparse mixed-base
additive representation into a smaller failure.

### 2. Exponential Diophantine finite reduction

Effective S-unit theorems are genuinely effective when the equation and finite
prime support are fixed.  Evertse–Schlickewei–Schmidt gives uniform *counts* of
nondegenerate solutions in finite-rank groups, but not a bound that first
creates a fixed group from the A303656 obstruction.  Primitive-divisor results
control fixed divisibility sequences, not a growing two-parameter family of
remainders.  No audited theorem supplies a uniform bad-prime set and valuation
depth.

### 3. Finite-state and automatic structures

For each fixed modulus, powers of `3` and `5` are eventually periodic, and the
Karimov et al. theorem shows substantial decidability for linear formulas with
two power predicates.  This does not include the quadratic norm predicate.
Ginsburg–Spanier and Li give precise negative information against the simplest
global semilinear/morphic encodings.  A finite automaton is valid only after
fixing `Q,E`; it is not a theorem that such data are uniform.

### 4. Covering systems and compactness

Hough's theorem is conditional on the existence of a finite distinct covering
system.  It is not a finite-subcover theorem for arbitrary moving local
obstructions.  Hypergraph/set-cover duality can optimize a finite instance,
but cannot create an absolute universe or prime bound.  The frozen `p^2`
authority remains the applicable computational result and was not reopened.

### 5. Two-square obstructions

The classical odd-valuation criterion gives a local witness for each
remainder.  Shuo Li's theorem shows the full characteristic sequence is not
morphic.  Crocker shows that same-base homogeneous structure can create an
exceptional descent family, but that mechanism does not survive mixed bases.
No pointwise obstruction theorem was found that synchronizes the witnesses of
all `O(log^2 n)` active pairs.

## Effectivity audit

The sources divide sharply:

- **effective but fixed-data:** Bugeaud–Győry, low-order Skolem, Presburger with
  two power predicates, Hough after a cover exists;
- **finite/counting but not the required height reduction:**
  Evertse–Schlickewei–Schmidt;
- **conditional effectivity:** p-adic Skolem under p-adic Schanuel;
- **qualitative negative structure:** Ginsburg–Spanier, Shuo Li;
- **structurally mismatched descent:** Crocker;
- **fixed divisibility sequence:** Voutier.

None proves `CRW(Q,E)` or `UBVC(Q,E)`, an explicit least A303656 exception
bound, or an unconditional finite list of obstruction certificates.

## Literature conclusion

No audited primary source crosses the promotion gate.  The only precise
literature-watch trigger is:

> a theorem giving an explicit finite bad-prime set and an explicit odd
> valuation-depth bound for the fixed canonical representative remainders of
> every sufficiently large A303656 counterexample (`CRW(Q,E)`), or a still
> weaker theorem that forces the state-certificate descent inequality.

Absent such a theorem, S-unit, Skolem, automata, and covering-system citations
do not compress the A303656 quantifiers.

## Locked URLs

Exact URLs, version dates, theorem identifiers, and local PDF hashes are in
`WEB_SOURCES_LOCK.json` and `SOURCE_PDF_HASHES.tsv`.
