# MINIMAL-COUNTEREXAMPLE CONSTRAINTS

Assume throughout that `n_0` is a least integer `>1` with `T(n_0)=0`.
Classifications are deliberately separated into `PROVED`, `TRIVIAL`,
`EXPERIMENTALLY FALSIFIED`, and `CONJECTURAL / NOT ESTABLISHED`.

## A. PROVED necessary conditions

### MC-1 — lower bound

`n_0 >= 7`.

The integers `2,...,6` have immediate representations, for example:

- `2=0^2+0^2+1+1`;
- `3=1^2+0^2+1+1`;
- `4=1^2+1^2+1+1`;
- `5=1^2+0^2+3+1`;
- `6=2^2+0^2+1+1`.

This tiny check is used only to initialize minimality, not as search evidence.

### MC-2 — strict positivity of every active remainder

For every active `(c,d)`,

\[
n_0-3^c-5^d>0.
\]

Equality would give the allowed two-square remainder `0`.

### MC-3 — odd bad-prime witness

For every active pair, some prime `q=3 (mod 4)` satisfies

\[
v_q(n_0-3^c-5^d)\equiv1\pmod2.
\]

The witness may depend on `(c,d)`.

### MC-4 — at least three distinct witness primes

The active shifts `2,4,6` have pairwise differences `2,2,4`.  By the collision
lemma, one prime `q=3 (mod 4)` cannot witness two of these remainders.  Thus
any complete witness assignment for `n_0` uses at least three distinct primes.

### MC-5 — witness collision valuation law

If the same prime `q` witnesses shifts `h != h'`, then `q | h-h'`.  If the two
odd valuations are unequal, the valuation of `h-h'` equals their minimum.
This is the only unconditional synchronization obtained from sharing a prime.
It is a restriction on a *given* collision, not a theorem forcing collisions.

### MC-6 — no common square factor of all active remainders

Because `gcd(n_0-2,n_0-4) | 2`, no square `q^2>1` divides both, hence no
nontrivial square divides every active remainder.  A global divide-by-a-square
descent is therefore unavailable.

### MC-7 — exact minimality escape relation

For every `1 <= Delta <= n_0-2`, every representation of `n_0-Delta` uses a
shift `h` with `h+Delta` outside the shift set.  This is the full conclusion
of minimality; it is invalid to assume an arbitrary representation lifts.

### MC-8 — odd increments give no information

All shifts are even.  For odd `Delta` (including `3^u` and `5^v`) the condition
`h+Delta` is not a shift holds automatically.  Subtracting an odd amount and
invoking minimality is therefore vacuous unless an additional identity changes
the two-square part.

### MC-9 — every fixed even increment has infinitely many escape shifts

For each fixed even `Delta>0`, infinitely many shifts `h` have `h+Delta` not a
shift.  Hence subtraction by `2,4,8`, or any other fixed even increment cannot
be converted into a uniform descent merely by choosing a representation of
`n_0-Delta`.

### MC-10 — pointwise finite-state self-bound

For every complete finite state certificate `(Q,E)` attached to `n_0`, let
`H_{n_0}(Q,E)` and `L(Q,E)` be as in Theorem 8.  Minimality forces

\[
n_0\le H_{n_0}(Q,E)+L(Q,E).
\]

Otherwise the explicit state-certificate map produces a smaller
counterexample.  This is a genuine necessary condition, but it is not a
uniform bound because `Q,E` may grow with `n_0`.

## B. TRIVIAL constraints or extractions

### TR-1 — finite witness extraction for a fixed `n`

The active exponent domain is finite, so one can select one witness prime per
active pair.  Thus a witness set exists with

\[
|P(n)|\le |\mathcal H(n)|
\le(\lfloor\log_3(n-1)\rfloor+1)
   (\lfloor\log_5(n-1)\rfloor+1).
\]

This `O(log^2 n)` bound is not a compactness theorem and gives no finite
reduction: the primes and their valuation depths can still grow with `n`.

### TR-2 — parity

Every shift is even, so all active remainders have the same parity as `n_0`.
Both parities contain infinitely many sums of two squares and infinitely many
non-sums of two squares.  No parity restriction on `n_0` follows.

### TR-3 — divisibility by `3` or `5`

No forced divisibility of `n_0` by `3` or `5` was proved.  Prime `3` can witness
at most one of the three remainders at shifts `2,4,6`; prime `5` is not a
Fermat bad prime because `5=1 (mod 4)`.

## C. EXPERIMENTALLY FALSIFIED naive claims

The experiments are not proofs of the general no-go statements below; the
formal theorems are in `THEOREMS_AND_PROOFS.md`.  They supplied early stopping
counterexamples and implementation checks.

- total shift closure under `+Delta` for `Delta=2,3,4,5,8,9,25`;
- fixed affine preservation maps in a representative finite menu;
- a fixed modulus deciding `S_2` on locally admissible classes for
  `M=8,12,40`;
- a nontrivial common-square divisor across the first two active remainders.

## D. CONJECTURAL / NOT ESTABLISHED

None of the following was established and none may be used as a property of a
minimal counterexample:

- a uniformly bounded least bad prime;
- a uniformly bounded number of witness primes;
- a uniformly bounded odd valuation depth;
- a forced prime divisor of `n_0`;
- a common witness prime for a positive fraction of active pairs;
- a descent under division by a square or by a prime factor of `n_0`;
- an eventual fixed-modulus or automatic description of all obstructions.
