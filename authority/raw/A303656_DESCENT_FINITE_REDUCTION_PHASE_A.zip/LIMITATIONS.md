# LIMITATIONS

## 1. Mathematical limitations

- No unconditional counterexample, universal proof, descent theorem, or least-
  exception bound was obtained.
- The finite-state descent theorem assumes a complete finite bad-prime and
  valuation-depth certificate.  Uniform existence of such data is open.
- The designated-private-witness CRT lemma does not construct a genuine
  A303656 counterexample and does not prove that alternate shared witnesses are
  absent.
- The affine anti-lifting theorem rules out only finite fixed affine menus
  whose additive offsets are nonzero.  It does not rule out zero-offset
  multiplicative maps, nonlinear, adaptive, or exponent-dependent identities.
- Non-semilinearity and non-morphicity rule out direct fixed encodings, not all
  possible adaptive certificate automata.
- No theorem was proved forcing or excluding divisibility of a minimal
  counterexample by `3` or `5`.
- The pointwise state bound may be enormous and can be vacuous for the trivial
  certificate.

## 2. Literature limitations

- The search was broad but not exhaustive across all historical languages and
  all papers on additive complements of norm forms.
- Some classical two-square and LTE facts were used as standard background
  rather than locked to a particular original edition.
- The Crocker PDF was inspected through a web-accessible journal mirror; a
  local source PDF hash was not retained, while DOI, title, journal, date, and
  theorem text were locked.
- Recent papers were audited at the exact versions recorded in
  `WEB_SOURCES_LOCK.json`; later revisions may change theorem numbering or
  hypotheses.
- A negative literature search is not a proof that no suitable theorem exists.
  The conclusion is only that no such theorem was located in this controlled
  round.

## 3. Effectivity limitations

- Evertse–Schlickewei–Schmidt gives explicit solution counts, but this is not an
  effective exponent-height bound for the moving A303656 family.
- General Skolem–Mahler–Lech is ineffective; recent effective results are
  restricted or conditional.
- S-unit bounds become relevant only after a fixed support theorem, which is
  exactly missing.
- No computable absolute `N_*` for A303656 was established.

## 4. Computational limitations

- No long interval of `n` was scanned and no new finite verification claim was
  made.
- Experiments used trial factorization and small moduli only; they were designed
  to falsify lemmas, not measure conjecture likelihood.
- The toy finite-state example validates residue bookkeeping only and has no
  evidentiary value for `CRW` or `UBVC`.
- No independent second implementation was commissioned because no promoted
  computational theorem remained.

## 5. Strategic uncertainty

The strongest unresolved question exposed by the round is whether genuine
counterexamples, if they exist, have hidden global structure that defeats the
private-witness flexibility available to arbitrary finite remainder families.
The current methods neither prove such structure nor prove it cannot exist;
the designated-private-witness lemma alone is not evidence against alternative
shared witnesses.

Accordingly, `SPECULATIVE_WATCH_ONLY` is a research-governance verdict, not a
mathematical impossibility theorem.
