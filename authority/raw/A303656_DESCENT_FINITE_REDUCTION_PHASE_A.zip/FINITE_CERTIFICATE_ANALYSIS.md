# FINITE CERTIFICATE ANALYSIS

## 1. What a counterexample certificate must prove

For a specified integer `n`, a valid obstruction certificate must cover every
active pair

\[
(c,d)\in\mathcal H(n)=\{(c,d):3^c+5^d\le n\}
\]

and prove that the remainder is positive and has a prime `q=3 (mod 4)` at odd
valuation.  Certifying a truncated exponent box is invalid.

## 2. C1 — direct per-pair valuation certificate

A direct certificate may contain, for every active pair, a tuple

\[
(c,d,q,k)
\]

with `q` prime, `q=3 (mod 4)`, `k` odd, and

\[
q^k\parallel n-3^c-5^d.
\]

### Verifier requirements

An independent verifier must:

1. regenerate the full active exponent domain with exact integer arithmetic;
2. check that each active pair appears at least once;
3. check primality and `q mod 4`;
4. check divisibility by `q^k` and nondivisibility by `q^{k+1}`;
5. check positivity of every remainder;
6. reject duplicate rows only if they conceal a missing active pair.

No full factorization is required when one exact odd valuation is supplied.

### Status

`PROVED` as a verifier format, but `NO QUANTIFIER COMPRESSION`.  For fixed `n`
the domain is already finite, so existence of this certificate is trivial
under `T(n)=0`.  It does not find `n` or bound the least `n`.

## 3. C2 — grouped finite-state valuation certificate

Fix finite `Q` and `E>=2`.  Canonical exponent states modulo the orders of `3`
and `5` in the rings `Z/q^E Z` reduce all active pairs to at most

\[
(E+C)D
\]

representatives, where `C,D` are the lcm periods in Theorem 8.

A grouped certificate records one exact odd witness below depth `E` for each
canonical state occurring in the active domain.  Exact congruence modulo
`q^E` transfers the valuation to every pair in that state.

### Verifier requirements

1. compute `L,C,D` exactly;
2. enumerate the canonical state representatives occurring for `n`;
3. check one exact odd valuation `<E` for each state;
4. verify the representative map, including stabilization of `3^c mod 3^E`;
5. optionally evaluate the descent inequality
   `n>H_n(Q,E)+L(Q,E)`.

### Payoff

- Certificate validity implies `T(n)=0`.
- If the descent inequality holds, validity also certifies a smaller explicit
  counterexample `F(n)`.

### Status

`PROVED`.  It is a real finite-state verifier and a pointwise descent
certificate, but no theorem guarantees a small certificate for an unknown
counterexample.

## 4. C3 — canonical-representative witness condition `CRW(Q,E)`

This is the weakest uniform certificate target isolated in the round that
triggers a global finite reduction:

> There are fixed finite `Q` and `E` such that, for every counterexample above
> `N_*(Q,E)`, each of the fixed `(E+C)D` canonical representative remainders
> has an odd witness in `Q` below depth `E`.

If valid, the finite automaton, explicit descent map, and `N_*=H+L` follow from
Corollary 9.  State congruence then covers every active pair; the hypothesis
itself need not name witnesses for the growing active domain.

### Status

`NOT ESTABLISHED` as a uniform hypothesis; the conditional reduction is
`PROVED`.

The missing statement still includes numerical prime-support compression and
valuation-depth compression, but only across a fixed finite translation list.
No primary source or elementary argument supplied these bounds.

## 5. C4 — stronger uniform bounded valuation certificate `UBVC(Q,E)`

`UBVC(Q,E)` requires the bounded witness condition for every active remainder
of every counterexample.  It implies `CRW(Q,E)` and hence finite reduction, but
is stronger than necessary.

### Status

`NOT ESTABLISHED`.  Its natural proof attempts have high overlap with the
frozen finite-`p^2` cover program, whose bounded-order support is already
certified insufficient.  This round did not resume that optimization.

## 6. Prime certificates

### What is trivial

Selecting one witness prime per active pair gives at most `O(log^2 n)` primes.
This is merely finite extraction.

### What would be nontrivial

Any of the following, with explicit constants, would be new leverage:

- the fixed canonical representative remainders have witnesses in primes
  `q<=B` with odd valuation below an absolute `E` (`CRW`-type control);
- all witnesses can be chosen from primes `q<=B`;
- all witnesses can be chosen from one fixed finite `Q`;
- a fixed number of explicitly bounded primes covers all pairs;
- the maximum relevant odd valuation is bounded by an absolute `E`;
- the pointwise state-certificate descent inequality holds for every large
  counterexample.

None was proved.

## 7. Residue certificates

A fixed residue class modulo `M` cannot certify the exact two-square predicate
on all integers: every locally admissible class contains infinitely many
members and nonmembers of `S_2`.  Residues become conclusive only when they
include an exact odd valuation condition modulo a specified prime power.

Thus a residue certificate must name its witness primes and depths; “bad
modulo `M`” without such a valuation interpretation is insufficient.

## 8. Automata and finite states

### Valid finite-state object

For fixed `Q,E`, the product of the finite exponent orbits modulo `q^E` is a
valid automaton.  Its state count and transitions are explicit.

### Invalid global inference

There is no fixed global automaton until `Q,E` are fixed independently of `n`.
Eventual periodicity modulo every fixed modulus does not imply a single global
modulus.  The relevant valuations range over all primes `3 mod 4` and
unbounded powers.

## 9. Covering certificates

A finite covering certificate would assign to every exponent state at least
one odd-valuation congruence

\[
n-h(c,d)\equiv q^k u\pmod{q^{k+1}},\qquad q\nmid u,
\]

with consistent CRT data for `n`.

For a given finite state system this is independently verifiable.  What is not
available is a theorem guaranteeing that a global counterexample, if one
exists, admits such a system with bounded prime support and depth.  Repeating
the frozen `p^2` search is not a new certificate theorem.

## 10. Candidate validity versus candidate existence

The distinction is decisive:

- **Verifier theorem:** given `n,Q,E` and state rows, one can check validity.
- **Existence theorem:** every counterexample admits a bounded valid object.
- **Search theorem:** one can enumerate all possible objects inside an explicit
  bound and thereby decide counterexample existence.

This round proves the first and a conditional descent payoff.  It does not
prove the second or third.

## 11. Certificate verdict

The finite-state valuation certificate is the strongest exact object retained
for speculative watch.  It becomes a promotion trigger only if an independent
primary theorem or new proof supplies explicit `Q,E` satisfying `CRW`, or a
strictly weaker hypothesis that implies the descent inequality for every
sufficiently large counterexample.
