# SMALL FALSIFICATION-ORIENTED EXPERIMENTS

Script: `scripts/small_experiments.py`  
Output: `results/small_experiments.json`

The script deliberately performs **no interval search for `T(n)`**.  It does
not seek low-representation records or evidence for the conjecture.  Every
experiment has a proposed lemma or bookkeeping claim as a falsification
target.

## E1 — fixed affine maps

**Target.** A tested fixed affine map `s -> lambda*s+k` preserves `S_2` on all
sufficiently large `s in S_2`.

**Method.** Enumerate sums of two squares only up to a small bound and stop at
the first image carrying an odd `3 mod 4` prime valuation.

**Result.** Each tested map was falsified.  The general finite-menu no-go is
proved independently by CRT in Theorem 3; E1 is only an early counterexample
check.

## E2 — simultaneous affine CRT construction

**Target.** Verify the local-norm and CRT steps used in Theorem 3.

**Method.** For four prescribed affine maps and distinct primes, solve local
sum-of-two-squares residues modulo `q^2`, combine `x,y` by CRT, and check exact
valuation one in every image.

**Result.** Verified.

## E3 — designated private witnesses

**Target.** Verify the CRT construction for shifts `2,4,6` while fixing
`n mod 8`.

**Result.** The constructed integer has exact designated private witnesses
`7,11,19` against the selected other shifts.  The output explicitly records
that alternative shared witnesses may still exist.

## E4 — fixed-modulus indistinguishability

**Target.** A fixed modulus decides `S_2` on all locally admissible residue
classes.

**Method.** For `M=8,12,40`, find one small sum of two squares and one small
non-sum in every locally admissible class.

**Result.** Falsified in all tested classes.  The general theorem is proved by
CRT.

## E5 — common square divisor

**Target.** A nontrivial square might divide both first remainders.

**Method.** Check `gcd(n-2,n-4)` for `5<=n<=200`.

**Result.** Always divides `2`; this merely checks the implementation of the
exact identity.

## E6 — shift translation closure

**Target.** For fixed `Delta`, every shift remains a shift after `+Delta`.

**Method.** Generate shifts only up to `2,000,000` and record early liftable and
escape examples for `Delta=2,3,4,5,8,9,25`.

**Result.** Falsified for every tested increment.  The proof that every fixed
even increment has infinitely many escapes is noncomputational.

## E7 — toy bounded-valuation finite states

**Target.** Check the exponent-state bookkeeping for `Q={3,7}`, `E=2`,
including the special `q=3` tail.

**Result.** The script obtained

- `L=441`;
- `C=D=42`;
- `1848` combined states;
- no residue mismatch in the stated test window;
- an explicit, extremely large toy `H` and `N_*`.

This does not test `CRW`, `UBVC`, counterexample existence, or the finite-reduction
hypothesis.  It only validates state formulas.

## E8 — three forced witnesses

**Target.** Verify that differences among shifts `2,4,6` have no prime divisor
`3 mod 4`.

**Result.** Verified.

## Replay

From the package root:

```bash
python3 scripts/small_experiments.py
```

The output is deterministic under the recorded Python version.  Package
validation replays the script and compares the generated JSON byte-for-byte.
