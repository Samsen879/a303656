#!/usr/bin/env python3
"""Build a byte-deterministic ZIP from the Phase-A package directory."""
from __future__ import annotations

import argparse
import stat
import zipfile
from pathlib import Path

FIXED_TIME = (2000, 1, 1, 0, 0, 0)


def build(root: Path, output: Path) -> None:
    root = root.resolve()
    output = output.resolve()
    files = sorted(p for p in root.rglob("*") if p.is_file())
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=True) as zf:
        zf.comment = b""
        for path in files:
            rel = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(rel, FIXED_TIME)
            info.create_system = 3
            mode = 0o755 if rel.startswith("scripts/") and rel.endswith(".py") else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            info.flag_bits = 0x800  # UTF-8 names
            info.extra = b""
            info.comment = b""
            zf.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    build(args.root, args.output)
    print(args.output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
