#!/usr/bin/env python3
"""Validate the A303656 Phase-A research package without external services."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

REQUIRED = {
    "README.md",
    "EXECUTIVE_VERDICT.md",
    "INPUT_AUDIT.md",
    "THEOREMS_AND_PROOFS.md",
    "MINIMAL_COUNTEREXAMPLE_CONSTRAINTS.md",
    "DESCENT_CANDIDATES.md",
    "FINITE_REDUCTION_CANDIDATES.md",
    "FINITE_CERTIFICATE_ANALYSIS.md",
    "LITERATURE_AUDIT.md",
    "NO_GO_RESULTS.md",
    "SMALL_EXPERIMENTS.md",
    "CANDIDATE_SCORECARD.csv",
    "PROMOTION_VERDICT.json",
    "NO_ROUTE_PROMOTED.md",
    "REPORT.md",
    "LIMITATIONS.md",
    "ENVIRONMENT_RECORD.json",
    "WEB_SOURCES_LOCK.json",
    "SOURCE_PDF_HASHES.tsv",
    "REPRODUCIBILITY.md",
    "PACKAGE_FILE_LIST.txt",
    "SHA256SUMS.txt",
    "JSON_VALIDATION.txt",
    "ZIP_INTEGRITY.txt",
    "scripts/small_experiments.py",
    "scripts/validate_package.py",
    "scripts/build_deterministic_zip.py",
    "results/input_integrity.txt",
    "results/small_experiments.json",
}

SCORECARD_COLUMNS = [
    "candidate_id",
    "candidate_type",
    "exact_statement_available",
    "quantifier_compression_0_5",
    "effectivity_0_5",
    "proof_support_0_5",
    "novelty_0_5",
    "closed_route_overlap_risk_0_5",
    "small_test_status",
    "classification",
    "promotion_status",
]


ALLOWED_CLASSIFICATIONS = {
    "PROVED",
    "PROVED CONDITIONAL ON CITED THEOREM",
    "PLAUSIBLE BUT CORE LEMMA OPEN",
    "FALSE",
    "CIRCULAR / EQUIVALENT TO ORIGINAL",
    "INEFFECTIVE",
    "NO QUANTIFIER COMPRESSION",
    "NOT ESTABLISHED",
}

EXPECTED_INPUT_HASHES = {
    "A303656_GLOBAL_ROUTE_RESET(2).zip": "b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13",
    "A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN.zip": "aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2",
    "a303656_p2cover_bundle.zip": "4dadb8ce07cd0ccf56575ef0882d6bb02284a02c61e05cd1424e070d83b22ff3",
    "analytic_bad_prime_phaseA.zip": "9dd538f5d47a4d2327159b619af7db752f241421caef926207e623be6a8b1ec2",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def fail(message: str) -> None:
    raise RuntimeError(message)


def validate(root: Path, check_checksums: bool = True) -> list[str]:
    log: list[str] = []
    present = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    missing = sorted(REQUIRED - present)
    if missing:
        fail(f"missing required files: {missing}")
    log.append(f"required_files=PASS ({len(REQUIRED)} required paths)")

    verdict = json.loads((root / "PROMOTION_VERDICT.json").read_text(encoding="utf-8"))
    required_verdict = {
        "schema": "a303656-descent-finite-reduction-phase-a-v1",
        "global_problem_status": "UNRESOLVED",
        "decision": "SPECULATIVE_WATCH_ONLY",
        "promoted_candidate_id": None,
        "exact_target_theorem": None,
        "quantifier_compression_established": False,
        "effectivity_established": False,
        "codex_authorized": False,
        "ultra_authorized": False,
    }
    for key, value in required_verdict.items():
        if verdict.get(key) != value:
            fail(f"PROMOTION_VERDICT mismatch for {key}: {verdict.get(key)!r}")
    log.append("promotion_verdict_schema=PASS")

    json_paths = sorted(p for p in root.rglob("*.json") if p.is_file())
    for path in json_paths:
        json.loads(path.read_text(encoding="utf-8"))
    log.append("json_parse=PASS (" + ", ".join(p.relative_to(root).as_posix() for p in json_paths) + ")")

    with (root / "CANDIDATE_SCORECARD.csv").open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != SCORECARD_COLUMNS:
            fail(f"scorecard columns mismatch: {reader.fieldnames}")
        rows = list(reader)
    if not rows or len({r["candidate_id"] for r in rows}) != len(rows):
        fail("scorecard candidate IDs missing or duplicated")
    for row in rows:
        for col in SCORECARD_COLUMNS[3:8]:
            val = int(row[col])
            if not 0 <= val <= 5:
                fail(f"score out of range: {row['candidate_id']} {col}={val}")
        if row["classification"] not in ALLOWED_CLASSIFICATIONS:
            fail(f"invalid candidate classification: {row['candidate_id']}={row['classification']!r}")
        if row["promotion_status"] != "NO":
            fail(f"unexpected promoted scorecard row: {row['candidate_id']}")
    by_id = {row["candidate_id"]: row for row in rows}
    if by_id.get("F1-CRW", {}).get("classification") != "PLAUSIBLE BUT CORE LEMMA OPEN":
        fail("F1-CRW scorecard classification missing or inconsistent")
    log.append(f"scorecard=PASS ({len(rows)} candidates; controlled vocabulary)")

    audit = (root / "INPUT_AUDIT.md").read_text(encoding="utf-8")
    for filename, digest in EXPECTED_INPUT_HASHES.items():
        if filename not in audit or digest not in audit:
            fail(f"input audit missing {filename} or expected digest")
    log.append("input_hash_records=PASS")

    # Replay in an isolated temporary package copy so the authoritative output
    # is not touched before comparison.
    experiment_doc = json.loads((root / "results/small_experiments.json").read_text(encoding="utf-8"))
    purpose = experiment_doc.get("purpose", "")
    if "no T(n) interval search" not in purpose:
        fail("small-experiment purpose does not preserve the no-search boundary")
    if "finite_state_toy" not in experiment_doc.get("experiments", {}):
        fail("finite-state bookkeeping experiment missing")
    expected = (root / "results/small_experiments.json").read_bytes()
    with tempfile.TemporaryDirectory(prefix="a303656-replay-") as td:
        replay_root = Path(td) / root.name
        shutil.copytree(root, replay_root)
        proc = subprocess.run(
            [sys.executable, str(replay_root / "scripts/small_experiments.py")],
            cwd=replay_root,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
        )
        if proc.returncode != 0:
            fail(f"small experiment replay failed: {proc.stderr}")
        actual = (replay_root / "results/small_experiments.json").read_bytes()
    if actual != expected:
        fail("small experiment replay is not byte-identical")
    log.append(f"small_experiment_replay=PASS (sha256={hashlib.sha256(expected).hexdigest()})")

    file_list_lines = [line.strip() for line in (root / "PACKAGE_FILE_LIST.txt").read_text(encoding="utf-8").splitlines() if line.strip()]
    if file_list_lines != sorted(present):
        fail("PACKAGE_FILE_LIST.txt does not exactly match sorted internal files")
    log.append(f"package_file_list=PASS ({len(file_list_lines)} files)")

    if check_checksums and (root / "SHA256SUMS.txt").stat().st_size:
        checksum_rows = []
        for line in (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            digest, rel = line.split("  ", 1)
            checksum_rows.append((digest, rel))
        expected_paths = sorted(p for p in present if p != "SHA256SUMS.txt")
        if [rel for _, rel in checksum_rows] != expected_paths:
            fail("SHA256SUMS path set/order mismatch")
        for digest, rel in checksum_rows:
            if sha256(root / rel) != digest:
                fail(f"checksum mismatch: {rel}")
        log.append(f"internal_checksums=PASS ({len(checksum_rows)} files; SHA256SUMS.txt self-excluded)")
    else:
        log.append("internal_checksums=SKIPPED (bootstrap mode)")

    if (root / "PROMOTED_ROUTE_SPEC.md").exists():
        fail("PROMOTED_ROUTE_SPEC.md must not exist for a non-promotion verdict")
    log.append("nonpromotion_file_logic=PASS")
    return log


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--bootstrap", action="store_true", help="skip populated checksum validation")
    args = parser.parse_args()
    try:
        log = validate(args.root.resolve(), check_checksums=not args.bootstrap)
    except Exception as exc:  # noqa: BLE001
        print(f"VALIDATION=FAIL\nreason={exc}")
        return 1
    print("VALIDATION=PASS")
    for line in log:
        print(line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
