#!/usr/bin/env python3
"""Small falsification-oriented checks for A303656 descent Phase A.

This script deliberately avoids any interval search for T(n).  It tests only
proposed lemmas, local constructions, and finite-state bookkeeping.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple


def factorint_trial(n: int) -> Dict[int, int]:
    if n < 0:
        n = -n
    out: Dict[int, int] = {}
    p = 2
    while p * p <= n:
        while n % p == 0:
            out[p] = out.get(p, 0) + 1
            n //= p
        p = 3 if p == 2 else p + 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def is_sum_two_squares(n: int) -> bool:
    if n < 0:
        return False
    if n == 0:
        return True
    return all(not (p % 4 == 3 and e % 2 == 1) for p, e in factorint_trial(n).items())


def v_p(n: int, p: int) -> int:
    if n == 0:
        raise ValueError("v_p(0) is not finite")
    n = abs(n)
    e = 0
    while n % p == 0:
        n //= p
        e += 1
    return e


def crt(congruences: Sequence[Tuple[int, int]]) -> Tuple[int, int]:
    """Return least nonnegative x and product modulus for pairwise-coprime moduli."""
    x = 0
    mod = 1
    for a, m in congruences:
        if math.gcd(mod, m) != 1:
            raise ValueError("CRT moduli are not pairwise coprime")
        t = ((a - x) * pow(mod, -1, m)) % m
        x += mod * t
        mod *= m
        x %= mod
    return x, mod


def multiplicative_order(a: int, m: int) -> int:
    if math.gcd(a, m) != 1:
        raise ValueError("a must be a unit modulo m")
    x = 1
    for k in range(1, m + 1):
        x = (x * a) % m
        if x == 1:
            return k
    raise RuntimeError("order not found")


def find_sum_two_squares_residue(u: int, m: int) -> Tuple[int, int]:
    squares: Dict[int, int] = {}
    for y in range(m):
        squares.setdefault((y * y) % m, y)
    for x in range(m):
        need = (u - x * x) % m
        if need in squares:
            return x, squares[need]
    raise RuntimeError(f"no norm representation of {u} mod {m}")


def bad_primes(n: int) -> List[int]:
    return sorted(p for p, e in factorint_trial(n).items() if p % 4 == 3 and e % 2 == 1)


def s2_values(limit: int) -> List[int]:
    vals = set()
    r = math.isqrt(limit)
    for a in range(r + 1):
        aa = a * a
        for b in range(r + 1):
            s = aa + b * b
            if s <= limit:
                vals.add(s)
    return sorted(vals)


def experiment_affine_counterexamples() -> dict:
    transforms = [
        (1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6),
        (1, 7), (1, 8), (1, 9), (1, 10), (1, 12), (1, 16),
        (2, 3), (3, -1), (5, 7),
    ]
    values = s2_values(20000)
    rows = []
    for lam, k in transforms:
        hit = None
        for s in values:
            y = lam * s + k
            if s > 0 and y > 0 and not is_sum_two_squares(y):
                hit = {
                    "lambda": lam,
                    "k": k,
                    "s": s,
                    "image": y,
                    "image_factorization": factorint_trial(y),
                    "bad_primes": bad_primes(y),
                }
                break
        if hit is None:
            raise RuntimeError(f"no affine counterexample found for {(lam, k)}")
        rows.append(hit)
    return {
        "falsification_target": "A fixed affine map s -> lambda*s+k preserves S2 for all sufficiently large s in S2.",
        "search_limit_for_s": 20000,
        "rows": rows,
        "status": "FALSIFIED_FOR_EACH_TESTED_MAP",
    }


def experiment_simultaneous_affine_construction() -> dict:
    data = [
        {"lambda": 1, "k": 2, "q": 7},
        {"lambda": 1, "k": 4, "q": 11},
        {"lambda": 2, "k": 3, "q": 19},
        {"lambda": 3, "k": -1, "q": 23},
    ]
    x_congs: List[Tuple[int, int]] = []
    y_congs: List[Tuple[int, int]] = []
    local = []
    for row in data:
        lam, k, q = row["lambda"], row["k"], row["q"]
        q2 = q * q
        if (2 * lam * k) % q == 0:
            raise RuntimeError("prime violates avoidance condition")
        u = ((q - k) * pow(lam, -1, q2)) % q2
        if u % q == 0:
            raise RuntimeError("constructed residue is not a unit")
        xq, yq = find_sum_two_squares_residue(u, q2)
        if (xq * xq + yq * yq - u) % q2 != 0:
            raise RuntimeError("local norm representation failed")
        x_congs.append((xq, q2))
        y_congs.append((yq, q2))
        local.append({**row, "modulus": q2, "u": u, "x": xq, "y": yq})
    x, Q = crt(x_congs)
    y, Q2 = crt(y_congs)
    assert Q == Q2
    s = x * x + y * y
    images = []
    for row in data:
        z = row["lambda"] * s + row["k"]
        e = v_p(z, row["q"])
        if e != 1:
            raise RuntimeError("exact valuation construction failed")
        images.append({
            **row,
            "image": z,
            "certifying_valuation": e,
            "certified_not_S2": True,
        })
    return {
        "construction": "CRT combination of local norm residues",
        "local_data": local,
        "combined_modulus": Q,
        "x": x,
        "y": y,
        "s": s,
        "s_identity": f"{x}^2 + {y}^2",
        "images": images,
        "status": "VERIFIED",
    }


def experiment_private_witness_crt() -> dict:
    shifts = [2, 4, 6]
    qs = [7, 11, 19]
    M, r = 8, 1
    congruences: List[Tuple[int, int]] = [(r, M)]
    for h, q in zip(shifts, qs):
        congruences.append((h + q, q * q))
    n, mod = crt(congruences)
    if n <= max(shifts):
        n += mod
    checks = []
    for i, (h, q) in enumerate(zip(shifts, qs)):
        rem = n - h
        private = all((n - h2) % q != 0 for j, h2 in enumerate(shifts) if j != i)
        checks.append({
            "shift": h,
            "designated_prime": q,
            "remainder": rem,
            "valuation": v_p(rem, q),
            "private_against_selected_other_shifts": private,
            "all_bad_prime_witnesses_in_factorization": bad_primes(rem),
            "factorization": factorint_trial(rem),
        })
    return {
        "fixed_modulus": M,
        "fixed_residue": r,
        "n": n,
        "global_modulus": mod,
        "checks": checks,
        "status": "VERIFIED",
        "caveat": "The construction certifies designated private witnesses only; it does not assert that alternate shared witnesses are absent or that the minimum witness cover has this cardinality.",
    }


def experiment_fixed_modulus_indistinguishability() -> dict:
    rows = []
    for M in [8, 12, 40]:
        residues = sorted({(x * x + y * y) % M for x in range(M) for y in range(M)})
        for r in residues:
            good = next(n for n in range(1, 5000) if n % M == r and is_sum_two_squares(n))
            bad = next(n for n in range(1, 5000) if n % M == r and not is_sum_two_squares(n))
            rows.append({
                "modulus": M,
                "residue": r,
                "S2_example": good,
                "non_S2_example": bad,
                "non_S2_bad_primes": bad_primes(bad),
            })
    return {
        "falsification_target": "A fixed modulus decides S2 membership on every locally S2-admissible residue.",
        "rows": rows,
        "status": "FALSIFIED",
    }


def experiment_common_square_divisor() -> dict:
    rows = []
    for n in range(5, 201):
        g = math.gcd(n - 2, n - 4)
        square_divisor = next((q * q for q in range(2, math.isqrt(g) + 1) if g % (q * q) == 0), None)
        rows.append({"n": n, "gcd_n_minus_2_n_minus_4": g, "square_divisor_gt_1": square_divisor})
    return {
        "range": [5, 200],
        "all_gcds_divide_2": all(2 % row["gcd_n_minus_2_n_minus_4"] == 0 for row in rows),
        "any_nontrivial_square_divisor": any(row["square_divisor_gt_1"] for row in rows),
        "status": "VERIFIED",
    }


def generate_shifts(limit: int) -> List[int]:
    vals = set()
    a = 1
    while a + 1 <= limit:
        b = 1
        while a + b <= limit:
            vals.add(a + b)
            b *= 5
        a *= 3
    return sorted(vals)


def experiment_shift_translation_failures() -> dict:
    H = generate_shifts(2_000_000)
    Hset = set(H)
    rows = []
    for delta in [2, 3, 4, 5, 8, 9, 25]:
        liftable = [h for h in H if h + delta in Hset][:10]
        escapes = [h for h in H if h + delta <= 2_000_000 and h + delta not in Hset][:10]
        rows.append({
            "delta": delta,
            "first_liftable_shifts": liftable,
            "first_escape_shifts": escapes,
            "naive_total_translation_closure_falsified": bool(escapes),
        })
    return {
        "shift_bound": 2_000_000,
        "falsification_target": "For a fixed delta, every active shift h can be replaced by h+delta inside the shift set.",
        "rows": rows,
        "status": "FALSIFIED_FOR_ALL_TESTED_DELTAS",
    }


def c_state_rep(c: int, E: int, C: int) -> Tuple[str, int, int]:
    if c < E:
        return ("head", c, c)
    r = c % C
    rep = E + ((r - E) % C)
    return ("tail", r, rep)


def experiment_finite_state_toy() -> dict:
    Q = [3, 7]
    E = 2
    L = math.prod(q ** E for q in Q)
    C_parts = [multiplicative_order(3, q ** E) for q in Q if q != 3]
    C = math.lcm(*C_parts) if C_parts else 1
    D = math.lcm(*(multiplicative_order(5, q ** E) for q in Q))
    max_c_rep = E + C - 1
    max_d_rep = D - 1
    H = 3 ** max_c_rep + 5 ** max_d_rep
    N_star = H + L

    # Verify that the finite state really determines every power residue in a test window.
    mismatches = []
    for q in Q:
        qE = q ** E
        for c in range(0, E + 3 * C + 1):
            _, _, crep = c_state_rep(c, E, C)
            if pow(3, c, qE) != pow(3, crep, qE):
                mismatches.append({"q": q, "coordinate": "c", "exponent": c, "representative": crep})
        for d in range(0, 3 * D + 1):
            drep = d % D
            if pow(5, d, qE) != pow(5, drep, qE):
                mismatches.append({"q": q, "coordinate": "d", "exponent": d, "representative": drep})
    return {
        "Q": Q,
        "E": E,
        "L": L,
        "C": C,
        "D": D,
        "c_state_count": E + C,
        "d_state_count": D,
        "combined_state_count": (E + C) * D,
        "max_c_representative": max_c_rep,
        "max_d_representative": max_d_rep,
        "H": H,
        "N_star": N_star,
        "verification_window": {"c_max": E + 3 * C, "d_max": 3 * D},
        "mismatches": mismatches,
        "status": "VERIFIED" if not mismatches else "FAILED",
        "scope": "State bookkeeping only; no CRW or UBVC hypothesis and no counterexample existence were tested.",
    }


def experiment_forced_distinct_witnesses() -> dict:
    shifts = [2, 4, 6]
    pairs = []
    for i in range(len(shifts)):
        for j in range(i + 1, len(shifts)):
            diff = abs(shifts[i] - shifts[j])
            q3 = [p for p in factorint_trial(diff) if p % 4 == 3]
            pairs.append({"shifts": [shifts[i], shifts[j]], "difference": diff, "prime_divisors_3_mod_4": q3})
    return {
        "shifts": shifts,
        "pair_differences": pairs,
        "same_bad_prime_can_witness_two_selected_shifts": any(row["prime_divisors_3_mod_4"] for row in pairs),
        "status": "VERIFIED",
    }


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    out = {
        "schema": "a303656-descent-small-experiments-v1",
        "purpose": "Falsification and bookkeeping only; no T(n) interval search.",
        "experiments": {
            "affine_counterexamples": experiment_affine_counterexamples(),
            "simultaneous_affine_construction": experiment_simultaneous_affine_construction(),
            "private_witness_crt": experiment_private_witness_crt(),
            "fixed_modulus_indistinguishability": experiment_fixed_modulus_indistinguishability(),
            "common_square_divisor": experiment_common_square_divisor(),
            "shift_translation_failures": experiment_shift_translation_failures(),
            "finite_state_toy": experiment_finite_state_toy(),
            "forced_distinct_witnesses": experiment_forced_distinct_witnesses(),
        },
    }
    output = root / "results" / "small_experiments.json"
    output.write_text(json.dumps(out, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
