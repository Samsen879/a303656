# REPRODUCIBILITY

## Scope

The package can be audited without a repository checkout.  It contains no
large enumeration and no new interval search for `T(n)`.

## Small-experiment replay

From the package root:

```bash
python3 scripts/small_experiments.py
```

The generated `results/small_experiments.json` is deterministic.  The package
validator replays the script in a temporary copy and requires byte equality.

## Package validation

```bash
python3 scripts/validate_package.py --root .
sha256sum -c SHA256SUMS.txt
```

The validator checks:

- the complete required-file set;
- JSON parseability and mandatory verdict fields;
- exact `CANDIDATE_SCORECARD.csv` columns and row integrity;
- input hashes recorded in `INPUT_AUDIT.md`;
- deterministic replay of the small experiments;
- internal checksums when `SHA256SUMS.txt` is populated.

## Deterministic archive rebuild

From the parent directory of the package root:

```bash
python3 A303656_DESCENT_FINITE_REDUCTION_PHASE_A/scripts/build_deterministic_zip.py \
  --root A303656_DESCENT_FINITE_REDUCTION_PHASE_A \
  --output A303656_DESCENT_FINITE_REDUCTION_PHASE_A.zip
unzip -t A303656_DESCENT_FINITE_REDUCTION_PHASE_A.zip
```

All ZIP entries are sorted and receive timestamp `2000-01-01 00:00:00`, fixed
Unix permissions, DEFLATE compression level 9, and no archive comment.  A
second rebuild must be byte-identical.

## Checksum policy

`SHA256SUMS.txt` covers every internal regular file except itself.  This is the
standard non-circular policy.  The final ZIP SHA256 is reported externally and
in the delivery response because an archive cannot contain its own stable hash.

## Literature provenance

`WEB_SOURCES_LOCK.json` records the accessed versions, theorem identifiers,
primary URLs, and A303656 mismatch.  `SOURCE_PDF_HASHES.tsv` records local
hashes for downloaded primary-source PDFs retained outside the distributable
archive.  The package is therefore self-auditing with respect to source locks
without redistributing the papers.
