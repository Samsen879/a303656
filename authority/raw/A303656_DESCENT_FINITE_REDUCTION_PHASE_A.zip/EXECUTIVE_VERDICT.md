# EXECUTIVE VERDICT

## FINAL VERDICT

\[
\boxed{\textbf{NO PROMOTABLE ROUTE — RETAIN AS SPECULATIVE WATCH}}
\]

The round found **no unconditional quantifier compression** of

\[
\exists n>1:T(n)=0
\]

into a smaller counterexample, an explicit finite range, or a uniformly
bounded finite certificate system.  Therefore no active descent campaign,
finite verification phase, Codex implementation, or Ultra computation is
authorized.

## Strongest theorem obtained

For finite

\[
Q\subset\{q:q\equiv3\pmod4\},\qquad E\ge2,
\]

the exponent pairs have a computable finite state system modulo

\[
L(Q,E)=\prod_{q\in Q}q^E.
\]

A complete pointwise state certificate gives an explicit descent whenever
`n>H_n(Q,E)+L(Q,E)`.  More sharply, define `CRW(Q,E)` to require bounded odd
witnesses only for the fixed finite list of `(E+C)D` canonical representative
shifts of every counterexample above

\[
N_*(Q,E)=H(Q,E)+L(Q,E).
\]

Then `CRW(Q,E)` implies the genuine Target D map

\[
F(n)=H(Q,E)+1+((n-H(Q,E)-1)\bmod L(Q,E)),
\]

and the Target F implication

\[
(\exists n>1:T(n)=0)\Longrightarrow
(\exists n\le N_*(Q,E):T(n)=0).
\]

This conditional reduction is **PROVED** and handles `q=3`, exact valuation
transfer, activation of canonical exponent representatives, and zero
remainders.  The stronger hypothesis `UBVC(Q,E)`, which bounds witnesses for
all active remainders, implies `CRW` but is not the minimal trigger.

## Why this is not promoted

No primary theorem, elementary argument, or small exact test produced fixed
`Q,E` satisfying `CRW`, even though `CRW` concerns only finitely many canonical
translations.  The missing data are:

1. a fixed numerical prime set `Q` covering those representative remainders
   for every sufficiently large counterexample; and
2. a fixed upper bound `E` on the odd witness valuation.

The obstruction is not bookkeeping.  A CRT lemma shows that any finite family
of distinct shifts can be assigned pairwise private *designated* bad-prime
witnesses while preserving an arbitrary fixed residue class.  This does not
construct an A303656 counterexample and does not exclude alternative shared
witnesses.  It rigorously invalidates only arguments that treat an arbitrary
one-witness-per-pair selection as canonical or assume that such a selection
must reuse primes.  A true bounded-cover theorem would need additional global
arithmetic structure.

The stronger `UBVC` hypothesis overlaps the frozen finite-prime-cover program.
The weaker `CRW` trigger avoids demanding a cover of every active pair, but no
argument or primary theorem was found that bounds witnesses even for its fixed
canonical translations.

## Reusable negative results

This round proves, among other statements:

- no fixed modulus can decide membership in the sums-of-two-squares set on
  all locally admissible residue classes;
- no finite menu of fixed affine corrections with nonzero additive offsets
  can map every sufficiently large sum of two squares back into the
  sums-of-two-squares set;
- the shift set `{3^c+5^d}` is not semilinear or Presburger-definable;
- a minimal counterexample must have at least three distinct bad-prime
  witnesses, already from shifts `2,4,6`;
- fixed subtraction by `2,4,8,3^u,5^v` does not automatically transfer
  minimality; for every fixed even increment the shift-escape set is infinite;
- no nontrivial common square divides all active remainders;
- uniform Brahmagupta–Fibonacci termwise scaling is impossible for the mixed
  bases `3` and `5` except at scale `1`.

These are valid route eliminations, not a failure of the project.

## Literature verdict

The audited primary theorems have narrower quantifiers:

- effective S-unit bounds fix the prime set and a fixed equation;
- finite-rank unit-equation bounds count nondegenerate solutions of a fixed
  linear equation;
- primitive-divisor theorems treat fixed divisibility sequences;
- Skolem–Mahler–Lech theory treats fixed one-dimensional recurrences and is
  generally ineffective outside restricted orders;
- Presburger-with-two-power-predicates decidability does not include the
  quadratic sums-of-two-squares predicate;
- covering-system theorems begin with an already existing finite cover.

None supplies `CRW(Q,E)`, `UBVC(Q,E)`, or another effective least-exception
bound for the growing two-dimensional exponent family.

## Authorization

- Next active theorem phase: **NO**.
- Low-cost primary-source literature watch for a theorem implying explicit
  `CRW(Q,E)` or the pointwise descent inequality: **YES**.
- Ordinary Codex: **NO**.
- Codex Ultra: **NO**.
- New interval search: **NO**.

**OEIS A303656: UNRESOLVED.**
