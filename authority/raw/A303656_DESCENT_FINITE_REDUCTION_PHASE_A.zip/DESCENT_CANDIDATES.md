# DESCENT CANDIDATES

Each candidate is evaluated against Target D:

\[
T(n)=0,\ n>N_0\Longrightarrow T(F(n))=0,
\qquad 1<F(n)<n.
\]

A theorem may be mathematically correct yet fail promotion because its premise
has not been proved for counterexamples.

## Summary table

| ID | proposed mechanism | exact map/relation | decisive status | classification | promotion |
|---|---|---|---|---|---|
| D0-SCD | finite-state valuation certificate | explicit `F_{Q,E,n}` | theorem proved; certificate smallness not guaranteed | `PROVED` | NO |
| D1-SUB | subtract fixed `Delta` | `n -> n-Delta` | minimality forces only an escape relation | `NO QUANTIFIER COMPRESSION` | NO |
| D2-AFF | finite affine correction menu | `s -> lambda_i s+k_i` | simultaneous CRT anti-lifting theorem | `FALSE` | NO |
| D3-SQDIV | divide by common square | `n -> n/q^2` or remainder scaling | shifts `2,4` forbid a common `q^2` | `FALSE` | NO |
| D4-ONEQ | one common bad prime | any map preserving one `q`-odd pattern | already impossible for shifts `2,4` | `FALSE` | NO |
| D5-BOUNDEDQ | bounded witness-prime set | state descent after adding depth bound | uniform bound not obtained | `NOT ESTABLISHED` | NO |
| D6-LTE | transfer odd valuation through exponent changes | exponent shifts depending on `q` | witness depends on pair; activation uncontrolled | `NOT ESTABLISHED` | NO |
| D7-BF | Brahmagupta–Fibonacci scaling | `n -> Qn` or reverse division | mixed-base termwise scaling forces `Q=1` | `FALSE` | NO |
| D8-FIXM | fixed residue-signature descent | `F(n)` determined by `n mod M` | fixed modulus cannot decide `S_2` | `FALSE` | NO |
| D9-PRIM | primitive-divisor synchronization | use primes of `3^u-5^v` | no link to remainder witness parity or all pairs | `NOT ESTABLISHED` | NO |

## D0-SCD — state-certificate descent

### Exact statement

Theorem 8 of `THEOREMS_AND_PROOFS.md`.  Given a finite bad-prime set `Q`, a
valuation cutoff `E`, and a complete finite state certificate for a particular
counterexample `n`, define

\[
L=\prod_{q\in Q}q^E,
\]

canonical exponent states, and the largest canonical representative shift
`H_n(Q,E)`.  If

\[
n>H_n(Q,E)+L,
\]

then

\[
F(n)=H_n(Q,E)+1+((n-H_n(Q,E)-1)\bmod L)
\]

is a smaller counterexample.

### Proof support

Complete.  The proof checks:

- exponent activation for all pairs active at `F(n)`;
- the special base-prime case `q=3`;
- exact, not merely positive, valuation transfer modulo `q^E`;
- the impossibility of a zero remainder;
- strict inequalities `1<F(n)<n`.

### Failed step toward promotion

No theorem gives a complete certificate with `H_n(Q,E)+L<n`, uniformly or for
a hypothetical least counterexample.  The trivial certificate obtained by
listing one witness per active pair may use primes and valuation depths so
large that the inequality is vacuous.

### Classification

- Pointwise implication: `PROVED`.
- Unconditional A303656 descent route: `NOT ESTABLISHED`.
- Promotion: rejected.

## D1-SUB — fixed subtraction and minimality transfer

### Proposed relation

Take `m=n_0-Delta`, represent `m=s+h` by minimality, and hope that `h+Delta`
is again a shift.

### Exact proved replacement

Every representation of `m` must instead use the escape set

\[
E_\Delta=\{h:h+\Delta\notin\mathcal A\}.
\]

For odd `Delta`, `E_Delta=A` because all shifts are even.  For every fixed even
`Delta`, `E_Delta` is infinite.

### Failure

Minimality does not choose a liftable representation.  Infinite escape sets
prevent a finite residue cleanup.  The argument supplies a necessary
condition on representations of `n_0-Delta`, not a map preserving
counterexample status.

### Classification

`NO QUANTIFIER COMPRESSION`.

## D2-AFF — finite affine correction of the two-square term

### Proposed mechanism

After representing a smaller integer, apply one of finitely many identities
that sends the two-square component `s` to `lambda_i s+k_i`, with
`lambda_i>0` and nonzero fixed offsets `k_i`, while separately adjusting
powers.

### Refutation

The finite affine anti-lifting theorem constructs arbitrarily large
`s in S_2` for which every member of any prescribed finite menu
`lambda_i s+k_i` with `k_i!=0` is positive but not in `S_2`.

This does not rule out transformations with an unbounded menu or with
non-affine, exponent-dependent coefficients.  It does rigorously terminate the
finite fixed-affine, nonzero-offset version.

### Classification

`FALSE`.

## D3-SQDIV — divide by a square

### Proposed map

If all remainders shared a square divisor `q^2`, divide the representation
problem by `q^2` and attempt to reduce `n`.

### Failure

Once shifts `2` and `4` are active,

\[
\gcd(n-2,n-4)\mid2.
\]

No `q^2>1` divides both remainders.  A global square factor cannot exist.
Dividing `n` itself by a square does not align the additive shifts and does not
preserve the active exponent domain.

### Classification

`FALSE`.

## D4-ONEQ — a single global witness prime

### Proposed mechanism

Find `q=3 (mod 4)` such that every active remainder has odd `q`-valuation;
then preserve this one local obstruction under descent.

### Failure

The remainders at shifts `2` and `4` differ by `2`.  If `q` divided both, it
would divide `2`, impossible.  In fact shifts `2,4,6` force three distinct
witnesses.

### Classification

`FALSE`.

## D5-BOUNDEDQ — uniformly bounded witness-prime set

### Exact candidate

There is an absolute finite set `Q` such that every active remainder of every
counterexample has an odd witness in `Q`.

With an additional uniform depth bound `E`, this becomes `UBVC(Q,E)` and D0
yields explicit descent.  The weaker `CRW(Q,E)` condition needs such bounds only
for the fixed canonical representative translations, not for every active pair.

### Evidence and blocker

No proof was found.  The designated-private-witness CRT lemma shows that an
arbitrary selection of one Fermat witness per pair can be made pairwise
private, even inside a fixed residue class.  It does **not** disprove the
existence of alternative shared witnesses or a bounded cover for actual
counterexamples.  It shows that any proof of the candidate must exploit the
full arithmetic witness sets or other global counterexample structure, rather
than collision in a chosen witness assignment.

A bound only on `|Q|`, without bounds on the numerical primes and their odd
valuation depths, does not produce a fixed modulus or finite range.

### Classification

`NOT ESTABLISHED`.

## D6-LTE — valuation transfer by LTE or exponent shifts

### Proposed relation

Use divisibility of `3^u-5^v`, multiplicative orders, LTE, or Hensel lifting to
transport odd valuations from `n-h(c,d)` to a smaller integer and a reindexed
pair `(c',d')`.

### Failed step

LTE controls the valuation of a specified exponential difference after a
prime and congruence relation have already been fixed.  Here the witness prime
may change with `(c,d)`, and an active pair of the smaller integer need not
correspond to a pair carrying the same witness at `n`.  No uniform reindexing
covering the entire smaller active domain was obtained.

### Classification

`NOT ESTABLISHED`.

## D7-BF — Brahmagupta–Fibonacci scaling

### Proposed map

Multiply or divide the two-square component using

\[
(x^2+y^2)(u^2+v^2)=(xu\pm yv)^2+(xv\mp yu)^2.
\]

### Uniform obstruction

A fixed termwise scale `Q` preserving both power families would require

\[
Q=3^r=5^s,
\]

hence `Q=1`.  The same-base homogeneity exploited in Crocker's powers-of-two
descent has no mixed-base analogue of this direct form.

Sporadic identities are not excluded, but no finite family was shown to cover
all minimal counterexamples; a fixed finite affine fallback with nonzero
offsets is ruled out by D2.

### Classification

`FALSE`.

Scope: this classification applies to the uniform termwise scaling candidate.

## D8-FIXM — fixed residue-signature descent

### Proposed map

Choose one modulus `M`, classify `n` and exponent orbits modulo `M`, and map
each residue state to a smaller state.

### Failure

Every locally two-square-admissible residue class modulo `M` contains
infinitely many sums of two squares and infinitely many non-sums.  Thus fixed
local data cannot preserve the exact counterexample property.  A finite-state
system becomes valid only after a finite witness-prime set and valuation depth
are independently supplied, as in D0.

### Classification

`FALSE`.

Scope: this classification applies to the exact fixed-modulus form.

## D9-PRIM — primitive-divisor synchronization

### Proposed mechanism

Use Zsigmondy/Lucas–Lehmer primitive divisors of exponential differences such
as `3^u-5^v` to force new primes and synchronize witness assignments.

### Mismatch

Primitive-divisor theorems supply a divisor new relative to earlier terms of a
fixed divisibility sequence.  They do not ensure:

- congruence `3 mod 4`;
- odd valuation in `n-3^c-5^d`;
- divisibility of a remainder rather than a shift difference;
- one prime controlling all active pairs;
- a smaller counterexample.

### Classification

`NOT ESTABLISHED`.
