# NO-GO RESULTS

The purpose of this file is to record reusable statements that terminate
specific tempting arguments.  Each result has a narrower scope than “no
descent exists.”

## NG-1 — fixed local information cannot decide `S_2`

**Statement.** For every modulus `M`, every residue class that is locally a sum
of two squares modulo `M` contains infinitely many global sums of two squares
and infinitely many global non-sums of two squares.

**Proof.** Theorem 5 in `THEOREMS_AND_PROOFS.md`.

**Terminates.** Any exact global descent or automaton whose only arithmetic
input is `n-h mod M` for one fixed `M`.

**Does not terminate.** Adaptive moduli built from a proven finite witness set.

## NG-2 — a chosen witness assignment need not reuse primes

**Statement.** For any finite distinct shifts and any fixed residue class, CRT
can assign a distinct exact valuation-one prime `3 mod 4` privately to every
shift.

**Proof.** Theorem 4.

**Terminates.** Pigeonhole or set-cover arguments applied to an arbitrary
one-witness-per-pair selection and asserting that the selected primes must
collide or come from a bounded list.

**Does not terminate.** A theorem proving that the *full sets* of available
witnesses admit a bounded cover, or that some alternative witness is shared.
The CRT construction neither excludes such alternatives nor produces an
A303656 counterexample.  Thus this is an underdetermination warning, not a
no-go theorem for `CRW(Q,E)` or `UBVC(Q,E)`.

## NG-3 — no finite fixed-affine nonzero-offset lifting menu

**Statement.** For any finite collection of affine maps
`s -> lambda_i s+k_i` with `lambda_i>0` and `k_i!=0`, arbitrarily large
`s in S_2` make every image a non-sum of two squares.

**Proof.** Theorem 3.

**Terminates.** Reverse descent based on finitely many fixed affine corrections
with nonzero additive offsets, applied to an arbitrary two-square remainder.

**Does not terminate.** Zero-offset multiplicative maps, non-affine
transformations, or an unbounded exponent-dependent menu.

## NG-4 — fixed subtraction has infinite escape

**Statement.** For every fixed even `Delta>0`, infinitely many shifts `h` have
`h+Delta` outside the shift set.  For odd `Delta`, no shift can survive
addition by `Delta`.

**Proof.** Theorem 2.

**Terminates.** The invalid inference “represent `n-Delta`, then add `Delta` to
the shift.”

## NG-5 — no global common-square division

**Statement.** Once shifts `2` and `4` are active, no square `q^2>1` divides all
remainders.

**Proof.** Their gcd divides `2`.

**Terminates.** A descent that divides every remainder by one common square.

## NG-6 — one witness prime is impossible

**Statement.** No prime `3 mod 4` can witness both remainders at shifts `2` and
`4`; shifts `2,4,6` force three distinct witnesses.

**Terminates.** Single-prime valuation descent.

## NG-7 — the shift set is not semilinear

**Statement.** `{3^c+5^d}` is infinite with `O(log^2 X)` counting function and
therefore cannot be semilinear or Presburger-definable.

**Terminates.** A direct ordinary-Presburger description of the exact shift
set or a proof that relies on it being eventually a finite union of arithmetic
progressions.

**Does not terminate.** Decidability in richer structures with explicit power
predicates.

## NG-8 — mixed-base termwise scaling is trivial

**Statement.** A fixed sum-of-two-squares scale preserving both power terms
termwise must equal `1`.

**Terminates.** Direct transplantation of same-base homogeneous descents such
as powers-of-two scaling.

## NG-9 — finite-subset cover compactness is false without compactness

Consider universe `U=N` and sets `A_m={0,1,...,m}`.  Every finite subset of
`U` is contained in one `A_m`, but no finite subfamily covers `U`.  Therefore

> every finite truncation is finitely coverable

never implies

> the infinite object has a finite subcover

without an actual compactness theorem and a fixed family of closed sets in a
compact space.

For A303656, both the active universe and the available witness congruences
change with `n`; the trivial finite extraction is logically of the first type.

## NG-10 — a bound on certificate cardinality is not a finite reduction

Even `|P(n)|<=C` does not bound the numerical primes, the prime-power modulus,
or the valuation depth.  A finite-state reduction needs enough precision to
determine odd valuation, not merely divisibility modulo `q`.

**Terminates.** Claims that a set-cover cardinality bound alone yields an
explicit least exception.

## NG-11 — S-unit projective finiteness does not eliminate scaling

A fixed finite-rank unit equation has finitely many nondegenerate projective
solutions, but A303656 does not first place all factors of every remainder in
one fixed finitely generated multiplicative group.  Moreover, projective
classes do not bound actual exponents until common scaling is controlled.

**Terminates.** Direct invocation of a Subspace-Theorem finiteness statement
without specifying the fixed equation, group, nondegeneracy, scaling
elimination, and effective numerical consequence.

## NG-12 — candidate verification is not candidate existence

A finite table can verify a proposed `n` is a counterexample.  This does not
supply an algorithm to find such an `n`, prove one exists, or prove the least
one lies below a computable bound.

**Terminates.** Promotion based only on a verifier specification.

## NG-13 — density does not eliminate the exceptional set

Positive density, and even an almost-all theorem, does not imply that the
exceptional set is finite.  A finite verification range becomes complete only
after an effective exceptional-set bound or descent theorem is proved.

**Terminates.** Any attempt to combine the frozen density theorem with a
larger search and call the result universal.
