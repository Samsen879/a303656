# FINITE-REDUCTION CANDIDATES

Target F requires an explicit computable `N_*` satisfying

\[
(\exists n>1:T(n)=0)\Longrightarrow(\exists n\le N_*:T(n)=0).
\]

## F1-CRW — canonical-representative witness finite reduction

### Exact theorem

For finite `Q` of primes `3 mod 4` and `E>=2`, define `L,C,D` as in Theorem 8,

\[
H=3^{E+C-1}+5^{D-1},\qquad N_*=H+L,
\]

and the fixed canonical state set

\[
\mathcal R(Q,E)=\{0,\ldots,E+C-1\}\times\{0,\ldots,D-1\}.
\]

Assume `CRW(Q,E)`: for every counterexample `n>N_*` and every
`(u,v) in R(Q,E)`, some `q in Q` has an odd exact valuation

\[
1\le v_q(n-3^u-5^v)<E.
\]

Then every counterexample above `N_*` descends to

\[
F(n)=H+1+((n-H-1)\bmod L),
\]

and therefore a least counterexample is at most `N_*`.

### Effectivity

Complete.  Given `Q,E`, all orders, states, `L,H,N_*`, and the descent map are
computable by exact arithmetic.

### Logical strength

This hypothesis concerns only `(E+C)D` fixed canonical translations.  It is
strictly weaker than requiring the same bounded witnesses for every active
pair.  State congruence propagates the finite representative data to the full
active exponent domain.

### External dependence

None for the reduction theorem itself.  The missing statement is the unproved
`CRW(Q,E)` hypothesis.

### Classification

- Conditional reduction: `PROVED`.
- Unconditional Target F candidate: `PLAUSIBLE BUT CORE LEMMA OPEN`.
- Promotion: NO, because no theorem supplies fixed numerical witnesses and
  valuation depths even for the canonical translations.

## F1B-UBVC — stronger all-active-pair sufficient condition

`UBVC(Q,E)` requires every active remainder of every counterexample to have an
odd exact witness at a prime in `Q` below depth `E`.  It implies `CRW(Q,E)` and
therefore the same explicit finite bound.

Classification: conditional implication `PROVED`; hypothesis `NOT
ESTABLISHED`.  It is not the minimal trigger and has higher overlap with the
frozen finite-cover route.

## F2-POINT — pointwise certificate self-bound

For a specific counterexample and a complete `(Q,E)` state certificate,
minimality implies

\[
n\le H_n(Q,E)+L(Q,E).
\]

This is effective and nontrivial, but the right-hand side depends on the
unknown counterexample through its certificate.  Substituting the trivial
bounds `q<=n`, `E=O(log n)`, and `|Q|=O(log^2 n)` produces only a self-bound
larger than `n`, not an absolute finite range.

Classification: `NO QUANTIFIER COMPRESSION` as a global F theorem.

## F3-CARD — bounding only the number of witnesses

A theorem of the form

\[
|P(n)|\le C\quad\text{or}\quad |P(n)|\le f(\log n)
\]

would not by itself give a finite reduction.  The prime values may grow with
`n`, and their odd valuations may be unbounded; consequently the required
prime-power modulus and exponent periods remain unbounded.

Classification: `NO QUANTIFIER COMPRESSION` unless supplemented by explicit
numerical and depth bounds.

## F4-SUNIT — effective S-unit equations

### Candidate mechanism

Force every remainder into a fixed finite prime support and apply effective
S-unit bounds to equations such as

\[
n-3^c-5^d=u.
\]

### Mismatch

The A303656 obstruction says only that each remainder has at least one odd
bad-prime valuation.  It gives no fixed support for the remaining factors.
The constant `n` moves, the active family grows with `n`, and the witness prime
may vary with `(c,d)`.  Effective fixed-`S` results cannot be invoked before
the missing support theorem is proved.

Classification: `NO QUANTIFIER COMPRESSION`.

## F5-PROJSUNIT — projective S-unit finiteness

A projective finiteness theorem for a fixed homogeneous equation does not
bound actual exponents until common scaling is eliminated.  In this problem
the moving constant and arbitrary cofactor support prevent such an
elimination.  No explicit equation with fixed term count and fixed group was
found whose solutions parameterize all counterexamples.

Classification: `NO QUANTIFIER COMPRESSION`; an ineffective finiteness claim
would also fail the project effectivity gate.

## F6-SML — Skolem–Mahler–Lech / recurrence zeros

### Candidate mechanism

Encode obstruction states as zeros of an exponential polynomial or linear
recurrence and use eventual periodicity of zero sets.

### Mismatch

Skolem–Mahler–Lech concerns a fixed one-dimensional recurrence.  The present
predicate is bivariate in `(c,d)`, has a moving parameter `n`, and asks for
membership in `S_2`, not equality to zero.  General SML is ineffective; the
recent decidability result covers algebraic recurrences of order at most four,
while even order five remains open in general.  No fixed low-order recurrence
encoding the counterexample condition was obtained.

Classification: `INEFFECTIVE` for the general theorem and
`NO QUANTIFIER COMPRESSION` for this application.

## F7-PRES2P — Presburger arithmetic with two power predicates

Karimov–Luca–Nieuwveld–Ouaknine–Worrell prove decidability of the existential
fragment of

\[
\langle\mathbf Z;0,1,<,+,\alpha^{\mathbf N},\beta^{\mathbf N}\rangle.
\]

This handles linear additive formulas with unary power predicates.  It does
not contain multiplication or the predicate `x in S_2`; introducing
`x=a^2+b^2` is quadratic.  Moreover, counterexample existence contains a
universal condition over all active exponent pairs.  No reduction to their
existential fragment was found.

Classification: `NO QUANTIFIER COMPRESSION`.

## F8-AUTO — global automaton / semilinearity

For fixed prime powers, exponent residues are periodic and produce a finite
product automaton.  Globally, however, the relevant prime set and valuation
depth can grow.  The shift set itself is not semilinear, and the characteristic
sequence of `S_2` is not morphic.  These facts do not forbid a certificate-
dependent automaton, but they rule out the direct fixed finite-state model.

Classification: `NOT ESTABLISHED` for adaptive automata;
`FALSE` for a fixed exact automaton based only on one modulus.

## F9-COVER — covering-system compactness

Hough's theorem bounds the least modulus of an already existing distinct
finite covering system.  It does not show that the A303656 exponent grid has a
finite bad-prime cover, nor does it bound the support of a cover whose sets and
universe vary with `n`.  Generic finite-subset compactness also fails without a
compact topology or a uniform finite subcover theorem.

Classification: `NO QUANTIFIER COMPRESSION`.

## F10-PRIM — primitive divisors and Zsigmondy

Primitive divisors can bound exceptional indices in fixed exponential
sequences.  They do not select odd `3 mod 4` valuations of the moving
remainders and do not cover the two-dimensional active family.  No explicit
least-exception bound follows.

Classification: `NO QUANTIFIER COMPRESSION`.

## F11-DENS — density or almost-all plus finite search

Positive density does not imply almost all.  Almost all would still allow an
infinite density-zero exceptional set.  A statement of the form “all
sufficiently large integers have a good shift” is exactly the missing theorem,
not an intermediate finite reduction.

Classification: `CIRCULAR / EQUIVALENT TO ORIGINAL` when used as the proposed
trigger.

## Finite-reduction verdict

Only F1 supplies a correct explicit `N_*`, and only under `CRW(Q,E)`.
`UBVC(Q,E)` is a stronger sufficient condition.  No source or proof supplies
fixed `Q,E` for either statement.  Therefore the least exception is not
unconditionally bounded.
