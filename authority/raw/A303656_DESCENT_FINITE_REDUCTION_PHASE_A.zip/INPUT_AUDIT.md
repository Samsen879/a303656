# INPUT AUDIT

Audit date: `2026-07-17`  
Execution environment: webpage GPT-5.6 Pro, Linux container, standalone Python.

## ZIP authorities

| received filename | size (bytes) | computed SHA256 | expected SHA256 | `unzip -t` | authority classification |
|---|---:|---|---|---|---|
| `A303656_GLOBAL_ROUTE_RESET(2).zip` | 47,597 | `b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13` | same | PASS | project-level STOP/GO authority |
| `A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN.zip` | 282,646 | `aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2` | same | PASS | frozen positive-density authority |
| `a303656_p2cover_bundle.zip` | 93,403 | `4dadb8ce07cd0ccf56575ef0882d6bb02284a02c61e05cd1424e070d83b22ff3` | same | PASS | frozen finite-`p^2`-cover authority |
| `analytic_bad_prime_phaseA.zip` | 563,522 | `9dd538f5d47a4d2327159b619af7db752f241421caef926207e623be6a8b1ec2` | same | PASS | optional closed-route authority |

The reset archive was received with the suffix `(2)`.  Its byte hash exactly
matches the expected project authority, so the naming difference is not a
provenance defect.

Raw integrity output is preserved in `results/input_integrity.txt`.

## Context files

| filename | size (bytes) | SHA256 | classification |
|---|---:|---|---|
| `分工规则.txt` | 4,366 | `94261338e1d2e0a348ff264e9a98322b647918eeca74b0932dcd90bac980b5f6` | execution-environment policy |
| `项目简介.txt` | 510 | `42903e1adb5731d195786538a1072aa5b54a5c2adbf7fe6b963226fa74a139ae` | project scope statement |

## Frozen authority state extracted

### Project reset

- Project status: `PAUSED`.
- Active promoted route: `NONE`.
- A303656: `UNRESOLVED`.
- Restart requires a new theorem-level mechanism with an effective finite next
  phase.

### Positive density

Accepted only as a positive-density many-representation theorem, including the
distinct-shift version.  It is not an almost-all theorem and not a universal
theorem.  No part of that proof was reopened.

### Finite `p^2` cover

The authenticated bundle certifies:

- exactly 527 bounded-order eligible primes at order bound 5000;
- those 527 primes cannot form a global finite `p^2` cover;
- every possible global cover needs at least 598 primes;
- at least 135 primes must have maximum relevant order above 5000.

This round did not enlarge the order bound and did not resume cover
optimization.

### Analytic bad-prime route

Random CRT moments, standard first/second moments, uncentered additive energy,
larger periodic tori, broad mask optimization, and an `L^2`-to-adversarial-
`L^infinity` inference remain stopped.

## Compliance boundary

No WSL repository, Git integration, Codex CLI, Codex Ultra, distributed
computation, long-range `T(n)` enumeration, low-`T` record search, or expansion
of the 598-prime program was used.
