# THEOREMS AND PROOFS

## 0. Notation

Let

\[
\mathcal S_2=\{a^2+b^2:a,b\in\mathbf Z_{\ge0}\},\qquad
h(c,d)=3^c+5^d,
\]

and

\[
\mathcal H(n)=\{(c,d)\in\mathbf Z_{\ge0}^2:h(c,d)\le n\}.
\]

A counterexample is an integer `n>1` for which every active remainder
`n-h(c,d)` is outside `S_2`.

For a prime `q`, `q^k || m` means `v_q(m)=k`.

---

## Theorem 1 — basic counterexample and collision constraints

Let `n` be a counterexample.

1. Every active remainder is strictly positive.
2. Every active remainder has a prime `q = 3 (mod 4)` at odd valuation.
3. If the same prime `q = 3 (mod 4)` witnesses two shifts `h != h'`, then
   `q | h-h'`.  More precisely, if
   `v_q(n-h)=k` and `v_q(n-h')=l`, then
   
   - if `k != l`, `v_q(h-h')=min(k,l)`;
   - if `k=l`, `v_q(h-h')>=k`.
4. If `n>6`, at least three distinct bad primes are required to witness the
   remainders at shifts `2,4,6`.

### Proof

If an active remainder were zero, then it would equal `0^2+0^2`, contrary to
counterexample status.  The second assertion is Fermat's two-square criterion.
For the third,

\[
h'-h=(n-h)-(n-h').
\]

The standard nonarchimedean valuation rule gives equality with the smaller
valuation when the valuations differ, and at least that value when they are
equal.  Finally, the pairwise differences among `2,4,6` are `2,2,4`.  No prime
`3 mod 4` divides any of them, so by the collision assertion no witness prime
can serve two of these three remainders.  ∎

---

## Theorem 2 — minimality escape lemma

Let `n_0` be a least counterexample.  For every integer
`1 <= Delta <= n_0-2`, every representation

\[
n_0-\Delta=s+h,\qquad s\in\mathcal S_2,\quad h\in
\{3^c+5^d:c,d\ge0\},
\]

satisfies

\[
h+\Delta\notin\{3^c+5^d:c,d\ge0\}.
\]

For odd `Delta` this condition is vacuous.  For every fixed even
`Delta>0`, the escape set

\[
E_\Delta=\{h:h=3^c+5^d,\ h+\Delta\notin\{3^u+5^v\}\}
\]

is infinite.

### Proof

Minimality represents `n_0-Delta` because it is greater than `1`.  If
`h+Delta` were another shift, the same two-square part would give a
representation of `n_0`, contradiction.

Every shift is even, so for odd `Delta`, `h+Delta` is odd and cannot be a
shift; no information is gained.

Now fix even `Delta` and suppose `E_Delta` were finite.  Beyond its largest
element the shift set would be closed under addition by `Delta`.  Starting
with any sufficiently large shift and iterating would produce an infinite
arithmetic progression inside the shift set.  But the number of shifts at most
`X` is at most

\[
(\lfloor\log_3 X\rfloor+1)(\lfloor\log_5 X\rfloor+1)=O((\log X)^2),
\]

whereas an arithmetic progression contributes `Omega(X)` elements.  This is
impossible.  ∎

---

## Theorem 3 — finite affine anti-lifting theorem

Fix finitely many pairs `(lambda_i,k_i)` with positive integers
`lambda_i` and nonzero integers `k_i`.  There exist arbitrarily large
`s in S_2` such that all integers

\[
\lambda_i s+k_i
\]

are positive and lie outside `S_2`.

### Proof

Choose distinct primes `q_i = 3 (mod 4)` such that

\[
q_i\nmid 2\lambda_i k_i.
\]

Modulo `q_i^2`, solve

\[
\lambda_i u_i+k_i\equiv q_i\pmod{q_i^2}.
\]

Because `q_i` divides neither `lambda_i` nor `k_i`, the resulting `u_i` is a
unit modulo `q_i`.

Every unit modulo `q_i^2` is a sum of two squares modulo `q_i^2`.  Indeed, the
norm map from `F_{q_i^2}^*` to `F_{q_i}^*` is surjective, so
`x^2+y^2=u_i (mod q_i)` has a solution not both zero.  At least one partial
derivative `2x,2y` is nonzero modulo `q_i`, and Hensel lifting gives a solution
modulo `q_i^2`.

Choose local pairs `(x_i,y_i)` with

\[
x_i^2+y_i^2\equiv u_i\pmod{q_i^2}.
\]

CRT gives integers `x,y` satisfying all local conditions.  Set
`s=x^2+y^2`.  Then

\[
\lambda_i s+k_i\equiv q_i\pmod{q_i^2},
\]

so `v_{q_i}(lambda_i s+k_i)=1`; hence every image is outside `S_2`.  Replacing
`x` by `x+t prod_i q_i^2` preserves every congruence and makes `s`, and hence
all images, arbitrarily large and positive.  ∎

### Consequence

No finite menu of fixed affine corrections with nonzero additive offsets can
be the universal mechanism that lifts arbitrary sufficiently large two-square
remainders in a minimal-counterexample argument.  Maps with zero offset are
outside the theorem and may preserve `S_2` (for example the identity).

---

## Theorem 4 — designated private-witness CRT lemma

Let `h_1,...,h_r` be distinct integers.  Let `M>=1` and `a mod M` be arbitrary.
There exist distinct primes `q_i = 3 (mod 4)` and infinitely many integers `n`
with

\[
n\equiv a\pmod M,
\]

such that

\[
q_i\parallel n-h_i,
\qquad
q_i\nmid n-h_j\quad(j\ne i).
\]

### Proof

Choose distinct primes `q_i = 3 (mod 4)` avoiding `M` and all nonzero
differences `h_i-h_j`.  The congruences

\[
n\equiv a\pmod M,
\qquad
n\equiv h_i+q_i\pmod{q_i^2}
\]

have infinitely many solutions by CRT.  The second congruence gives exact
valuation one at `h_i`; for `j!=i`, reduction modulo `q_i` gives
`n-h_j = h_i-h_j != 0 (mod q_i)`.  ∎

### Logical scope

This theorem constructs *designated* private witnesses.  It does not assert
that alternative shared witnesses are absent, and it does not construct an
A303656 counterexample.  Its rigorous conclusion is narrower: an arbitrary
choice of one Fermat witness per remainder need not exhibit reuse, even after
a fixed residue signature is imposed.  Therefore any theorem forcing a small
cover must use the full arithmetic set of available witnesses or additional
global structure; it cannot treat a chosen witness assignment as canonical.

---

## Theorem 5 — fixed-modulus indistinguishability of `S_2`

Let `M>=1`.  If a residue `r mod M` is represented by a sum of two squares
modulo `M`, then that residue class contains infinitely many integers in
`S_2` and infinitely many positive integers outside `S_2`.

### Proof

Choose `x_0,y_0` with `x_0^2+y_0^2=r (mod M)`.  The integers

\[
(x_0+tM)^2+y_0^2
\]

supply infinitely many members of `S_2` in the class.

Choose a prime `q=3 (mod 4)` not dividing `M`.  CRT gives infinitely many
positive `z` satisfying

\[
z\equiv r\pmod M,
\qquad z\equiv q\pmod{q^2}.
\]

Then `v_q(z)=1`, so `z` is not a sum of two squares.  ∎

### Consequence

No single fixed modulus, and no finite automaton whose acceptance is exactly a
fixed residue test, decides the two-square predicate globally.

---

## Theorem 6 — non-semilinearity of the shift set

The set

\[
\mathcal A=\{3^c+5^d:c,d\ge0\}\subset\mathbf N
\]

is not semilinear.  Consequently it is not definable in ordinary Presburger
arithmetic.

### Proof

The set is infinite, while

\[
|\mathcal A\cap[0,X]|=O((\log X)^2).
\]

Every infinite one-dimensional semilinear set contains an infinite arithmetic
progression and therefore has at least linear counting growth along a tail.
This contradicts the displayed bound.  The Presburger conclusion follows from
the Ginsburg–Spanier equivalence between Presburger and semilinear sets.  ∎

---

## Theorem 7 — no common-square descent from the first two shifts

For every integer `n`,

\[
\gcd(n-2,n-4)\mid2.
\]

Hence no square `q^2>1` divides all active remainders of a counterexample once
shifts `2` and `4` are active.

### Proof

The gcd divides their difference `2`.  ∎

---

## Theorem 8 — state-certificate descent theorem

Let `Q` be a nonempty finite set of primes `q=3 (mod 4)` and let `E>=2`.
Define

\[
L=\prod_{q\in Q}q^E,
\]

\[
C=\operatorname{lcm}\{\operatorname{ord}_{q^E}(3):q\in Q,\ q\ne3\},
\]

with the lcm of the empty set equal to `1`, and

\[
D=\operatorname{lcm}\{\operatorname{ord}_{q^E}(5):q\in Q\}.
\]

Define canonical exponent representatives

\[
c^*=\begin{cases}
c,&c<E,\\
E+((c-E)\bmod C),&c\ge E,
\end{cases}
\qquad
d^*=d\bmod D.
\]

For an integer `n`, let `R_n(Q,E)` be the set of canonical pairs `(c^*,d^*)`
arising from active pairs `(c,d) in H(n)`, and let

\[
H_n(Q,E)=\max_{(u,v)\in R_n(Q,E)}(3^u+5^v).
\]

Suppose that for every `(u,v) in R_n(Q,E)` there exist `q in Q` and odd
`k`, `1<=k<E`, such that

\[
q^k\parallel n-3^u-5^v. \tag{SC}
\]

Then:

1. condition `(SC)` is a finite certificate implying `T(n)=0`;
2. if `n>H_n(Q,E)+L`, then
   
   \[
   F(n)=H_n(Q,E)+1+((n-H_n(Q,E)-1)\bmod L)
   \]
   
   satisfies `1<F(n)<n` and `T(F(n))=0`.

### Proof

For every `q in Q`, the canonical representative preserves both powers modulo
`q^E`.  Moreover `c^*<=c` and `d^*<=d`, so a canonical representative of an
active pair is itself active.  For the base `3`, the only special case is `q=3`: once `c>=E`, both
`3^c` and `3^{c^*}` vanish modulo `3^E`.  For `q!=3`, congruence of exponents
modulo `C` gives equality of residues.  Since no `q in Q` equals `5`, the
`d`-coordinate is periodic modulo `D`.

Thus any active pair and its canonical representative have congruent shifts
modulo every `q^E`.  If the representative has exact valuation `k<E`, the
active pair has the same exact valuation.  This proves `T(n)=0`; a zero
remainder is impossible because its valuation would not be the finite `k`.

Now assume `n>H_n+L`.  The displayed `F(n)` lies in `[H_n+1,H_n+L]`, is
congruent to `n` modulo `L`, and is strictly between `1` and `n`.  Every pair
active for `F(n)` is active for `n`.  Its canonical state therefore belongs to
`R_n`.  Transfer `(SC)` first from the representative to the pair and then
from `n` to `F(n)` using congruence modulo `q^E`; exact valuation remains the
same because `k<E`.  Every remainder for `F(n)` is positive and has an odd
`q=3 (mod 4)` valuation.  Hence `T(F(n))=0`.  ∎

---

## Corollary 9 — canonical-representative witness finite reduction

With `Q,E,L,C,D` as in Theorem 8, define the full canonical state set

\[
\mathcal R(Q,E)=\{0,1,\ldots,E+C-1\}\times
                 \{0,1,\ldots,D-1\},
\]

and put

\[
H(Q,E)=3^{E+C-1}+5^{D-1},
\qquad N_*(Q,E)=H(Q,E)+L(Q,E).
\]

Define `CRW(Q,E)` (canonical-representative witnesses) to mean:

> For every A303656 counterexample `n>N_*(Q,E)` and every
> `(u,v) in R(Q,E)`, there exist `q in Q` and an odd integer `k` with
> `1<=k<E` such that
> 
> \[
> q^k\parallel n-3^u-5^v. \tag{CRW}
> \]

If `CRW(Q,E)` holds, then every counterexample above `N_*(Q,E)` descends by

\[
F(n)=H(Q,E)+1+((n-H(Q,E)-1)\bmod L(Q,E)).
\]

Consequently,

\[
(\exists n>1:T(n)=0)\Longrightarrow
(\exists n\le N_*(Q,E):T(n)=0).
\]

### Proof

If `n>H+L`, every pair in the full canonical state set has shift at most `H`
and is active for `n`.  Conversely every active pair maps into that state set,
so `R_n(Q,E)=R(Q,E)`.  Condition `(CRW)` is therefore exactly condition `(SC)`
of Theorem 8.  The explicit descent follows.  A least counterexample cannot
exceed `N_*`.  ∎

### Logical strength

`CRW(Q,E)` asks for bounded witnesses only for the fixed finite list of
`(E+C)D` canonical translations.  It does **not** ask that every active
remainder itself have a witness in `Q`.  Thus it is strictly weaker than the
`UBVC(Q,E)` hypothesis below and is the sharpest uniform trigger isolated in
this round.

### Classification

The implication `CRW(Q,E) => explicit descent and finite reduction` is
**PROVED**.  The existence of explicit `Q,E` satisfying `CRW` is **NOT ESTABLISHED**.

---

## Corollary 10 — uniform bounded valuation certificates are sufficient

Define `UBVC(Q,E)` to mean:

> For every A303656 counterexample `n` and every active pair `(c,d)`, at least
> one prime `q in Q` has an odd exact valuation
> `1<=v_q(n-3^c-5^d)<E`.

Then `UBVC(Q,E)` implies `CRW(Q,E)`, and hence gives the same explicit descent
map and finite bound `N_*(Q,E)` from Corollary 9.

### Proof

For `n>N_*`, every canonical representative is active.  Apply `UBVC` to those
representatives and then Corollary 9.  ∎

### Classification

The implication `UBVC(Q,E) => CRW(Q,E) => finite reduction` is **PROVED**.
The existence of uniform `Q,E` satisfying either hypothesis is
**NOT ESTABLISHED**.  `UBVC` is a convenient stronger sufficient condition,
not the minimal missing lemma.

---

## Proposition 11 — uniform mixed-base Brahmagupta scaling is trivial

Suppose a fixed `Q in S_2` is intended to scale every representation termwise,
so that for fixed nonnegative integers `r,s`,

\[
Q3^c=3^{c+r},\qquad Q5^d=5^{d+s}
\]

for all `c,d`.  Then `Q=1` and `r=s=0`.

### Proof

The two identities force `Q=3^r=5^s`.  Unique factorization gives
`r=s=0` and `Q=1`.  ∎

This does not exclude sporadic identities or transformations that mix terms;
it excludes the direct uniform termwise scaling that succeeds in same-base
problems.
