# REPORT

# A303656 EXCEPTIONAL-SET DESCENT AND FINITE-REDUCTION TRIGGER HUNT — PHASE A

User: Samsen  
Date: 2026-07-17  
Recommended and used environment: webpage GPT-5.6 Pro, standalone Python,
Linux container.  No Codex CLI or Codex Ultra.

## 1. Final verdict

\[
\boxed{\textbf{NO PROMOTABLE ROUTE — RETAIN AS SPECULATIVE WATCH}}
\]

No unconditional Target D, F, or globally useful Target C theorem was proved.
A precise and effective conditional finite-reduction theorem was proved from
the weaker canonical-representative witness hypothesis `CRW(Q,E)`.  The
stronger all-active-pair condition `UBVC(Q,E)` implies `CRW`.  Neither is
established; the missing numerical-prime and valuation-depth bounds are the
central unresolved synchronization problem, not a technical afterthought.

Global problem status:

\[
\boxed{\text{OEIS A303656: UNRESOLVED}.}
\]

## 2. Problem and quantifier barrier

Let

\[
T(n)=\#\{(c,d):3^c+5^d\le n,\ n-3^c-5^d\in\mathcal S_2\}.
\]

A counterexample has `T(n)=0`.  Fermat's criterion gives

\[
\forall(c,d)\in\mathcal H(n)\quad
\exists q=q(c,d)\equiv3\pmod4:
 v_q(n-3^c-5^d)\text{ is odd}.
\]

The desired reduction would need to exchange or compress the quantifiers:
replace the pair-dependent primes and depths by a bounded finite object, then
use periodic exponent states.  The finite-state part is tractable; the
witness-synchronization part is not.

For fixed `n`, selecting one witness per active pair is trivial and gives at
most `O(log^2 n)` primes.  This does not bound the prime values, valuation
depths, modulus, or least exception.

## 3. Authority compliance

All four expected ZIP archives passed SHA256 and `unzip -t`.  The reset archive
has a harmless `(2)` filename suffix but exact expected bytes.  The following
states were treated as binding:

- project `PAUSED`, no active promoted route;
- positive-density theorem frozen and not re-audited;
- 527 bounded-order primes cannot form a global `p^2` cover;
- every possible global cover needs at least 598 primes and at least 135 primes
  beyond order bound 5000;
- random CRT, standard moments, uncentered energy, larger tori, broad mask
  optimization, and range expansion remain stopped.

No new `T(n)` interval enumeration was performed.

## 4. Minimal-counterexample analysis

Assume a least counterexample `n_0` exists.

### 4.1 Exact constraints

- `n_0>=7`.
- Every active remainder is positive; equality zero is already a two-square
  representation.
- Every active remainder has an odd bad-prime valuation.
- One witness prime shared by two shifts must divide their difference, with the
  precise valuation law recorded in Theorem 1.
- Shifts `2,4,6` force at least three distinct witness primes.
- No square `q^2>1` divides all active remainders because
  `gcd(n_0-2,n_0-4)|2`.

### 4.2 What minimality actually gives

For `m=n_0-Delta`, minimality gives some representation `m=s+h`.  It does not
allow an arbitrary choice of `h`.  The exact conclusion is

\[
h+\Delta\notin\mathcal A.
\]

For odd `Delta`, this is automatic because `A` is even.  For fixed even
`Delta`, the set of such escape shifts is infinite.  Therefore subtraction by
`2,4,8,3^u,5^v` does not yield descent without a new transformation of the
two-square component.

### 4.3 Parity and divisibility

Parity produces no restriction on `n_0`.  No forced divisibility by `3` or `5`
was obtained.  Prime `3` cannot witness more than one of shifts `2,4,6`; prime
`5` is not a bad prime for the two-square theorem.

## 5. Strongest proved positive theorem

### 5.1 Finite exponent states from bounded valuation data

Fix a finite set `Q` of bad primes and `E>=2`.  Residues of `3^c` and `5^d`
modulo `q^E` have finitely many states.  The base-prime case `q=3` is handled
by a finite head `c<E` and the stable tail `3^c=0 mod 3^E`.

Let `L=prod q^E`.  A certificate that gives one exact odd valuation below `E`
for each canonical state certifies all active pairs in that state.

### 5.2 Pointwise state-certificate descent

For a particular certified counterexample `n`, let `H_n` be the maximum
canonical representative shift among states occurring in its active domain.
If

\[
n>H_n+L,
\]

then

\[
F(n)=H_n+1+((n-H_n-1)\bmod L)
\]

is a smaller counterexample.  This is a complete Target D theorem under an
explicit, independently verifiable premise.

### 5.3 Uniform finite-reduction corollary

Let

\[
H=3^{E+C-1}+5^{D-1},\qquad N_*=H+L.
\]

It is enough to prove `CRW(Q,E)`: for every counterexample `n>N_*`, each of the
fixed `(E+C)D` canonical representative remainders has an odd witness in `Q`
below depth `E`.  Then

\[
(\exists n>1:T(n)=0)\Longrightarrow
(\exists n\le N_*:T(n)=0).
\]

The exact map and bound are computable.  The stronger `UBVC(Q,E)` condition for
all active remainders implies `CRW`, but is not needed.  Thus the finite-state
construction is not the gap.

## 6. Why `CRW(Q,E)` remains open

Two independent bounds are still needed, but only for a fixed finite list of
canonical translations:

1. a fixed finite set of numerical primes covering those representative
   remainders for every sufficiently large counterexample;
2. a fixed upper bound on the odd valuation used by the certificate.

A bound on cardinality alone is insufficient.  Without numerical and depth
bounds, the prime-power modulus and multiplicative periods remain unbounded.

The designated-private-witness CRT lemma shows that any finite set of shifts
can be given pairwise private exact *designated* bad-prime witnesses while `n`
remains in an arbitrary fixed residue class.  This does not construct a
counterexample and does not exclude alternative shared witnesses.  Its exact
negative leverage is that an arbitrary one-witness-per-pair selection need not
show reuse; a bounded-cover theorem must analyze the full witness sets or use
additional global counterexample structure.

The frozen `p^2` results reinforce the scale obstruction: the natural bounded-
order pool is already certified insufficient.  Restarting finite cover
optimization would not prove the missing theorem.

## 7. Reverse descent and identities

### 7.1 Finite affine corrections

A general CRT theorem proves that for any finite list
`s -> lambda_i s+k_i` with `lambda_i>0` and `k_i!=0`, there are arbitrarily
large `s in S_2` whose every image is a positive non-sum of two squares.
Therefore no finite fixed-affine menu with nonzero offsets can be the universal
reverse-lifting device.  Zero-offset maps are outside this theorem.

### 7.2 Brahmagupta–Fibonacci scaling

The product of two integers in `S_2` is again in `S_2`, but a fixed scale preserving the two power
terms termwise would satisfy `Q=3^r=5^s`, hence `Q=1`.  Crocker's same-base
powers-of-two descent relies on homogeneity absent here.  Sporadic identities
remain possible but no finite covering family was found.

## 8. Finite-state and fixed-modulus audit

For a fixed modulus, exponent orbits are periodic.  This is not a global
finite-state theorem because the bad primes and valuation depths can grow.
Two rigorous obstructions were recorded:

- every locally two-square-admissible residue class modulo any fixed `M`
  contains infinitely many members and nonmembers of `S_2`;
- the shift set `{3^c+5^d}` is not semilinear and hence not ordinary
  Presburger-definable.

Shuo Li's non-morphicity theorem gives compatible negative evidence against a
direct global substitution automaton.  None of these results rules out the
certificate-dependent automaton used in the proved conditional theorem.

## 9. S-unit, primitive-divisor, and Skolem audit

Effective S-unit bounds require a fixed finite prime set and fixed equation.
The A303656 witness statement supplies neither.  Finite-rank linear-equation
bounds count solutions once a fixed multiplicative group exists; they do not
create it from pair-dependent factors.

Primitive-divisor theorems concern fixed divisibility sequences and do not
supply odd `3 mod 4` valuations of all moving remainders.

Skolem–Mahler–Lech treats zeros of fixed one-dimensional recurrences.  Its
general effectivity remains limited; recent order-four decidability and
conditional p-adic algorithms do not encode the bivariate moving two-square
predicate.

## 10. Covering systems and compactness

A fixed finite covering certificate is independently checkable.  Hough's
minimum-modulus theorem starts from an existing finite distinct covering
system; it does not show one exists here.  Generic finite-truncation coverability
has no compactness consequence when the universe and witness family grow.
Hypergraph optimization can solve a frozen finite instance but cannot supply
the missing absolute prime/depth bound.

## 11. Small experiments

Only falsification-oriented tests were run:

- early counterexamples to tested affine maps;
- direct verification of the CRT norm construction;
- a private-witness CRT example;
- fixed-modulus member/nonmember pairs;
- shift-translation escape examples;
- toy finite-state residue bookkeeping for `Q={3,7}`, `E=2`;
- the elementary three-witness and gcd checks.

No absence of a small counterexample is used as evidence.

## 12. Candidate score

The highest-value candidate is `F1-CRW`:

- exact theorem: YES;
- quantifier compression conditional on `CRW`: complete;
- effectivity: complete;
- hypothesis concerns only fixed canonical representatives;
- core support for fixed numerical primes and depths: absent;
- finite next phase without the missing theorem: none.

The pointwise `D0-SCD` theorem is retained as a reusable proof component.  It
becomes operational only when a complete certificate satisfies a strict
self-bound.

## 13. Promotion-gate decision

| gate | result | reason |
|---|---|---|
| Exact theorem | PARTIAL PASS | exact conditional D/F and pointwise C/D theorem proved |
| Unconditional quantifier compression | FAIL | no proved `CRW(Q,E)`, no explicit absolute `N_*` |
| Non-circularity | PASS for conditional theorem | `CRW` is a distinct finite-translation statement, but not proved |
| Nontrivial support | PARTIAL PASS | finite-state descent core proved; prime/depth core open |
| Effectivity | PASS conditionally / FAIL globally | formulas explicit once `Q,E` are known |
| Closed-route separation | PARTIAL | `CRW` is weaker than global cover; `UBVC` would overlap the frozen route |
| Finite next phase | FAIL | no bounded auditable search follows without new theorem input |

Because all gates must pass, promotion is denied.

## 14. Authorized next action

Retain `CRW(Q,E) => finite reduction` as a low-cost theorem-watch trigger.
Reopen work only if a primary source or independent proof supplies explicit
`Q,E` satisfying `CRW`, or a still weaker effective statement that forces the
pointwise descent inequality for all sufficiently large counterexamples.

Not authorized:

- Codex implementation;
- Codex Ultra;
- new long-range search;
- larger modulus or torus search;
- renewed 598-prime optimization;
- density-only continuation.

## 15. Research value of the negative verdict

The round did not prove that no descent exists.  It did rigorously separate the
finite-state bookkeeping from the true global obstacle and eliminated several
seductive false transfers.  This prevents future rounds from spending compute
on certificates whose existence has not been bounded.

**OEIS A303656: UNRESOLVED.**
