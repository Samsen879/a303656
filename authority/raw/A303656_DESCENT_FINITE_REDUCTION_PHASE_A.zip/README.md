# A303656 DESCENT / FINITE-REDUCTION TRIGGER HUNT — PHASE A

## Scope

This package records a controlled theorem-discovery round for OEIS A303656:

\[
n=a^2+b^2+3^c+5^d,
\qquad a,b,c,d\in\mathbf Z_{\ge 0}.
\]

The project-level status remains `PAUSED`; A303656 remains `UNRESOLVED`.  This
round did not reopen interval search, the bounded-order `p^2` cover program,
random-CRT moments, or any large computation.

## Final decision

`SPECULATIVE_WATCH_ONLY`

No unconditional descent, least-exception bound, or uniformly bounded
certificate family was obtained.  The strongest positive result is an exact,
effective **finite-state descent theorem conditional on canonical-representative
witness bounds** `CRW(Q,E)`.  This hypothesis concerns only a fixed finite set
of state representatives; the stronger all-active-pair hypothesis `UBVC(Q,E)`
implies it.  The reduction is proved, but neither witness-bound hypothesis is
established.

## Entry points

- `EXECUTIVE_VERDICT.md` — two-page decision summary.
- `REPORT.md` — full synthesis.
- `THEOREMS_AND_PROOFS.md` — exact statements and proofs.
- `LITERATURE_AUDIT.md` — primary-source theorem crosswalk.
- `NO_GO_RESULTS.md` — reusable route-elimination lemmas.
- `PROMOTION_VERDICT.json` — machine-readable gate decision.
- `scripts/small_experiments.py` — falsification-oriented checks only.

## Execution policy

Recommended environment for this round: webpage GPT-5.6 Pro with standalone
Python and Linux container.  Ordinary Codex and Codex Ultra were not used and
are not authorized by this package.
