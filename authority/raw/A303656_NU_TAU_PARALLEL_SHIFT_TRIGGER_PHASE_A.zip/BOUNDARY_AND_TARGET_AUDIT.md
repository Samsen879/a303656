# Boundary, diagonal, centering, and target audit

## Exact variance versus the schematic \(C_h\)-sum

The support-transference object inherited from the previous phase is

\[
\sum_{n\in I_X}(V_X(n)-\bar V_X)^2
=
\sum_{s,t}w_X(s)w_X(t)
\left(
C_{s,t}^{\nu}(X)-
\frac{A_s^\nu(X)A_t^\nu(X)}{|I_X|}
\right),
\tag{1}
\]

where

\[
A_s^\nu(X)=\sum_{n\in I_X}\nu(n-s),
\qquad
C_{s,t}^{\nu}(X)=\sum_{n\in I_X}\nu(n-s)\nu(n-t).
\tag{2}
\]

After \(m=n-s\), the pair term is a parallel correlation at \(h=s-t\), but on the moving interval

\[
[X-s,2X-s].
\tag{3}
\]

The user's schematic expression

\[
\sum_h \nu_X(h)
\left(C_h(X)-\frac{M(X)^2}{X}\right)
\tag{4}
\]

is not an exact substitute for (1) unless all of the following are frozen:

1. the definition of the difference multiplicity \(\nu_X(h)\);
2. whether both arguments in \(C_h\) are truncated to a common interval;
3. treatment of negative \(h\);
4. the absolute location of the interval;
5. the correct one-point factors \(A_sA_t/|I_X|\), rather than a universal \(M^2/X\).

Here shifts can reach \(X/2\), so changing (3) to \([1,X]\) can create an error of main-term size. It is not a harmless \(o(X/\log X)\) boundary replacement.

## Diagonal

Because \(0\le\nu\le1\),

\[
\nu(n)^2\le\nu(n).
\]

With the frozen collision estimate

\[
\sum_s w_X(s)^2=W_X+O(1),
\]

the diagonal contribution is

\[
O\!\left(\frac{XW_X}{\sqrt{\log X}}\right)
=o\!\left(\frac{XW_X^2}{\log X}\right)
\]

because \(W_X\asymp(\log X)^2\). The diagonal is not the blocker.

## Boundary-uniform one-point terms

The one-point asymptotic gives, uniformly for \(0\le s\le X/2\),

\[
A_s^\nu(X)
=F_\nu(2X-s)-F_\nu(X-s)
=(c_\tau+o(1))\frac{X}{\sqrt{\log X}}.
\]

The same endpoint-subtraction argument works after any fixed congruence restriction. Thus the mod-6 obstruction in `STRONGEST_LEMMA.md` is fully boundary-aware.

## Singular-series centering

Even for fixed \(h\), a plausible main term must depend on \(h\) through local factors. The universal subtraction \(M(X)^2/X\) represents an independence model with Haar-distributed local differences. The structured shifts are not Haar-distributed:

- every shift \(3^c+5^d\) is even, hence every difference is even;
- asymptotically half of the shifts are \(2\pmod6\) and half are \(4\pmod6\);
- consequently, structured difference divisibility at 2 and 3 is biased.

The exact variance lower bound shows that this local bias survives at the target scale. Any future correlation theorem must either retain an \(h\)-dependent singular series and average it against the true difference multiset, or first perform a congruence-class/\(W\)-tricked renormalization.

## Verdict for the literal schematic target

- If (4) is intended as shorthand for the exact variance (1), its global-centering little-o is false by the strongest lemma.
- If (4) is interpreted literally with \(C_h(X)=\sum_{m\le X}\nu(m)\nu(m+h)\), it is under-specified and is not proven equivalent to the support trigger; boundary changes can be main-scale.
- Neither interpretation supplies a promotable support theorem.
