# A303656 NU-TAU PARALLEL-SHIFT CORRELATION — PHASE A

审计日期：2026-07-21  
执行环境：网页端 GPT-5.6 Pro（无 Codex、无 Ultra、无 repository integration、无大型 `T(n)` search）

## 最终裁决

**STOP NU-TAU CORRELATION TRIGGER**

本轮最强结论不是“仍需要 covariance”，而是：上一阶段使用 global mean centering 的 exact support-transference variance trigger 被一个可证明的 `mod 6` local profile 否定。若

\[
V_X(n)=\sum_s w_X(s)\nu_\tau(n-s),
\qquad
\bar V_X=|I_X|^{-1}\sum_{n\in I_X}V_X(n),
\]

则

\[
\liminf_{X\to\infty}
\frac{\log X}{c_\tau^2XW_X^2}
\sum_{n\in I_X}|V_X(n)-\bar V_X|^2
\ge \kappa_6,
\]

其中

\[
\kappa_6
=\frac32\left(\frac1{\log2}-1\right)^2
+\frac12\left(\frac1{\log2}-1\right)^4
=0.31317221331276824365\ldots>0.
\]

因此所需的 `little-o` concentration 不成立；这不是 literature gap，而是 target defect。

## 三个目标的状态

1. **fixed h asymptotic**：未找到可直接应用于 `nu_tau × nu_tau` 的 primary theorem；可信 main term 必须包含依赖 `v_p(h)` 的 singular series。
2. **growing h uniform asymptotic**：已审计 theorem 的 coefficient class、pretentiousness、divisor-convolution decay 或 nonparallel geometry hypotheses 均失败。
3. **structured aggregate signed covariance**：若它代表上一阶段 exact boundary-aware variance，则 global-centering `little-o` 已被上述 lemma 否定；若按字面采用统一区间 `C_h(X)`，则尚未冻结 boundary、negative shifts、difference multiplicity 和 centering，不能等同于 support trigger。

可进行的 repair 是 `mod 6` classwise centering 或 fuller `W`-trick。但 repair 后仍需 parallel covariance theorem，且该剩余 lemma 并不明显弱于 frozen indicator covariance blocker，故不 promotion。

## Bundle 目录

- `REPORT.md`：中文主报告与 promotion decision。
- `STRONGEST_LEMMA.md`：`mod 6` obstruction 的完整证明。
- `LITERATURE_AUDIT.md`：primary-source theorem-by-theorem audit。
- `THEOREM_HYPOTHESIS_CROSSWALK.csv`：exact theorem / hypothesis / failure crosswalk。
- `BOUNDARY_AND_TARGET_AUDIT.md`：exact variance 与 schematic `C_h` 的边界差异。
- `SINGULAR_SERIES_AUDIT.md`：candidate local factors；明确标为 conjectural local model。
- `SOURCE_LOCK.json`：primary-source versions、theorem anchors、PDF SHA256 与 access status。
- `PROVENANCE.json`, `INPUT_HASHES.tsv`：上游 bundle provenance。
- `PROMOTION_VERDICT.json`：machine-readable verdict。
- `scripts/check_local_obstruction.py`：闭式常数和小型 exponent-domain audit；不是 `T(n)` search。
- `results/check_local_obstruction.txt`：deterministic check output。
- `scripts/verify_bundle.py`, `scripts/build_deterministic_zip.py`, `REPRODUCE.sh`：复验与 deterministic ZIP build。

## 复验

在 bundle 根目录运行：

```bash
bash REPRODUCE.sh
```

脚本会重跑 local obstruction check、逐文件验证 SHA256，并在父目录重建 deterministic ZIP。
