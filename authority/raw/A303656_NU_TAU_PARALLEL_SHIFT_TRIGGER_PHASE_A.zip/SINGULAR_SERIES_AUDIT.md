# Candidate singular-series audit (local model only)

This file records the local factor that any credible fixed-shift asymptotic should reproduce. It is **not** asserted as a proved global asymptotic.

Let \(a_k=\nu_\tau(p^k)\) and

\[
\mu_p=(1-p^{-1})\sum_{k\ge0}a_kp^{-k}.
\]

For \(r=v_p(h)<\infty\), direct \(p\)-adic valuation enumeration gives

\[
L_{p,0}=1-\frac2p
+2\left(1-\frac1p\right)
\sum_{j\ge1}a_jp^{-j},
\tag{1}
\]

and, for \(r\ge1\),

\[
L_{p,r}
=\left(1-\frac1p\right)
\sum_{a=0}^{r-1}a_a^2p^{-a}
+p^{-r}\left[
\left(1-\frac2p\right)a_r^2
+2\left(1-\frac1p\right)a_r
\sum_{j\ge1}a_{r+j}p^{-j}
\right].
\tag{2}
\]

The natural normalized candidate is

\[
\mathfrak S_p(h)=\frac{L_{p,v_p(h)}}{\mu_p^2}.
\tag{3}
\]

At \(p=3\),

\[
\mu_3=\log2.
\]

If \(3\nmid h\), then

\[
L_{3,0}=2\log2-1.
\]

If \(v_3(h)=1\), then

\[
L_{3,1}=\frac23.
\]

Thus the local main term changes with \(v_3(h)\). Similar dependence occurs at 2. A fixed-\(h\) theorem with an \(h\)-independent main term would therefore be arithmetically implausible.

For the structured family, the distribution of \(v_p(h)\) is not the Haar distribution assumed by a naive product-of-means centering. In particular all differences are even, and the mod-3 difference frequencies are inherited from the approximately two-point shift distribution \(\{2,4\}\pmod6\). This is the local mechanism behind the proven mod-6 variance lower bound.

A future theorem would need all three components:

1. a proved fixed- or growing-shift asymptotic with factors such as (3);
2. an error uniform enough to sum against the structured difference multiplicities;
3. an exact average of the singular series against that multiset, with boundary-dependent one-point terms retained.

None is presently locked for \(\nu_\tau\).
