#!/usr/bin/env python3
"""Build a byte-deterministic ZIP from the Phase A bundle directory."""
from __future__ import annotations

import pathlib
import sys
import zipfile

FIXED_TIME = (1980, 1, 1, 0, 0, 0)
EXCLUDE_NAMES = {"A303656_NU_TAU_PARALLEL_SHIFT_TRIGGER_PHASE_A.reproduced.zip"}


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: build_deterministic_zip.py ROOT OUTPUT.zip")
    root = pathlib.Path(sys.argv[1]).resolve()
    out = pathlib.Path(sys.argv[2]).resolve()
    if not root.is_dir():
        raise SystemExit(f"not a directory: {root}")
    files = sorted(
        p for p in root.rglob("*")
        if p.is_file() and p.name not in EXCLUDE_NAMES and p.resolve() != out
    )
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in files:
            rel = path.relative_to(root).as_posix()
            data = path.read_bytes()
            info = zipfile.ZipInfo(rel, FIXED_TIME)
            info.create_system = 3
            info.external_attr = (0o100644 & 0xFFFF) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            info.flag_bits |= 0x800
            zf.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    print(out)


if __name__ == "__main__":
    main()
