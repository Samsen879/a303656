#!/usr/bin/env python3
"""Verify schemas, hashes, deterministic local output, and verdict invariants."""
from __future__ import annotations

import hashlib
import json
import pathlib
import subprocess
import sys

REQUIRED = {
    "README.md", "REPORT.md", "EXECUTIVE_VERDICT.md", "STRONGEST_LEMMA.md",
    "BOUNDARY_AND_TARGET_AUDIT.md", "SINGULAR_SERIES_AUDIT.md",
    "LITERATURE_AUDIT.md", "THEOREM_HYPOTHESIS_CROSSWALK.csv",
    "SOURCE_LOCK.json", "PROVENANCE.json", "PROMOTION_VERDICT.json",
    "INPUT_HASHES.tsv", "MANIFEST.json", "SHA256SUMS.txt", "REPRODUCE.sh",
    "results/check_local_obstruction.txt", "results/source_pdf_sha256s.txt",
    "scripts/check_local_obstruction.py", "scripts/build_deterministic_zip.py",
    "scripts/verify_bundle.py"
}


def sha(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    files = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    missing = sorted(REQUIRED - files)
    if missing:
        raise SystemExit(f"missing required files: {missing}")

    for rel in sorted(files):
        data = (root / rel).read_bytes()
        if b"\r\n" in data:
            raise SystemExit(f"CRLF forbidden: {rel}")

    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["schema"] == "A303656_NU_TAU_PARALLEL_SHIFT_MANIFEST_V1"
    for item in manifest["files"]:
        path = root / item["path"]
        assert path.is_file(), item["path"]
        assert path.stat().st_size == item["bytes"], item["path"]
        assert sha(path) == item["sha256"], item["path"]

    for line in (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        digest, rel = line.split("  ", 1)
        assert sha(root / rel) == digest, rel

    verdict = json.loads((root / "PROMOTION_VERDICT.json").read_text(encoding="utf-8"))
    assert verdict["schema"] == "A303656_NU_TAU_PARALLEL_SHIFT_VERDICT_V1"
    assert verdict["verdict"] == "STOP NU-TAU CORRELATION TRIGGER"
    assert not any(verdict["promotion_gates"].values())
    assert verdict["oeis_status"] == "A303656 UNRESOLVED"

    source = json.loads((root / "SOURCE_LOCK.json").read_text(encoding="utf-8"))
    assert source["schema"] == "A303656_NU_TAU_PARALLEL_SHIFT_SOURCE_LOCK_V1"
    provenance = json.loads((root / "PROVENANCE.json").read_text(encoding="utf-8"))
    assert provenance["schema"] == "A303656_NU_TAU_PARALLEL_SHIFT_PROVENANCE_V1"

    reproduced = subprocess.check_output(
        [sys.executable, str(root / "scripts/check_local_obstruction.py")], text=True
    )
    locked = (root / "results/check_local_obstruction.txt").read_text(encoding="utf-8")
    assert reproduced == locked
    assert "status=PASS" in locked
    print("VERIFY_STATUS=PASS")


if __name__ == "__main__":
    main()
