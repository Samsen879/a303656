#!/usr/bin/env python3
"""Deterministic checks for the mod-6 obstruction in the nu_tau shift family.

This is not a search for A303656 exceptions.  It only checks closed-form local
constants and enumerates the tiny exponent domain D_X by exponent pairs.
"""
from __future__ import annotations

from decimal import Decimal, getcontext
from typing import Iterable

getcontext().prec = 80
D = Decimal


def fmt(x: Decimal, places: int = 60) -> str:
    q = D(1).scaleb(-places)
    return format(x.quantize(q), "f")


def powers_leq(base: int, limit: int) -> list[int]:
    vals: list[int] = []
    v = 1
    while v <= limit:
        vals.append(v)
        v *= base
    return vals


def domain_counts(X: int) -> tuple[int, dict[int, int]]:
    limit = X // 2
    p3 = powers_leq(3, limit)
    p5 = powers_leq(5, limit)
    counts = {0: 0, 2: 0, 4: 0}
    W = 0
    for c, a in enumerate(p3):
        for d, b in enumerate(p5):
            if a + b <= limit:
                W += 1
                counts[(a + b) % 6] += 1
    return W, counts


def main() -> None:
    ln2 = D(2).ln()
    eta = D(1) / ln2 - D(1)
    A2 = D(2) * ln2
    A3 = D(3) * ln2 / D(2)

    q2_odd = D(1) / A2
    q2_even = (A2 - D(1)) / A2
    q3_zero = (A3 - D(1)) / A3
    q3_one = D(1) / (D(2) * A3)

    P_odd = D(2) * q2_odd
    P_even = D(2) * q2_even
    Q_zero = D(3) * q3_one
    Q_nonzero = D(3) * (q3_zero + q3_one) / D(2)

    kappa2 = eta * eta
    kappa3 = eta * eta / D(2)
    kappa6 = (D(1) + kappa2) * (D(1) + kappa3) - D(1)
    kappa6_alt = D(3) * eta * eta / D(2) + eta**4 / D(2)

    # High-precision partial sums for the two local Euler factors.
    s2 = sum((D(2) ** (-k)) / D(k + 1) for k in range(400))
    s3 = sum((D(3) ** (-2 * j)) / D(2 * j + 1) for j in range(200))

    coeffs = []
    for P in (P_even, P_odd):
        for Q in (Q_zero, Q_nonzero, Q_nonzero):
            coeffs.append(P * Q)
    coeff_mean = sum(coeffs) / D(6)
    coeff_var = sum((z - D(1)) ** 2 for z in coeffs) / D(6)

    print("schema=A303656_NU_TAU_LOCAL_OBSTRUCTION_CHECK_V1")
    print("purpose=closed-form local audit; no T(n) search")
    print(f"ln2={fmt(ln2)}")
    print(f"eta=1/ln2-1={fmt(eta)}")
    print(f"A2=2*ln2={fmt(A2)}")
    print(f"A2_partial_error={fmt(abs(s2-A2))}")
    print(f"A3=3*ln2/2={fmt(A3)}")
    print(f"A3_partial_error={fmt(abs(s3-A3))}")
    print(f"q2_odd={fmt(q2_odd)}")
    print(f"q2_even={fmt(q2_even)}")
    print(f"q3_zero={fmt(q3_zero)}")
    print(f"q3_one=q3_two={fmt(q3_one)}")
    print(f"P_odd={fmt(P_odd)}")
    print(f"P_even={fmt(P_even)}")
    print(f"Q_zero={fmt(Q_zero)}")
    print(f"Q_one=Q_two={fmt(Q_nonzero)}")
    print(f"class_coefficient_mean={fmt(coeff_mean)}")
    print(f"kappa2={fmt(kappa2)}")
    print(f"kappa3={fmt(kappa3)}")
    print(f"kappa6={fmt(kappa6)}")
    print(f"kappa6_alt_error={fmt(abs(kappa6-kappa6_alt))}")
    print(f"class_coefficient_variance={fmt(coeff_var)}")
    print(f"class_variance_error={fmt(abs(coeff_var-kappa6))}")

    for X in (10**6, 10**12, 10**24, 10**48):
        W, counts = domain_counts(X)
        n0, n2, n4 = counts[0], counts[2], counts[4]
        print(
            "domain "
            f"X=1e{len(str(X))-1} W={W} N0={n0} N2={n2} N4={n4} "
            f"N2_minus_N4={n2-n4} nonzero_parity_imbalance={abs(n2-n4)}"
        )

    assert abs(s2 - A2) < D("1e-70")
    assert abs(s3 - A3) < D("1e-70")
    assert abs(coeff_mean - D(1)) < D("1e-70")
    assert abs(kappa6 - kappa6_alt) < D("1e-70")
    assert abs(coeff_var - kappa6) < D("1e-70")
    print("status=PASS")


if __name__ == "__main__":
    main()
