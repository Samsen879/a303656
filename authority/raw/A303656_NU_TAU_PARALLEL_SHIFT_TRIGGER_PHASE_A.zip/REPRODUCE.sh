#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts/check_local_obstruction.py" > "$ROOT/results/check_local_obstruction.reproduced.txt"
cmp "$ROOT/results/check_local_obstruction.txt" "$ROOT/results/check_local_obstruction.reproduced.txt"
rm "$ROOT/results/check_local_obstruction.reproduced.txt"
python3 "$ROOT/scripts/verify_bundle.py" "$ROOT"
python3 "$ROOT/scripts/build_deterministic_zip.py" "$ROOT" "$(dirname "$ROOT")/A303656_NU_TAU_PARALLEL_SHIFT_TRIGGER_PHASE_A.reproduced.zip"
echo "REPRODUCE_STATUS=PASS"
