# Executive verdict

## STOP NU-TAU CORRELATION TRIGGER

### Strongest lemma

For the exact boundary-aware support-transference variance,

\[
\liminf_{X\to\infty}
\frac{\log X}{c_\tau^2XW_X^2}
\sum_{n\in[X,2X]}|V_X(n)-\bar V_X|^2
\ge
\frac32\left(\frac1{\log2}-1\right)^2
+\frac12\left(\frac1{\log2}-1\right)^4
=0.31317221331276824365\ldots.
\]

Hence global-centering concentration at `o(X W_X^2 / log X)` is false.

### Core gap

After mod-6 classwise centering / a fuller W-trick, one still needs a boundary-uniform parallel correlation theorem with an h-dependent singular series and an error summable against the structured difference multiplicity. No audited primary theorem supplies it, and this remaining lemma is not clearly weaker than the frozen indicator covariance blocker.

### Promotion gate

No summable asymptotic; no direct theorem; no complete conditional almost-all theorem. Stop this trigger rather than restating “covariance is needed.”
