# Literature audit: parallel shifted correlations for \(\nu_\tau\)

## Audit standard

A source is promotable only if its primary theorem supplies either:

- an asymptotic for \(\sum\nu_\tau(n)\nu_\tau(n+h)\) with a correctly identified singular series and an error summable over the true structured difference multiset; or
- a directly applicable aggregate theorem; or
- a complete conditional almost-all theorem whose sole missing lemma is demonstrably weaker than the frozen indicator covariance blocker.

Upper bounds, lower bounds, logarithmic averages, representation-weighted statements, fixed finite nonparallel systems, and almost-all statements for unrelated coefficient classes do not pass.

## 1. Frobenian one-point and nonparallel linear forms

### Loughran--Matthiesen, *Frobenian multiplicative functions and rational points in fibrations*

Locked items: Definitions 2.1, 2.6, 2.7; Lemmas 2.5 and 2.8; Theorem 1.9.

- Lemma 2.8 is the valid one-point Selberg--Delange input for \(\nu_\tau\).
- Theorem 1.9 assumes the nonconstant parts of the linear polynomials are pairwise linearly independent.
- For \(n-s\) and \(n-t\), both nonconstant parts equal \(n\). The hypothesis fails exactly in the parallel direction under audit.

**Status:** one-point input only; no pair theorem.

### Matthiesen, *Linear correlations of multiplicative functions*

Locked item: Theorem 2.4 (Main Theorem), with Definitions 1.1 and 1.2.

The affine forms must be pairwise linearly independent over \(\mathbb Q\), with bounded complexity and the stated multiplicative-function regularity/majorant hypotheses. Parallel forms \(n-s,n-t\) fail the geometry before any function-specific verification.

**Status:** inapplicable to the target pair.

## 2. Nair--Tenenbaum / Henriot / de la Bretèche type bounds

### Nair--Tenenbaum, *Short sums of certain arithmetic functions*

Locked item: Theorem 1.

This is a general **upper bound** for nonnegative arithmetic functions evaluated on polynomial values, under growth and polynomial hypotheses. It does not identify a signed main term for the parallel pair and cannot yield covariance cancellation.

**Status:** useful envelope only.

### Henriot, *Nair--Tenenbaum bounds uniform with respect to the discriminant*

Locked items: Theorems 1 and 3 in the 2012 paper; 2014 erratum, New Theorems 5 and 6.

The results make Nair--Tenenbaum-type nonnegative bounds uniform in discriminants/resultants. The erratum replaces the congruence-counting function, corrects submultiplicativity and leading-coefficient issues, and states that the earlier upper bounds remain valid, while the claimed sharpness/lower-bound formulation required correction.

No theorem produces an asymptotic or a signed error for \(\nu_\tau(n)\nu_\tau(n+h)\).

**Status:** upper-bound technology, not covariance.

### de la Bretèche--Browning, *Sums of arithmetic functions over values of binary forms*

Locked items: Theorem 1 and Theorem 2.

- Theorem 1 gives an upper bound for a nonnegative submultiplicative \(h\in\mathcal M(A,B)\) over values of a binary form.
- Theorem 2 is a one-variable Nair-type upper bound.

A two-dimensional average cannot be restricted to the thin one-dimensional parallel slice and retain its conclusion. Neither theorem supplies a signed main term.

**Status:** no route.

## 3. Divisor-convolution criteria

Let \(g=\nu_\tau*\mu\). For every inert prime \(q\equiv3\pmod4\),

\[
g(q)=\nu_\tau(q)-1=-1.
\]

Hence

\[
\sum_{q\equiv3(4)}\frac{|g(q)|}{q}=\infty.
\tag{3.1}
\]

This single calculation defeats the direct absolute-decay hypotheses below.

### Balasubramanian--Giri, Theorem 1

The theorem decomposes \(F=A\sum_{d\mid n}f(d)\) and \(G=B\sum_{d\mid n}g(d)\), assumes absolute harmonic summability of \(f,g\), and assumes an arithmetic-progression mean for the residual product \(A(n-h)B(n)\). With \(A=B=1\), (3.1) fails. Moving complexity into \(A,B\) simply reinstates the desired shifted correlation as a hypothesis.

**Status:** hypotheses fail or become circular.

### Balasubramanian--Giri--Srivastav, Definition 2.1 and Theorem 2.2

The theorem requires \(f\in\mathcal A_\alpha\), \(g\in\mathcal A_\beta\), i.e. pointwise decay \(f(n)=O(n^{-\alpha})\), and then gives a uniform asymptotic for \(|h|\le x/2\). Since \((\nu_\tau*\mu)(q)=-1\) on infinitely many primes, no \(\alpha>0\) is possible.

**Status:** function-class failure.

## 4. Pretentious methods

### Klurman, *Correlations of multiplicative functions and applications*

Locked items: Theorems 1.3 and 1.5.

- Theorem 1.3 treats bounded multiplicative functions on polynomial values with nonzero resultant, but its error is controlled by modified pretentious distances to 1.
- Theorem 1.5 gives a fixed nonzero-shift asymptotic under finite distance \(\mathbb D(f,\chi n^{it};\infty)<\infty\).

For \(\nu_\tau\), at every inert prime \(q\equiv3\pmod4\), \(\nu_\tau(q)=0\). Therefore, for every \(\chi,t\),

\[
\mathbb D(\nu_\tau,\chi n^{it};x)^2
\ge \sum_{\substack{q\le x\\q\equiv3(4)}}\frac1q
=\frac12\log\log x+O(1).
\]

The finite-distance hypotheses fail, and the quantitative error in Theorem 1.3 does not tend to zero.

**Status:** no fixed-shift asymptotic for this weight.

Logarithmically averaged nonpretentious correlation theorems can at most give estimates on the \(X\)-scale; the target main term is \(X/\log X\), so such results do not resolve the required second-order asymptotic.

## 5. Divisor switching, dispersion, and spectral methods

### Drappeau--Topacogullari, Theorems 1.1 and 1.2

Theorem 1.1 treats \(\sum f(n)\tau(n-1)\) for multiplicative \(f\) periodic on primes. Theorem 1.2 gives general shifts \(f(n)\tau(an-h)\) with a controlled range of \(a,h\). The second factor is the divisor function, and the combinatorial identity is tailored to that factor. Selberg--Delange evaluates the main term only after the shifted-divisor analysis has been completed.

**Status:** one divisor factor only; not \(\nu_\tau\times\nu_\tau\).

### Matomäki--Radziwiłł--Tao, Theorem 1.3

For \(H\ge X^{8/33+\varepsilon}\), the theorem gives almost-all-shift asymptotics for four specific families: \(\Lambda\Lambda\), \(d_kd_\ell\), \(\Lambda d_k\), and Goldbach. It is coefficient-specific. Moreover, an exceptional set small relative to all \(h\in[1,H]\) need not be small against a sparse, highly nonuniform structured-difference measure.

**Status:** wrong coefficients and wrong averaging measure.

### Kim, Definitions 1.1 and 1.3; Theorem 1.4

The theorem treats \(f=g*1\) where \(g\) belongs to an Euler-product/L-function class with unit-modulus Satake parameters, analytic continuation, and twisted square-moment assumptions. It gives almost-all \(h\) for \(H\ge X^{23/24+10\varepsilon}\). The Möbius transform of \(\nu_\tau\) has value \(-1\) at a positive-density set of primes and does not fit the locked \(\mathcal F_k/\mathcal E_k\) architecture.

**Status:** function-class failure; all-shift exceptional set also does not transfer automatically.

### Iudelevich, Theorems 1.1 and 1.2

Theorem 1.1 is a Bombieri--Vinogradov-type estimate for \(\chi(n)/\tau(n)\) with a fixed coprimality parameter. Theorem 1.2 evaluates a fixed \(+1\) quotient involving \(r(n)/r(n+1)\), with a prime indicating a restricted support. It is neither a product \(\nu_\tau(n)\nu_\tau(n+h)\) nor a growing-shift theorem.

**Status:** different observable.

Spectral shifted-convolution theorems require automorphic/Fourier coefficient structures or divisor coefficients for which Voronoi/Kuznetsov machinery exists. No such realization is known for \(\nu_\tau\). Divisor switching or dispersion does not by itself create the missing bilinear cancellation; it must be coupled to distribution estimates not available for both \(\nu_\tau\) factors.

## 6. Recent 2025--2026 watch

### Huang--Lü, JNT 278 (2026), 128--177

The journal metadata and abstract state an almost-all-shift asymptotic for correlations of an automorphic coefficient class \(\lambda_F(n)\overline{\lambda_F(n+h)}\). The accessible primary full text was not available in this audit environment, so no theorem number or detailed hypothesis is promoted or guessed. The coefficient class described in the abstract is not \(\nu_\tau\).

**Status:** metadata-level speculative watch only; excluded from proof evidence.

### Kim, arXiv:2603.23250

The abstract concerns **ternary** correlations of general divisor-bounded multiplicative functions under associated L-function moment hypotheses. It is not a binary parallel correlation theorem for \(\nu_\tau\).

### Parkkonen--Paulin, arXiv:2602.13058

This studies pair correlations of logarithms of norm-form values under geometric scaling. “Pair correlation” here is multiplicative/geometric, not the additive shift \(n,n+h\).

## 7. Selberg--Delange with two parallel forms

Ordinary Selberg--Delange applies to a multiplicative Dirichlet series in one integer variable. For fixed nonzero \(h\),

\[
n\longmapsto \nu_\tau(n)\nu_\tau(n+h)
\]

is not multiplicative and has no direct Euler product. The local factors in `SINGULAR_SERIES_AUDIT.md` describe a conjectural main term, not a Dirichlet-series factorization. Existing nonparallel linear-form theorems solve a different geometry; existing shifted-convolution theorems solve special coefficient classes.

## 8. Literature verdict

No locked primary theorem supplies:

1. a fixed-\(h\) asymptotic for \(\nu_\tau\);
2. uniformity for growing \(h\) sufficient for the structured family;
3. a signed aggregate theorem against its difference multiplicities; or
4. a classwise/\(W\)-tricked covariance estimate after removing the proven mod-6 bias.

The globally centered target is additionally false, not just unproved.
