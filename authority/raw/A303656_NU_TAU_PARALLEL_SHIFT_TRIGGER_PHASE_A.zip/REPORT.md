# A303656 NU-TAU PARALLEL-SHIFT CORRELATION AND SUPPORT TRANSFERENCE TRIGGER HUNT — PHASE A

审计日期：2026-07-21  
对象：

\[
\nu_\tau(n)=\frac{r_2(n)}{4\tau(n)},\qquad
C_h(X)=\sum_{m\le X}\nu_\tau(m)\nu_\tau(m+h).
\]

## 1. Executive decision

# STOP NU-TAU CORRELATION TRIGGER

理由分为两个彼此独立的层次。

第一，primary-source audit 没有锁定任何 theorem 能够给出以下任一项：

- `nu_tau × nu_tau` 的 fixed-shift asymptotic；
- 对 growing `h` 足以按 structured difference multiplicity 求和的 uniform asymptotic；
- 对该 sparse、non-Haar difference measure 的 signed aggregate covariance theorem。

第二，也是决定性的：上一阶段 globally centered support-transference trigger 本身是假的。structured shifts 与 `nu_tau` 的 `2`-adic、`3`-adic weighted mass profile 产生 target-scale 的 deterministic between-class variance。故本轮不允许把结论缩写成“还需要 covariance”；正确结论是 current trigger 必须停止。

## 2. Frozen inputs and scope

本轮不重新证明 positive-density theorem，也不把任何 `r_2`-weighted statement 当作 support theorem。使用的 frozen inputs 为：

\[
0\le\nu_\tau(n)\le 1_{\mathcal S_2}(n),\qquad
\nu_\tau(n)>0\Longleftrightarrow n\in\mathcal S_2,
\]

以及 one-point asymptotic

\[
\sum_{n\le x}\nu_\tau(n)
=c_\tau\frac{x}{\sqrt{\log x}}
+O\!\left(\frac{x}{(\log x)^{3/2}}\right),
\qquad c_\tau>0.
\]

上游 bundle 的 byte-level SHA256 记录在 `INPUT_HASHES.tsv` 与 `PROVENANCE.json`。

## 3. Exact support-transference object

令

\[
I_X=[X,2X]\cap\mathbb Z,
\quad
\mathcal D_X=\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le X/2\},
\quad W_X=|\mathcal D_X|,
\]

`w_X(s)` 为 shift value `s` 的 exponent-pair multiplicity，并令

\[
V_X(n)=\sum_s w_X(s)\nu_\tau(n-s).
\]

上一阶段的 exact variance 为

\[
\sum_{n\in I_X}(V_X(n)-\bar V_X)^2
=
\sum_{s,t}w_X(s)w_X(t)
\left(
C_{s,t}^{\nu}(X)-\frac{A_s^\nu(X)A_t^\nu(X)}{|I_X|}
\right),
\]

其中 pair correlation 的 interval 为 `[X-s,2X-s]`。因为 `s` 可达 `X/2`，把它替换为统一 `[1,X]` 可能产生 main-scale error；因此 schematic

\[
\sum_h\nu_X(h)\left(C_h(X)-M(X)^2/X\right)
\]

除非同时冻结 difference multiplicity、negative-shift convention、common truncation、moving boundary 与 one-point centering，否则不是 exact support trigger。

Diagonal 不是 blocker：由 `nu_tau^2 <= nu_tau`、`sum_s w_X(s)^2=W_X+O(1)` 和 `W_X asymp (log X)^2`，diagonal 为

\[
O\!\left(\frac{XW_X}{\sqrt{\log X}}\right)
=o\!\left(\frac{XW_X^2}{\log X}\right).
\]

## 4. Strongest lemma: a proved mod-6 lower bound

设

\[
\eta=\frac1{\log2}-1,
\qquad
\kappa_6=\frac32\eta^2+\frac12\eta^4
=0.31317221331276824365\ldots.
\]

则

\[
\boxed{
\liminf_{X\to\infty}
\frac{\log X}{c_\tau^2XW_X^2}
\sum_{n\in I_X}(V_X(n)-\bar V_X)^2
\ge\kappa_6>0.}
\]

证明详见 `STRONGEST_LEMMA.md`。机制如下。

### 4.1 Weighted local mass at 2 and 3

Prime-power values 为

\[
\nu_\tau(2^k)=\frac1{k+1},
\quad
\nu_\tau(p^k)=1\ (p\equiv1\bmod4),
\quad
\nu_\tau(q^k)=0\ (k\text{ odd}),\ \frac1{k+1}\ (k\text{ even})
\]

for `q = 3 mod 4`. 因而

\[
A_2=\sum_{k\ge0}\frac{2^{-k}}{k+1}=2\log2,
\qquad
A_3=\sum_{j\ge0}\frac{3^{-2j}}{2j+1}=\frac32\log2.
\]

由 finite Euler-factor modification 与 `chi_3` twist，`nu_tau` mass 在 mod `2`、mod `3` classes 上具有非均匀但可精确计算的 leading proportions。

### 4.2 Structured shifts are non-Haar modulo 6

对 `c>=1`，

\[
3^c+5^d\equiv4\pmod6\quad(d\text{ even}),
\qquad
3^c+5^d\equiv2\pmod6\quad(d\text{ odd}).
\]

故 exponent-pair shifts asymptotically half in class `2 mod 6`、half in class `4 mod 6`，且 residue `0 mod 6` 仅来自 negligible `c=0` row。

### 4.3 Class means and law of total variance

六个 relative class means 为

\[
P_{\rm odd}=1/\log2,
\quad P_{\rm even}=(2\log2-1)/\log2,
\]

\[
Q_0=1/\log2,
\quad Q_1=Q_2=(3\log2-1)/(2\log2),
\]

并满足

\[
\bar V_{X,r}
=\left(P_{\operatorname{parity}(r)}Q_{r\bmod3}+o(1)\right)
\frac{c_\tau W_X}{\sqrt{\log X}}.
\]

这些 coefficients 的平均值为 `1`，但 variance 恰为 `kappa_6`。Law of total variance 立即给出 lower bound。该推导保留 moving intervals，因而不是 boundary artifact。

## 5. Answers to the three requested targets

### 5.1 Fixed h asymptotic

**未锁定可直接应用 theorem；状态 unresolved for this weight.**

普通 Selberg–Delange 不能直接作用于

\[
n\mapsto\nu_\tau(n)\nu_\tau(n+h),
\]

因为 fixed nonzero `h` 后该函数不 multiplicative，亦无一变量 Euler product。任何可信 main term 都必须依赖 `h` 的 local valuations。`SINGULAR_SERIES_AUDIT.md` 给出 direct p-adic enumeration 的 candidate factors；例如在 `p=3`，`3∤h` 与 `v_3(h)=1` 的 local pair masses 分别为 `2 log 2 - 1` 与 `2/3`。

这只是 necessary local model，不是 global asymptotic。

### 5.2 Uniform asymptotic for growing h

**无 promotable theorem。**

主要失败模式：

- Frobenian/linear-forms theorems 要求 nonconstant parts pairwise linearly independent；`n-s` 与 `n-t` parallel。
- Nair–Tenenbaum、Henriot、de la Bretèche–Browning 为 nonnegative upper-bound technology，不产生 signed main term。
- 令 `g=nu_tau*mu`，则对每个 inert prime `q=3 mod 4`，`g(q)=-1`；absolute harmonic summability 与 pointwise decay classes 失败。
- Pretentious distance 对任意 `chi n^{it}` 至少含 `sum_{q=3 mod4}1/q`，故发散。
- Dispersion/spectral results 审计到的 theorem 针对 divisor、von Mangoldt、automorphic coefficients 或仅一个 divisor factor；没有 `nu_tau × nu_tau` coefficient realization。
- Almost-all results 对 Lebesgue/counting measure on all shifts 的 exceptional set，不能自动转移到 sparse、highly nonuniform structured difference multiplicity。

### 5.3 Structured aggregate signed covariance

**对 exact support variance：目标为 false。**

上述 `mod 6` lemma 给出 target-scale positive lower bound，排除了

\[
o(XW_X^2/\log X).
\]

**对 literal raw `C_h(X)` formula：target under-specified and not equivalent.** Boundary 可为 main-scale，且 universal subtraction `M(X)^2/X` 忽略 `h`-dependent singular series 与 moving one-point factors。

因此第三条不能 promotion。

## 6. Primary-source theorem audit

完整 crosswalk 见 `THEOREM_HYPOTHESIS_CROSSWALK.csv`；核心锁定如下。

| Primary source | Exact item | Output | Decisive hypothesis/failure |
|---|---|---|---|
| Loughran–Matthiesen, arXiv:1904.12845v2 | Defs. 2.1, 2.6, 2.7; Lemmas 2.5, 2.8 | Frobenian one-point Selberg–Delange and twists | Valid one-point input only |
| same | Theorem 1.9 | Linear-polynomial asymptotic | nonconstant parts pairwise linearly independent; parallel pair fails |
| Matthiesen, arXiv:1606.04482v4 | Theorem 2.4 (Main Theorem) | Linear-forms correlation | forms pairwise linearly independent over Q; parallel pair fails |
| Nair–Tenenbaum, Acta Math. 180 (1998) | Theorem 1 | Short polynomial-value upper bound | nonnegative upper bound; no signed covariance |
| Henriot, arXiv:1102.1643v1; erratum | Theorems 1, 3; New Theorems 5, 6 | discriminant-uniform Nair–Tenenbaum bounds | upper-bound framework only; erratum does not add target asymptotic |
| de la Bretèche–Browning, math/0604119 | Theorems 1, 2 | binary-form / one-variable upper bounds | no signed main term; thin parallel slice invalid |
| Balasubramanian–Giri, arXiv:1408.3394v3 | Theorem 1 | fixed-shift asymptotic under convolution/AP hypotheses | `nu_tau*mu` fails absolute harmonic summability; residual AP hypothesis otherwise circular |
| Balasubramanian–Giri–Srivastav, arXiv:1511.02221v3 | Definition 2.1; Theorem 2.2 | uniform shifted asymptotic | requires `f(n)=O(n^-alpha)`; transform equals `-1` on inert primes |
| Klurman, arXiv:1603.08453v1 | Theorems 1.3, 1.5 | local-product / fixed-shift pretentious asymptotic | required error does not vanish; finite pretentious distance fails |
| Drappeau–Topacogullari | Theorems 1.1, 1.2 | `f(n) tau(an-h)` | second factor specifically divisor function, not `nu_tau` |
| Matomäki–Radziwiłł–Tao, arXiv:1707.01315 | Theorem 1.3 | almost-all long shifts | only Lambda/divisor/Goldbach coefficient families; wrong measure |
| Kim, arXiv:2310.00668v5 | Definitions 1.1, 1.3; Theorem 1.4 | almost-all shifts for `f=g*1` | automorphic-type Euler product, Satake and L-function moment hypotheses; `nu_tau` not in class |
| Iudelevich, arXiv:2508.02701v1 | Theorems 1.1, 1.2 | BV-type estimate; fixed `+1` quotient | different observable, not product correlation |
| Huang–Lü, JNT 278 (2026) | theorem number not locked | metadata says almost-all automorphic correlation | full primary text unavailable here; excluded from proof evidence, watch only |

`SOURCE_LOCK.json` records exact versions and downloaded-PDF SHA256, preventing silent source drift。

## 7. Core gap after the only plausible repair

可用 classwise centering 或 fuller `W`-trick 去除已证明的 finite-dimensional local bias：

\[
\sum_{r=0}^5\sum_{n\in I_{X,r}}
|V_X(n)-\bar V_{X,r}|^2
=o(XW_X^2/\log X).
\]

由于每个 class mean 均为正且为 `W_X/sqrt(log X)` 量级，该 estimate 若成立仍可推出 density-one weighted support coverage。

但它仍要求 boundary-uniform、parallel two-point cancellation，并需保留 classwise singular series。没有 audited theorem 证明它；其唯一 remaining lemma 也不明显弱于原 frozen indicator covariance blocker。根据用户指定 promotion gate，这一 repair 不能 promotion，亦不构成 conditional almost-all theorem。

## 8. Promotion decision

- Sufficiently summable correlation asymptotic：**NO**。
- Directly applicable primary theorem：**NO**。
- Complete conditional almost-all theorem with a clearly weaker sole lemma：**NO**。
- Current globally centered trigger mathematically viable：**NO; disproved by the mod-6 lower bound**。

# STOP NU-TAU CORRELATION TRIGGER

A303656 的整体状态不因本轮改变。
