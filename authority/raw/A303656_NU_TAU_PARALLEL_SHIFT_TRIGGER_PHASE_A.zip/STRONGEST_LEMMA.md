# Strongest Lemma: a mod-6 obstruction to the globally centered support trigger

## 1. Setup

Let

\[
\nu(n)=\nu_\tau(n)=\frac{r_2(n)}{4\tau(n)},\qquad
I_X=[X,2X]\cap\mathbb Z,
\]

and

\[
\mathcal D_X=\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le X/2\},
\quad W_X=|\mathcal D_X|.
\]

For a shift value \(s\), let

\[
w_X(s)=\#\{(c,d)\in\mathcal D_X:3^c+5^d=s\},
\qquad
V_X(n)=\sum_s w_X(s)\nu(n-s),
\]

where \(\nu(m)=0\) for \(m\le0\). Define

\[
\bar V_X=\frac1{|I_X|}\sum_{n\in I_X}V_X(n).
\]

The frozen one-point input is

\[
\sum_{n\le x}\nu(n)
=c_\tau\frac{x}{\sqrt{\log x}}
+O\!\left(\frac{x}{(\log x)^{3/2}}\right),
\qquad c_\tau>0.
\tag{1.1}
\]

No positive-density theorem is reproved here.

## 2. Statement

Set

\[
\eta=\frac1{\log 2}-1>0
\]

and

\[
\kappa_6=(1+\eta^2)(1+\eta^2/2)-1
=\frac32\eta^2+\frac12\eta^4
=0.31317221331276824365\ldots.
\tag{2.1}
\]

### Lemma

As \(X\to\infty\),

\[
\liminf_{X\to\infty}
\frac{\log X}{c_\tau^2XW_X^2}
\sum_{n\in I_X}\bigl(V_X(n)-\bar V_X\bigr)^2
\ge \kappa_6>0.
\tag{2.2}
\]

Consequently, the globally centered concentration trigger

\[
\sum_{n\in I_X}\bigl(V_X(n)-\bar V_X\bigr)^2
=o\!\left(\frac{XW_X^2}{\log X}\right)
\tag{2.3}
\]

is false for \(\nu_\tau\) and this structured shift family.

This is a lower bound for the exact, boundary-aware variance used in the previous weighted-to-support reduction. It is not merely a heuristic singular-series objection.

## 3. Local Euler factors at 2 and 3

The prime-power values are

\[
\nu(2^k)=\frac1{k+1},
\quad
\nu(p^k)=1\ (p\equiv1\!\!\pmod4),
\quad
\nu(q^k)=
\begin{cases}
0,&k\text{ odd},\\
1/(k+1),&k\text{ even},
\end{cases}
\quad(q\equiv3\!\!\pmod4).
\tag{3.1}
\]

Hence the local factors at \(s=1\) are

\[
A_2=\sum_{k\ge0}\frac{2^{-k}}{k+1}=2\log2,
\qquad
A_3=\sum_{j\ge0}\frac{3^{-2j}}{2j+1}
=3\operatorname{artanh}(1/3)=\frac32\log2.
\tag{3.2}
\]

Changing finitely many Euler factors preserves the Frobenian mean and changes the Selberg--Delange leading constant by the corresponding local-factor ratio. Therefore the proportions of the \(\nu\)-mass are

\[
q_{2,\mathrm{odd}}=\frac1{A_2},
\qquad
q_{2,\mathrm{even}}=\frac{A_2-1}{A_2},
\tag{3.3}
\]

and

\[
q_{3,0}=\frac{A_3-1}{A_3},
\qquad
q_{3,1}=q_{3,2}=\frac1{2A_3}.
\tag{3.4}
\]

For the equality of the two nonzero classes modulo 3, twist by the nonprincipal character \(\chi_3\). At primes outside \(6\), the Frobenian prime mean of \(\nu\chi_3\) is zero: among primes with \(\nu(p)=1\), the classes \(1\) and \(5\pmod {12}\) have equal Chebotarev density and opposite \(\chi_3\)-values. Loughran--Matthiesen, Lemmas 2.5 and 2.8, then give

\[
\sum_{n\le x}\nu(n)\chi_3(n)=O(x/\log x)
=o(x/\sqrt{\log x}).
\tag{3.5}
\]

Combining the finite restrictions at 2 and 3, for every \(a\pmod6\),

\[
\sum_{\substack{n\le x\\n\equiv a\ (6)}}\nu(n)
=(c_\tau q_a+o(1))\frac{x}{\sqrt{\log x}},
\quad
q_a=q_{2,\operatorname{parity}(a)}q_{3,a\bmod3}.
\tag{3.6}
\]

By subtracting endpoint asymptotics, (3.6) is uniform for intervals of length \(X\) whose endpoints lie in \([X/2,2X]\):

\[
\sum_{\substack{m\in[Y,Y+X]\\m\equiv a\ (6)}}\nu(m)
=(c_\tau q_a+o(1))\frac{X}{\sqrt{\log X}}.
\tag{3.7}
\]

## 4. Residues of the structured shifts

For \(c\ge1\),

\[
3^c+5^d\equiv
\begin{cases}
4\pmod6,&d\text{ even},\\
2\pmod6,&d\text{ odd}.
\end{cases}
\tag{4.1}
\]

For \(c=0\), the residues are \(2\) and \(0\). For each fixed \(c\ge1\), the admissible \(d\)'s form an initial interval, so its even/odd imbalance is at most one. Since there are \(O(\log X)\) possible \(c\)'s and the row \(c=0\) contains \(O(\log X)\) shifts,

\[
N_0=O(\log X),
\qquad
N_2=\frac{W_X}{2}+O(\log X),
\qquad
N_4=\frac{W_X}{2}+O(\log X),
\tag{4.2}
\]

where \(N_u\) is the number of exponent pairs whose shift is \(u\pmod6\). The frozen estimate \(W_X\asymp(\log X)^2\) makes these errors negligible.

## 5. Classwise means

For \(r\pmod6\), write

\[
I_{X,r}=\{n\in I_X:n\equiv r\pmod6\},
\qquad
\bar V_{X,r}=\frac1{|I_{X,r}|}\sum_{n\in I_{X,r}}V_X(n).
\tag{5.1}
\]

Define relative local densities

\[
P_{\mathrm{odd}}=\frac1{\log2}=1+\eta,
\qquad
P_{\mathrm{even}}=\frac{2\log2-1}{\log2}=1-\eta,
\tag{5.2}
\]

and

\[
Q_0=\frac1{\log2}=1+\eta,
\qquad
Q_1=Q_2=\frac{3\log2-1}{2\log2}=1-\eta/2.
\tag{5.3}
\]

Using (3.7), (4.2), and \(|I_{X,r}|=X/6+O(1)\), one obtains

\[
\bar V_{X,r}
=\left(P_{\operatorname{parity}(r)}Q_{r\bmod3}+o(1)\right)
\frac{c_\tau W_X}{\sqrt{\log X}}.
\tag{5.4}
\]

The six coefficients are approximately

| \(r\pmod6\) | coefficient in (5.4) |
|---:|---:|
| 0 | 0.804021100772319... |
| 1 | 1.123358070830641... |
| 2 | 0.433946888280395... |
| 3 | 2.081368981005608... |
| 4 | 0.433946888280395... |
| 5 | 1.123358070830641... |

Their average is exactly one, so

\[
\bar V_X=(1+o(1))\frac{c_\tau W_X}{\sqrt{\log X}}.
\tag{5.5}
\]

## 6. Law of total variance

The exact identity

\[
\sum_{n\in I_X}(V_X(n)-\bar V_X)^2
=
\sum_{r=0}^5\sum_{n\in I_{X,r}}(V_X(n)-\bar V_{X,r})^2
+
\sum_{r=0}^5|I_{X,r}|(\bar V_{X,r}-\bar V_X)^2
\tag{6.1}
\]

implies a lower bound by its second term. Substituting (5.4)--(5.5) gives

\[
\liminf
\frac{\log X}{c_\tau^2XW_X^2}
\sum_{n\in I_X}(V_X(n)-\bar V_X)^2
\ge
\frac16\sum_{\epsilon\in\{\mathrm{even},\mathrm{odd}\}}
\sum_{\rho=0}^2(P_\epsilon Q_\rho-1)^2.
\tag{6.2}
\]

Since the means of \(P\) and \(Q\) are one,

\[
\frac16\sum(PQ-1)^2
=\mathbb E(P^2)\mathbb E(Q^2)-1
=(1+\eta^2)(1+\eta^2/2)-1
=\kappa_6.
\tag{6.3}
\]

This proves (2.2).

## 7. Scope and repair

The lemma invalidates global centering by \(M^2/X\) in the exact support-transference variance. It does **not** by itself identify a fixed-\(h\) asymptotic for \(C_h(X)\).

A necessary repair is to remove the finite-dimensional local profile, for example by classwise centering modulo 6 or a fuller \(W\)-trick:

\[
\sum_{r=0}^5\sum_{n\in I_{X,r}}
|V_X(n)-\bar V_{X,r}|^2
=o\!\left(\frac{XW_X^2}{\log X}\right).
\tag{7.1}
\]

If every \(\bar V_{X,r}\gg W_X/\sqrt{\log X}\), (7.1) would still imply density-one support coverage. But no audited theorem proves (7.1), and its remaining parallel covariance problem is not visibly weaker than the frozen indicator covariance blocker. Therefore this repair does not satisfy the promotion gate.
