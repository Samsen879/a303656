# STRUCTURED SUBGRID ANALYSIS

## 1. Monochromatic rectangles

A repeated prime on a \(2\times2\) exponent rectangle forces simultaneous divisibility of one power-of-3 difference and one power-of-5 difference. This can be combined with multiplicative-order or gcd estimates, but only after a dense repeated label is known.

The Kővári–Sós–Turán estimate shows that a single rectangle-free label class has at most \(O((\log X)^{3/2})\) cells. Since the grid has \(\Theta((\log X)^2)\) cells, this forces only \(\Omega(\sqrt{\log X})\) labels if all classes are rectangle-free. It does not force a rectangle and it gives no exceptional-set saving.

## 2. Private-label obstruction

A private label occupies one cell and automatically avoids every repeated-label structure: rectangles, high codegrees, shared resultants, and common-divisor graphs. Theorem PW-A proves that a positive fraction of an actual complete survivor set can have this form at square-root cutoff. Thus a structured-subgrid theorem must either absorb private cells into a different structure or prove that counterexamples behave more rigidly than general complete survivors.

## 3. Dependent random choice

Dependent random choice requires a dense bipartite incidence graph. For a fixed prime label, density is not guaranteed. Aggregating all primes produces a multicolored graph in which each cell has one label, but common-neighborhood conclusions mix different primes and no longer imply a common congruence. The available density is therefore in the wrong graph.

## 4. Ramsey theory

A finite-color Ramsey theorem is inapplicable because the number of prime colors grows with \(X\) and can be comparable to the number of cells. Quantitative multicolor bounds at \(K=\Theta((\log X)^2)\) are far beyond the information budget even if they produce a tiny rectangle.

## 5. Hypergraph containers

A container application would need a fixed uniform hypergraph whose independent sets encode admissible certificate matrices, together with degree and codegree estimates. Here:

- the vertex set includes primes up to \(2X\) and changes with \(X\);
- admissibility depends on one global integer \(n\);
- private labels give degree-one incidences;
- no supersaturation theorem is known;
- a generic \(\exp(o(K))\) container count can still exceed \(X\).

No container theorem was found whose hypotheses are verified by the complete canonical grid.

## 6. Additive structure and BSG

Balog–Szemerédi–Gowers type conclusions require many additive quadruples or large energy in a set. The exponent shift set has structured additive energy, but the prime labels are attached to translated remainders, not to an additive subset with controlled energy. Passing from many shared labels to an additive-energy statement is possible only for the shared component already visible in shift differences; it does not control private labels.

## 7. Multiplicative orders and gcd estimates

For a monochromatic rectangle and \(p\nmid15\),

\[
\operatorname{ord}_p(3)\mid\Delta c,
\qquad
\operatorname{ord}_p(5)\mid\Delta d.
\]

Subspace-theorem gcd estimates and primitive-divisor results can restrict primes common to recurrence differences. They are nonuniform or ineffective at the needed grid-wide scale, and more importantly they apply only after prime reuse. They do not compress the positive private component.

## 8. Verdict on structured extraction

The complete grid yields exact local consistency constraints, but no quantitative extraction theorem with a contradiction, density loss, descent, or low-fiber record. Structured-subgrid extraction remains descriptive rather than promotable.
