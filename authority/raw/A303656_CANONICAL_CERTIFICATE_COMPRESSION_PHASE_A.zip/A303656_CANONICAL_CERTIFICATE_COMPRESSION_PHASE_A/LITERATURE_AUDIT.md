# LITERATURE AUDIT

## Audit rule

Only primary papers or their author-posted arXiv versions are used for theorem matching. For each source, the relevant theorem, quantifiers, and missing A303656 hypothesis are stated explicitly. A theorem name without a hypothesis crosswalk is not treated as evidence of applicability. A current arXiv preprint is treated as a method benchmark, not silently promoted to frozen authority.

## 1. Li — canonical witnesses, compression, and injective reconstruction

**Source:** Eric Li, *A Resolution of Erdős Problem 768: the Sylow Divisor Condition*, arXiv:2606.24872v2 (13 July 2026).

**Precise theorem:** If \(A(x)\) counts integers \(n\le x\) such that, for every prime \(p\mid n\), there is a divisor \(d>1\) of \(n\) with \(d\equiv1\pmod p\), the paper proves

\[
\lim_{x\to\infty}
\frac{\log(x/A(x))}{\sqrt{\log x}\log\log x}
=
\frac1{2\sqrt{\log2}}.
\]

**Canonical mechanism:** For each \(p\mid n\), choose

\[
D_p=\min\{d:d\mid n,\ d>1,\ d\equiv1\pmod p\}.
\]

A deterministic majority-halving procedure selects a row-homogeneous sequence of prime factors of \(n\). It then removes a squarefree product \(Q\mid\operatorname{rad}(n)\), writes \(n=mQ\), and uses one-bit valuation completion for divisors \(D\mid n\). Zero rows are reconstructed because a recorded index selects the missing row prime among the prime divisors of \(D_p-1\); positive rows recover a common product by CRT. Proposition 6.7 gives injective reconstruction of a fixed-prefix fiber, Proposition 6.11 bounds the full canonical fiber by a growing divisor moment of \(m\), and Proposition 7.2 forces \(Q\) to be large.

**Quantifiers:** deterministic and pointwise for every admissible \(n\); the final counting step is uniform over the relevant \(x,t,m\) ranges.

**Indispensable hypotheses:**

1. every row and every selected column is a prime factor of the same integer \(n\);
2. every witness \(D_p\) lies in the common divisor lattice of \(n\);
3. squarefree deletion gives the exact common relation \(n=mQ\), so omitted valuations cost one bit each;
4. the self-indexed congruence \(D_p\equiv1\pmod p\) makes a deleted row prime recoverable from \(D_p-1\);
5. divisor moments of the single quotient \(m\) are summable after the size gain from \(Q\).

**A303656 crosswalk:** A cell witness \(p_*(n-h)\) divides one translated remainder, not a common ambient integer shared by all rows. Cells are not prime factors, there is no analogue of \(D_p\equiv1\pmod p\), and conditioning on a label need not preserve any hereditary divisor lattice or complete exponent grid. The obvious container \(F_{\mathcal H}(n)=\prod_{h\in\mathcal H}(n-h)\) has \(\log F_{\mathcal H}(n)=\Theta((\log X)^3)\) on a complete core, does not supply the self-indexed witness relation, and has no proved special-value divisor-moment theorem yielding an \(o(X)\) count. **Closest conceptual analogue; no theorem transfer.**

## 2. Gallagher — the larger sieve

**Source:** P. X. Gallagher, *A larger sieve*, Acta Arith. 18 (1971), 77–81, Theorem 1.

**Precise input:** A fixed integer set \(A\subset[1,N]\) occupies at most \(g(q)\) residue classes modulo each chosen prime power \(q\). When the weighted denominator

\[
\sum_q\frac{\Lambda(q)}{g(q)}-\log N
\]

is positive, Gallagher's inequality bounds \(|A|\) using the corresponding weighted numerator. The useful regime therefore requires a quantitative local class deficit for one fixed set over many moduli.

**A303656 crosswalk:** No bound for \(|E_X\bmod p|\), or for a fixed modulo-\(p^2\) projection, follows from the fact that every pair \((n,h)\) may choose its own certificate prime. The union over active shifts can occupy all residues. **Primary hypothesis missing.**

## 3. Walsh — inverse sieve in high dimensions

**Source:** Miguel N. Walsh, *The inverse sieve problem in high dimensions*, arXiv:1105.1551v2 (2011).

**Precise input:** Theorem 1.1 assumes a fixed set \(S\subset[N]^d\) occupies fewer than \(\alpha p^k\) residue classes modulo every prime \(p\), with \(0\le k<d\).

**Output:** Either \(|S|\ll N^{k-1+\varepsilon}\), or a bounded-degree polynomial with controlled coefficients vanishes on more than \((1-\eta)|S|\) points.

**Quantifiers:** pointwise residue-class hypothesis for a fixed set; uniform over the specified primes; structural alternative.

**A303656 crosswalk:** no theorem in this phase shows that \(E_X\), or a fixed encoding of its certificate matrices, occupies \(O(p^k)\) classes modulo many primes. A prime chosen separately for each cell does not imply a residue restriction on \(E_X\). **Not applicable.**

## 4. Shao — averaged larger-sieve formulation

**Source:** Xuancheng Shao, *On an inverse ternary Goldbach problem*, arXiv:1404.6022 (2014), especially Lemmas 2.1–2.3.

**Precise input:** The averaged form still requires a quantitative deficit in \(|A\bmod p|/p\) over many primes for one fixed set \(A\).

**Output:** bounds of the shape \(|A|\ll N^\alpha\) under the stated local class deficit.

**A303656 crosswalk:** no deficit for \(|E_X\bmod p|\) is known. **Hypothesis missing.**

## 5. Green–Harper — structured local half-sets

**Source:** Ben Green and Adam J. Harper, *Inverse questions for the large sieve*, arXiv:1311.6176 (2013).

**Precise input:** a fixed integer set \(A\) lies modulo each prime inside a specified set \(S_p\) of about half the residues; improvements beyond the square-root barrier require additive structure of \(S_p\), such as excess additive quadruples or interval/progression containment.

**Output:** power or polylogarithmic improvements depending on the local structure.

**A303656 crosswalk:** the canonical-label condition does not put \(E_X\bmod p\) inside a fixed structured half-set. The cell \(h\) and certifying prime vary with \(n\). **Not applicable.**

## 6. Dietmann–Elsholtz–Ruzsa — square conditions

**Source:** Rainer Dietmann, Christian Elsholtz, Imre Ruzsa, *Sieving with square conditions and applications to Hilbert cubes in arithmetic sets*, arXiv:2603.17132v1 (17 March 2026).

**Precise mechanism:** the paper explains that naive larger-sieve use modulo \(p^2\) fails; successful applications transform prime-square information using additional information about the projection modulo \(p\). Its Hilbert-cube results assume subset-sum structure and exploit local avoidance for a fixed additive object.

**Relevant output:** Hilbert cubes in values of irreducible positive definite binary quadratic forms, including sums of two squares, have dimension \(O(\log N)\).

**A303656 crosswalk:** odd valuation is a union of \(p\)-adic shells, not a single square condition. More importantly, no fixed modulo-\(p^2\) class omission plus modulo-\(p\) distribution is proved for \(E_X\). The exponent grid is not a Hilbert cube, and the counterexample condition concerns a translate lying in the complement of \(\mathcal S_2\). **No theorem transfer.**

## 7. Croot–Mao–Pohoata–Sheffer–Yip — combinatorial large sieve

**Source:** Ernie Croot, Junzhe Mao, Cosmin Pohoata, Adam Sheffer, Chi Hoi Yip, *A combinatorial large sieve for Sidon sets, distances, and norm forms*, arXiv:2606.17487v2 (24 June 2026).

**Precise mechanism:** local algebraic splitting modulo many primes creates many compatible branches; a global bounded representation/difference multiplicity prevents the resulting collisions from occurring too often. Theorem 1.1 assumes a fixed Sidon set \(A\subset[N]\) with \(|A_p|\le\alpha p\) for every prime. The norm-form extensions assume pointwise bounds such as \(R_{A,F}(m)\le B\) or \(R_{A_1,\ldots,A_r,F}(m)\le g\).

**Output:** savings of the form \(\exp(-c\log N/\log\log N)\) beyond natural large-sieve scales.

**A303656 crosswalk:** neither required ingredient is verified: there is no fixed local ill-distribution theorem for \(E_X\), and no bounded global multiplicity for the relevant certificate-incidence map. Applying the theorem to the shift set itself only bounds a set already of size \(\Theta((\log X)^2)\) and does not count \(n\). **Not applicable without two new theorems.**

## 8. Saxton–Thomason and Balogh–Morris–Samotij — hypergraph containers

**Sources:**

- David Saxton and Andrew Thomason, *Hypergraph containers*, arXiv:1204.6595.
- József Balogh, Robert Morris, Wojciech Samotij, *Independent sets in hypergraphs*, arXiv:1204.6530.

**Precise input:** a fixed uniform hypergraph with quantitative average-degree and codegree control; independent or sparse sets are covered by a controlled family of containers.

**A303656 crosswalk:** no fixed hypergraph with verified supersaturation/codegrees is available. Prime labels and admissibility change with \(n\), while private incidences have degree one. Even a container count \(\exp(o(K))\), \(K\asymp(\log X)^2\), can greatly exceed \(X\). **No quantitative counting payoff.**

## 9. Matomäki–Shao–Tao–Teräväinen — representation weight versus indicator

**Source:** Kaisa Matomäki, Xuancheng Shao, Terence Tao, Joni Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, arXiv:2204.03754v4 (2024), Appendix A.3–A.4.

**Precise distinction:** the representation-counting function \(r_2(n)=4(1*\chi_4)(n)\) admits the Type-I approximation used by their method. The indicator \(1_{\mathcal S_2}\) is discussed separately as a potential extension, with construction of a sufficiently accurate approximant identified as nontrivial.

**A303656 crosswalk:** this directly confirms that weighted \(r_2\) correlation results do not automatically provide indicator concentration or HC-LT. **Relevant blocker, not a solution.**

## 10. Croot–Mao–Yip — Hilbert cubes in arithmetic sets

**Source:** Ernie Croot, Junzhe Mao, Chi Hoi Yip, *Hilbert cubes in sets with arithmetic properties*, arXiv:2603.14654v1 (2026).

**Precise input:** subset-sum/Hilbert-cube containment in a fixed arithmetic set, with local residue restrictions and additive-combinatorial structure.

**A303656 crosswalk:** \(\{3^c+5^d\}\) is a two-parameter Cartesian sum of two lacunary sequences, not the set of all subset sums of a multiset; a counterexample requires \(n-H_X\subset\mathcal S_2^c\), not a Hilbert cube contained in \(\mathcal S_2\). **Wrong shape and polarity.**

## 11. Bugeaud–Corvaja–Zannier — gcd of recurrence values

**Source:** Yann Bugeaud, Pietro Corvaja, Umberto Zannier, *An upper bound for the G.C.D. of \(a^n-1\) and \(b^n-1\)*, Math. Z. 243 (2003), 79–84.

**Precise output:** for multiplicatively independent integers \(a,b\ge2\) and every \(\varepsilon>0\),

\[
\gcd(a^n-1,b^n-1)<\exp(\varepsilon n)
\]

for all sufficiently large \(n\).

**A303656 crosswalk:** a shared label on a rectangle can force divisibility of two power differences, but the row and column gaps need not be equal, and the theorem is ineffective at the required grid-wide counting level. It says nothing about private labels. **At most a shared-rectangle auxiliary input.**

## 12. Bilu–Hanrot–Voutier — primitive divisors

**Source:** Yuri Bilu, Guillaume Hanrot, Paul M. Voutier, *Existence of primitive divisors of Lucas and Lehmer numbers*, J. reine angew. Math. 539 (2001), 75–122.

**Precise input/output:** terms of a fixed Lucas or Lehmer sequence have primitive prime divisors beyond an explicit finite range, subject to the sequence hypotheses.

**A303656 crosswalk:** \(n-3^c-5^d\) with adversarial \(n\) is not a fixed recurrence sequence. Primitive primes in \(3^u-1\) or \(5^v-1\) concern shared shift differences and tend to create fresh primes rather than compress private witnesses. **No direct application.**

## 13. Square sieve and squarefree-kernel literature

**Representative primary source:** D. R. Heath-Brown, *The square sieve and consecutive square-free numbers*, Math. Ann. 266 (1984), 251–259.

**Precise mechanism:** detect squares or squarefree conditions through character sums and average over moduli.

**A303656 crosswalk:** the obstruction is parity of valuations at primes \(3\bmod4\), separately for a growing translated family and an adversarial exceptional set. No available square-sieve estimate supplies a pointwise canonical-label compression or the signed covariance required for HC-LT. **No theorem match.**

## 14. Literature conclusion

The audit found one genuinely close positive model: Li's canonical witness compression. It succeeds because a common ambient divisor lattice supplies closure under majority selection, one-bit completion after squarefree deletion, self-indexed prime reconstruction, and summable quotient divisor moments. None of those inputs is presently available for the family of different translates \(n-3^c-5^d\).

All remaining frameworks also require at least one unproved input:

1. fixed residue-class ill-distribution of \(E_X\);
2. bounded algebraic multiplicity for a fixed incidence map;
3. modulo-\(p^2\) restriction together with modulo-\(p\) projection control;
4. a fixed hypergraph with supersaturation and a container count below the \(X\) information scale;
5. an accurate indicator or truncated-survivor approximant with signed correlation control;
6. a common-container quotient with ambient bit budget \(O(\log X)\), injective reconstruction, and controlled divisor moments.

No audited primary source closes the canonical certificate record count or proves HC-LT. The literature verdict is therefore **methodologically informative but non-promotional**.
