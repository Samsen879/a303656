# INPUT AUDIT

## 1. Scope

This phase used three task/governance files and five prior A303656 archives. Their byte hashes and validation statuses are recorded in `results/input_audit.json` and `results/input_hashes.tsv`. No prior ZIP is embedded in the new package.

## 2. Frozen authority accepted

The following results were accepted only within their stated scope:

1. the direct positive-density theorem, without any almost-all or universal upgrade;
2. the square-root survivor identity and Theorem PW-A from the private-witness phase;
3. the high-
   \(c\) equal-shift collision control;
4. the project-level `PAUSED / ACTIVE PROMOTED ROUTE: NONE` governance decision.

The descent and simultaneous-selection packages were used as blocker and scope references, not as sources of a new positive theorem.

## 3. Validation results

- `A303656_DESCENT_FINITE_REDUCTION_PHASE_A(3).zip`: internal required-file, JSON, scorecard, manifest, and experiment replay checks passed.
- `A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(6).zip`: the frozen scientific core replay passed. The outer legacy archive still contains known form-feed bytes in two Markdown files and in the generator source. Those defects are disclosed but not copied.
- `A303656_GLOBAL_ROUTE_RESET(10).zip`: manifest-listed files and governance records passed.
- `A303656_PRIVATE_WITNESS_SUPPRESSION_PHASE_A(3).zip`: manifest/control scan passed; the supplied finite theorem checks passed.
- `A303656_SIMULTANEOUS_SELECTION_PHASE_A(4).zip`: the package validator reported an experiment replay mismatch. A structural JSON comparison found exactly one differing field, `/platform`; the mathematical fields were byte-equal after removing that environment string. Its legacy `REPORT.md` also contains one form-feed byte.

The complete raw logs are preserved under `logs/input_validation/`.

## 4. Authority consequences

The known control-character defects do not invalidate the frozen proofs, but this phase does not silently repair or republish those archives. The simultaneous-selection replay is classified as a reproducibility defect, not a mathematical counterexample to its finite outputs. No unverified numerical or heuristic claim from any prior archive is promoted.

## 5. New-package hygiene

The new package contains only UTF-8 text, uses LF line endings, forbids unsafe paths and symlinks, and is scanned for C0 bytes. Its deterministic experiment outputs and theorem sanity outputs are regenerated during validation.
