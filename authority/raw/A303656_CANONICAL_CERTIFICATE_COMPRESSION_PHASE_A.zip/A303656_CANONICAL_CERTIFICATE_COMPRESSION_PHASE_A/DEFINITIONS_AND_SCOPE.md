# DEFINITIONS AND SCOPE

## 1. Original problem

Let

\[
h(c,d)=3^c+5^d,
\qquad
\mathcal D(n)=\{(c,d)\in\mathbf Z_{\ge0}^2:h(c,d)\le n\},
\]

and let

\[
\mathcal S_2=\{a^2+b^2:a,b\in\mathbf Z_{\ge0}\}.
\]

The representation count is

\[
T(n)=\#\{(c,d)\in\mathcal D(n):n-h(c,d)\in\mathcal S_2\}.
\]

The exceptional set on a dyadic interval is

\[
E_X=\{n\in[X,2X]\cap\mathbf Z:T(n)=0\}.
\]

The universal assertion `T(n)>0 for every n>1` remains unresolved.

## 2. Fermat obstruction set

For a positive integer \(m\), put

\[
\mathcal B(m)=\{p\text{ prime}:p\equiv3\pmod4,\ v_p(m)\equiv1\pmod2\}.
\]

Fermat's two-square criterion gives

\[
m\in\mathcal S_2\quad\Longleftrightarrow\quad \mathcal B(m)=\varnothing.
\]

The convention is \(0\in\mathcal S_2\). Consequently, a zero remainder has no bad-prime certificate.

## 3. Pair-labelled and quotient systems

The **pair-labelled grid** retains every exponent pair \((c,d)\), even when two pairs give the same numerical shift. The **distinct-shift quotient** merges all pairs with equal \(h(c,d)\). Both systems are used, and every theorem states which one it concerns.

For a hypothetical counterexample \(n\in E_X\), no active pair can have \(h(c,d)=n\), because that would give remainder zero and hence a representation. Therefore all active remainders in a counterexample are positive.

## 4. Complete-grid restriction

Every positive statement or no-go statement in this package that concerns A303656 is tied to either:

1. the complete active domain \(\mathcal D(n)\); or
2. the fixed dyadic core
   \[
   \mathcal H_X=\{(c,d):h(c,d)\le X/2\},
   \]
   which is active for every \(n\in[X,2X]\).

No universal compression claim is made for arbitrary finite shift sets. Such claims are blocked by the accepted arbitrary-subset CRT construction.

## 5. Frozen authority boundary

This phase accepts, without reproving:

- the frozen positive-density theorem, which gives a positive proportion but not almost all;
- the square-root survivor identity;
- Theorem PW-A, which gives complete actual survivor sets with positive private-witness proportion on infinitely many \(n\);
- the high-\(c\) collision control and the \(O(\log X\log\log X)\) duplicate excess;
- the arbitrary-subset CRT barrier as a scope warning only.

The present phase derives new record-counting consequences from these accepted results and proves a new high-cutoff aggregate tail bound.

## 6. Scale notation

Throughout a dyadic argument,

\[
L=\log X.
\]

The complete exponent grid and fixed core have cardinality \(\Theta(L^2)\). The natural average number of two-square shifts, and the natural square-root survivor scale, are \(\Theta(L^{3/2})\).

## 7. Status vocabulary

- **PROVED:** a complete deterministic derivation is supplied, possibly using a named frozen theorem as an input.
- **CONDITIONAL THEOREM:** the implication is proved, but a stated hypothesis is open.
- **CANDIDATE:** an exact missing theorem with a quantified payoff.
- **COMPUTATIONAL OBSERVATION:** exact finite output with no asymptotic inference.
- **NO-GO:** a specified framework cannot close the requested counting inequality without additional input.
