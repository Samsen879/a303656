# REPRODUCE

## 1. Requirements

- Python 3.11 or later;
- standard library only for all new-package scripts;
- a POSIX-like shell for the command examples.

No Codex, repository checkout, external database, solver, or network connection is needed for replay.

## 2. Replay exact experiments

From the package root:

```bash
rm -rf /tmp/a303656-canonical-experiments
python3 scripts/run_experiments.py \
  --output-dir /tmp/a303656-canonical-experiments
```

Compare these files byte-for-byte with `results/`:

```text
experiment_summary.json
parameters.json
dyadic_metrics.csv
sample_matrix_metrics.csv
experiment_output_hashes.json
```

## 3. Replay finite theorem sanity checks

```bash
python3 scripts/theorem_sanity_checks.py \
  --output /tmp/a303656-theorem-sanity.json
cmp /tmp/a303656-theorem-sanity.json results/theorem_sanity_checks.json
```

## 4. Validate the directory

```bash
python3 scripts/validate_package.py --root .
```

The validator checks:

- required files;
- JSON and CSV parsing;
- exact verdict schema;
- UTF-8 and LF-only text;
- forbidden C0 bytes;
- unsafe paths and symlinks;
- sorted SHA256 manifest;
- sorted package file list;
- byte-identical experiment replay;
- byte-identical theorem-sanity replay.

## 5. Rebuild the deterministic ZIP

If the extracted directory is named exactly

```text
A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A
```

run from its parent directory:

```bash
python3 A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A/scripts/build_deterministic_zip.py \
  --root A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A \
  --output A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A.rebuilt.zip
```

The builder uses:

- sorted entry order;
- timestamp `1980-01-01 00:00:00` for every entry;
- `0644` for data files and `0755` for scripts;
- UTF-8 path flag;
- no ZIP comments or extra fields;
- `ZIP_STORED`, avoiding compressor-version variation.

Validate the rebuilt ZIP against the directory:

```bash
python3 A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A/scripts/validate_package.py \
  --root A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A \
  --zip A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A.rebuilt.zip
```

A rebuild in the audited environment must be byte-identical to the delivered ZIP.

## 6. Manifest convention

`MANIFEST.sha256` hashes every package file except itself. `PACKAGE_FILE_LIST.txt` lists every package file, including the manifest and itself, in sorted POSIX-path order.

## 7. Scientific limitation

Successful replay verifies the delivered finite outputs and packaging. It does not prove A303656, HC-LT, or the absence of counterexamples outside the tested range.
