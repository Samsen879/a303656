# NO-GO RESULTS

## NG-1 — raw full-matrix storage

Storing all \(\Theta((\log X)^2)\) labels is not compression. Counting realized matrices gives only the trivial \(O(X)\) bound; counting abstract matrices is much larger than \(X\).

## NG-2 — natural private-tail charging

Theorem CC-A shows that the global record space of complete-grid private square-root records has exact order

\[
X(\log X)^{3/2}.
\]

Dividing by the natural \((\log X)^{3/2}\) incidence scale yields only \(O(X)\). Any proof in this framework needs a supercritical degree or a smaller record family.

## NG-3 — private-prime product contradiction

The product lower bound from primes exceeding \(\sqrt n\) is at most halfway to the trivial product upper bound from the remainders. It gives no contradiction.

## NG-4 — resultant/discriminant compression

For distinct shifts, private primes divide \(F(n)\) but not \(F'(n)\). Resultants and discriminants detect shared primes and cannot bound the private component that is known to be positive on complete actual survivor sets.

## NG-5 — modulo \(p\) replacement of odd valuation

The condition \(p\mid n-h\) is not equivalent to a bad-prime certificate. Even valuation, including divisibility by \(p^2\), is compatible with \(n-h\in\mathcal S_2\). Any sieve that discards the prime-power parity information changes the problem.

## NG-6 — generic majority-halving

No canonical prime is guaranteed to cover half, or any fixed fraction, of the remaining cells. Private labels can force single-cell branches. Conditioning on labels does not preserve a complete grid.

## NG-7 — qualitative structured subgrid

A monochromatic rectangle or low-rank incidence pattern has no theorem payoff unless it leads to a bound on \(E_X\). Current rectangle extraction controls only shared labels and yields no density loss.

## NG-8 — inverse-sieve theorem-name transfer

Inverse-sieve theorems require a fixed set occupying few residue classes for many primes. A certificate matrix with a prime chosen separately for each \((n,c,d)\) does not verify this hypothesis for \(E_X\).

## NG-9 — combinatorial large sieve without bounded multiplicity

The recent combinatorial large sieve uses local splitting plus a global bound on representation or difference multiplicities. Neither a residue-class bound for \(E_X\) nor the required global multiplicity bound is available. Applying the theorem to the already-polylogarithmic shift set does not count exceptional integers.

## NG-10 — square-condition sieve without projection control

Avoiding or occupying classes modulo \(p^2\) is insufficient by itself. The relevant recent theorem also uses distribution modulo \(p\). The A303656 certificate condition supplies no uniform class restriction for \(E_X\) at either level.

## NG-11 — generic hypergraph containers

Even \(\exp(o(K))\) containers with \(K\asymp(\log X)^2\) can exceed \(X\), and no degree/codegree/supersaturation hypotheses have been verified for the canonical-label hypergraph.

## NG-12 — arbitrary-subset compression

Any theorem stated for arbitrary finite shift subsets is vulnerable to exact-one private-witness CRT constructions. The present package uses the complete grid, but no compression theorem survives after an iterative branch turns it into an arbitrary subset.

## NG-13 — canonical-witness divisor compression without a common ambient lattice

The 2026 Sylow-divisor compression theorem succeeds because all canonical witnesses are divisors of one integer, all selected labels are prime factors of that integer, deleted factors form one squarefree quotient, and the congruence \(D_p\equiv1\pmod p\) reconstructs the row prime. A303656 witnesses divide different translates \(n-h\) and have none of these closure or self-indexing properties. Replacing the common integer by \(\prod_h(n-h)\) does not restore them and enlarges the ambient information scale to \(\exp(\Theta((\log X)^3))\). Therefore the published compression theorem cannot be transferred by a formal change of notation; a new common-container reconstruction and divisor-moment theorem would be required.

## Scope of the no-go verdict

These results stop the current canonical-certificate mechanisms. They do not prove that every possible exceptional-set argument is impossible. HC-LT remains a precise unproved route to almost all.
