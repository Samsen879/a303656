# COMPRESSION AND RECONSTRUCTION

## 1. Compression target

A record is useful only when both quantities are controlled:

\[
N_X=\#\{\text{admissible records}\},
\qquad
F_X=\max_R\#\{n\in E_X:\mathcal R(n)=R\}.
\]

The required inequality is

\[
N_XF_X=o(X).
\]

Because \(|\mathcal D(n)|=\Theta((\log X)^2)\), a record using even one constant-size symbol per cell has exponential size in \((\log X)^2\), much larger than the \(\exp(\log X)=X\) budget.

## 2. Full canonical matrix

The full matrix is not a compression. It stores \(\Theta((\log X)^2)\) prime labels, valuations, or `GOOD` symbols. Counting only realized matrices gives at most \(X\) records because there are only \(X\) possible integers, while counting abstract matrices gives vastly more. Neither count is below the target scale.

## 3. Selected witness records

A record of the form

\[
(c,d,p,e,n\bmod p^{e+1})
\]

has two opposing costs:

- naming a prime near \(P\) costs about \(\log P\) bits;
- the exact odd-valuation shell saves about \(e\log p\) bits, but for the dominant case \(e=1\) the shell has density \(\asymp1/p\), not \(1/p^2\).

For \(e=1\), the prime-name cost and congruence gain cancel to first order. The residual prime-density saving is only polylogarithmic and is lost after union over \(\Theta((\log X)^2)\) possible cells unless a small universal subfamily is proved.

## 4. The square-root reconstruction record

At square-root cutoff, a bad survivor has

\[
n=3^c+5^d+qs,
\qquad q>\sqrt n,
\qquad s\in\mathcal S_2.
\]

The record \((c,d,q,s)\) has fiber one. This is the cleanest possible reconstruction theorem. Nevertheless, Theorem CC-A counts \(\Theta(X(\log X)^{3/2})\) complete-grid private records, exactly matching the natural incidence scale. Perfect reconstruction does not imply compression.

## 5. Closest primary-source benchmark: Li's 2026 canonical compression

Eric Li's 2026 arXiv preprint on Erdős Problem 768 supplies a genuine canonical-witness compression/reconstruction theorem, so it is the closest known benchmark for the mechanism requested in this phase. Its decisive invariant is multiplicative and common to all rows:

- every row is indexed by a prime \(p\mid n\);
- the canonical witness \(D_p\) is a divisor of the **same ambient integer** \(n\) and satisfies \(D_p\equiv1\pmod p\);
- majority-halving is performed inside the prime-factor set of \(n\), so the retained set remains in one hereditary divisor lattice;
- the deleted product \(Q\mid\operatorname{rad}(n)\) is squarefree, and \(n=mQ\) gives one-bit valuation completion for every witness divisor;
- a missing row prime can be reconstructed from a recorded prime-divisor index of \(D_p-1\), after which CRT reconstructs the remaining common product.

These are not cosmetic features. For A303656, rows are exponent cells and their witnesses divide different translated integers

\[
n-3^c-5^d.
\]

There is no common divisor \(D_p\mid n\), no self-indexed congruence \(D_p\equiv1\pmod p\), and no squarefree quotient \(n=mQ\) whose removed factors complete every row with one bit. Conditioning on a label generally leaves an arbitrary cell subset. The obvious common container

\[
F_{\mathcal H}(n)=\prod_{h\in\mathcal H}(n-h)
\]

has logarithmic size \(\Theta((\log X)^3)\) for a complete core, does not create the self-indexed witness relation, and has no proved growing-divisor-moment bound capable of returning to an \(o(X)\) count of inputs \(n\). Thus Li's theorem validates the architecture in a genuinely multiplicative problem but does not instantiate it here. A transfer would require a new **common-container reconstruction theorem**, not merely the same terminology.

## 6. Majority-halving audit

A canonical majority procedure would need, at each stage:

1. a deterministic label or congruence chosen from the current structured grid;
2. a guaranteed positive fraction of cells carrying that label;
3. a residual set that remains a complete or explicitly structured subgrid;
4. a bounded depth;
5. a record count whose total bit budget is below \(\log X\).

None of these is currently available for A303656. Theorem PW-A supplies complete actual survivor sets with a positive fraction of private labels, so a procedure cannot assume that all but \(o(|S|)\) cells are discharged by shared-majority primes. Unlike Li's prime-factor lattice, conditioning on an A303656 label generally leaves an arbitrary subset and destroys the exponent-grid invariant.

## 7. Canonical smallest-prime branching

Choosing the globally smallest canonical label among all cells is deterministic, but no theorem shows that this prime labels many cells. If it is private, one branch removes only one cell. Repeating can require at least the number of private cells, which is \(\Omega((\log X)^{3/2})\) along the complete-family sequence supplied by PW-A.

Choosing the most frequent prime is also deterministic after a tie rule, but the maximum frequency can be one. No complete-grid theorem excludes that situation at the scale needed for counting.

## 8. Residue reconstruction by products

Suppose selected congruences give

\[
n\equiv r_i\pmod{M_i}.
\]

If their least common multiple exceeds \(X\), then the record may reconstruct \(n\) in \([X,2X]\). However, naming the moduli and residues has already paid enough information to distinguish up to \(X\) integers. A product-modulus argument becomes nontrivial only if the moduli come from a record family with substantially fewer than \(X\) possible choices.

## 9. Kernel and quotient summaries

For

\[
\kappa_-(m)=\prod_{p\in\mathcal B(m)}p,
\]

one has \(\kappa_-(m)\mid m\), but recording \(\kappa_-(n-h)\) at every cell is again a full matrix. Recording only an ordered list of the largest kernels lacks a reconstruction theorem; recording the corresponding cofactors returns to the \((h,q,s)\) critical count.

No bounded-complexity quotient, squarefree-kernel, or ordered-prime statistic was found that simultaneously has few records and low fibers.

## 10. What an actual breakthrough must add

A viable compression theorem must supply at least one of:

- a fixed subfamily of \(o(\sqrt{\log X})\) shifts that every counterexample must certify in a restricted prime range;
- supercritical record multiplicity \(\omega((\log X)^{3/2})\) from a record space of size \(O(X(\log X)^{3/2})\);
- a bounded-depth branch preserving a large exponent rectangle while using only \(O(\log X)\) total bits with a strict saving;
- a residue-class restriction on \(E_X\) itself for many primes;
- the high-cutoff survivor lower-tail theorem HC-LT.
