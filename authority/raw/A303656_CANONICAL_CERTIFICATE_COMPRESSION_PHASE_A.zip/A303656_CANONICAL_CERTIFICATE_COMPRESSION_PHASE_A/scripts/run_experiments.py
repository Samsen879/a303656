#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, math, sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

SCHEMA = "a303656-canonical-certificate-compression-experiments-v1"


def powers(base:int, limit:int)->list[int]:
    out=[]; x=1
    while x<=limit:
        out.append(x); x*=base
    return out


def spf_sieve(n:int)->list[int]:
    spf=list(range(n+1))
    if n>=1: spf[1]=1
    for i in range(2,int(n**0.5)+1):
        if spf[i]==i:
            start=i*i
            for j in range(start,n+1,i):
                if spf[j]==j: spf[j]=i
    return spf


def bad_data(max_n:int, spf:list[int]):
    pstar=[0]*(max_n+1)
    estar=[0]*(max_n+1)
    bad_tuple=[()]*(max_n+1)
    is_s2=[False]*(max_n+1)
    is_s2[0]=True; is_s2[1]=True
    for m in range(2,max_n+1):
        x=m; bad=[]
        while x>1:
            p=spf[x]; e=0
            while x%p==0:
                x//=p; e+=1
            if p%4==3 and e%2==1:
                bad.append((p,e))
        bad_tuple[m]=tuple(bad)
        if not bad:
            is_s2[m]=True
        else:
            pstar[m],estar[m]=bad[0]
    return pstar,estar,bad_tuple,is_s2


def active_pairs(limit:int, p3:list[int], p5:list[int]):
    return [(c,d,a+b) for c,a in enumerate(p3) for d,b in enumerate(p5) if a+b<=limit]


def unique_shift_quotient(pairs):
    seen={}
    for c,d,h in pairs:
        seen.setdefault(h,(c,d,h))
    return [seen[h] for h in sorted(seen)]


def shannon_entropy(labels:list[int])->float:
    if not labels: return 0.0
    cnt=Counter(labels); k=len(labels)
    return -sum((v/k)*math.log2(v/k) for v in cnt.values())


def rectangle_count(matrix:list[list[int]])->tuple[int,int]:
    # Same positive label at all four corners.
    rows=len(matrix); total=0; max_color_rects=0
    by_color=Counter()
    for i in range(rows):
        for j in range(i+1,rows):
            c=Counter()
            for x,y in zip(matrix[i],matrix[j]):
                if x>0 and x==y: c[x]+=1
            for p,k in c.items():
                if k>=2:
                    z=k*(k-1)//2; total+=z; by_color[p]+=z
    if by_color: max_color_rects=max(by_color.values())
    return total,max_color_rects


def fixed_rect(X:int,p3:list[int],p5:list[int]):
    # a<=X/4 and b<=X/4 makes all sums <=X/2.
    cs=[(c,a) for c,a in enumerate(p3) if a<=X//4]
    ds=[(d,b) for d,b in enumerate(p5) if b<=X//4]
    return cs,ds


def pair_label_matrix(n:int,cs,ds,pstar):
    return [[pstar[n-a-b] for d,b in ds] for c,a in cs]


def analyze_dyadic(X:int, deltas:list[float], p3,p5,pstar,estar,bad_tuple,is_s2):
    L=math.log(X)
    full_pairs=active_pairs(2*X,p3,p5)
    core_pairs=active_pairs(X//2,p3,p5)
    core_q=unique_shift_quotient(core_pairs)
    cs,ds=fixed_rect(X,p3,p5)
    # Fixed sample points, deterministic and spread through interval.
    sample_stride=max(1,X//128)
    sample_ns=list(range(X,2*X+1,sample_stride))
    if sample_ns[-1]!=2*X: sample_ns.append(2*X)

    agg={
      "n_count": X+1,
      "core_pair_count": len(core_pairs),
      "core_distinct_shift_count": len(core_q),
      "full_pair_count_at_2X": len(full_pairs),
      "fixed_rectangle_rows": len(cs),
      "fixed_rectangle_cols": len(ds),
      "zero_full_T_count": 0,
      "square_root_bad_survivor_incidences": 0,
      "square_root_private_pair_incidences": 0,
      "square_root_bad_survivor_distinct_shift_incidences": 0,
      "square_root_private_distinct_shift_incidences": 0,
      "square_root_survivor_incidences": 0,
      "square_root_good_survivor_incidences": 0,
      "sample_entropy_sum_bits": 0.0,
      "sample_entropy_count": 0,
      "sample_rectangle_total": 0,
      "sample_rectangle_positive_count": 0,
      "sample_max_label_multiplicity": 0,
    }
    high={str(delta): {"delta":delta,"z":int(X**(1-delta)),"bad_incidences":0,"survivor_incidences":0,"good_incidences":0,
                       "survivor_counts":[],"bad_counts":[]} for delta in deltas}
    sample_set=set(sample_ns)
    sample_rows=[]
    # Restricted all-bad prefix cores and records.
    prefix_sizes=[4,8,12]
    prefix_pairs=sorted(core_pairs)[:max(prefix_sizes)]
    restricted={k:{"n_all_bad":0,"full_label_records":Counter(),"coarse_profile_records":Counter()} for k in prefix_sizes}

    for n in range(X,2*X+1):
        active=[t for t in full_pairs if t[2]<=n]
        labels=[]; good_count=0
        sq_surv=[]
        for c,d,h in active:
            r=n-h
            if is_s2[r]: good_count+=1
            zsq=math.isqrt(n)
            if not bad_tuple[r] or bad_tuple[r][0][0]>zsq:
                sq_surv.append((c,d,h,r,pstar[r]))
        if good_count==0: agg["zero_full_T_count"]+=1
        agg["square_root_survivor_incidences"] += len(sq_surv)
        good_sq=sum(1 for *_,p in sq_surv if p==0)
        agg["square_root_good_survivor_incidences"] += good_sq
        bad_sq=[x for x in sq_surv if x[-1]>0]
        agg["square_root_bad_survivor_incidences"] += len(bad_sq)
        cnt=Counter(x[-1] for x in bad_sq)
        agg["square_root_private_pair_incidences"] += sum(1 for x in bad_sq if cnt[x[-1]]==1)
        # Quotient by equal numerical shift; first pair only.
        qseen={}
        for row in sq_surv: qseen.setdefault(row[2],row)
        qbad=[x for x in qseen.values() if x[-1]>0]
        qcnt=Counter(x[-1] for x in qbad)
        agg["square_root_bad_survivor_distinct_shift_incidences"] += len(qbad)
        agg["square_root_private_distinct_shift_incidences"] += sum(1 for x in qbad if qcnt[x[-1]]==1)

        for delta in deltas:
            rec=high[str(delta)]; z=rec["z"]
            surv=0; badc=0; goodc=0
            for c,d,h in core_pairs:
                r=n-h
                if not bad_tuple[r] or bad_tuple[r][0][0]>z:
                    surv+=1
                    if is_s2[r]: goodc+=1
                    else: badc+=1
            rec["survivor_incidences"]+=surv; rec["bad_incidences"]+=badc; rec["good_incidences"]+=goodc
            rec["survivor_counts"].append(surv); rec["bad_counts"].append(badc)

        prefix_vals=[(pstar[n-h],estar[n-h]) for c,d,h in prefix_pairs]
        for k in prefix_sizes:
            vals=prefix_vals[:k]
            if all(p>0 for p,e in vals):
                rr=restricted[k]; rr["n_all_bad"]+=1
                rr["full_label_records"][tuple(vals)]+=1
                ps=[p for p,e in vals]
                prof=(len(set(ps)), max(Counter(ps).values()), sum(p<=31 for p in ps), sum(p>math.isqrt(n) for p in ps))
                rr["coarse_profile_records"][prof]+=1

        if n in sample_set:
            bad_labels=[pstar[n-h] for c,d,h in active if pstar[n-h]>0]
            H=shannon_entropy(bad_labels)
            matrix=pair_label_matrix(n,cs,ds,pstar)
            rects,maxcr=rectangle_count(matrix)
            mx=max(Counter(bad_labels).values(),default=0)
            agg["sample_entropy_sum_bits"]+=H; agg["sample_entropy_count"]+=1
            agg["sample_rectangle_total"]+=rects
            agg["sample_rectangle_positive_count"]+=int(rects>0)
            agg["sample_max_label_multiplicity"]=max(agg["sample_max_label_multiplicity"],mx)
            sample_rows.append({"X":X,"n":n,"active_pairs":len(active),"good_count":good_count,"bad_cells":len(bad_labels),
                                "distinct_bad_labels":len(set(bad_labels)),"label_entropy_bits":round(H,12),
                                "same_label_rectangles":rects,"max_color_rectangles":maxcr,"max_label_multiplicity":mx})

    # finalize high cutoff stats, no raw arrays in output
    for delta in deltas:
        rec=high[str(delta)]
        sc=rec.pop("survivor_counts"); bc=rec.pop("bad_counts")
        mean=sum(sc)/len(sc); sorted_sc=sorted(sc)
        rec["mean_survivors_per_n"]=mean
        rec["min_survivors"]=min(sc); rec["median_survivors"]=sorted_sc[len(sc)//2]
        rec["fraction_below_half_mean"]=sum(x<0.5*mean for x in sc)/len(sc)
        rec["fraction_below_quarter_mean"]=sum(x<0.25*mean for x in sc)/len(sc)
        rec["mean_bad_per_n"]=sum(bc)/len(bc)
        rec["normalized_bad_by_sqrtdelta_X_log32"]=rec["bad_incidences"]/(math.sqrt(delta)*X*(L**1.5))
    agg["sample_mean_label_entropy_bits"]=agg.pop("sample_entropy_sum_bits")/max(1,agg["sample_entropy_count"])
    agg["sample_fraction_with_monochromatic_rectangle"]=agg["sample_rectangle_positive_count"]/max(1,agg["sample_entropy_count"])
    agg["normalized_sqrt_bad_by_X_log32"]=agg["square_root_bad_survivor_incidences"]/(X*(L**1.5))
    agg["normalized_sqrt_private_by_X_log32"]=agg["square_root_private_pair_incidences"]/(X*(L**1.5))
    agg["normalized_sqrt_private_quotient_by_X_log32"]=agg["square_root_private_distinct_shift_incidences"]/(X*(L**1.5))
    agg["mean_square_root_survivors_per_n"]=agg["square_root_survivor_incidences"]/(X+1)
    agg["mean_square_root_bad_survivors_per_n"]=agg["square_root_bad_survivor_incidences"]/(X+1)
    agg["mean_square_root_private_pair_per_n"]=agg["square_root_private_pair_incidences"]/(X+1)
    # finalize record collision stats
    restricted_out={}
    for k,rr in restricted.items():
        full=rr["full_label_records"]; coarse=rr["coarse_profile_records"]
        restricted_out[str(k)]={
          "prefix_cells":k,"n_all_bad":rr["n_all_bad"],
          "full_record_count":len(full),"full_record_max_fiber":max(full.values(),default=0),
          "coarse_record_count":len(coarse),"coarse_record_max_fiber":max(coarse.values(),default=0),
        }
    return agg, high, restricted_out, sample_rows


def collision_analysis(max_shift:int,p3,p5):
    groups=defaultdict(list)
    for c,a in enumerate(p3):
        for d,b in enumerate(p5):
            h=a+b
            if h<=max_shift: groups[h].append((c,d))
    cols={str(h):v for h,v in groups.items() if len(v)>1}
    vertices=sum(len(v) for v in groups.values())
    duplicate_excess=sum(len(v)-1 for v in groups.values())
    return {"limit":max_shift,"pair_vertices":vertices,"distinct_shifts":len(groups),"collision_class_count":len(cols),
            "duplicate_excess":duplicate_excess,"collision_classes":dict(sorted(cols.items(), key=lambda kv:int(kv[0])))}


def sha(path:Path)->str:
    h=hashlib.sha256(); h.update(path.read_bytes()); return h.hexdigest()


def dump_json(path:Path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8",newline="\n")


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--output-dir",required=True)
    ap.add_argument("--x-values",default="4000,8000,16000,32000")
    ap.add_argument("--deltas",default="0.10,0.15,0.25")
    ns=ap.parse_args()
    out=Path(ns.output_dir); out.mkdir(parents=True,exist_ok=True)
    Xs=[int(x) for x in ns.x_values.split(',')]
    deltas=[float(x) for x in ns.deltas.split(',')]
    max_n=2*max(Xs)
    p3=powers(3,max_n); p5=powers(5,max_n)
    spf=spf_sieve(max_n)
    pstar,estar,bad_tuple,is_s2=bad_data(max_n,spf)
    all_metrics=[]; high_metrics={}; restricted={}; sample_rows=[]
    for X in Xs:
        a,h,r,s=analyze_dyadic(X,deltas,p3,p5,pstar,estar,bad_tuple,is_s2)
        a["X"]=X; all_metrics.append(a); high_metrics[str(X)]=h; restricted[str(X)]=r; sample_rows.extend(s)
    collision=collision_analysis(max_n,p3,p5)
    params={"schema":SCHEMA,"x_values":Xs,"deltas":deltas,"max_n":max_n,
            "scope":"small/medium exact classification only; no inference to asymptotics or counterexample nonexistence"}
    summary={"schema":SCHEMA,"parameters":params,"dyadic_metrics":all_metrics,"high_cutoff_metrics":high_metrics,
             "restricted_record_fibers":restricted,"shift_collisions":collision,
             "classification":"COMPUTATIONAL OBSERVATION"}
    dump_json(out/"experiment_summary.json",summary)
    dump_json(out/"parameters.json",params)
    with (out/"dyadic_metrics.csv").open('w',encoding='utf-8',newline='') as f:
        fields=sorted(all_metrics[0])
        w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n'); w.writeheader(); w.writerows(all_metrics)
    with (out/"sample_matrix_metrics.csv").open('w',encoding='utf-8',newline='') as f:
        fields=list(sample_rows[0])
        w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n'); w.writeheader(); w.writerows(sample_rows)
    deterministic_names=["experiment_summary.json","parameters.json","dyadic_metrics.csv","sample_matrix_metrics.csv"]
    hashes={name:sha(out/name) for name in deterministic_names}
    dump_json(out/"experiment_output_hashes.json",hashes)
    print(json.dumps({"status":"PASS","schema":SCHEMA,"files":deterministic_names+["experiment_output_hashes.json"],"max_n":max_n},sort_keys=True))

if __name__=="__main__": main()
