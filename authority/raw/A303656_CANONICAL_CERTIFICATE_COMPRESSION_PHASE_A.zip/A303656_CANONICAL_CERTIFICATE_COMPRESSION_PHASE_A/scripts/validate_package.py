#!/usr/bin/env python3
"""Read-only validator for the directory and optional deterministic ZIP."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Dict, List

FIXED_TIMESTAMP = (1980, 1, 1, 0, 0, 0)
FORBIDDEN_C0 = set(range(0x00, 0x09)) | {0x0B, 0x0C} | set(range(0x0E, 0x20)) | {0x7F}
REQUIRED = [
    "EXECUTIVE_VERDICT.md",
    "ROUTE_VERDICT.json",
    "REPORT.md",
    "DEFINITIONS_AND_SCOPE.md",
    "CANONICAL_WITNESS_SYSTEM.md",
    "COMPLETE_GRID_GEOMETRY.md",
    "COMPRESSION_AND_RECONSTRUCTION.md",
    "RECORD_COUNT_AND_FIBERS.md",
    "EXCEPTIONAL_SET_COUNTING.md",
    "STRUCTURED_SUBGRID_ANALYSIS.md",
    "CANDIDATE_THEOREMS.md",
    "PROVED_LEMMAS.md",
    "NO_GO_RESULTS.md",
    "LITERATURE_AUDIT.md",
    "COMPUTATIONAL_EXPERIMENTS.md",
    "LIMITATIONS.md",
    "AUTHORITY_UPDATES.md",
    "INPUT_AUDIT.md",
    "environment.json",
    "MANIFEST.sha256",
    "PACKAGE_FILE_LIST.txt",
    "REPRODUCE.md",
    "scripts/run_experiments.py",
    "scripts/theorem_sanity_checks.py",
    "scripts/build_deterministic_zip.py",
    "scripts/validate_package.py",
    "results/experiment_summary.json",
    "results/parameters.json",
    "results/dyadic_metrics.csv",
    "results/sample_matrix_metrics.csv",
    "results/experiment_output_hashes.json",
    "results/theorem_sanity_checks.json",
    "results/input_audit.json",
    "results/input_hashes.tsv",
    "results/candidate_scorecard.csv",
    "results/literature_sources.json",
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def add(errors: List[str], condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


def parse_manifest(root: Path, errors: List[str]) -> Dict[str, str]:
    manifest_path = root / "MANIFEST.sha256"
    entries: Dict[str, str] = {}
    try:
        lines = manifest_path.read_text(encoding="utf-8").splitlines()
    except Exception as exc:
        errors.append(f"manifest read: {exc}")
        return entries
    for line in lines:
        if not line:
            continue
        if "  " not in line:
            errors.append(f"manifest syntax: {line!r}")
            continue
        digest, rel = line.split("  ", 1)
        if rel in entries:
            errors.append(f"manifest duplicate: {rel}")
            continue
        entries[rel] = digest
        p = root / rel
        if not p.is_file():
            errors.append(f"manifest missing file: {rel}")
        elif sha256(p) != digest:
            errors.append(f"manifest hash mismatch: {rel}")
    expected = sorted(
        p.relative_to(root).as_posix()
        for p in root.rglob("*")
        if p.is_file() and p.name != "MANIFEST.sha256"
    )
    add(errors, sorted(entries) == expected, "manifest path set mismatch")
    add(errors, list(entries) == expected, "manifest is not sorted")
    return entries


def scan_text_and_paths(root: Path, errors: List[str]) -> Dict[str, int]:
    scanned = 0
    byte_count = 0
    for p in sorted(root.rglob("*")):
        if p.is_symlink():
            errors.append(f"symlink forbidden: {p.relative_to(root)}")
            continue
        if not p.is_file():
            continue
        rel = p.relative_to(root).as_posix()
        if rel.startswith("/") or ".." in Path(rel).parts:
            errors.append(f"unsafe path: {rel}")
        data = p.read_bytes()
        scanned += 1
        byte_count += len(data)
        bad = [(i, b) for i, b in enumerate(data) if b in FORBIDDEN_C0]
        if bad:
            errors.append(f"forbidden C0 bytes in {rel}: {bad[:5]}")
        try:
            data.decode("utf-8")
        except UnicodeDecodeError as exc:
            errors.append(f"non-UTF-8 file {rel}: {exc}")
        if b"\r" in data:
            errors.append(f"non-LF newline byte in {rel}")
    return {"files_scanned": scanned, "bytes_scanned": byte_count}


def parse_structured_files(root: Path, errors: List[str]) -> None:
    json_files = sorted(root.rglob("*.json"))
    for p in json_files:
        try:
            json.loads(p.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"JSON parse {p.relative_to(root)}: {exc}")
    for rel in ["results/dyadic_metrics.csv", "results/sample_matrix_metrics.csv", "results/candidate_scorecard.csv"]:
        try:
            with (root / rel).open(encoding="utf-8", newline="") as f:
                rows = list(csv.DictReader(f))
            if not rows:
                errors.append(f"empty CSV: {rel}")
        except Exception as exc:
            errors.append(f"CSV parse {rel}: {exc}")


def validate_verdict(root: Path, errors: List[str]) -> None:
    try:
        obj = json.loads((root / "ROUTE_VERDICT.json").read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"verdict read: {exc}")
        return
    required = {
        "project",
        "phase",
        "final_verdict",
        "strongest_proved_lemma",
        "strongest_candidate",
        "core_missing_lemma",
        "promotion_recommended",
        "codex_authorized",
        "ultra_authorized",
        "a303656_status",
    }
    add(errors, required <= set(obj), "verdict schema missing fields")
    add(errors, obj.get("project") == "A303656", "verdict project mismatch")
    add(errors, obj.get("phase") == "canonical_certificate_compression_phase_a", "verdict phase mismatch")
    add(errors, obj.get("final_verdict") == "NO PROMOTABLE ROUTE — RETAIN AS SPECULATIVE WATCH", "verdict value mismatch")
    add(errors, obj.get("promotion_recommended") is False, "promotion flag must be false")
    add(errors, obj.get("codex_authorized") is False, "Codex flag must be false")
    add(errors, obj.get("ultra_authorized") is False, "Ultra flag must be false")
    add(errors, obj.get("a303656_status") == "UNRESOLVED", "A303656 status mismatch")


def replay(root: Path, errors: List[str]) -> Dict[str, object]:
    report: Dict[str, object] = {}
    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        exp_out = td_path / "experiments"
        cp = subprocess.run(
            [sys.executable, str(root / "scripts/run_experiments.py"), "--output-dir", str(exp_out)],
            capture_output=True,
            text=True,
        )
        report["experiment_exit"] = cp.returncode
        report["experiment_stdout"] = cp.stdout.strip()
        if cp.returncode != 0:
            errors.append("experiment replay failed: " + cp.stderr.strip())
        else:
            names = [
                "experiment_summary.json",
                "parameters.json",
                "dyadic_metrics.csv",
                "sample_matrix_metrics.csv",
                "experiment_output_hashes.json",
            ]
            mismatches = [name for name in names if (exp_out / name).read_bytes() != (root / "results" / name).read_bytes()]
            report["experiment_mismatches"] = mismatches
            if mismatches:
                errors.append("experiment replay mismatch: " + ", ".join(mismatches))

        sanity_out = td_path / "theorem_sanity_checks.json"
        cp2 = subprocess.run(
            [sys.executable, str(root / "scripts/theorem_sanity_checks.py"), "--output", str(sanity_out)],
            capture_output=True,
            text=True,
        )
        report["sanity_exit"] = cp2.returncode
        report["sanity_stdout"] = cp2.stdout.strip()
        if cp2.returncode != 0:
            errors.append("theorem sanity replay failed: " + cp2.stderr.strip())
        elif sanity_out.read_bytes() != (root / "results/theorem_sanity_checks.json").read_bytes():
            errors.append("theorem sanity replay mismatch")
            report["sanity_mismatch"] = True
        else:
            report["sanity_mismatch"] = False
    return report


def validate_zip(root: Path, zip_path: Path, errors: List[str]) -> Dict[str, object]:
    info: Dict[str, object] = {}
    if not zip_path.is_file():
        errors.append(f"ZIP missing: {zip_path}")
        return info
    expected_rel = sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file())
    expected_names = [f"{root.name}/{rel}" for rel in expected_rel]
    with zipfile.ZipFile(zip_path) as zf:
        entries = zf.infolist()
        names = [zi.filename for zi in entries]
        info["entry_count"] = len(entries)
        info["compression_methods"] = sorted({zi.compress_type for zi in entries})
        info["timestamps"] = sorted({zi.date_time for zi in entries})
        add(errors, names == expected_names, "ZIP entries not sorted or path set mismatch")
        add(errors, len(names) == len(set(names)), "ZIP has duplicate entries")
        for zi, rel in zip(entries, expected_rel):
            add(errors, zi.date_time == FIXED_TIMESTAMP, f"ZIP timestamp mismatch: {zi.filename}")
            add(errors, zi.compress_type == zipfile.ZIP_STORED, f"ZIP compression mismatch: {zi.filename}")
            mode = (zi.external_attr >> 16) & 0o777
            expected_mode = 0o755 if rel.startswith("scripts/") else 0o644
            add(errors, mode == expected_mode, f"ZIP mode mismatch: {zi.filename} {oct(mode)}")
            if zf.read(zi) != (root / rel).read_bytes():
                errors.append(f"ZIP content mismatch: {zi.filename}")
    info["sha256"] = sha256(zip_path)
    return info


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--zip")
    ap.add_argument("--skip-replay", action="store_true")
    ap.add_argument("--json-output")
    ns = ap.parse_args()

    root = Path(ns.root).resolve()
    errors: List[str] = []
    add(errors, root.is_dir(), f"root is not a directory: {root}")
    for rel in REQUIRED:
        add(errors, (root / rel).is_file(), f"missing required file: {rel}")
    scan = scan_text_and_paths(root, errors)
    parse_structured_files(root, errors)
    validate_verdict(root, errors)
    parse_manifest(root, errors)
    try:
        listed = (root / "PACKAGE_FILE_LIST.txt").read_text(encoding="utf-8").splitlines()
        actual = sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file())
        add(errors, listed == actual, "PACKAGE_FILE_LIST mismatch or unsorted")
    except Exception as exc:
        errors.append(f"PACKAGE_FILE_LIST read: {exc}")

    replay_report: Dict[str, object] = {"skipped": bool(ns.skip_replay)}
    if not ns.skip_replay:
        replay_report = replay(root, errors)
    zip_report: Dict[str, object] = {}
    if ns.zip:
        zip_report = validate_zip(root, Path(ns.zip).resolve(), errors)

    payload = {
        "status": "PASS" if not errors else "FAIL",
        "root": str(root),
        "required_file_count": len(REQUIRED),
        "scan": scan,
        "replay": replay_report,
        "zip": zip_report,
        "errors": errors,
    }
    text = json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    if ns.json_output:
        Path(ns.json_output).write_text(text, encoding="utf-8", newline="\n")
    sys.stdout.write(text)
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
