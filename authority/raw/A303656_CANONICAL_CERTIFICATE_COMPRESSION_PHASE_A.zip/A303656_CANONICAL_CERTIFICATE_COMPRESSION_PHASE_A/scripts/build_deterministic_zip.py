#!/usr/bin/env python3
"""Build a byte-stable ZIP with fixed metadata and sorted entries."""
from __future__ import annotations

import argparse
import os
import stat
import tempfile
import zipfile
from pathlib import Path

FIXED_TIMESTAMP = (1980, 1, 1, 0, 0, 0)


def iter_files(root: Path, output: Path):
    files = []
    for p in root.rglob("*"):
        if p.is_symlink():
            raise ValueError(f"symlinks are not allowed: {p}")
        if p.is_file() and p.resolve() != output.resolve():
            files.append(p)
    return sorted(files, key=lambda p: p.relative_to(root).as_posix())


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--output", required=True)
    ns = ap.parse_args()

    root = Path(ns.root).resolve()
    output = Path(ns.output).resolve()
    if not root.is_dir():
        raise SystemExit(f"not a directory: {root}")
    output.parent.mkdir(parents=True, exist_ok=True)
    files = iter_files(root, output)
    prefix = root.name

    fd, tmp_name = tempfile.mkstemp(prefix=output.name + ".", suffix=".tmp", dir=output.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as zf:
            zf.comment = b""
            for p in files:
                rel = p.relative_to(root).as_posix()
                arcname = f"{prefix}/{rel}"
                zi = zipfile.ZipInfo(arcname, date_time=FIXED_TIMESTAMP)
                zi.create_system = 3
                zi.compress_type = zipfile.ZIP_STORED
                zi.flag_bits |= 0x800
                zi.extra = b""
                zi.comment = b""
                mode = 0o755 if rel.startswith("scripts/") else 0o644
                zi.external_attr = (stat.S_IFREG | mode) << 16
                zf.writestr(zi, p.read_bytes(), compress_type=zipfile.ZIP_STORED)
        os.replace(tmp, output)
    finally:
        if tmp.exists():
            tmp.unlink()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
