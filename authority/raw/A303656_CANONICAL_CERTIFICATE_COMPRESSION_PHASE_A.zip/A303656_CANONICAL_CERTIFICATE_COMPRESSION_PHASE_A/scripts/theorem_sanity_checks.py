#!/usr/bin/env python3
"""Deterministic exact sanity checks for Phase A proved identities.

These checks are finite falsification aids only.  They are not used as proofs of
asymptotic theorems and they do not authorize a production search.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

SCHEMA = "a303656-canonical-certificate-theorem-sanity-v1"


def powers(base: int, limit: int) -> List[int]:
    out: List[int] = []
    x = 1
    while x <= limit:
        out.append(x)
        x *= base
    return out


def spf_sieve(limit: int) -> List[int]:
    spf = list(range(limit + 1))
    if limit >= 1:
        spf[1] = 1
    for p in range(2, math.isqrt(limit) + 1):
        if spf[p] == p:
            for m in range(p * p, limit + 1, p):
                if spf[m] == m:
                    spf[m] = p
    return spf


def factorization(n: int, spf: Sequence[int]) -> List[Tuple[int, int]]:
    if n < 1:
        raise ValueError("factorization requires n >= 1")
    out: List[Tuple[int, int]] = []
    while n > 1:
        p = spf[n]
        e = 0
        while n % p == 0:
            n //= p
            e += 1
        out.append((p, e))
    return out


def bad_primes(n: int, spf: Sequence[int]) -> List[Tuple[int, int]]:
    if n == 0:
        return []
    return [(p, e) for p, e in factorization(n, spf) if p % 4 == 3 and e % 2 == 1]


def is_two_square_factor(n: int, spf: Sequence[int]) -> bool:
    return not bad_primes(n, spf)


def two_square_table(limit: int) -> List[bool]:
    table = [False] * (limit + 1)
    r = math.isqrt(limit)
    for a in range(r + 1):
        aa = a * a
        for b in range(r + 1):
            s = aa + b * b
            if s > limit:
                break
            table[s] = True
    return table


def active_pairs(limit: int, p3: Sequence[int], p5: Sequence[int]) -> List[Tuple[int, int, int]]:
    out: List[Tuple[int, int, int]] = []
    for c, a in enumerate(p3):
        for d, b in enumerate(p5):
            h = a + b
            if h <= limit:
                out.append((c, d, h))
    return sorted(out, key=lambda row: (row[2], row[0], row[1]))


def primes_upto(limit: int, spf: Sequence[int]) -> List[int]:
    return [n for n in range(2, limit + 1) if spf[n] == n]


def dump_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def check_two_square_criterion(limit: int, spf: Sequence[int]) -> Dict[str, object]:
    brute = two_square_table(limit)
    mismatches = [n for n in range(limit + 1) if brute[n] != is_two_square_factor(n, spf)]
    return {
        "name": "fermat_two_square_criterion",
        "limit": limit,
        "mismatch_count": len(mismatches),
        "first_mismatches": mismatches[:10],
        "status": "PASS" if not mismatches else "FAIL",
    }


def check_canonical_minimum(limit: int, spf: Sequence[int]) -> Dict[str, object]:
    failures: List[Dict[str, object]] = []
    checked = 0
    for n in range(1, limit + 1):
        bad = bad_primes(n, spf)
        if not bad:
            continue
        checked += 1
        p, e = bad[0]
        if p % 4 != 3 or e % 2 != 1:
            failures.append({"n": n, "reason": "bad canonical parity", "p": p, "e": e})
        for q, f in factorization(n, spf):
            if q < p and q % 4 == 3 and f % 2 == 1:
                failures.append({"n": n, "reason": "smaller odd bad prime", "p": p, "q": q})
    return {
        "name": "canonical_minimum_and_tie_breaking",
        "limit": limit,
        "non_two_square_checked": checked,
        "failure_count": len(failures),
        "first_failures": failures[:10],
        "status": "PASS" if not failures else "FAIL",
    }


def check_square_root_identity(n_limit: int, spf: Sequence[int], p3: Sequence[int], p5: Sequence[int]) -> Dict[str, object]:
    pairs = active_pairs(n_limit, p3, p5)
    failures: List[Dict[str, object]] = []
    checked = 0
    reconstructed = 0
    for n in range(2, n_limit + 1):
        z = math.isqrt(n)
        for c, d, h in pairs:
            if h > n:
                break
            m = n - h
            if m <= 0:
                continue
            bad = bad_primes(m, spf)
            if any(p <= z for p, _ in bad):
                continue
            if not bad:
                continue
            checked += 1
            if len(bad) != 1:
                failures.append({"n": n, "c": c, "d": d, "m": m, "reason": "bad-prime count", "bad": bad})
                continue
            q, e = bad[0]
            s = m // q
            if not (q > math.sqrt(n) and e == 1 and is_two_square_factor(s, spf) and h + q * s == n):
                failures.append({"n": n, "c": c, "d": d, "m": m, "q": q, "e": e, "s": s})
            else:
                reconstructed += 1
    return {
        "name": "square_root_tail_identity_and_reconstruction",
        "n_limit": n_limit,
        "bad_survivor_cells_checked": checked,
        "reconstructions_checked": reconstructed,
        "failure_count": len(failures),
        "first_failures": failures[:10],
        "status": "PASS" if not failures else "FAIL",
    }


def check_high_cutoff_decomposition(X: int, delta: float, spf: Sequence[int], p3: Sequence[int], p5: Sequence[int]) -> Dict[str, object]:
    z = int(X ** (1.0 - delta))
    core = active_pairs(X // 2, p3, p5)
    failures: List[Dict[str, object]] = []
    checked = 0
    for n in range(X, 2 * X + 1):
        for c, d, h in core:
            m = n - h
            bad = bad_primes(m, spf)
            if any(p <= z for p, _ in bad):
                continue
            if not bad:
                continue
            checked += 1
            q, e = bad[0]
            s = m // q
            ok = (
                len(bad) == 1
                and q > z
                and e == 1
                and is_two_square_factor(s, spf)
                and s <= (2 * X) // z + 1
                and h + q * s == n
            )
            if not ok:
                failures.append({"n": n, "c": c, "d": d, "m": m, "bad": bad, "q": q, "e": e, "s": s})
    return {
        "name": "high_cutoff_unique_tail_decomposition",
        "X": X,
        "delta": delta,
        "z": z,
        "core_pair_count": len(core),
        "bad_survivor_cells_checked": checked,
        "failure_count": len(failures),
        "first_failures": failures[:10],
        "status": "PASS" if not failures else "FAIL",
    }


def check_rectangle_divisibility(n_limit: int, spf: Sequence[int], p3: Sequence[int], p5: Sequence[int]) -> Dict[str, object]:
    cs = list(range(min(8, len(p3))))
    ds = list(range(min(7, len(p5))))
    failures: List[Dict[str, object]] = []
    rectangles = 0
    for n in range(max(3, n_limit // 2), n_limit + 1):
        labels: Dict[Tuple[int, int], int] = {}
        for c in cs:
            for d in ds:
                h = p3[c] + p5[d]
                if h > n:
                    continue
                bad = bad_primes(n - h, spf)
                labels[(c, d)] = bad[0][0] if bad else 0
        for i, c1 in enumerate(cs):
            for c2 in cs[i + 1 :]:
                for j, d1 in enumerate(ds):
                    for d2 in ds[j + 1 :]:
                        vals = [labels.get((c1, d1)), labels.get((c1, d2)), labels.get((c2, d1)), labels.get((c2, d2))]
                        if None in vals or vals[0] == 0 or len(set(vals)) != 1:
                            continue
                        rectangles += 1
                        p = int(vals[0])
                        if (p3[c1] - p3[c2]) % p != 0 or (p5[d1] - p5[d2]) % p != 0:
                            failures.append({"n": n, "corners": [c1, c2, d1, d2], "p": p})
    return {
        "name": "monochromatic_rectangle_divisibility",
        "n_limit": n_limit,
        "rectangles_checked": rectangles,
        "failure_count": len(failures),
        "first_failures": failures[:10],
        "status": "PASS" if not failures else "FAIL",
    }


def check_derivative_dichotomy(limit: int, spf: Sequence[int], p3: Sequence[int], p5: Sequence[int]) -> Dict[str, object]:
    shifts = sorted({h for _, _, h in active_pairs(limit // 2, p3, p5)})[:18]
    primes = [p for p in primes_upto(97, spf) if p % 4 == 3]
    failures: List[Dict[str, object]] = []
    checks = 0
    for n in range(limit // 2, limit + 1, 7):
        for p in primes:
            divisible = [h for h in shifts if (n - h) % p == 0]
            if not divisible:
                continue
            checks += 1
            # Evaluate F'(n) modulo p without constructing F over the integers.
            fp = 0
            for h in shifts:
                term = 1
                for hp in shifts:
                    if hp != h:
                        term = (term * ((n - hp) % p)) % p
                fp = (fp + term) % p
            expected_zero = len(divisible) >= 2
            if (fp == 0) != expected_zero:
                failures.append({"n": n, "p": p, "divisible_factor_count": len(divisible), "Fprime_mod_p": fp})
    return {
        "name": "private_shared_derivative_dichotomy",
        "shift_count": len(shifts),
        "checks": checks,
        "failure_count": len(failures),
        "first_failures": failures[:10],
        "status": "PASS" if not failures else "FAIL",
    }


def check_shift_collisions(limit: int, p3: Sequence[int], p5: Sequence[int]) -> Dict[str, object]:
    groups: Dict[int, List[Tuple[int, int]]] = defaultdict(list)
    for c, a in enumerate(p3):
        for d, b in enumerate(p5):
            h = a + b
            if h <= limit:
                groups[h].append((c, d))
    collision_classes = {str(h): pairs for h, pairs in sorted(groups.items()) if len(pairs) > 1}
    duplicate_excess = sum(len(v) - 1 for v in groups.values())
    return {
        "name": "finite_equal_shift_inventory",
        "limit": limit,
        "pair_vertices": sum(len(v) for v in groups.values()),
        "distinct_shifts": len(groups),
        "collision_class_count": len(collision_classes),
        "duplicate_excess": duplicate_excess,
        "collision_classes": collision_classes,
        "classification": "COMPUTATIONAL OBSERVATION",
        "status": "PASS",
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", required=True)
    ap.add_argument("--factor-limit", type=int, default=64000)
    ap.add_argument("--criterion-limit", type=int, default=5000)
    ap.add_argument("--identity-limit", type=int, default=5000)
    ap.add_argument("--high-cutoff-x", type=int, default=2000)
    ap.add_argument("--high-cutoff-delta", type=float, default=0.25)
    ns = ap.parse_args()

    needed = max(ns.factor_limit, 2 * ns.high_cutoff_x, ns.identity_limit, ns.criterion_limit)
    spf = spf_sieve(needed)
    p3 = powers(3, needed)
    p5 = powers(5, needed)

    checks = [
        check_two_square_criterion(ns.criterion_limit, spf),
        check_canonical_minimum(ns.criterion_limit, spf),
        check_square_root_identity(ns.identity_limit, spf, p3, p5),
        check_high_cutoff_decomposition(ns.high_cutoff_x, ns.high_cutoff_delta, spf, p3, p5),
        check_rectangle_divisibility(min(ns.identity_limit, 2500), spf, p3, p5),
        check_derivative_dichotomy(min(ns.identity_limit, 2500), spf, p3, p5),
        check_shift_collisions(ns.factor_limit, p3, p5),
    ]
    status = "PASS" if all(c.get("status") == "PASS" for c in checks) else "FAIL"
    payload = {
        "schema": SCHEMA,
        "status": status,
        "classification": "FINITE EXACT SANITY ONLY",
        "parameters": {
            "factor_limit": ns.factor_limit,
            "criterion_limit": ns.criterion_limit,
            "identity_limit": ns.identity_limit,
            "high_cutoff_x": ns.high_cutoff_x,
            "high_cutoff_delta": ns.high_cutoff_delta,
        },
        "checks": checks,
        "limitations": [
            "No asymptotic theorem is inferred from these finite checks.",
            "No absence-of-counterexample claim is inferred.",
            "The checks validate exact identities and implementation conventions only.",
        ],
    }
    out = Path(ns.output)
    dump_json(out, payload)
    digest = hashlib.sha256(out.read_bytes()).hexdigest()
    print(json.dumps({"status": status, "schema": SCHEMA, "sha256": digest}, sort_keys=True))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
