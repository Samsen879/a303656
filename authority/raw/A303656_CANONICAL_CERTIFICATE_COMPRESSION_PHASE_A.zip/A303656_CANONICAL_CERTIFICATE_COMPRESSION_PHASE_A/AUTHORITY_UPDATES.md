# AUTHORITY UPDATES

## Accepted additions

### CC-A: critical canonical-tail record saturation

For complete actual square-root survivors, private canonical reconstruction records \((c,d,q,s)\) have total dyadic count

\[
\Theta(X(\log X)^{3/2}).
\]

**Authority class:** PROVED DERIVED THEOREM.

### CC-B: natural incidence-charging ceiling

A raw record charge using this record space and only \(\Theta((\log X)^{3/2})\) records per target gives at best \(O(X)\).

**Authority class:** PROVED METHOD-LEVEL NO-GO.

### HC-A: aggregate high-cutoff bad-tail theorem

For cutoff \(X^{1-\delta}\), complete fixed-core bad survivors have aggregate count

\[
\ll X(\log X)^{3/2}\sqrt{\delta+1/\log X}.
\]

**Authority class:** PROVED THEOREM.

### HC-B: conditional almost-all implication

The quantified survivor lower-tail hypothesis HC-LT implies \(|E_X|=o(X)\).

**Authority class:** CONDITIONAL THEOREM; hypothesis OPEN.

### Rectangle and derivative lemmas

Repeated labels force power-difference divisibility; private and shared primes are separated by \(F'(n)\).

**Authority class:** PROVED SUPPORTING LEMMAS.

### Li-type common-divisor compression transfer

The 2026 canonical-witness reconstruction mechanism for Erdős Problem 768 was audited in full theorem form. Its common ambient divisor lattice, one-bit valuation completion, and self-indexed reconstruction hypotheses are absent for translated A303656 remainders.

**Authority class:** PRIMARY-SOURCE METHOD BENCHMARK; NO THEOREM TRANSFER.

## Rejected upgrades

The following are not added to authority:

- low entropy of canonical matrices;
- random or independent witness distribution;
- a universal majority-halving theorem;
- residue omission for \(E_X\);
- a low-fiber certificate theorem;
- a structured-subgrid theorem with counting payoff;
- almost-all representability;
- finite reduction;
- universal A303656.

## Frozen authority retained

- direct positive-density theorem: retained, no stronger interpretation;
- almost-all blocker: retained;
- Theorem PW-A: retained;
- square-root survivor identity: retained;
- project status: PAUSED;
- active promoted route: NONE.

## Project status after this phase

```text
PROJECT: PAUSED
ACTIVE PROMOTED ROUTE: NONE
PROMOTION RECOMMENDED: NO
CODEX AUTHORIZED: NO
ULTRA AUTHORIZED: NO
OEIS A303656: UNRESOLVED
```
