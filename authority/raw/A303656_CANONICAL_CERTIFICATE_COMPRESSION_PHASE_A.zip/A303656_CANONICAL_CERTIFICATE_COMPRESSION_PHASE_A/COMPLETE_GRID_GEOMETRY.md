# COMPLETE GRID GEOMETRY

## 1. Size and fixed cores

For \(n\asymp X\),

\[
|\mathcal D(n)|=\Theta((\log X)^2).
\]

The fixed core

\[
\mathcal H_X=\{(c,d):3^c+5^d\le X/2\}
\]

has the same order and is active for every \(n\in[X,2X]\). A convenient complete rectangle is

\[
\mathcal Q_X=
\{(c,d):3^c\le X/4,\ 5^d\le X/4\}\subseteq\mathcal H_X.
\]

It has \(C_XD_X=\Theta((\log X)^2)\) cells with \(C_X,D_X=\Theta(\log X)\).

## 2. Shift collisions

The frozen high-\(c\) collision lemma states that every nontrivial equality

\[
3^c+5^d=3^{c'}+5^{d'}
\]

has a low-\(c\) representative with

\[
\min(c,c')\le1+\lfloor\log_3\log_5(2X)\rfloor.
\]

Consequently the total duplicate excess up to \(2X\) is

\[
O(\log X\log\log X),
\]

which is lower order than the \(\Theta((\log X)^2)\) grid. Collisions must still be handled explicitly because a duplicated shift can turn a quotient-private prime into a pair-shared prime.

## 3. Two-cell congruence

If the same prime \(p\) labels two cells \((c,d)\) and \((c',d')\), then

\[
p\mid h(c,d)-h(c',d').
\]

This is necessary even when the two valuations differ. Exact odd valuation imposes additional prime-power conditions, but divisibility of the shift difference is the first deterministic incidence constraint.

## 4. Monochromatic rectangle lemma

Suppose a prime \(p\) labels all four corners

\[
(c_1,d_1),\ (c_1,d_2),\ (c_2,d_1),\ (c_2,d_2),
\qquad c_1\ne c_2,
\quad d_1\ne d_2.
\]

Then

\[
p\mid 3^{c_1}-3^{c_2},
\qquad
p\mid 5^{d_1}-5^{d_2}.
\]

For \(p\nmid15\),

\[
\operatorname{ord}_p(3)\mid|c_1-c_2|,
\qquad
\operatorname{ord}_p(5)\mid|d_1-d_2|.
\]

This is genuine complete-grid structure, but it concerns shared labels. A private label occupies one cell and creates no rectangle.

## 5. Quantitative rectangle extraction

For one prime \(p\), view its labelled cells in \(\mathcal Q_X\) as edges of a bipartite graph with \(C_X\) row vertices and \(D_X\) column vertices. If there is no monochromatic \(2\times2\) rectangle, the Kővári–Sós–Turán bound gives

\[
|E_p|=O(C_XD_X^{1/2}+D_X)=O((\log X)^{3/2}).
\]

Therefore a coloring of all \(\Theta((\log X)^2)\) cells by rectangle-free prime classes needs at least

\[
\Omega((\log X)^{1/2})
\]

distinct labels. This lower bound is far too weak for exceptional-set counting, and the all-private coloring uses \(\Theta((\log X)^2)\) labels while remaining rectangle-free.

## 6. Why extraction can destroy the grid

A majority or iterative branch that keeps only cells carrying a chosen prime generally leaves an arbitrary subset of \(\mathcal Q_X\), not another exponent rectangle or complete curved domain. Once this happens, the arbitrary-subset CRT barrier again becomes relevant. A valid bounded-depth branching theorem must preserve an explicit structured subgrid at every step or prove a replacement invariant.

## 7. Polynomial viewpoint

On the distinct-shift quotient let

\[
F(T)=\prod_{h\in H}(T-h).
\]

If \(p\) divides exactly one factor \(n-h\), then

\[
F'(n)\not\equiv0\pmod p.
\]

If \(p\) divides at least two distinct factors, then

\[
p\mid F(n)\quad\text{and}\quad p\mid F'(n).
\]

Thus resultants and discriminants naturally detect shared witnesses. They are structurally blind to the private part that Theorem PW-A shows can have positive density in the complete actual survivor system.
