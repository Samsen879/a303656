# COMPUTATIONAL EXPERIMENTS

## 1. Classification and scope

Every result in this file is classified as:

```text
COMPUTATIONAL OBSERVATION
```

The experiment uses exact integer factorization from a deterministic smallest-prime-factor sieve, exact valuation parity, exact canonical smallest bad primes, and the literal active exponent grid. It covers dyadic intervals with

\[
X\in\{4000,8000,16000,32000\},
\qquad n\le64000,
\]

and high cutoffs with \(\delta\in\{0.10,0.15,0.25\}\). It is not a search at production scale and is not evidence that counterexamples do not exist.

The complete outputs are in:

- `results/experiment_summary.json`;
- `results/dyadic_metrics.csv`;
- `results/sample_matrix_metrics.csv`;
- `results/parameters.json`;
- `results/experiment_output_hashes.json`.

## 2. Square-root survivor and private-record scale

For each dyadic interval the script counted all square-root survivors, all bad square-root survivors, and private canonical labels on both the pair graph and the distinct-shift quotient.

| \(X\) | core pairs | no-representation integers observed | bad records / \(XL^{3/2}\) | private pair records / \(XL^{3/2}\) |
|---:|---:|---:|---:|---:|
| 4,000 | 35 | 0 | 0.44095 | 0.41027 |
| 8,000 | 47 | 0 | 0.42303 | 0.39960 |
| 16,000 | 53 | 0 | 0.45054 | 0.42930 |
| 32,000 | 60 | 0 | 0.41980 | 0.40404 |

The stable-looking normalization is compatible with Theorem CC-A, but the finite table is not used to prove that theorem. The absence of a sampled counterexample is not used anywhere.

## 3. Canonical label entropy and rectangles

A deterministic grid sample was taken roughly every \(X/128\) integers. The empirical Shannon entropy of the bad-prime labels rose from about 3.28 to 3.62 bits across the tested range. The fraction of sampled matrices containing at least one monochromatic rectangle rose from about 0.54 to 0.70.

These observations do not establish low entropy, concentration, or a rectangle theorem. They also do not show that rectangles have a counting payoff. Private colors can occupy singleton cells, and a shared-color rectangle only yields the divisibility constraints proved in `COMPLETE_GRID_GEOMETRY.md`.

## 4. Record collisions on restricted prefixes

For the first \(k\in\{4,8,12\}\) core cells, the experiment restricted to integers for which every selected cell was bad. It compared:

1. the full ordered canonical label record \(((p_*,e_*))_{1\le j\le k}\);
2. a coarse profile recording only the number of distinct labels, maximum multiplicity, count of labels at most 31, and count above \(\sqrt n\).

At \(X=32000\):

| prefix cells | all-bad integers | full records | maximum full fiber | coarse records | maximum coarse fiber |
|---:|---:|---:|---:|---:|---:|
| 4 | 13,062 | 12,086 | 37 | 20 | 1,878 |
| 8 | 5,864 | 5,863 | 2 | 139 | 269 |
| 12 | 762 | 762 | 1 | 222 | 27 |

This illustrates the central tradeoff rather than solving it: full labels can have tiny fibers but nearly one record per integer, while coarse summaries are cheap but have large fibers. No extrapolation to the full \(\Theta((\log X)^2)\)-cell matrix is justified.

## 5. High-cutoff observations

For \(X=32000\), the exact fixed-core high-cutoff data were:

| \(\delta\) | \(z=\lfloor X^{1-\delta}\rfloor\) | mean survivors | minimum survivors | fraction below half the mean | bad incidences / \(\sqrt\delta XL^{3/2}\) |
|---:|---:|---:|---:|---:|---:|
| 0.10 | 11,340 | 18.9878 | 4 | 0.01253 | 0.45007 |
| 0.15 | 6,751 | 19.9955 | 4 | 0.00544 | 0.44536 |
| 0.25 | 2,392 | 21.9529 | 7 | 0.00250 | 0.46215 |

The last column is numerically compatible with the \(\sqrt\delta\) upper-bound scale in HC-A. The observed lower tail motivates HC-LT but is not evidence for its uniform asymptotic form.

## 6. Equal numerical shifts

Up to shift height 64,000 the only collision class found was

\[
3^1+5^2=3^3+5^0=28.
\]

Thus the finite duplicate excess was one. This is merely a finite inventory; the asymptotic collision control comes from the frozen high-\(c\) theorem, not from this table.

## 7. Exact theorem sanity checks

`results/theorem_sanity_checks.json` records the following finite checks:

- Fermat's two-square criterion matched direct enumeration for every \(0\le m\le5000\);
- canonical minimum/tie-breaking was checked on 3,557 non-two-square integers;
- 42,555 square-root bad-survivor cells reconstructed exactly as \(n=h+qs\);
- 10,027 high-cutoff bad-survivor cells passed the unique-tail decomposition;
- 8,729 monochromatic rectangles passed both power-difference divisibility tests;
- 1,186 private/shared derivative cases passed;
- the finite shift-collision inventory matched the class at 28.

These checks validate implementation conventions and exact identities only.

## 8. Reproducibility

Run:

```bash
python3 scripts/run_experiments.py --output-dir /tmp/a303656-experiments
python3 scripts/theorem_sanity_checks.py --output /tmp/a303656-sanity.json
```

The package validator reruns both commands and requires byte identity with the delivered outputs.
