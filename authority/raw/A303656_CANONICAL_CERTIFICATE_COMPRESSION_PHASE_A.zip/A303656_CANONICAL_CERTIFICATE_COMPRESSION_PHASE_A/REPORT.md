# A303656 CANONICAL BAD-PRIME CERTIFICATE COMPRESSION — PHASE A REPORT

## 1. Mandate and final decision

This phase investigated whether a hypothetical counterexample

\[
n\in E_X=\{n\in[X,2X]:T(n)=0\}
\]

can be counted by assigning a deterministic canonical bad-prime certificate to every active exponent pair and compressing the resulting complete label grid.

The final decision is:

```text
NO PROMOTABLE ROUTE — RETAIN AS SPECULATIVE WATCH
```

The decision is not based on a failed numerical search. It follows from a quantitative information-budget audit. The natural private canonical record family is proved to sit exactly at the critical \(X(\log X)^{3/2}\) scale, so raw reconstruction charging yields no density saving. A different high-cutoff decomposition gives a real \(\sqrt\delta\) aggregate saving, but the matching complete-survivor lower-tail theorem is open.

## 2. Canonical witness system

For a positive integer \(m\notin\mathcal S_2\), define

\[
p_*(m)=\min\{p\equiv3\pmod4:v_p(m)\text{ is odd}\},
\qquad e_*(m)=v_{p_*(m)}(m).
\]

For an active pair \((c,d)\), the complete pair-labelled grid records

\[
(c,d)\mapsto\bigl(p_*(n-3^c-5^d),e_*(n-3^c-5^d)\bigr).
\]

If the remainder lies in \(\mathcal S_2\), including zero, the label is `GOOD`. In a counterexample no active remainder is zero, because zero is a sum of two squares.

The smallest-prime convention is deterministic but not free. It records both an odd valuation at \(p\) and even valuations at every smaller bad prime. Merely recording \(p\mid n-h\) loses the parity condition. Exact valuation one occupies \(p-1\) classes modulo \(p^2\), so it has density comparable to \(1/p\), not \(1/p^2\).

Equal numerical shifts are handled twice: the pair-labelled grid preserves exponent-pair multiplicity, while the quotient merges equal values of \(3^c+5^d\). The main record theorem is stated on the complete unmerged graph and then transferred to the quotient using the globally unique-shift core from the frozen private-witness theorem.

## 3. Strongest proved theorem: critical record saturation

At cutoff \(z_n=\lfloor\sqrt n\rfloor\), every positive bad survivor remainder has a unique factorization

\[
n-3^c-5^d=qs,
\]

where

\[
q>\sqrt n,
\quad q\equiv3\pmod4,
\quad v_q=1,
\quad s\in\mathcal S_2.
\]

The prime \(q\) is automatically the canonical smallest bad prime. For a private survivor vertex, the quadruple \((c,d,q,s)\) reconstructs \(n\) exactly.

Define \(\mathscr C_X^{\mathrm{pvt}}\) to be all such private complete-grid records with reconstructed \(n\in[X,2X]\). Theorem CC-A proves

\[
|\mathscr C_X^{\mathrm{pvt}}|
=\Theta\!\left(X(\log X)^{3/2}\right).
\]

The lower bound is the aggregate private-incidence lower bound already contained in the proof of frozen Theorem PW-A. The upper bound is the aggregate complete-survivor bound from the same proof. The record/vertex correspondence is bijective because the square-root factorization is unique.

This theorem is a genuine compression result in the negative direction: it determines the exact global size of the most natural private reconstruction space. It also gives the method-level ceiling

\[
|A_X|D_X\le C X(\log X)^{3/2}
\]

whenever each \(n\in A_X\) is charged to \(D_X\) distinct records of this type. At the natural degree \(D_X\asymp(\log X)^{3/2}\), the conclusion is only \(|A_X|=O(X)\). To reach \(o(X)\), one must prove either

\[
D_X=\omega((\log X)^{3/2})
\]

or that every target's assigned records lie in a strictly smaller global family. Neither statement is known.

This is not a universal impossibility theorem for every compression scheme. It precisely closes the raw one-record/private-tail charging mechanism requested in the prompt.

## 4. High-cutoff mechanism and the only closed candidate chain

The critical obstruction changes if the cutoff is raised to

\[
z=X^{1-\delta},
\qquad 0<\delta<1/2,
\]

and one works on the fixed complete core

\[
\mathcal H_X=\{(c,d):3^c+5^d\le X/2\}.
\]

For \(n\in[X,2X]\), every bad survivor beyond this cutoff again has a unique exact-valuation-one bad prime \(q>z\), but now its cofactor satisfies

\[
s\le 2X^\delta.
\]

Summing over two-square cofactors and using a fixed-progression prime upper bound gives, for each fixed shift,

\[
\ll \frac{X}{\sqrt{\log X}}
\sqrt{\delta+\frac1{\log X}}
\]

bad survivor values. Multiplying by \(|\mathcal H_X|\ll(\log X)^2\) proves HC-A:

\[
\sum_{X\le n\le2X}B_{X,\delta}(n)
\ll
X(\log X)^{3/2}
\sqrt{\delta+\frac1{\log X}}.
\]

This is an actual density-loss theorem on a complete exponent core. It does not discard private witnesses; it counts every bad high-cutoff survivor through its exact \(qs\) reconstruction.

Let \(U_{X,\delta}(n)\) be the total number of fixed-core survivors, good or bad. If \(n\in E_X\), all of them are bad, hence

\[
U_{X,\delta}(n)=B_{X,\delta}(n).
\]

The missing lower-tail theorem HC-LT is:

\[
\#\left\{n\in[X,2X]:
U_{X,\delta}(n)<\kappa(\log X)^{3/2}
\right\}
\le \rho(\delta)X+o_\delta(X),
\]

with \(\kappa>0\) and \(\rho(\delta)\to0\). If HC-LT held, Markov division against HC-A would give

\[
\frac{|E_X|}{X}
\ll
\rho(\delta)+\sqrt\delta+o_\delta(1),
\]

and then \(|E_X|=o(X)\).

This implication is complete and quantitative. HC-LT itself is not proved. It is the strongest candidate theorem and the exact core missing lemma.

## 5. Compression and reconstruction audit

### 5.1 Full canonical matrix

A complete matrix has \(K=\Theta((\log X)^2)\) cells. Storing every prime/valuation label is not compression. Counting the matrices actually realized by integers in \([X,2X]\) gives at most \(X+1\) records and therefore only the trivial bound. Counting all abstract matrices is exponentially worse.

A generic container estimate of the form \(\exp(o(K))\) is not enough, because

\[
\exp(o((\log X)^2))
\]

may still be much larger than \(X=\exp(\log X)\). Any record theorem must report its bit budget against \(\log X\), not merely against the number of grid cells.

### 5.2 Selected canonical congruences

A self-selected prime \(p\) simultaneously costs roughly \(\log p\) bits to name and saves roughly \(\log p\) bits through the congruence \(n\equiv h\pmod p\). Prime density can contribute a residual \(\log\log p\)-scale saving for one fixed shift, but there are \(\Theta((\log X)^2)\) candidate shifts. Without a theorem forcing a much smaller canonical subfamily or substantial prime reuse, the union cost dominates.

### 5.3 Quotients and squarefree kernels

At square-root cutoff, the cofactor \(s\in\mathcal S_2\) is already the most economical quotient description available. Recording a squarefree kernel or a radical does not remove the need to identify the shift and the large prime. The product of private primes gives only

\[
\prod q_i>n^{P/2},
\]

whereas the associated remainder product may be as large as \(n^P\). Thus product size alone leaves an exponential gap rather than a contradiction.

### 5.4 Polynomial/resultant encoding

For distinct shifts \(H\), let

\[
F(T)=\prod_{h\in H}(T-h).
\]

A private prime dividing exactly one factor of \(F(n)\) does not divide \(F'(n)\); a shared prime does. Hence gcd, discriminant, and resultant methods detect shared fibers, precisely the component already controlled by shift-difference incidence. They do not compress the positive private mass certified by PW-A.

## 6. Majority-halving and complete-grid preservation

A deterministic majority-halving scheme would need a prime or congruence covering a fixed fraction of the remaining cells at every step. No such majority label is guaranteed. Theorem PW-A requires any valid method to tolerate positive private mass, and a private label produces a singleton branch.

More seriously, conditioning on selected labels generally leaves an arbitrary subset of the exponent grid rather than a complete rectangle or complete active domain. Once completeness is lost, the arbitrary-subset CRT construction can assign fresh exact-one private witnesses to the surviving cells. Therefore a viable branching theorem must preserve a large complete subgrid at each node and must count all prime/residue branch choices. No such theorem was proved.

## 7. Complete-grid geometry

If the same prime labels two cells, it divides their shift difference. If it labels all four corners of a rectangle, then

\[
p\mid 3^{c_1}-3^{c_2},
\qquad
p\mid 5^{d_1}-5^{d_2}.
\]

When \(p\nmid15\), the multiplicative orders of 3 and 5 modulo \(p\) divide the corresponding row and column gaps. This is exact arithmetic structure.

However, quantitative rectangle extraction is too weak for the desired endpoint. A rectangle-free color class in an \(R\times C\) grid can still have \(O(R\sqrt C+C)\) cells by the Kővári–Sós–Turán bound. With \(R,C\asymp\log X\), a complete coloring needs only \(\Omega(\sqrt{\log X})\) colors. That does not control prime sizes, record costs, or \(E_X\), and private singleton colors avoid the mechanism entirely.

Qualitative Ramsey, dependent-random-choice, Balog–Szemerédi–Gowers, VC-dimension, or low-rank language therefore has no promotion value without an additional theorem turning the extracted structure into a record count below \(X\).

## 8. Sieve and literature hypothesis audit

The closest positive benchmark is Li's July 2026 arXiv preprint resolving Erdős Problem 768 by canonical witness divisors, deterministic homogeneous subsequences, a squarefree deleted divisor, injective reconstruction, and growing divisor moments. The transfer audit identifies three indispensable hypotheses: every witness divisor lies in one common ambient divisor lattice, the row label is itself a prime factor of that ambient integer, and the self-indexed congruence \(D_p\equiv1\pmod p\) recovers deleted row primes. A303656 labels divide different translates \(n-h\); no common squarefree quotient or one-bit completion reconstructs all cells. The product \(\prod_h(n-h)\) is much too large and still lacks the self-indexed relation. Thus this new paper sharpens, rather than removes, the missing lemma.

The audited inverse-sieve and larger-sieve theorems begin with a fixed set that occupies few residue classes modulo many primes. A certificate condition in which the cell and the certifying prime both vary with \(n\) does not imply any fixed omission for \(E_X\bmod p\).

The recent combinatorial large sieve combines local ill-distribution with a global bound on representation or norm-difference multiplicity. Neither input is known for the exceptional integers or their certificate incidence map. Applying the theorem to the already-polylogarithmic shift set does not count \(n\).

The recent square-condition sieve explicitly requires more than a modulo-\(p^2\) class count: it also uses the distribution of the set under projection modulo \(p\). A303656 supplies no fixed modulo-\(p^2\) avoidance pattern for \(E_X\), and odd valuation is a union of \(p\)-adic shells rather than a single square condition.

Hypergraph containers require a fixed hypergraph with degree, codegree, and supersaturation control. Here the prime labels and admissibility relation vary with \(n\), private edges have degree one, and no container budget below the \(X\) information scale is available.

Primitive-divisor and gcd-of-recurrence theorems concern fixed recurrence sequences or shared power differences. They can constrain some repeated-label rectangles but do not control adversarial private labels of \(n-3^c-5^d\).

Finally, existing higher-uniformity results treat the representation weight \(r_2\) more readily than the support indicator \(1_{\mathcal S_2}\). The literature itself identifies construction of a sufficiently accurate indicator approximant as nontrivial. HC-LT therefore does not follow from the frozen weighted positive-density theorem.

The literature conclusion is negative but precise: no audited primary theorem supplies the common ambient divisor lattice, fixed local deficit, bounded multiplicity, projection control, or indicator lower-tail estimate needed here.

## 9. Computational observations

Exact experiments were run only through \(n=64000\). They measured canonical matrices, private/shared multiplicities, restricted-record fibers, monochromatic rectangles, and high-cutoff survivor tails. The output is reproducible and is described in `COMPUTATIONAL_EXPERIMENTS.md`.

The finite data illustrate two opposing facts:

1. full ordered label records quickly approach injectivity on small selected prefixes;
2. coarse profiles have much smaller record count but much larger fibers.

This is exactly the record/fiber tradeoff in the theorem statement. It does not prove asymptotic low entropy or a low-fiber certificate theorem. The observed high-cutoff lower tails are compatible with HC-LT but provide no uniform proof.

## 10. Candidate classification

### Candidate A: quantitative exceptional-set theorem

Not obtained. HC-LT would imply \(|E_X|=o(X)\), but HC-LT is open.

### Candidate B: low-fiber certificate theorem

Not obtained. The natural private record family is critically saturated, and no cheaper all-target record was proved.

### Candidate C: complete-grid structure theorem

Only supporting structure was proved: rectangle divisibility and the private/shared derivative dichotomy. Neither yields a counting payoff.

### Candidate D: finite reduction

Not obtained. No explicit \(N_*\) or descent map was produced.

### Candidate E: broad no-go theorem

A meaningful method-level no-go was proved: raw complete-grid private square-root reconstruction charging cannot beat \(O(X)\) at the natural degree scale. This is accepted as a negative structural theorem but does not justify promotion.

## 11. Promotion-gate review

The phase supplies exact statements and proofs, genuinely uses the complete actual exponent grid, respects the arbitrary-subset CRT barrier, and closes the information budget for the mechanisms it rejects. It nevertheless fails the decisive gate: no quantitative bound on \(E_X\), no finite reduction, and no low-fiber certificate theorem is proved.

A future theorem-only phase would be justified only after an external result or new argument establishes one of the following:

1. a nonnegative minorant for the high-cutoff survivor indicator with the correct mean and variance \(o(X(\log X)^3)\);
2. a uniform signed pair-correlation asymptotic for the truncated survivor indicator over all grid differences;
3. a direct lower-tail sieve with \(\rho(\delta)\to0\);
4. a grid-preserving branch theorem whose complete leaf count times maximum fiber is \(o(X)\);
5. a Li-type common-container quotient theorem with ambient bit budget \(O(\log X)\), injective reconstruction, and summable divisor moments.

Until then, further label-entropy experiments or larger enumeration do not cross a mathematical gate.

## 12. Final status

```text
FINAL VERDICT:
NO PROMOTABLE ROUTE — RETAIN AS SPECULATIVE WATCH

PROMOTION RECOMMENDED: NO
CODEX RECOMMENDED: NO
ULTRA RECOMMENDED: NO

OEIS A303656:
UNRESOLVED
```
