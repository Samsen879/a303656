# PROVED LEMMAS

All logarithms are natural. Theorems marked **DERIVED FROM FROZEN AUTHORITY** use the accepted square-root survivor theorem and Theorem PW-A; their deductions are complete here.

## Lemma 1 — canonical well-posedness

For every active pair with positive non-two-square remainder, \(p_*(n;c,d)\) and \(e_*(n;c,d)\) are uniquely defined. In a counterexample \(n\in E_X\), every active pair has such a label.

### Proof

Fermat's criterion makes \(\mathcal B(n-h)\) a nonempty finite set, so its minimum exists and has a unique valuation. If \(h=n\), the remainder is zero and belongs to \(\mathcal S_2\), contradicting \(T(n)=0\). ∎

## Lemma 2 — exact square-root canonical tail

Let \(m=n-h\) satisfy \(0<m\le n\), and suppose every prime \(p\le\lfloor\sqrt n\rfloor\), \(p\equiv3\pmod4\), has even valuation in \(m\). If \(m\notin\mathcal S_2\), then

\[
m=qs,
\qquad q\equiv3\pmod4,
\qquad q>\sqrt n,
\qquad v_q(m)=1,
\qquad s\in\mathcal S_2.
\]

The prime \(q\) is unique and equals \(p_*(m)\).

### Proof

Every odd-valuation bad prime exceeds \(\sqrt n\). Two distinct such primes would have product greater than \(n\), and the square of one would also exceed \(n\). Hence exactly one exists and has valuation one. Dividing it out leaves even valuation at every bad prime. ∎

## Theorem CC-A — critical canonical-tail record saturation

**Status: PROVED; DERIVED FROM FROZEN AUTHORITY.**

Let \(\mathscr C_X^{\mathrm{pvt}}\) be the set of quadruples

\[
(c,d,q,s)
\]

such that, with

\[
n=3^c+5^d+qs,
\]

all of the following hold:

1. \(X\le n\le2X\);
2. \((c,d)\) belongs to the complete survivor set \(S(n,\lfloor\sqrt n\rfloor)\);
3. \(q\equiv3\pmod4\) is prime, \(q>\sqrt n\), and \(s\in\mathcal S_2\);
4. \(q\) has degree one against the **complete unmerged survivor graph** at \(n\).

Then there are absolute constants \(0<a<A<\infty\) such that, for all sufficiently large \(X\),

\[
aX(\log X)^{3/2}
\le
|\mathscr C_X^{\mathrm{pvt}}|
\le
AX(\log X)^{3/2}.
\tag{CC-A}
\]

The same order holds after passing to the distinct-shift quotient.

### Proof

By Lemma 2, every private bad survivor vertex at square-root cutoff has a unique factorization \(n-h=qs\), with \(q\) the canonical witness. Conversely each quadruple in \(\mathscr C_X^{\mathrm{pvt}}\) gives exactly one such private vertex. Hence

\[
|\mathscr C_X^{\mathrm{pvt}}|
=
\sum_{X\le n\le2X}
P_{\mathrm{pair}}(n,\lfloor\sqrt n\rfloor).
\]

The aggregate lower bound in the proof of Theorem PW-A is

\[
\sum_{X\le n\le2X}P_{\mathrm{pair}}(n,\lfloor\sqrt n\rfloor)
\gg X(\log X)^{3/2}.
\]

The complete survivor denominator estimate from the same theorem is

\[
\sum_{X\le n\le2X}|S(n,\lfloor\sqrt n\rfloor)|
\ll X(\log X)^{3/2}.
\]

Since the private count is at most the survivor count, (CC-A) follows. The lower-bound construction uses globally unique numerical shifts, so the same records remain private after quotienting; the quotient upper bound is immediate. ∎

## Corollary CC-B — ceiling for one-record incidence charging

Let \(A_X\subseteq[X,2X]\) be a family for which every \(n\in A_X\) is assigned at least \(D_X\) distinct records from \(\mathscr C_X^{\mathrm{pvt}}\), and suppose each record reconstructs its \(n\) by

\[
n=3^c+5^d+qs.
\]

Then

\[
|A_X|D_X\le A X(\log X)^{3/2}.
\]

Thus a lower bound \(D_X\asymp(\log X)^{3/2}\) yields only \(|A_X|=O(X)\). This framework gives \(o(X)\) only if

\[
D_X=\omega((\log X)^{3/2})
\]

or if a strictly smaller record family is proved to contain all assigned records.

This is a no-go for the specified raw charging framework, not for every conceivable compression theorem.

## Theorem HC-A — aggregate high-cutoff bad-tail bound

**Status: PROVED.**

Fix \(0<\delta\le\delta_0<1/2\), put

\[
z=X^{1-\delta},
\qquad
\mathcal H_X=\{(c,d):3^c+5^d\le X/2\},
\]

and define

\[
B_{X,\delta}(n)=
\#\left\{(c,d)\in\mathcal H_X:
\begin{array}{l}
 n-h(c,d)\notin\mathcal S_2,\\
 v_p(n-h(c,d))\text{ is even for all }p\le z,\ p\equiv3\pmod4
\end{array}
\right\}.
\]

For all sufficiently large \(X\), uniformly in \(0<\delta\le\delta_0\),

\[
\sum_{X\le n\le2X}B_{X,\delta}(n)
\ll
X(\log X)^{3/2}
\sqrt{\delta+\frac1{\log X}}.
\tag{HC-A}
\]

### Proof

Because \(1-\delta_0>1/2\), for all sufficiently large \(X\) one has

\[
z=X^{1-\delta}>\sqrt{2X}.
\]

Every counted bad remainder \(m=n-h\le2X\) therefore has a unique odd-valuation bad prime \(q>z\), with valuation one, and

\[
m=qs,
\qquad s\in\mathcal S_2,
\qquad 1\le s\le\frac{2X}{z}=2X^\delta.
\]

Indeed, two odd-valuation bad primes greater than \(z\), or the square of one, would exceed \(2X\).

Fix one shift \(h\). For a fixed admissible \(s\), every possible prime lies in

\[
q\equiv3\pmod4,
\qquad
\frac{X-h}{s}\le q\le\frac{2X-h}{s},
\]

so it is enough to bound \(\pi(2X/s;4,3)\). Since \(s\le2X^\delta\) and \(\delta\le\delta_0\),

\[
\frac{2X}{s}\ge X^{1-\delta_0}.
\]

The Brun–Titchmarsh inequality for the fixed modulus \(4\) (or the standard Chebyshev upper bound in that progression) therefore gives, uniformly in \(s\) and \(\delta\),

\[
\pi(2X/s;4,3)
\ll_{\delta_0}
\frac{X}{s\log X}.
\]

Let \(A(Y)=|\mathcal S_2\cap[1,Y]|\). The Landau–Ramanujan upper bound

\[
A(Y)\ll\frac{Y}{\sqrt{\log(2Y)}}
\]

and partial summation yield

\[
\sum_{\substack{s\le Y\\s\in\mathcal S_2}}\frac1s
=
\frac{A(Y)}Y+
\int_{1^-}^{Y}\frac{A(t)}{t^2}\,dt
\ll\sqrt{\log(2Y)}.
\]

With \(Y=2X^\delta\), the number of bad survivor values for this fixed \(h\) is

\[
\ll
\frac{X}{\log X}\sqrt{\delta\log X+1}
=
\frac{X}{\sqrt{\log X}}
\sqrt{\delta+\frac1{\log X}}.
\]

Finally \(|\mathcal H_X|\ll(\log X)^2\), giving (HC-A). ∎

## Corollary HC-B — an exact sufficient lower-tail theorem for almost all

Define the full high-cutoff survivor count

\[
U_{X,\delta}(n)=
\#\left\{(c,d)\in\mathcal H_X:
 v_p(n-h(c,d))\text{ is even for every }p\le X^{1-\delta},\ p\equiv3\pmod4
\right\}.
\]

Suppose there are a constant \(\kappa>0\) and a function \(\rho(\delta)\to0\) as \(\delta\downarrow0\) such that

\[
\#\{n\in[X,2X]:U_{X,\delta}(n)<\kappa(\log X)^{3/2}\}
\le
\rho(\delta)X+o_\delta(X).
\tag{HC-LT}
\]

Then

\[
|E_X|=o(X).
\]

### Proof

For \(n\in E_X\), every survivor in the fixed active core is bad, so

\[
U_{X,\delta}(n)=B_{X,\delta}(n).
\]

Outside the lower-tail exceptional set, each \(n\in E_X\) contributes at least \(\kappa L^{3/2}\) to the left side of (HC-A). Hence

\[
\kappa L^{3/2}
\bigl(|E_X|-\rho(\delta)X-o_\delta(X)\bigr)
\ll
XL^{3/2}\sqrt{\delta+1/L}.
\]

Taking \(X\to\infty\) and then \(\delta\downarrow0\) proves \(|E_X|/X\to0\). ∎

The hypothesis (HC-LT) is not proved in this package.

## Lemma 5 — monochromatic rectangle divisibility

If one prime \(p\) labels all four corners of a nondegenerate exponent rectangle, then

\[
p\mid3^{c_1}-3^{c_2},
\qquad
p\mid5^{d_1}-5^{d_2}.
\]

### Proof

Subtract the congruences \(n-h(c_i,d_j)\equiv0\pmod p\) along a fixed row and a fixed column. ∎

## Lemma 6 — private/shared derivative dichotomy

Let \(H\) be a set of distinct numerical shifts and

\[
F(T)=\prod_{h\in H}(T-h).
\]

If a prime \(p\) divides \(n-h_0\) for exactly one \(h_0\in H\), then \(p\nmid F'(n)\). If it divides two or more distinct factors, then \(p\mid F'(n)\).

### Proof

Modulo \(p\),

\[
F'(n)=\sum_{h\in H}\prod_{h'\ne h}(n-h').
\]

With exactly one vanishing factor, only the term indexed by that factor survives and is nonzero. With at least two vanishing factors, every summand contains a vanishing factor. ∎

## Lemma 7 — record/fiber information budget

For any deterministic record map \(\mathcal R:E_X\to\mathfrak R_X\),

\[
|E_X|
\le
|\mathfrak R_X|\,
\max_{R\in\mathfrak R_X}|\mathcal R^{-1}(R)|.
\]

Writing \(N_X=|\mathfrak R_X|\) and \(F_X=\max_R|\mathcal R^{-1}(R)|\), a necessary and sufficient numerical condition for this inequality itself to yield \(o(X)\) is

\[
\log N_X+\log F_X
\le
\log X-\omega(1).
\]

Since the grid has \(\Theta((\log X)^2)\) cells, a container count of the form \(\exp(o((\log X)^2))\) is not by itself useful: it can still be much larger than \(X\).
