# LIMITATIONS

1. No bound \(|E_X|=o(X)\), \(X/(\log X)^A\), or \(X^{1-\eta}\) is proved.
2. Theorem CC-A is a method-level saturation theorem, not a universal impossibility theorem for all compression schemes.
3. HC-LT is unproved and may require essentially the same indicator-correlation strength as the frozen almost-all blocker.
4. The computational experiments stop at \(2X=64000\), use deterministic samples for matrix statistics, and are not evidence of asymptotic entropy concentration.
5. The absence of observed full counterexamples in the finite experiment is not used mathematically.
6. Monochromatic rectangle counts are descriptive; no uniform rectangle theorem for counterexample matrices is proved.
7. Literature theorems are audited by hypotheses, but no claim of exhaustive coverage of all unpublished work is made. The July 2026 canonical-compression source is an arXiv preprint; this package audits its stated proof architecture and does not independently formal-verify the paper.
8. The package does not alter or repair prior input archives. It records their validation state and excludes their control-character defects from the new output.
9. No Codex CLI, Codex Ultra, repository integration, or large-scale enumeration was used.
10. The positive-density theorem remains frozen; this phase neither reproves nor strengthens it.
11. Equal-shift multiplicity is lower order but not ignored; pair and quotient statements are separated.
12. All asymptotic constants in proved lemmas are ineffective only to the extent inherited from standard prime and Landau–Ramanujan bounds; no explicit finite threshold is claimed.

# OEIS A303656: UNRESOLVED
