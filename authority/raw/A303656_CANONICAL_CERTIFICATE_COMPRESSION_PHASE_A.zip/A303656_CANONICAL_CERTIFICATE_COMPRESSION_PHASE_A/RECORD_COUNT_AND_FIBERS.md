# RECORD COUNT AND FIBERS

## 1. Budget table

| Record | Number of formal coordinates | Reconstruction fiber | Proven total count | Counting payoff |
|---|---:|---:|---:|---|
| Full canonical matrix | \(\Theta((\log X)^2)\) | unknown, often small | realized count \(\le X\) only | tautological |
| One cell and one prime | one cell, \(p,e\) | progression-sized | union over cells uncontrolled | none |
| CRT product of selected labels | branch-dependent | can be one | record choices not controlled | none |
| Square-root \((c,d,q,s)\) | four integers | exactly one | \(\Theta(X(\log X)^{3/2})\) for private complete-grid records | at best \(O(X)\) after natural incidence division |
| Prime-size histogram | bounded-dimensional | very large | small in experiments only | no theorem |
| Structured rectangle data | row gaps, column gaps, prime | large | shared labels only | no control of private cells |
| Common-container quotient (Li-type transfer) | quotient plus branch bits | unknown | no admissible A303656 container | none without new reconstruction/divisor-moment theorem |
| High-cutoff survivor count | one integer per \(n\) | not a reconstruction record | aggregate bad tail \(\ll\sqrt\delta XL^{3/2}\) | almost-all if HC-LT holds |

## 2. Exact critical count

Theorem CC-A gives

\[
|\mathscr C_X^{\mathrm{pvt}}|
\asymp X(\log X)^{3/2}.
\]

Every record has fiber one because \(n=h+qs\). Therefore low fiber is not the missing component. The missing component is a record count below the aggregate incidence budget or a lower bound on the number of records per target that is supercritical.

## 3. Why prime profiles do not reconstruct

A profile such as

\[
(\#\{p_*\le y_1\},\ldots,\#\{p_*>y_k\},\#\text{private},\#\text{shared})
\]

has only polynomially many values, but many different \(n\) have the same profile. No deterministic theorem bounds these fibers below \(X^{1-o(1)}\). The finite experiments show exactly this tradeoff: full labels have small fibers, while coarse profiles have much larger fibers.

## 4. Valuation costs

For a fixed prime \(p\), exact valuation \(e\) restricts \(n\) to a proportion \((1-1/p)/p^e\) of residues modulo \(p^{e+1}\). Higher odd valuations can give extra saving, but

\[
\sum_h e_h\log p_h
\le
\sum_h\log(n-h)
\ll |\mathcal D(n)|\log X,
\]

which is too large to force a contradiction. The dominant square-root private regime has \(e=1\) exactly.

## 5. Product lower and upper bounds

If \(P\) private primes exceed \(\sqrt n\), then

\[
\prod_{j=1}^Pq_j>n^{P/2}.
\]

The corresponding remainders satisfy only

\[
\prod_{j=1}^P(n-h_j)\le n^P.
\]

There is no contradiction. The interval between exponents \(P/2\) and \(P\) is precisely large enough to accommodate the private-prime product.

## 6. Container-scale warning

Let \(K\asymp(\log X)^2\). A theorem producing

\[
\exp(o(K))
\]

containers can still produce \(\exp((\log X)^{3/2})\) records, which is superpolynomial in \(X\). A useful container theorem must give an explicit exponent below \(\log X\) after adding the fiber cost; the usual qualitative `subexponential in K` statement is insufficient.

## 7. Current fiber verdict

No low-fiber certificate theorem satisfying

\[
\#\text{records}\times\max\text{fiber}=o(X)
\]

was proved. The cleanest fiber-one record is critically overabundant.
