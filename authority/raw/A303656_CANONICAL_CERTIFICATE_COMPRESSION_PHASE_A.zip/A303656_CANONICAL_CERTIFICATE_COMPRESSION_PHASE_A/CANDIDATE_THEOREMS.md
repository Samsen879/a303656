# CANDIDATE THEOREMS

## Candidate 1 — HC-LT high-cutoff survivor lower tail

There exist \(\kappa>0\), \(\delta_0>0\), and a function \(\rho:(0,\delta_0]\to[0,1]\) with \(\rho(\delta)\to0\) such that

\[
\#\left\{n\in[X,2X]:
U_{X,\delta}(n)<\kappa(\log X)^{3/2}
\right\}
\le
\rho(\delta)X+o_\delta(X),
\]

where

\[
U_{X,\delta}(n)=
\#\left\{(c,d)\in\mathcal H_X:
 v_p(n-3^c-5^d)\text{ is even for all }p\le X^{1-\delta},\ p\equiv3\pmod4
\right\}.
\]

### Exact payoff

Combined with Theorem HC-A, this proves

\[
|E_X|=o(X).
\]

### Why it is not promoted

No proof of the lower tail is available. It requires concentration or a strong minorant for a truncated parity-sieve indicator over the complete two-dimensional shift family. Current indicator correlation bounds do not supply the necessary signed variance saving.

### Phase-B gate

A future theorem-only phase should be authorized only if it first proves one of:

1. a nonnegative minorant \(\nu_{X,\delta}\le1_{\mathrm{survivor}}\) with the correct mean and variance \(o(XL^3)\);
2. a uniform pair-correlation asymptotic for the truncated survivor indicator over all shift differences;
3. a direct lower-tail sieve with error \(\rho(\delta)\to0\).

Finite entropy experiments are not a gate.

## Candidate 2 — bounded-depth grid-preserving canonical branching

Construct a deterministic branching rule with depth \(O(\log X)\) or smaller such that:

- each node retains a complete exponent rectangle of controlled relative size;
- each recorded branch has a rigorously counted family of prime/residue choices;
- every counterexample follows at least one branch;
- the total number of leaves times the largest leaf fiber is \(o(X)\).

### Missing lemma

No theorem guarantees either a dense repeated canonical label or a large structured residual rectangle. Theorem PW-A shows that positive private mass must be tolerated.

### Status

SPECULATIVE; no bounded Phase B.

## Candidate 3 — residue omission for \(E_X\)

Prove that for a positive-density set of primes \(p\), the exceptional set occupies at most \((1-\eta)p\) residue classes modulo \(p\), or an analogous strong restriction modulo \(p^2\) with controlled projection modulo \(p\).

### Payoff

Gallagher's larger sieve, inverse sieve, or a square-condition sieve could then give a nontrivial upper bound for \(|E_X|\).

### Missing lemma

The canonical certificate condition is existential in both the cell and the prime and currently implies no fixed residue omission for \(E_X\). This candidate is therefore only a reformulation of the missing local-to-global step.

## Candidate 4 — supercritical canonical-tail multiplicity

Prove that every \(n\in E_X\) has

\[
\omega((\log X)^{3/2})
\]

complete-grid private square-root-tail records from a global record family of size \(O(X(\log X)^{3/2})\).

### Payoff

Corollary CC-B would give \(|E_X|=o(X)\).

### Problem

No pointwise lower bound of this strength is known; some integers may have very few square-root survivors. The statement is at least as strong as a substantial lower-tail theorem and is not supported by current methods.

## Candidate 5 — common-container quotient compression

Find a deterministic common object \(M(n)\) and a squarefree selected divisor \(Q(n)\mid M(n)\) such that:

1. \(\log M(n)=O(\log X)\), or the special-value family \(M([X,2X])\) has an independently proved sub-\(X\) counting theory;
2. all selected canonical cell witnesses are factors of \(Q(n)\);
3. the quotient \(m=M(n)/Q(n)\) plus \(o(\log X)\) auxiliary bits reconstructs \(n\) with a uniformly controlled fiber;
4. a deterministic selection theorem forces \(Q(n)\) large enough that the quotient count times the fiber is \(o(X)\).

### Motivation and blocker

This abstracts the common-divisor lattice that makes Li's 2026 canonical compression work. The obvious A303656 choice \(M(n)=\prod_{h\in\mathcal H_X}(n-h)\) has \(\log M(n)=\Theta((\log X)^3)\), no self-indexed witness congruence, and no applicable growing divisor-moment estimate on its special values. No candidate \(M(n)\) meeting item 1 is known.

### Status

SPECULATIVE; no bounded Phase B. It is weaker as a present route than HC-LT because neither the common container nor the reconstruction theorem exists.

## Candidate score

Only Candidate 1 has a closed quantitative counting chain and a clearly isolated missing lemma. It is retained as a speculative watch, not promoted.
