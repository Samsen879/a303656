# LOGS

- `experiment_run.log`: canonical exact experiment run.
- `theorem_sanity_run.log`: finite identity and implementation checks.
- `input_validation/`: read-only validation outputs for the supplied prior archives.

Logs are evidence of execution and validation only. Mathematical authority comes from the stated proofs, not from exit codes.
