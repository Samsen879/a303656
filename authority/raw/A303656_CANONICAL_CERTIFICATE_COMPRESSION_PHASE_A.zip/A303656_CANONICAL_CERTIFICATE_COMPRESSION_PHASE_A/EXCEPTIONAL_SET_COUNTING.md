# EXCEPTIONAL-SET COUNTING

## 1. Required endpoint

A certificate argument must end with an explicit inequality of the form

\[
|E_X|
\le
\#\{\text{admissible records}\}
\cdot
\max_R\#\{n\in E_X:\mathcal R(n)=R\},
\]

whose right side is \(o(X)\), \(X/(\log X)^A\), or \(X^{1-\eta}\). Merely proving that a counterexample has an unusual label matrix is not enough.

## 2. Full-matrix tautology

The complete canonical matrix is deterministic once \(n\) is known, so at most \(X+1\) such matrices are realized on \([X,2X]\). This gives only

\[
|E_X|\le X+1.
\]

Counting all abstract matrices is far worse: with \(K=\Theta((\log X)^2)\) cells and labels up to \(2X\), a naive count is exponential in \(K\log X\). Neither viewpoint creates a saving.

## 3. Selected-congruence records

For a fixed shift \(h\) and primes \(p\in[P,2P]\), the union of congruences

\[
n\equiv h\pmod p
\]

occupies at most

\[
\ll \frac{X}{\log P}+\frac{P}{\log P}
\]

prime-progressions counted with multiplicity. This contains a small logarithmic saving for one fixed shift. Multiplying by \(\Theta((\log X)^2)\) possible shifts destroys it unless a counterexample can be forced to use a much smaller canonical subfamily.

Exact valuation one does not give a \(p^2\)-sized gain: it occupies \(p-1\) classes modulo \(p^2\), still a proportion \(\asymp1/p\).

## 4. Natural square-root records

The quadruple

\[
(c,d,q,s),
\qquad n=3^c+5^d+qs,
\]

reconstructs \(n\) exactly. Theorem CC-A proves that complete-grid private canonical records of this form number

\[
\Theta(X(\log X)^{3/2}).
\]

If every target \(n\) supplied only \(\Theta((\log X)^{3/2})\) such records, incidence division gives only \(O(X)\). This closes the record-counting chain and identifies the exact missing saving.

## 5. High-cutoff counting chain

At cutoff \(z=X^{1-\delta}\), Theorem HC-A gives

\[
\sum_{n\sim X}B_{X,\delta}(n)
\ll
X(\log X)^{3/2}\sqrt\delta
\]

after taking \(X\to\infty\) with fixed \(\delta\).

For a counterexample,

\[
U_{X,\delta}(n)=B_{X,\delta}(n).
\]

Therefore the missing lower-tail theorem (HC-LT) would give

\[
\frac{|E_X|}{X}
\ll
\rho(\delta)+\sqrt\delta+o_\delta(1).
\]

Letting \(\delta\downarrow0\) would prove

\[
|E_X|=o(X).
\]

This is the only candidate in the phase with a complete quantitative payoff chain.

## 6. Why existing inputs do not prove HC-LT

The first moment of \(U_{X,\delta}\) is expected at the \((\log X)^{3/2}\) scale, but a growing mean does not imply a lower-tail bound. One needs a minorant or a signed correlation estimate for the truncated parity-survivor indicator, uniformly over all differences

\[
3^c+5^d-3^{c'}-5^{d'}.
\]

Current frozen indicator bounds provide an upper second moment sufficient for positive density, not the variance saving needed for \(\rho(\delta)\to0\).

## 7. Current result

No unconditional nontrivial upper bound for \(|E_X|\) is obtained in this phase. The exact payoff remains conditional on HC-LT.
