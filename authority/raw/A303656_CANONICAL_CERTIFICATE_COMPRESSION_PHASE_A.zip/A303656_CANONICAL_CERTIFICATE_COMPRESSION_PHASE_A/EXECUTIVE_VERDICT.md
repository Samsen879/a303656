# EXECUTIVE VERDICT

## Final verdict

```text
NO PROMOTABLE ROUTE — RETAIN AS SPECULATIVE WATCH
```

```text
PROJECT: PAUSED
ACTIVE PROMOTED ROUTE: NONE
PROMOTION RECOMMENDED: NO
CODEX AUTHORIZED: NO
ULTRA AUTHORIZED: NO
OEIS A303656: UNRESOLVED
```

## What was proved

### 1. Critical canonical-tail record saturation

For complete actual survivors at the natural cutoff \(z=\lfloor\sqrt n\rfloor\), every bad survivor has the exact canonical form

\[
n-3^c-5^d=qs,
\qquad q>\sqrt n,
\quad q\equiv3\pmod4,
\quad v_q=1,
\quad s\in\mathcal S_2.
\]

Let \(\mathscr C_X^{\mathrm{pvt}}\) be the complete-grid private records \((c,d,q,s)\) with reconstructed integer \(n\in[X,2X]\). Theorem CC-A proves

\[
|\mathscr C_X^{\mathrm{pvt}}|
=\Theta\!\bigl(X(\log X)^{3/2}\bigr).
\]

This is the strongest proved result of the phase. It converts Theorem PW-A into an exact record-count theorem and shows that the most natural private-certificate charging scheme is critical rather than subcritical. If a target contributes only \(\Theta((\log X)^{3/2})\) records, incidence division gives only \(O(X)\), not \(o(X)\).

### 2. Aggregate high-cutoff bad-tail bound

For fixed \(0<\delta<1/2\), cutoff \(z=X^{1-\delta}\), and the complete fixed core

\[
\mathcal H_X=\{(c,d):3^c+5^d\le X/2\},
\]

Theorem HC-A proves

\[
\sum_{X\le n\le2X} B_{X,\delta}(n)
\ll
X(\log X)^{3/2}
\sqrt{\delta+\frac1{\log X}}.
\]

This is a genuine complete-grid density loss for bad high-cutoff survivors.

## Strongest candidate and exact payoff

The missing theorem HC-LT asks for constants \(\kappa>0\) and \(\rho(\delta)\to0\) such that

\[
\#\{n\in[X,2X]:U_{X,\delta}(n)<\kappa(\log X)^{3/2}\}
\le \rho(\delta)X+o_\delta(X).
\]

For a counterexample every high-cutoff survivor is bad. Therefore HC-A plus HC-LT would give

\[
\frac{|E_X|}{X}
\ll \rho(\delta)+\sqrt\delta+o_\delta(1),
\]

and then \(|E_X|=o(X)\). This is the only candidate in the phase with a complete quantitative exceptional-set counting chain.

## Why it is not promoted

HC-LT is unproved. Proving it requires a nonnegative minorant, signed pair-correlation estimate, or direct lower-tail sieve for a truncated parity-survivor indicator over the complete two-dimensional exponent grid. Current weighted \(r_2\) results do not automatically control the indicator, and the audited inverse-sieve, square-condition, combinatorial-large-sieve, container, primitive-divisor, and square-kernel frameworks all lack at least one essential hypothesis.

A July 2026 arXiv preprint does prove a powerful canonical-witness compression theorem for Erdős Problem 768, but its reconstruction depends on all witnesses living in one common divisor lattice \(D_p\mid n\), squarefree deletion \(n=mQ\), and the self-indexed relation \(D_p\equiv1\pmod p\). A303656 witnesses divide different translates \(n-h\), so the theorem does not transfer without a new common-container reconstruction and divisor-moment theorem.

No low-fiber certificate theorem, structured-subgrid theorem with counting payoff, finite reduction, or exceptional-set saving was proved. The computational outputs are classified only as `COMPUTATIONAL OBSERVATION`.

## Decision

The canonical-certificate route has produced a useful negative theorem and a sharply formulated high-cutoff candidate, but it has not crossed the promotion gate. It should remain a theorem-level speculative watch only; no repository implementation or large computation is justified.
