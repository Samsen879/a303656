# CANONICAL WITNESS SYSTEM

## 1. Definition

For \(m>0\) with \(m\notin\mathcal S_2\), define

\[
p_*(m)=\min\mathcal B(m),
\qquad
e_*(m)=v_{p_*(m)}(m).
\]

For an active exponent pair, write

\[
p_*(n;c,d)=p_*(n-h(c,d)),
\qquad
e_*(n;c,d)=e_*(n-h(c,d)).
\]

If the remainder is in \(\mathcal S_2\), including remainder zero, the label is `GOOD` and no prime is assigned.

The labelled complete grid is

\[
(c,d)\longmapsto
\begin{cases}
\mathrm{GOOD},&n-h(c,d)\in\mathcal S_2,\\
(p_*(n;c,d),e_*(n;c,d)),&\text{otherwise}.
\end{cases}
\]

The minimum makes tie-breaking deterministic. There is no tie among primes, and \(e_*\) is uniquely determined once \(p_*\) is chosen.

## 2. Exact meaning of a canonical label

For \(m\le2X\), the assertion \((p_*(m),e_*(m))=(p,e)\) means simultaneously:

1. \(p\equiv3\pmod4\);
2. \(e\) is odd and \(p^e\Vert m\);
3. every prime \(q<p\), \(q\equiv3\pmod4\), has even valuation in \(m\).

Thus `p divides m` is not a certificate. Exact valuation one is the union of the \(p-1\) residue classes

\[
m\equiv up\pmod{p^2},\qquad u\in(\mathbf Z/p\mathbf Z)^\times,
\]

whereas higher odd valuations require deeper \(p\)-adic shells. Modulo \(p\) alone loses the parity information.

## 3. Smallest-prime choice versus other choices

The smallest-prime choice records a nested lower-prime survival condition. A largest-prime choice, a lexicographic choice, or a chosen private witness does not have this condition. Therefore results about an arbitrarily designated witness cannot be transferred automatically to \(p_*\).

Conversely, canonicality alone does not make the record cheap. To specify a self-selected prime of size \(P\) costs approximately \(\log P\) bits, while the congruence \(n\equiv h\pmod p\) saves approximately \(\log p\) bits. The net gain is at most logarithmic in the prime-counting density unless prime reuse or a structured restricted family is proved.

## 4. Equal numerical shifts

If

\[
h(c,d)=h(c',d'),
\]

then the two pair vertices have the same remainder and hence the same canonical label. The pair-labelled matrix retains both entries. The quotient matrix carries one entry for the common numerical shift.

A prime that is private on the pair graph is automatically attached to a multiplicity-one shift and remains private on the quotient. A prime private only on the quotient need not be private on the pair graph when the shift has exponent-pair multiplicity.

## 5. Active-domain boundary

The canonical label is defined only for active pairs. For general \(n\), an active pair with \(h=n\) receives `GOOD` because the remainder is zero. For \(n\in E_X\), such a pair cannot occur, so every active cell has a positive non-two-square remainder and a canonical witness.

## 6. Square-root simplification

Let

\[
z_n=\lfloor\sqrt n\rfloor
\]

and suppose a positive remainder \(m\le n\) has even valuation at every bad prime \(p\le z_n\). If \(m\notin\mathcal S_2\), then there is exactly one bad prime \(q>z_n\), its valuation is one, and

\[
m=qs,
\qquad s\in\mathcal S_2.
\]

In this regime the unique large bad prime is automatically the canonical smallest bad prime. This exact identity is the basis of the critical record theorem in `PROVED_LEMMAS.md`.

## 7. Periodic truncations

For fixed \(X\) and a fixed bad prime \(p\), the parity of \(v_p(m)\) for \(0<m\le2X\) is determined by \(m\) modulo

\[
p^{1+\lfloor\log_p(2X)\rfloor}.
\]

A complete small-prime parity vector up to \(z\) is therefore periodic modulo the product of these prime powers. Recording all residues is exact but not a compression theorem: once the product modulus exceeds \(X\), it can simply encode \(n\) itself, leaving up to \(X\) realized records.
