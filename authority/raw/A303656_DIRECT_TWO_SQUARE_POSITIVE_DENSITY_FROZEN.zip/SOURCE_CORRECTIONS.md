# Source and Metadata Corrections

## 1. Radomskii author and version

Incorrect: “Konstantin Radomskii”.  
Correct: **Artyom Radomskii**, *Variants of Romanoff's theorem*,
arXiv:2504.09954v6, revised **13 July 2026**.

## 2. FKR bibliography

Correct citation:

> Tristan Freiberg, Pär Kurlberg, and Lior Rosenzweig,
> *Poisson distribution for gaps between sums of two squares and level spacings
> for toral point scatterers*, *Communications in Number Theory and Physics*
> **11** (2017), no. 4, 837–877,
> DOI 10.4310/CNTP.2017.v11.n4.a3.

The needed indicator upper bound is the **unnumbered display in §2.1**.  The
package does not assign it a nonexistent theorem or lemma number.  The general
case is credited there to Nowak.

## 3. Primitive-subset leading constant

Let

\[
\mathcal S'_2=\langle P_1\rangle
\]

be the positive integers composed only of primes \(1\pmod4\), and

\[
H(z)=\prod_{p\equiv1(4)}(1-p^{-z})^{-1}.
\]

Then

\[
H(z)^2=\zeta(z)L(z,\chi_4)(1-2^{-z})
\prod_{p\equiv3(4)}(1-p^{-2z}).
\]

Selberg–Delange therefore gives

\[
\#\{n\le x:n\in\mathcal S'_2\}
\sim \kappa\frac{x}{\sqrt{\log x}},
\]

where

\[
\kappa=\frac1{2\sqrt2}
\prod_{p\equiv3(4)}(1-p^{-2})^{1/2}
=\frac1{4K}.
\]

Radomskii v6 Example 2 prints the inverse Euler-product exponent, yielding
\(K/2\).  That printed constant is inconsistent with the displayed set identity
\(\mathcal S'_2=\langle P_1\rangle\).  The previous formal audit's instruction
to retain \(K/2\) is therefore superseded.  The subsumption argument uses only
\(A(x)\asymp x/\sqrt{\log x}\), so it survives unchanged.

## 4. Crocker scope

Crocker 2008 records one-power positive density in the abstract.  Its numbered
main theorems prove infinitely many nonrepresentable integers for two or fewer
powers; they do not establish the present \((\log X)^{3/2}\) multiplicity
threshold.

## 5. Provenance language

The Phase A draft's own packaging notes identify reconstructed files and
nondeterministic diagnostics.  This Phase B package preserves the uploaded ZIP
unchanged and never describes reconstructed content as an original web-session
artifact.

## 6. Mathematical authority hierarchy

The Phase A formal audit is referee evidence, not an authority.  Primary-source
statements and the independent Phase B derivation control every conflict.

### Accepted

- Direct dyadic positive-density theorem: **PROVED**.
- Distinct-shift dyadic theorem: **PROVED**.
- Finite nontrivial shift collisions: **PROVED**.
- Bounded shift multiplicity: **PROVED**.
- Sidon-scale additive energy: **PROVED; NOVELTY NOT ESTABLISHED**.
- Structured singular-factor average: **PROVED; NOVELTY NOT ESTABLISHED**.
- FKR indicator-level correlation input: **VERIFIED**.
- Radomskii v6 subsumption: **SUBSTANTIALLY SUBSUMED**.
- Crocker bare positive-density prior art: **VERIFIED**.

### Rejected or deprecated

- Author “Konstantin Radomskii”: **REJECTED**; the correct author is Artyom
  Radomskii.
- Primitive-subset constant \(K/2\): **REJECTED FOR THIS SET**; the corrected
  value is \(1/(4K)\).
- Headline classification `NEW THEOREM`: **REJECTED**.
- Almost-all inference from the second moment: **REJECTED**.
- Universal inference: **REJECTED**.

### Unresolved

- Almost-all representability: **NOT PROVED**.
- Universal A303656: **UNRESOLVED**.
- Novelty of the two structural lemmas: **NOT ESTABLISHED**.
- Certified counterexample: **NONE**.

## 7. Novelty wording

Replace `NEW THEOREM` by

\[
\text{SPECIALIZED APPLICATION / INDEPENDENT ALTERNATIVE PROOF},
\]

with the headline phenomenon marked `SUBSTANTIALLY SUBSUMED` by Radomskii v6.
