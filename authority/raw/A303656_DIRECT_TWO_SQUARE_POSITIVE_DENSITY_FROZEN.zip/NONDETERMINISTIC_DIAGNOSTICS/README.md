# Nondeterministic Diagnostics — Excluded

Runtime, wall-clock time, peak RSS, scheduler data, and floating-point
last-digit diagnostics belong only in this directory. No such quantity enters
`SCIENTIFIC_CORE.json` or its hash. This frozen package intentionally contains
no runtime/RSS measurement.
