# Radomskii v6 Subsumption Verdict

## Version and author correction

The locked source is

> **Artyom Radomskii**, *Variants of Romanoff's theorem*,
> arXiv:2504.09954v6, 13 July 2026.

The task text's forename “Konstantin” is incorrect.

## Verdict

\[
\boxed{\text{SUBSTANTIALLY SUBSUMED}.}
\]

## What is subsumed

After taking \(A=\mathcal S'_2\),
\(B=(3^c+5^d)_{c,d\ge0}\), and
\(\eta(x)=\sqrt{\log x}\), every hypothesis of Radomskii Theorem 1.1 is
verified by the frozen lemmas.  The theorem explicitly permits multiplicity in
\(B\).  It yields a positive proportion of integers \(n\le x\) having

\[
\Omega\!\left(\frac{B(x)}{\eta(x)}\right)
=\Omega((\log x)^{3/2})
\]

representations.  The distinct set of shifts also satisfies the theorem.
Therefore the headline statement “positive density with
\(\Omega((\log x)^{3/2})\) two-base shift representations” is not a new
specialized theorem after v6.

## Why the label is not `FULLY SUBSUMED`

Radomskii's printed conclusion is cumulative on \([1,x]\) and uses the global
sequence \(B\).  The present theorem is uniform on **every** sufficiently large
\([X,2X]\) and deliberately restricts the shifts to
\(3^c+5^d\le X/2\), so every translated two-square argument remains in a
controlled common interval.  A cumulative lower bound alone does not logically
force the same lower bound in each dyadic shell.  The present direct first/second
moment proof supplies that stronger localization.

The Sidon-scale energy lemma and the structured singular-factor average are
also independent structural statements rather than conclusions of Theorem 1.1.

## Remaining independent contribution

- exact curved-domain bookkeeping;
- a fully typeset projective-to-actual collision argument;
- Sidon-scale energy for \(\{3^c+5^d\}\);
- structured totient/singular-factor averaging;
- a direct indicator-level proof on every dyadic interval;
- the explicit almost-all covariance blocker.

These are specialized contributions.  Their publication novelty, especially
for the two structural lemmas, is not established by this freeze.

## Publication status caveat

arXiv:2504.09954v6 is a recent preprint and has not completed traditional
journal peer review.  That status is relevant to bibliographic caution but is
not a reason to ignore a mathematically applicable general theorem.
