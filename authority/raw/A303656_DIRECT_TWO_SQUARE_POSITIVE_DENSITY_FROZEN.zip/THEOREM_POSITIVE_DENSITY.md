# Theorem: Direct Two-Square Positive Density on Every Dyadic Interval

Let

\[
\mathcal D_X=\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le X/2\},
\]

\[
R_X(n)=\sum_{(c,d)\in\mathcal D_X}
\mathbf1_{\mathcal S_2}(n-3^c-5^d),
\]

and

\[
R_X^{\rm dist}(n)=
\sum_{s:\,\exists(c,d)\in\mathcal D_X,\ 3^c+5^d=s}
\mathbf1_{\mathcal S_2}(n-s).
\]

## Theorem

There exist constants \(c_0,c_1,X_0>0\) such that for every integer
\(X\ge X_0\),

\[
\boxed{
\#\left\{n\in[X,2X]\cap\mathbb Z:
R_X(n)\ge c_0(\log X)^{3/2}\right\}
\ge c_1X.}
\tag{1}
\]

After changing \(c_0,c_1,X_0\) if necessary,

\[
\boxed{
\#\left\{n\in[X,2X]\cap\mathbb Z:
R_X^{\rm dist}(n)\ge c_0(\log X)^{3/2}\right\}
\ge c_1X.}
\tag{2}
\]

In particular,

\[
\#\{n\in[X,2X]\cap\mathbb Z:R_X(n)>0\}\gg X.
\]

The constants depend only on the fixed bases 3 and 5 and on the absolute
constants in the cited Landau–Ramanujan and indicator-sieve estimates.

## Proof

The curved-domain lemma gives

\[
|\mathcal D_X|=\frac{(\log X)^2}{\log3\log5}+O(\log X).
\]

The collision theorem gives bounded shift multiplicity and
\(\sum_sw_X(s)^2=|\mathcal D_X|+O(1)\).  The first-moment proof gives

\[
\sum_{X\le n\le2X}R_X(n)
=\frac K{\log3\log5}X(\log X)^{3/2}
+O(X(\log X)^{1/2}),
\]

where

\[
K=\frac1{\sqrt2}\prod_{p\equiv3\pmod4}(1-p^{-2})^{-1/2}.
\]

The indicator-level FKR/Nowak bound, together with the structured
singular-factor average, yields

\[
\sum_{X\le n\le2X}R_X(n)^2\ll X(\log X)^3,
\]

with the diagonal handled separately.  Paley–Zygmund therefore gives (1).
The distinct first and second moments give (2); equivalently, bounded global
collision excess changes every representation count by only \(O(1)\).
Full details are in `PROOF_FIRST_MOMENT.md`, `PROOF_SECOND_MOMENT.md`, and
`PROOF_POSITIVE_DENSITY.md`. \(\square\)

## Logical scope

This theorem gives a positive proportion in every sufficiently large dyadic
interval and a growing number of exponent-pair representations on that
proportion.  It does not imply density one, almost-all representability, or the
universal A303656 statement.

## Novelty status

The theorem is **PROVED**, but its headline many-representation phenomenon is
**SUBSTANTIALLY SUBSUMED** by Radomskii v6.  The exact dyadic truncation and
direct proof are an **INDEPENDENT ALTERNATIVE PROOF**, not a claim of a new
headline theorem.
