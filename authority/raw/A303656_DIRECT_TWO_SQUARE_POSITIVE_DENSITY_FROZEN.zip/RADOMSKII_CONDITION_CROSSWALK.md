# Radomskii v6 — Condition Crosswalk

Version lock: **Artyom Radomskii**, *Variants of Romanoff's theorem*,
arXiv:2504.09954v6, revised 13 July 2026.

Radomskii defines sequences \(A=(a_i)\) and \(B=(b_j)\), permits repetitions
in \(B\), and writes

\[
r(n)=\#\{(i,j):a_i+b_j=n\},
\qquad
\rho_B(x)=\max_{v\le x}\operatorname{ord}_B(v).
\]

Use

\[
A=\mathcal S'_2=\langle P_1\rangle,
\qquad
B=(3^c+5^d)_{c,d\ge0},
\qquad
\eta(x)=\sqrt{\log x}.
\]

| Radomskii Theorem 1.1 condition | Verification for the shift family | Frozen lemma/source |
|---|---|---|
| \(A\) strictly increasing | Enumerate the distinct primitive odd sums \(\mathcal S'_2\) increasingly. | Radomskii Example 2; exact set identity \(\mathcal S'_2=\langle P_1\rangle\). |
| \(A(x)\asymp x/\eta(x)\) | Selberg–Delange gives \(A(x)\asymp x/\sqrt{\log x}\).  Only comparability is needed. | Radomskii Example 2; `SOURCE_CORRECTIONS.md` for the corrected leading constant. |
| \(A(x/2)\gg A(x)\) | Immediate from the same asymptotic. | Selberg–Delange. |
| Pair hypothesis \(A(x,r)\ll (r/\varphi(r))x/\eta(x)^2\) | Primitive-set sieve gives \(A(x,r)\ll(r/\varphi(r))x/\log x\). | Radomskii Example 2, citing Halberstam–Richert. |
| \(B\) may have multiplicity | The theorem explicitly says \(b_n\) need not be distinct, while each value has finite multiplicity. | Radomskii Theorem 1.1. |
| \(B(x)\) | \(B(x)=\#\{(c,d):3^c+5^d\le x\}\asymp(\log x)^2\). | `LEMMA_SHIFT_DOMAIN.md`. |
| \(B(x/2)\gg B(x)\) | Fixed-scale stability gives ratio tending to 1. | `LEMMA_SHIFT_DOMAIN.md`. |
| Finite value multiplicity and \(\rho_B(x)\) | Global unit-equation finiteness gives \(\rho_B(x)=O(1)\). | `LEMMA_COLLISIONS.md`. |
| Small-prime condition (1.4) | Its left side equals \(\sum_{p\le(\log x)^\alpha}A_p\log p/p\), where \(A_p\ll L^3+L^4/\operatorname{ord}_p(5)\); the order series converges, so it is \(O(L^4)=O(B(x)^2)\). | `LEMMA_SINGULAR_FACTOR_AVERAGE.md` with \(m=1\). |
| Resulting threshold | \(B(x)/\eta(x)\asymp(\log x)^{3/2}\). | Algebra from the two growth laws. |
| Resulting density factor | \(B(x)/(B(x)+\rho_B(x)\eta(x))\to1\), hence the lower bound is \(\gg x\). | Bounded \(\rho_B\), \(B\asymp L^2\), \(\eta\asymp L^{1/2}\). |
| Primitive subset role | Each primitive representation is a full sum-of-two-squares representation, so Radomskii's lower bound transfers to the original indicator family. | Set inclusion \(\mathcal S'_2\subset\mathcal S_2\). |
| Distinct shifts | Replace the multisequence by its distinct value set.  Then \(\rho_B=1\), the count remains \(\asymp L^2\), and all congruence counts decrease. | Collision theorem and monotonicity. |

## Exact theorem output

Radomskii obtains constants \(c_1,c_2>0\) such that

\[
\#\left\{n\le x:r(n)\ge c_1\frac{B(x)}{\eta(x)}\right\}
\ge c_2x\frac{B(x)}{B(x)+\rho_B(x)\eta(x)}.
\]

For the present family this is

\[
\#\{n\le x:r(n)\gg(\log x)^{3/2}\}\gg x.
\]

The theorem is cumulative and is not printed as a statement on every dyadic
interval with the project-specific truncation \(b\le X/2\).  This distinction
controls the final subsumption label.
