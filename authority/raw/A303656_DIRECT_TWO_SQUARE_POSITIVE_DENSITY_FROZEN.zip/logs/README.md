# Deterministic Verification Logs

This directory contains only deterministic pass/fail and digest records from
the two fresh core replays. No runtime or RSS field is recorded. These logs are
outside the scientific-core hash but are covered by the final
`SHA256SUMS.txt`.
