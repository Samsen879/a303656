# Limitations

1. **No universal theorem.**  The assertion that every \(n>1\) has the target
   representation remains unresolved.
2. **No almost-all theorem.**  The signed indicator covariance estimate in
   `ALMOST_ALL_BLOCKER.md` is missing.
3. **No new \(T(n)\) computation.**  This phase performs no interval scan,
   low-\(T\) search, counterexample search, or production computation.
4. **No global collision enumeration.**  The unit-equation theorem proves
   finiteness but does not identify every collision or prove that 28 is unique.
5. **Ineffective structural constants.**  The cited Evertse–Győry bound is
   finite but not made numerically effective here; the positive-density constants
   and threshold \(X_0\) are not extracted.
6. **Recent-preprint dependence in the novelty audit.**  Radomskii v6 is an
   arXiv preprint dated 13 July 2026 and has not completed traditional journal
   peer review.
7. **Novelty search is not exhaustive.**  The energy and singular-factor lemmas
   are only marked potentially new; no publication claim is frozen.
8. **Crocker wording is limited.**  One-power positive density is recorded in
   the abstract, while the body focuses on infinite exceptional sets.
9. **Primitive constant correction.**  The corrected \(1/(4K)\) is an exact
   Euler-product derivation; it is not needed in the full-set first moment.
10. **No repository integration.**  No Codex, Codex Ultra, Git, WSL repository,
    build system, or production artifact was used.
11. **No source PDFs redistributed.**  The package freezes hashes and metadata,
    not copies of copyrighted primary-source PDFs.
12. **Determinism scope.**  Byte identity is asserted for the scientific core
    and for two ZIP builds in the locked environment.  Runtime/RSS is excluded.
