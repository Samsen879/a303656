# Final Frozen Proof Layer

The authoritative Phase B proof is the set of top-level theorem, lemma, proof,
source-audit, novelty, limitation, and reproducibility files authenticated by
`SCIENTIFIC_CORE.json`.

This directory marker distinguishes that layer from the untouched historical
ZIPs in `ORIGINAL_PHASE_A_DRAFT/` and `FORMAL_AUDIT/`.  No reconstructed Phase A
file is relabeled as an original session artifact.
