# Final Report

## 1. Scope and final classification

The Phase B task was a proof-freeze and source-correction stage, not a search for
new values of \(T(n)\), a counterexample, an almost-all theorem, or a universal
proof.  The frozen conclusion is

\[
\boxed{\text{ACCEPT PROOF / SUBSTANTIALLY SUBSUMED}},
\qquad
\boxed{\text{Route: FREEZE AND STOP}}.
\]

The global problem remains

\[
\boxed{\text{OEIS A303656: UNRESOLVED}}.
\]

For integer \(X\ge1\), put

\[
\mathcal D_X=\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le X/2\},
\quad N_X=|\mathcal D_X|,
\]
\[
w_X(s)=\#\{(c,d)\in\mathcal D_X:3^c+5^d=s\},
\]
\[
R_X(n)=\sum_s w_X(s)\mathbf 1_{\mathcal S_2}(n-s),
\qquad
R_X^{\rm dist}(n)=\sum_{s:w_X(s)>0}\mathbf 1_{\mathcal S_2}(n-s).
\]

The final theorem states that constants \(c_0,c_1,X_0>0\), depending only on
bases 3 and 5 and the cited absolute sieve constants, satisfy

\[
\#\{n\in[X,2X]\cap\mathbb Z:R_X(n)\ge c_0(\log X)^{3/2}\}\ge c_1X
\]

for every integer \(X\ge X_0\), and the same is true with
\(R_X^{\rm dist}\).  This is a positive-lower-density theorem only.

## 2. Archive integrity and provenance

The uploaded draft ZIP has SHA256
`a1fa61b65ed734133046410d1ab3f8ac1aa697f88cc9de0e10bd5d8f094b2375`.
It has 42 files, no unsafe path, no symlink entry, and no CRC failure.  Its
internal manifest authenticates all 41 files it lists; the manifest does not
list itself.

The uploaded formal-audit ZIP has SHA256
`e3d8559c32bc64e046b85032c4111145092f4f63e373e0d0355932a43f972e15`.
It has three files, no unsafe path, no symlink entry, and no CRC failure.  It
contains no internal manifest, so its outer ZIP hash is the archival lock.

The source hierarchy used in this report is:

1. exact-version primary literature and the present independent derivation;
2. the task specification for scope and prohibited routes;
3. the Phase A draft as a claim source;
4. the Phase A formal audit as referee evidence.

Where the draft or audit conflicts with a primary source or an independently
checked derivation, the latter prevails.  In particular, the previous audit's
instruction to retain \(K/2\) for the primitive subset is rejected by an exact
Euler-product calculation.

## 3. Load-bearing proof chain

### 3.1 Curved shift domain

The rectangle cut out by \(3^c\le X/2\) and \(5^d\le X/2\) has

\[
\frac{(\log X)^2}{\log3\log5}+O(\log X)
\]

points.  A rectangle point excluded by the true curved boundary has either
\(3^c\in(X/4,X/2]\) or \(5^d\in(X/4,X/2]\).  Each such interval contains at
most one power of the corresponding base, leaving only \(O(\log X)\) excluded
points.  Thus

\[
N_X=\frac{(\log X)^2}{\log3\log5}+O(\log X).
\]

For every fixed \(0<\theta<1\),
\(N_{\theta X}=N_X+O_\theta(\log X)\), hence
\(N_{\theta X}\asymp_\theta N_X\).  This also proves the
\(B(x/2)\gg B(x)\) condition needed in Radomskii's theorem.

### 3.2 Global collisions and bounded multiplicity

The equation

\[
3^c+5^d-3^{c'}-5^{d'}=0
\]

is a homogeneous unit equation in
\(\Gamma=\langle3,5\rangle\subset\mathbb Q^\times\).  Evertse–Győry's
weighted unit theorem gives finitely many nondegenerate projective classes.
For a class containing a pure 3-power slot and a pure 5-power slot, a common
scale \(\gamma\) preserving both slot types lies in
\(\langle3\rangle\cap\langle5\rangle=\{1\}\); projective finiteness therefore
becomes actual exponent finiteness.  Degenerate two-term blocks give only
trivial identities.  Consequently

\[
|\mathcal B_X|=N_X+O(1),\quad \max_sw_X(s)=O(1),\quad
\sum_sw_X(s)^2=N_X+O(1).
\]

No claim is made that 28 is the only global collision.

### 3.3 Sidon-scale energy

The energy equation expands into eight signed pure powers.  Partition the
labeled terms into minimal zero-sum blocks.  A mixed block has \(O(1)\) actual
assignments by the same projective-unit-equation argument.  A pure block over
\(q\in\{3,5\}\) is either a two-term cancellation or impossible: a three-term
block would give \(q^a+q^b=q^c\), and a four-term block would give
\(q^a+q^b=q^c+q^d\), whose base-\(q\) digit uniqueness forces a two-term
zero subblock.  There are at most four free pure cancellations.  Therefore

\[
E_X=\sum_h\nu_X(h)^2\ll(\log X)^4\asymp N_X^2.
\]

### 3.4 First moment

The Landau–Ramanujan/Selberg–Delange estimate, with

\[
K=\frac1{\sqrt2}\prod_{p\equiv3\pmod4}(1-p^{-2})^{-1/2},
\]

is

\[
B_2(y)=K\frac{y}{\sqrt{\log y}}+
O\!\left(\frac{y}{(\log y)^{3/2}}\right).
\]

For every \(s\le X/2\), both translated endpoints remain in a fixed
multiplicative interval, so uniformly

\[
B_2(2X-s)-B_2(X-s-1)
=K\frac X{\sqrt{\log X}}+O\!\left(\frac X{(\log X)^{3/2}}\right).
\]

Summation over \(\mathcal D_X\) gives

\[
M_1(X)=\frac K{\log3\log5}X(\log X)^{3/2}
+O\bigl(X(\log X)^{1/2}\bigr).
\]

Finite collisions leave the distinct-shift leading term unchanged.

### 3.5 Indicator correlation and local-factor average

FKR §2.1 records the Selberg-sieve bound, due in general to Nowak, for the
actual indicator of sums of two squares.  At \(k=2\), uniformly for nonzero
integer \(h\),

\[
\sum_{m\le x}\mathbf1_{\mathcal S_2}(m)
\mathbf1_{\mathcal S_2}(m+h)
\ll \frac{x}{\log x}
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}\left(1+\frac2p\right).
\]

This is not an \(r_2\)-weighted shifted convolution.

For every fixed real \(A>0\), the structured difference family satisfies

\[
\sum_{\substack{u,v\in\mathcal D_X\\b_u\ne b_v}}
\left(\frac{|b_u-b_v|}{\varphi(|b_u-b_v|)}\right)^A\ll_A N_X^2.
\]

The key congruence count is

\[
A_p\ll (\log X)^3+
\frac{(\log X)^4}{\operatorname{ord}_p(5)}\qquad(p\ne5),
\]

and the key absolutely convergent series is

\[
\sum_{p\nmid5}\frac{(\log p)^m}{p\operatorname{ord}_p(5)}<\infty
\quad(m\in\mathbb Z_{\ge1}).
\]

Primes 2 and 5 are separated, the curved boundary only decreases counts, and
the diagonal is omitted.  Since

\[
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}(1+2/p)
\le (|h|/\varphi(|h|))^2,
\]

the averaged FKR factor is \(O(N_X^2)\).

### 3.6 Second moment and Paley–Zygmund

The exact boundary-aware identity is

\[
M_2(X)=\sum_{s,t}w_X(s)w_X(t)
\sum_{m=X-t}^{2X-t}\mathbf1_{\mathcal S_2}(m)
\mathbf1_{\mathcal S_2}(m+t-s).
\]

For \(s,t\le X/2\), both arguments lie in \([X/2,2X]\).  The diagonal is
handled separately:

\[
\nu_X(0)=N_X+O(1),\qquad Q_0(X)\ll X/\sqrt{\log X}.
\]

The off-diagonal FKR bound and structured average give

\[
M_2(X)\ll X(\log X)^3.
\]

Since \(M_1(X)\asymp X(\log X)^{3/2}\), Paley–Zygmund on the uniform measure
of \([X,2X]\cap\mathbb Z\) gives the theorem.  The distinct version follows
in parallel, or from
\(0\le R_X-R_X^{\rm dist}\le N_X-|\mathcal B_X|=O(1)\).

## 4. Radomskii v6 subsumption

The version-locked source is Artyom Radomskii, *Variants of Romanoff's
theorem*, arXiv:2504.09954v6, revised 13 July 2026.  Theorem 1.1 explicitly
allows the shift sequence \(B\) to have multiplicity.  Set

\[
A=\mathcal S'_2=\langle P_1\rangle,
\qquad B=(3^c+5^d)_{c,d\ge0},
\qquad \eta(x)=\sqrt{\log x}.
\]

The primitive set satisfies \(A(x)\asymp x/\eta(x)\) and the required pair
upper bound.  The lemmas in this package give
\(B(x)\asymp(\log x)^2\), \(B(x/2)\gg B(x)\), bounded
\(\rho_B(x)\), and Radomskii's small-prime congruence condition.  The theorem
therefore yields a positive proportion of \(n\le x\) with

\[
r(n)\gg \frac{B(x)}{\eta(x)}\asymp(\log x)^{3/2}.
\]

The same application works for the distinct set of shifts.

This is **substantial** rather than literal full subsumption because Radomskii's
printed conclusion is cumulative on \([1,x]\) and uses its global sequence,
whereas the frozen theorem is a uniform statement on every dyadic interval
\([X,2X]\) with the explicit truncation \(3^c+5^d\le X/2\).  The direct
energy and singular-average lemmas also remain independent proof components.
Radomskii v6 is a recent arXiv preprint and has not completed traditional
journal peer review; that publication status does not negate its mathematical
subsumption.

## 5. Crocker and one-dimensional prior art

Crocker's 2008 article states in its abstract that integers representable as two
squares plus one fixed-base power have positive density.  Its numbered main
results instead prove infinitely many exceptions for two or fewer powers and do
not prove a growing representation multiplicity.  Taking base 3 and translating
by 1 shows that the support-only positive-density phenomenon is already present
in the subfamily

\[
a^2+b^2+3^c+1.
\]

Thus bare positive density is not the contribution of this package.  The stronger
many-representation threshold is itself substantially subsumed by Radomskii v6.

## 6. Novelty verdict

The curved-domain count, collision finiteness, and bounded multiplicity are
standard consequences of elementary lattice counting and unit equations.  The
direct dyadic proof is an independent alternative proof, not a new headline
theorem.  The many-representation and distinct-shift phenomena are subsumed at
the general-theorem level by Radomskii.

The Sidon-scale energy and structured singular-factor average may have
standalone methodological value for sparse two-base sumsets.  This freeze did
not perform an exhaustive novelty search, so both are classified only as
**POTENTIALLY NEW LEMMA / NOVELTY NOT ESTABLISHED**.  They are not promoted
to a major advance.

## 7. Almost-all blocker

The exact variance requires the signed covariance estimate

\[
\sum_{s,t}w_X(s)w_X(t)
\left(C_{s,t}(X)-\frac{A_s(X)A_t(X)}{|I_X|}\right)
=o\!\left(\frac{XN_X^2}{\log X}\right).
\]

Indicator upper bounds, a divergent mean, Sidon-scale energy, and pairwise
upper bounds do not provide this signed cancellation.  An \(r_2\)-weighted
shifted convolution cannot replace indicator covariance.  The blocker is frozen;
no numerical or theoretical almost-all campaign is started.

## 8. Reproducibility result

The scientific core contains no runtime/RSS data and no floating-point research
payload.  It is generated twice in fresh directories and compared byte for byte.
The canonical core manifest and its SHA256 are stored in
`SCIENTIFIC_CORE.json` and `SCIENTIFIC_CORE.sha256`.  The final package manifest
`SHA256SUMS.txt` is generated once after replay evidence is added and is never
modified by a replay script.  The final ZIP is built twice with sorted entries,
fixed timestamps, normalized permissions, and `ZIP_STORED`; both builds are
required to be byte-identical.

The package verifier also rejects every C0 control byte other than horizontal tab
and line feed in the scientific core.  This closes the generator-origin defects
that previously emitted two form-feed bytes and converted one carriage-return
escape into a broken formula line.

## 9. Frozen authority hierarchy

### Accepted

- Direct dyadic positive-density theorem: **PROVED**.
- Distinct-shift dyadic theorem: **PROVED**.
- Finite nontrivial shift collisions: **PROVED**.
- Bounded shift multiplicity: **PROVED**.
- Sidon-scale additive energy: **PROVED; NOVELTY NOT ESTABLISHED**.
- Structured singular-factor average: **PROVED; NOVELTY NOT ESTABLISHED**.
- FKR indicator-level correlation input: **VERIFIED**.
- Radomskii v6 subsumption: **SUBSTANTIALLY SUBSUMED**.
- Crocker bare positive-density prior art: **VERIFIED**.

### Rejected or deprecated

- “Konstantin Radomskii”: **REJECTED**; the author is Artyom Radomskii.
- Primitive-subset constant \(K/2\): **REJECTED FOR THIS SET**; the corrected
  value is \(1/(4K)\).
- `NEW THEOREM` headline classification: **REJECTED**.
- Almost-all inference from the second moment: **REJECTED**.
- Universal inference: **REJECTED**.

### Unresolved

- Almost-all representability: **NOT PROVED**.
- Universal A303656: **UNRESOLVED**.
- Novelty of the two structural lemmas: **NOT ESTABLISHED**.
- Certified counterexample: **NONE**.
