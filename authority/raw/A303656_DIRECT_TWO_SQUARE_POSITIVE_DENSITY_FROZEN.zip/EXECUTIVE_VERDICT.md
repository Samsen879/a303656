# Executive Verdict

## One-sentence verdict

**The dyadic positive-density many-representation theorem is formally proved,
but its headline phenomenon is substantially subsumed by Artyom Radomskii's
Theorem 1.1 in arXiv:2504.09954v6; the correct route is `FREEZE AND STOP`.**

## Formal route verdict

\[
\boxed{\text{ACCEPT PROOF / SUBSTANTIALLY SUBSUMED}.}
\]

| Item | Frozen status |
|---|---|
| Positive lower density | **PROVED** |
| \(\Omega((\log X)^{3/2})\) exponent-pair representations on a positive proportion of every dyadic interval | **PROVED** |
| Distinct-shift version | **PROVED** |
| Sidon-scale additive energy \(E_X\ll |\mathcal D_X|^2\) | **PROVED; POTENTIALLY NEW LEMMA / NOVELTY NOT ESTABLISHED** |
| Structured singular-factor average | **PROVED; POTENTIALLY NEW LEMMA / NOVELTY NOT ESTABLISHED** |
| Radomskii v6 subsumption | **SUBSTANTIALLY SUBSUMED** |
| Bare support positive density | **PRIOR ART; already visible from a one-dimensional subfamily** |
| Almost-all representability | **NOT PROVED; covariance blocker frozen** |
| Universal A303656 statement | **UNRESOLVED** |

## Source corrections that affect the freeze

1. The author of *Variants of Romanoff's theorem* is **Artyom Radomskii**, not
   Konstantin Radomskii.
2. The correct FKR paper is *Poisson distribution for gaps between sums of two
   squares and level spacings for toral point scatterers*, *Communications in
   Number Theory and Physics* **11** (2017), no. 4, 837–877.
3. For the odd primitive set \(\mathcal S'_2=\langle P_1\rangle\), the
   Selberg–Delange constant is \(1/(4K)\), not \(K/2\).  This correction does
   not affect Radomskii subsumption, which uses order of magnitude and an upper
   correlation bound.
4. Crocker's 2008 paper records one-power positive density in its abstract; its
   numbered main theorems concern infinitely many nonrepresentable integers and
   do not provide the present many-representation threshold.

No claim of almost-all or universal representability is made.

## Frozen authority hierarchy

### Accepted

- Direct dyadic positive-density theorem: **PROVED**.
- Distinct-shift dyadic theorem: **PROVED**.
- Finite nontrivial shift collisions: **PROVED**.
- Bounded shift multiplicity: **PROVED**.
- Sidon-scale additive energy: **PROVED; NOVELTY NOT ESTABLISHED**.
- Structured singular-factor average: **PROVED; NOVELTY NOT ESTABLISHED**.
- FKR indicator-level correlation input: **VERIFIED**.
- Radomskii v6 subsumption: **SUBSTANTIALLY SUBSUMED**.
- Crocker bare positive-density prior art: **VERIFIED**.

### Rejected or deprecated

- Author “Konstantin Radomskii”: **REJECTED**; the correct author is Artyom
  Radomskii.
- Primitive-subset constant \(K/2\): **REJECTED FOR THIS SET**; the corrected
  value is \(1/(4K)\).
- Headline classification `NEW THEOREM`: **REJECTED**.
- Almost-all inference from the second moment: **REJECTED**.
- Universal inference: **REJECTED**.

### Unresolved

- Almost-all representability: **NOT PROVED**.
- Universal A303656: **UNRESOLVED**.
- Novelty of the two structural lemmas: **NOT ESTABLISHED**.
- Certified counterexample: **NONE**.
