# A303656 Direct Two-Square Positive-Density Theorem — Phase B Frozen Package

Freeze date: **2026-07-17**  
Scientific status: **PROVED / SUBSTANTIALLY SUBSUMED**  
Route: **FREEZE AND STOP**

This package freezes a formal dyadic positive-density theorem for

\[
n=a^2+b^2+3^c+5^d,
\qquad a,b,c,d\in\mathbb Z_{\ge0},
\]

including the curved shift-domain count, global collision finiteness, bounded
multiplicity, Sidon-scale additive energy, an indicator-level correlation input,
a structured singular-factor average, exact first and second moments, and the
Paley–Zygmund conclusion.  It also freezes the Radomskii v6 subsumption audit,
Crocker prior-art audit, bibliography corrections, and the unresolved almost-all
covariance blocker.

The global OEIS problem is not solved:

\[
\boxed{\text{OEIS A303656: UNRESOLVED}.}
\]

## Package layers

- `ORIGINAL_PHASE_A_DRAFT/`: the untouched uploaded Phase A ZIP and its
  authenticated listing.  Several files inside that historical ZIP were already
  described by its own packaging notes as reconstructed; this package does not
  relabel them as original web-session artifacts.
- `FORMAL_AUDIT/`: the untouched uploaded referee ZIP.  It is evidence, not a
  mathematical authority.
- Top-level proof files and `FINAL_FROZEN_PROOF/`: the final Phase B proof layer.
- `NONDETERMINISTIC_DIAGNOSTICS/`: the only permitted location for runtime/RSS
  diagnostics; it is excluded from the scientific-core hash.

Start with `EXECUTIVE_VERDICT.md`, then `FINAL_REPORT.md`.  Verification and
replay commands are in `REPRODUCIBILITY.md`.
