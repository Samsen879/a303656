# Original Phase A Draft Evidence

This directory contains the untouched uploaded ZIP
`A303656_DIRECT_TWO_SQUARE_PHASE_A_DRAFT(2).zip`.

- Outer SHA256: `a1fa61b65ed734133046410d1ab3f8ac1aa697f88cc9de0e10bd5d8f094b2375`
- ZIP CRC: PASS
- Unsafe paths: none
- Symlink entries: none
- Internal manifest: 41 listed files, 41 passed
- Total files in ZIP: 42; the internal manifest does not list itself

The ZIP's own `PACKAGING_NOTES.md` states that several artifacts were
reconstructed during Phase A packaging. Their presence here authenticates the
uploaded archive; it does not make them original web-session outputs.

The authenticated extracted-file list is in
`results/draft_file_listing.txt` at the package root.
