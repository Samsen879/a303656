# Lemma: Sidon-Scale Additive Energy

Define

\[
\nu_X(h)=\sum_{t-s=h}w_X(s)w_X(t),
\qquad
E_X=\sum_{h\in\mathbb Z}\nu_X(h)^2.
\]

Equivalently, \(E_X\) counts ordered exponent-pair quadruples satisfying

\[
(3^{c_1}+5^{d_1})+(3^{c_2}+5^{d_2})
=(3^{c_3}+5^{d_3})+(3^{c_4}+5^{d_4}). \tag{1}
\]

## Theorem

As \(X\to\infty\),

\[
\boxed{E_X\ll |\mathcal D_X|^2.}
\]

More explicitly,

\[
E_X\ll(\log X)^4.
\]

The same estimate holds for the distinct-shift energy.

## Proof

Expand (1) into the signed relation

\[
3^{c_1}+3^{c_2}-3^{c_3}-3^{c_4}
+5^{d_1}+5^{d_2}-5^{d_3}-5^{d_4}=0. \tag{2}
\]

All eight terms are labeled.  Partition them into **minimal zero-sum blocks**:
each block sums to zero and no proper nonempty subblock does.  Every zero-sum
multiset admits such a partition by repeatedly extracting a minimal zero
submultiset.  There are at most the eighth Bell number, \(B_8=4140\), labeled
partition patterns, an absolute constant.

### 1. Mixed blocks

A mixed block contains at least one pure power of 3 and at least one pure power
of 5.  If it has two terms, it is a cross-base cancellation
\(3^a=5^b\), which forces \(a=b=0\), so it has \(O(1)\) assignments.

If it has at least three terms, minimality makes the corresponding homogeneous
unit equation nondegenerate.  The ambient group is
\(\Gamma=\langle3,5\rangle\).  Evertse–Győry gives finitely many projective
classes.  Because the block has both a pure-3 and a pure-5 slot, the
projective-scaling lemma in `LEMMA_COLLISIONS.md` forces the common scale to be
1.  Thus a fixed mixed block pattern has only \(O(1)\) actual assignments,
uniformly in \(X\).

### 2. Pure blocks

A pure block contains powers of one base \(q\in\{3,5\}\).  Across all of (2)
there are only two positive and two negative \(q\)-terms, so a pure block has
size at most four.

- **Size 2.**  Opposite signs force \(q^a=q^b\), hence \(a=b\).  The common
  exponent has \(O(\log X)\) choices.
- **Size 3.**  Up to sign, the equation is \(q^a+q^b=q^c\).  If
  \(a\le b\), division by \(q^a\) gives
  \(1+q^{b-a}=q^{c-a}\).  If \(c>a\), the two sides are incongruent modulo
  \(q\); if \(c=a\), the right side is 1 and the left side exceeds 1.  Hence
  no solution exists.
- **Size 4.**  It necessarily contains two positive and two negative terms,
  so
  \(q^a+q^b=q^c+q^d\).  In base \(q\), each coefficient digit on either
  side is 0, 1, or 2, and \(2<q\).  Uniqueness of base-\(q\) expansion gives
  \(\{a,b\}=\{c,d\}\) as multisets.  A positive term therefore cancels a
  negative term in a proper two-term subblock, contradicting minimality.

Thus every pure minimal block is a two-term cancellation.

### 3. Count by block pattern

A partition pattern contains at most four pure cancellation blocks.  Each such
block contributes one free exponent and hence \(O(\log X)\) choices.  Every
mixed block contributes \(O(1)\).  Therefore each pattern contributes at most
\(O((\log X)^4)\), and the number of patterns is absolute.  Summing gives

\[
E_X\ll(\log X)^4.
\]

By the curved-domain lemma,
\(|\mathcal D_X|\asymp(\log X)^2\), proving the stated Sidon-scale bound.
For distinct shifts, \(\nu_X^{\rm dist}(h)\le\nu_X(h)\) pointwise, so the same
estimate follows. \(\square\)

## Audit status

The proof is global and does not use a finite collision search.  Its novelty is
classified only as **POTENTIALLY NEW LEMMA / NOVELTY NOT ESTABLISHED**.
