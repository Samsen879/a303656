# Lemma: Structured Singular-Factor Average

Put \(b_{c,d}=3^c+5^d\), \(N_X=|\mathcal D_X|\), and \(L=\log X\).

## Theorem

For every fixed real \(A>0\),

\[
\boxed{
\sum_{\substack{u,v\in\mathcal D_X\\b_u\ne b_v}}
\left(\frac{|b_u-b_v|}{\varphi(|b_u-b_v|)}\right)^A
\ll_A N_X^2.}
\tag{1}
\]

Consequently,

\[
\boxed{
\sum_{h\ne0}\nu_X(h)
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}
\left(1+\frac2p\right)
\ll N_X^2.}
\tag{2}
\]

All implied constants are independent of \(X\).

## 1. Finite divisor-expansion reduction

We use Radomskii v6, Lemma 3.1.  In the notation needed here, if
\(a_1,\ldots,a_J\le M\) are positive integers, repetitions allowed,

\[
\omega(p)=\#\{j:p\mid a_j\},
\]

then for every fixed \(0<\alpha<1\) and positive integer \(m\),

\[
\sum_{j=1}^J\left(\frac{a_j}{\varphi(a_j)}\right)^m
\ll_{\alpha,m}
J+\sum_{p\le(\log M)^\alpha}
\frac{\omega(p)(\log p)^m}{p}. \tag{3}
\]

This is the required divisor expansion: its proof expands the Euler factors of
\(a/\varphi(a)\), separates primes at \((\log M)^\alpha\), and uses the
product constraint \(a\le M\) to absorb the large-prime part into the constant.
Equation (3) is a finite statement for a finite list; no infinite exchange is
hidden in its application below.

Take the list of all ordered nonzero differences

\[
a_{u,v}=|b_u-b_v|,
\qquad u,v\in\mathcal D_X,
\qquad b_u\ne b_v.
\]

Then \(J\le N_X^2\) and \(a_{u,v}<X\).  If

\[
A_p=\#\{(u,v)\in\mathcal D_X^2:b_u\equiv b_v\pmod p\},
\]

then the \(\omega(p)\) for the nonzero-difference list is at most \(A_p\).

## 2. Congruence and order-period count

Embed the curved domain in the rectangle

\[
0\le c\le C\ll L,
\qquad 0\le d\le D\ll L.
\]

For \(p\ne5\), fix \(c,c',d\).  The congruence

\[
3^c+5^d\equiv3^{c'}+5^{d'}\pmod p \tag{4}
\]

asks for \(5^{d'}\) to equal a fixed residue.  If that residue is zero or is
outside \(\langle5\rangle\subset(\mathbb Z/p\mathbb Z)^\times\), there is no
solution.  Otherwise \(d'\) lies in one residue class modulo
\(\operatorname{ord}_p(5)\).  Therefore

\[
A_p\ll L^3+\frac{L^4}{\operatorname{ord}_p(5)}
\qquad(p\ne5). \tag{5}
\]

The estimate remains valid for \(p=3\): only invertibility of 5 was used.
Primes \(p=2\) and \(p=5\) are treated separately by the trivial bound
\(A_p\le N_X^2\).  The curved boundary causes no endpoint loss because the
rectangle is an upper envelope.

## 3. Absolute convergence of the order series

### Lemma

For every fixed integer \(m\ge1\),

\[
\sum_{p\nmid5}\frac{(\log p)^m}{p\operatorname{ord}_p(5)}<\infty. \tag{6}
\]

### Proof

Let

\[
G_m(T)=\sum_{\substack{p\nmid5\\\operatorname{ord}_p(5)\le T}}
\frac{(\log p)^m}{p}.
\]

Every prime counted by \(G_m(T)\) divides

\[
P_T=\prod_{1\le r\le T}(5^r-1),
\]

and

\[
\log P_T\le\sum_{r\le T}r\log5=O(T^2). \tag{7}
\]

For every integer \(M\ge3\),

\[
\sum_{p\mid M}\frac{(\log p)^m}{p}
\ll_m(\log\log(3M))^m. \tag{8}
\]

To prove (8), split at \(z=\log M\).  For \(p\le z\), Chebyshev's bound and
partial summation give

\[
\sum_{p\le z}\frac{(\log p)^m}{p}\ll_m(\log z)^m.
\]

For \(p>z\), the number of distinct prime divisors is at most
\(\log M/\log z\).  For sufficiently large \(z\),
\((\log t)^m/t\) decreases on \([z,\infty)\), so their total contribution is
at most

\[
\frac{\log M}{\log z}\frac{(\log z)^m}{z}
=(\log z)^{m-1}.
\]

The bounded remaining range is absorbed into the constant.  This proves (8).
Applying (8) to \(P_T\) and using (7) yields

\[
G_m(T)\ll_m(\log(2T))^m. \tag{9}
\]

Stieltjes partial summation now gives, for \(U\ge2\),

\[
\sum_{\substack{p\nmid5\\\operatorname{ord}_p(5)\le U}}
\frac{(\log p)^m}{p\operatorname{ord}_p(5)}
=\frac{G_m(U)}U+
\int_{1^-}^{U}\frac{G_m(t)}{t^2}\,dt.
\]

The right side has a finite limit as \(U\to\infty\) by (9), because
\(\int_1^\infty(\log(2t))^m t^{-2}\,dt<\infty\).  This proves absolute
convergence. \(\square\)

## 4. Completion of the totient moment

Let \(m=\lceil A\rceil\).  Since \(n/\varphi(n)\ge1\), the left side of (1)
is bounded by the corresponding \(m\)-th moment.  Apply (3) with any fixed
\(0<\alpha<1\), \(M=X\), and (5).  The primes 2 and 5 contribute
\(O(N_X^2)\).  For the remaining primes,

\[
\sum_{p\le L^\alpha}\frac{A_p(\log p)^m}{p}
\ll
L^3\sum_{p\le L^\alpha}\frac{(\log p)^m}{p}
+L^4\sum_{p\nmid5}
\frac{(\log p)^m}{p\operatorname{ord}_p(5)}.
\]

The first prime sum is \(O_m((\log L)^m)\); the second is finite by (6).
Thus the expression is

\[
O_m(L^3(\log L)^m+L^4)=O_m(L^4).
\]

Since \(N_X\asymp L^2\), (1) follows.  Every sum before the final limiting
order series is finite and nonnegative; the limiting passage in (6) is justified
by monotone convergence and the displayed absolute bound.

## 5. FKR factor and diagonal

For \(h\ne0\),

\[
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}\left(1+\frac2p\right)
\le
\prod_{p\mid h}(1-1/p)^{-2}
=\left(\frac{|h|}{\varphi(|h|)}\right)^2,
\]

because \(1+2/p\le(1-1/p)^{-2}\).  Taking \(A=2\) proves (2).  The diagonal
\(h=0\) is not assigned a totient or singular factor and is handled separately
in the second-moment proof.  The distinct-shift sum is smaller term by term.
\(\square\)

## Audit status

The result is **PROVED**.  It is classified as **POTENTIALLY NEW LEMMA /
NOVELTY NOT ESTABLISHED**, not as a new headline theorem.
