# Almost-All Blocker — Frozen

Let \(I_X=[X,2X]\cap\mathbb Z\), \(\beta=\mathbf1_{\mathcal S_2}\), and

\[
A_s(X)=\sum_{n\in I_X}\beta(n-s),
\qquad
C_{s,t}(X)=\sum_{n\in I_X}\beta(n-s)\beta(n-t).
\]

Since

\[
R_X(n)=\sum_s w_X(s)\beta(n-s),
\qquad
\mu_X=\frac1{|I_X|}\sum_{n\in I_X}R_X(n),
\]

finite expansion gives the exact variance identity

\[
\boxed{
\sum_{n\in I_X}(R_X(n)-\mu_X)^2
=\sum_{s,t}w_X(s)w_X(t)
\left(C_{s,t}(X)-\frac{A_s(X)A_t(X)}{|I_X|}\right).}
\tag{1}
\]

A sufficient concentration input would be

\[
\boxed{
\sum_{s,t}w_X(s)w_X(t)
\left(C_{s,t}(X)-\frac{A_s(X)A_t(X)}{|I_X|}\right)
=o\!\left(\frac{X|\mathcal D_X|^2}{\log X}\right).}
\tag{2}
\]

Indeed, the square of the mean is of order
\(|\mathcal D_X|^2/\log X\); (2) and Chebyshev would make the exceptional
proportion tend to zero.

## Why the frozen inputs do not prove (2)

1. **Indicator upper bounds are unsigned.**  FKR/Nowak controls
   \(C_{s,t}\) from above but does not approximate it by the product of the two
   one-point densities with a signed error.
2. **A growing mean is not concentration.**  The fact that
   \(\mu_X\asymp(\log X)^{3/2}\to\infty\) permits large variance.
3. **Sidon-scale energy is combinatorial, not probabilistic.**  It controls how
   often differences repeat, but it gives no cancellation in the covariance
   attached to a difference.
4. **Pair upper bounds do not yield a variance asymptotic.**  They are sufficient
   for a bounded second-moment ratio and positive density, not for a ratio
   tending to 1.
5. **An \(r_2\)-weighted convolution is the wrong observable.**  Representation
   weights can be highly nonuniform; estimates for
   \(r_2(m)r_2(m+h)\) do not replace covariance of the 0–1 indicator.
6. **Boundary dependence matters.**  The intervals in \(C_{s,t}(X)\) vary with
   both shifts; any future theorem must be uniform over the growing structured
   family and preserve the exact dyadic boundary.

## Frozen status

\[
\boxed{\text{ALMOST ALL: NOT PROVED}.}
\]

No numerical covariance campaign, no further almost-all route, and no density-1
claim is authorized in this phase.
