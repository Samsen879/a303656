# Proof: Positive Density by Paley–Zygmund

Let

\[
I_X=[X,2X]\cap\mathbb Z,
\qquad |I_X|=X+1
\]

for integer \(X\).  Equip \(I_X\) with the uniform probability measure and
write \(Z(n)=R_X(n)\).

The first-moment theorem gives constants \(a>0\) and \(X_1\) such that

\[
\mathbb E Z=\frac{M_1(X)}{|I_X|}
\ge a(\log X)^{3/2} \tag{1}
\]

for \(X\ge X_1\).  The second-moment theorem gives a constant \(b>0\) and
\(X_2\) such that

\[
\mathbb E Z^2=\frac{M_2(X)}{|I_X|}
\le b(\log X)^3. \tag{2}
\]

For any fixed \(0<\theta<1\), Paley–Zygmund gives

\[
\mathbb P(Z\ge\theta\mathbb EZ)
\ge(1-\theta)^2\frac{(\mathbb EZ)^2}{\mathbb EZ^2}
\ge(1-\theta)^2\frac{a^2}{b}. \tag{3}
\]

Take \(\theta=1/2\).  With

\[
c_0=a/2,
\qquad
c_1=\frac{a^2}{8b},
\]

and after increasing \(X_0=\max(X_1,X_2)\) so that \(X+1\ge X\), (3) yields

\[
\boxed{
\#\{n\in I_X:R_X(n)\ge c_0(\log X)^{3/2}\}\ge c_1X.}
\tag{4}
\]

The exact numerical values of \(a,b,c_0,c_1,X_0\) are not extracted.  Their
dependence is only on bases 3 and 5 and the absolute constants in the
Landau–Ramanujan and FKR/Nowak estimates.

For distinct shifts, the distinct first and second moments give the same proof.
Alternatively, collision finiteness gives uniformly

\[
0\le R_X(n)-R_X^{\rm dist}(n)
\le\sum_s(w_X(s)-1)_+
=N_X-|\mathcal B_X|=O(1).
\]

For large \(X\), subtracting this bounded quantity from the threshold in (4)
and reducing \(c_0\) by a fixed factor proves the distinct statement.

The result is a **positive lower density** theorem.  It says neither “almost
all” nor “all”. \(\square\)
