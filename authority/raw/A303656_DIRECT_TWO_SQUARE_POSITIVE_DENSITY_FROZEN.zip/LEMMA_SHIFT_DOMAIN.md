# Lemma: Curved Shift Domain and Scale Stability

Let \(X\ge4\) be real and put \(Y=X/2\).  Define

\[
\mathcal D_X=\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le Y\},
\qquad N_X=|\mathcal D_X|.
\]

## Lemma 1 (curved-domain asymptotic)

As \(X\to\infty\),

\[
\boxed{N_X=\frac{(\log X)^2}{\log3\,\log5}+O(\log X).}
\]

The implied constant is absolute.

### Proof

Set

\[
C=\left\lfloor\frac{\log Y}{\log3}\right\rfloor,
\qquad
D=\left\lfloor\frac{\log Y}{\log5}\right\rfloor.
\]

Every point of \(\mathcal D_X\) lies in
\(\mathcal R=[0,C]\times[0,D]\cap\mathbb Z^2\), and

\[
|\mathcal R|=(C+1)(D+1)
=\frac{(\log X)^2}{\log3\log5}+O(\log X).
\]

It remains to bound the points of \(\mathcal R\) above the curved boundary.
If \(3^c+5^d>Y\), then at least one summand exceeds \(Y/2\).  The interval
\((Y/2,Y]\) contains at most one power of 3: two such powers would have ratio
at most 2, while two distinct powers of 3 have ratio at least 3.  The same
argument applies to powers of 5.  Hence the excluded set is contained in the
union of at most one complete row and at most one complete column of
\(\mathcal R\), and therefore has at most

\[
(C+1)+(D+1)=O(\log X)
\]

points.  Subtracting this controlled corner proves the formula. \(\square\)

## Lemma 2 (fixed-scale stability)

For every fixed \(0<\theta<1\),

\[
N_{\theta X}=N_X+O_\theta(\log X)
\]

and therefore

\[
\frac{N_{\theta X}}{N_X}=1+O_\theta\!\left(\frac1{\log X}\right),
\qquad
N_{\theta X}\asymp_\theta N_X.
\]

### Proof

Apply Lemma 1 with \(\theta X\):

\[
N_{\theta X}=
\frac{(\log X+\log\theta)^2}{\log3\log5}+O_\theta(\log X).
\]

Expanding the square and comparing with Lemma 1 gives the first assertion.
Since \(N_X\asymp(\log X)^2\), division gives the ratio estimate.  For all
sufficiently large \(X\), the ratio lies, for example, between \(1/2\) and
\(3/2\); enlarging the constants handles the remaining bounded range.
The constants may depend on \(\theta\), and on no other parameter. \(\square\)

## Corollary (Radomskii growth condition)

Let

\[
B(x)=\#\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le x\}.
\]

Then \(B(x)=N_{2x}\), so

\[
B(x)\asymp(\log x)^2,
\qquad B(x/2)=N_x\gg N_{2x}=B(x).
\]
