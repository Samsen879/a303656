# Frozen Bibliography

1. **Edmund Landau**, “Über die Einteilung der positiven ganzen Zahlen in vier
   Klassen nach der Mindestzahl der zu ihrer additiven Zusammensetzung
   erforderlichen Quadrate,” *Archiv der Mathematik und Physik*, series 3,
   **13** (1908), 305–312.

2. **Hubert Delange**, “Généralisation du théorème de Ikehara,” *Annales
   scientifiques de l'École Normale Supérieure*, 3e série, **71** (1954),
   no. 3, 213–242.  NUMDAM item `ASENS_1954_3_71_3_213_0`.

3. **J. H. Evertse and K. Győry**, “On the numbers of solutions of weighted
   unit equations,” *Compositio Mathematica* **66** (1988), no. 3, 329–354.
   NUMDAM item `CM_1988__66_3_329_0`.

4. **H. Halberstam and H. E. Richert**, *Sieve Methods*, London Mathematical
   Society Monographs, Academic Press, 1974.  This is the source cited by
   Radomskii for the primitive-set pair upper bound.

5. **Werner Georg Nowak**, “On the distribution of M-tuples of B-numbers,”
   *Publications de l'Institut Mathématique (Nouvelle série)* **77(91)**
   (2005), 71–78.  DOI 10.2298/PIM0591071N; arXiv:math/0410010.

6. **Roger Clement Crocker**, “On the sum of two squares and two powers of
   k,” *Colloquium Mathematicum* **112** (2008), no. 2, 235–267.
   DOI 10.4064/cm112-2-3.

7. **John Friedlander and Henryk Iwaniec**, *Opera de Cribro*, American
   Mathematical Society Colloquium Publications, vol. 57, AMS, 2010.

8. **Tristan Freiberg, Pär Kurlberg, and Lior Rosenzweig**, “Poisson
   distribution for gaps between sums of two squares and level spacings for
   toral point scatterers,” *Communications in Number Theory and Physics*
   **11** (2017), no. 4, 837–877.
   DOI 10.4310/CNTP.2017.v11.n4.a3; arXiv:1701.01157.

9. **Artyom Radomskii**, “On Romanoff's theorem,” *Izvestiya: Mathematics*
   **87** (2023), no. 1, 113–153.  Cited in Radomskii v6 for the totient-moment
   divisor-expansion lemma.

10. **Artyom Radomskii**, “Variants of Romanoff's theorem,”
    arXiv:2504.09954v6, revised 13 July 2026.  Version lock applies throughout
    this package.

Exact inspected-PDF hashes and source locations are in
`results/source_locks.json`.
