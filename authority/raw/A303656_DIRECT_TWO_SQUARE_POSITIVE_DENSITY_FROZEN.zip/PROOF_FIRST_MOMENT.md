# Proof: Exact First Moment

For real \(y\), define

\[
B_2(y)=\#\{m\in\mathbb Z_{\ge0}:m\le y,\ m\in\mathcal S_2\},
\]

with \(B_2(y)=0\) for \(y<0\).  Let

\[
K=\frac1{\sqrt2}
\prod_{p\equiv3\pmod4}(1-p^{-2})^{-1/2}
\]

be the Landau–Ramanujan constant.

## 1. Selberg–Delange input and constant

The Dirichlet series of the indicator of positive sums of two squares is

\[
F(z)=(1-2^{-z})^{-1}
\prod_{p\equiv1(4)}(1-p^{-z})^{-1}
\prod_{p\equiv3(4)}(1-p^{-2z})^{-1}.
\]

Using the Euler products of \(\zeta(z)\) and \(L(z,\chi_4)\),

\[
F(z)^2=\zeta(z)L(z,\chi_4)(1-2^{-z})^{-1}
\prod_{p\equiv3(4)}(1-p^{-2z})^{-1}.
\]

Thus \(F(z)=\zeta(z)^{1/2}G(z)\), where \(G\) is analytic and nonzero near
1.  Delange's theorem gives

\[
B_2(y)=K\frac{y}{\sqrt{\log y}}+
O\!\left(\frac{y}{(\log y)^{3/2}}\right) \tag{1}
\]

for \(y\ge3\).  Adding the value \(m=0\) changes the counting function by
one and is absorbed by the error term.  Evaluating \(G(1)/\Gamma(1/2)\)
gives exactly the displayed \(K\).

## 2. Uniform translated interval

Fix an integer \(X\) and a shift \(0\le s\le X/2\).  Inclusive endpoints give

\[
\sum_{X\le n\le2X}\beta(n-s)
=B_2(2X-s)-B_2(X-s-1). \tag{2}
\]

For all sufficiently large \(X\), both arguments in (2) lie between
\(X/2-1\) and \(2X\).  Let

\[
f(y)=\frac{y}{\sqrt{\log y}}.
\]

Uniformly on that multiplicative interval,

\[
f'(y)=\frac1{\sqrt{\log y}}-
\frac1{2(\log y)^{3/2}}
=\frac1{\sqrt{\log X}}+O\!\left((\log X)^{-3/2}\right). \tag{3}
\]

The two endpoints in (2) differ by \(X+1\).  The mean-value theorem and (3)
give

\[
f(2X-s)-f(X-s-1)
=\frac X{\sqrt{\log X}}+
O\!\left(\frac X{(\log X)^{3/2}}\right). \tag{4}
\]

The two error terms from (1) are uniformly
\(O(X(\log X)^{-3/2})\).  Combining (1), (2), and (4),

\[
\sum_{X\le n\le2X}\beta(n-s)
=K\frac X{\sqrt{\log X}}+
O\!\left(\frac X{(\log X)^{3/2}}\right), \tag{5}
\]

uniformly for every \(s\le X/2\).  In this range
\(n-s\ge X/2>0\), so \(m=0\) never occurs in the actual translated interval.
The inclusive `+1` in its length contributes only
\(O((\log X)^{-1/2})\), already absorbed in (5).

## 3. Weighted first moment

Interchange the two finite sums:

\[
M_1(X):=\sum_{X\le n\le2X}R_X(n)
=\sum_{(c,d)\in\mathcal D_X}
\sum_{X\le n\le2X}\beta(n-3^c-5^d).
\]

By (5),

\[
M_1(X)=N_XK\frac X{\sqrt{\log X}}+
O\!\left(N_X\frac X{(\log X)^{3/2}}\right).
\]

Using

\[
N_X=\frac{(\log X)^2}{\log3\log5}+O(\log X),
\]

we obtain

\[
\boxed{
M_1(X)=\frac K{\log3\log5}X(\log X)^{3/2}
+O\bigl(X(\log X)^{1/2}\bigr).}
\tag{6}
\]

## 4. Distinct shifts and finite collisions

The collision theorem gives \(|\mathcal B_X|=N_X+O(1)\).  Applying (5) once
for every distinct shift gives

\[
\sum_{X\le n\le2X}R_X^{\rm dist}(n)
=|\mathcal B_X|K\frac X{\sqrt{\log X}}
+O\!\left(|\mathcal B_X|\frac X{(\log X)^{3/2}}\right).
\]

The replacement of \(N_X\) by \(|\mathcal B_X|\) changes the expression by
only \(O(X/\sqrt{\log X})\), which is smaller than the error in (6).  Hence the
distinct-shift first moment has the same leading constant and error term.
\(\square\)

## Primitive-subset warning

No primitive-subset constant enters (6).  For the separate set
\(\mathcal S'_2=\langle P_1\rangle\), exact Euler-product algebra gives
\(1/(4K)\), not \(K/2\); see `SOURCE_CORRECTIONS.md`.
