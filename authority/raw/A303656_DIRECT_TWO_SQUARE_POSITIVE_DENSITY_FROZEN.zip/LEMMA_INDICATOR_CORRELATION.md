# Lemma: Indicator-Level Correlation for Sums of Two Squares

Let

\[
\beta(m)=\mathbf1_{\mathcal S_2}(m),
\qquad
\mathcal S_2=\{a^2+b^2:a,b\in\mathbb Z_{\ge0}\}.
\]

## Primary-source statement

Freiberg–Kurlberg–Rosenzweig, §2.1, page 6 of the published article (page 5
of arXiv:1701.01157v1), gives the following unnumbered Selberg-sieve upper
bound, with the general case credited to Nowak.  For fixed \(k\) and distinct
integer shifts \(h_1,\ldots,h_k\),

\[
\sum_{n\le x}\prod_{i=1}^k\beta(n+h_i)
\ll_k\frac{x}{(\log x)^{k/2}}
\prod_{\substack{p\equiv3\pmod4\\p\mid h_j-h_i\text{ for some }i<j}}
\left(1+\frac{k}{p}\right). \tag{1}
\]

The source's convention states that \(\ll_k\) depends only on \(k\); the
arithmetic dependence on the shifts is displayed in the product.  This is an
indicator theorem, not a theorem for \(r_2(n)r_2(n+h)\).

## Corollary for pairs

For every nonzero integer \(h\),

\[
\boxed{
Q_h(x):=\sum_{m\le x}\beta(m)\beta(m+h)
\ll \frac{x}{\log x}
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}
\left(1+\frac2p\right).}
\tag{2}
\]

For negative \(h\), substitute \(u=m+h\) and use \(|h|\); the same factor
results.  The factor at \(p=2\) is absent from the product in (1) and is absorbed
in the absolute implied constant.

## Boundary-aware envelope used in this project

For \(s,t\le X/2\), set \(h=t-s\).  The exact pair sum in the second moment is

\[
\sum_{m=X-t}^{2X-t}\beta(m)\beta(m+h). \tag{3}
\]

Both \(m\) and \(m+h\) lie in \([X/2,2X]\).  If \(h>0\), (3) is bounded by
\(Q_h(2X)\); if \(h<0\), change variables and bound by \(Q_{|h|}(2X)\).
Moreover \(|h|\le X/2\).  Hence, uniformly for every off-diagonal pair,

\[
(3)\ll\frac{X}{\log X}
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}
\left(1+\frac2p\right). \tag{4}
\]

The interval length and translated endpoints cause only the replacement of
\(x\) by \(2X\), which changes the absolute constant.  The diagonal \(h=0\)
is not inserted into (2); it is bounded by the one-point Landau–Ramanujan
count.

## Bibliographic lock

Tristan Freiberg, Pär Kurlberg, and Lior Rosenzweig,
*Poisson distribution for gaps between sums of two squares and level spacings
for toral point scatterers*, *Communications in Number Theory and Physics*
**11** (2017), no. 4, 837–877, DOI 10.4310/CNTP.2017.v11.n4.a3.

The exact source location is an unnumbered display in §2.1; this package does
not invent a theorem or lemma number.
