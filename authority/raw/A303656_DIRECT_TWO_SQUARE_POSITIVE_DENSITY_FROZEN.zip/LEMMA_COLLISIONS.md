# Lemma: Global Collision Finiteness and Bounded Shift Multiplicity

Write

\[
b_{c,d}=3^c+5^d,
\qquad
\mathcal B_X=\{b_{c,d}:(c,d)\in\mathcal D_X\},
\qquad
w_X(s)=\#\{(c,d)\in\mathcal D_X:b_{c,d}=s\}.
\]

## Primary unit-equation input

Let \(K\) be a finitely generated extension of \(\mathbb Q\), let
\(\Gamma\subset K^\times\) be a finitely generated multiplicative group, and
fix nonzero coefficients \(\alpha_1,\ldots,\alpha_r\in K\).  Evertse–Győry,
Theorem 1, proves that

\[
\alpha_1x_1+\cdots+\alpha_rx_r=1,
\qquad x_i\in\Gamma,
\]

has only finitely many **nondegenerate** solutions, where nondegenerate means
that no nonempty subsum \(\sum_{i\in I}\alpha_ix_i\) vanishes.

Here the ambient group is explicitly

\[
\Gamma=\langle3,5\rangle
=\{3^u5^v:u,v\in\mathbb Z\}\subset\mathbb Q^\times.
\]

## Lemma 1 (projective finiteness for a homogeneous block)

Fix coefficients \(\varepsilon_i\in\{+1,-1\}\).  Homogeneous solutions of

\[
\sum_{i=1}^r\varepsilon_i y_i=0,
\qquad y_i\in\Gamma,
\]

having no proper nonempty zero subsum occupy only finitely many projective
\(\Gamma\)-classes under simultaneous scaling
\((y_1,\ldots,y_r)\mapsto(\gamma y_1,\ldots,\gamma y_r)\).

### Proof

Choose the last coordinate as anchor and divide by
\(-\varepsilon_r y_r\).  The ratios \(x_i=y_i/y_r\) lie in \(\Gamma\) and
satisfy a fixed weighted equation with right side 1.  A zero subsum among its
left-side terms would be a proper zero subsum of the original homogeneous
relation.  Thus the normalized solution is nondegenerate, and Evertse–Győry
gives finitely many ratio tuples.  These ratio tuples are exactly the
projective classes. \(\square\)

## Lemma 2 (loss of projective scaling for mixed pure-power slots)

Suppose a projective class contains an actual assignment with at least one slot
required to be a pure power of 3 and at least one slot required to be a pure
power of 5.  Then that class contains at most one actual assignment with the
same slot requirements.

### Proof

If two actual assignments in the same class differ by \(\gamma\in\Gamma\),
then comparison at a pure-3 slot gives

\[
\gamma=3^{u'-u}\in\langle3\rangle,
\]

whereas comparison at a pure-5 slot gives

\[
\gamma=5^{v'-v}\in\langle5\rangle.
\]

Unique factorization in \(\mathbb Q^\times\) gives

\[
\langle3\rangle\cap\langle5\rangle=\{1\}.
\]

Hence \(\gamma=1\), so every exponent in the two assignments is equal.
\(\square\)

## Theorem (finite nontrivial collisions)

The equation

\[
3^c+5^d=3^{c'}+5^{d'},
\qquad c,d,c',d'\in\mathbb Z_{\ge0},
\]

has only finitely many nontrivial exponent quadruples.

### Proof

Rewrite it as

\[
3^c+5^d-3^{c'}-5^{d'}=0. \tag{1}
\]

First suppose (1) is nondegenerate, meaning that no proper nonempty subset of
its four signed terms sums to zero.  Lemma 1 gives finitely many projective
classes.  Each class has a pure-3 slot and a pure-5 slot, so Lemma 2 makes each
class contain at most one actual exponent assignment.  Hence there are only
finitely many nondegenerate collisions.

Now suppose (1) is degenerate.  A one-term zero block is impossible.  A
three-term zero block would leave a one-term zero complement and is also
impossible.  Thus a proper zero block has two terms of opposite sign.

- A same-base cancellation, such as \(3^c-3^{c'}=0\), forces
  \(c=c'\), and the remaining terms force \(d=d'\).
- A cross-base cancellation forces \(3^c=5^{d'}\).  Unique factorization gives
  \(c=d'=0\); the complementary equality similarly gives \(d=c'=0\).

Every degenerate solution is therefore the trivial identity obtained by matching
the two exponent pairs.  This proves global finiteness of nontrivial collisions.
\(\square\)

## Corollaries

Let

\[
K_{\rm coll}=\sum_s\binom{w_\infty(s)}2,
\]

where the sum ranges over all global shift values and
\(w_\infty(s)=\#\{(c,d):3^c+5^d=s\}\).  The theorem gives
\(K_{\rm coll}<\infty\).  Hence, uniformly in \(X\),

\[
\sum_s\binom{w_X(s)}2\le K_{\rm coll}.
\]

It follows that

\[
\boxed{|\mathcal B_X|=|\mathcal D_X|+O(1)},
\]
\[
\boxed{\max_s w_X(s)=O(1)},
\]
\[
\boxed{\sum_s w_X(s)^2=|\mathcal D_X|+O(1)}.
\]

The constants are absolute but ineffective with the cited form of the
unit-equation theorem.  No enumeration of all collisions, and in particular no
claim that shift 28 is globally unique, is part of the proof.
