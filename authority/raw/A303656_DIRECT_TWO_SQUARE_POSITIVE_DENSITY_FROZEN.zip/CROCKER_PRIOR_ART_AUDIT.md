# Crocker and One-Dimensional Prior-Art Audit

## Locked source

Roger Clement Crocker, *On the sum of two squares and two powers of k*,
*Colloquium Mathematicum* **112** (2008), no. 2, 235–267,
DOI 10.4064/cm112-2-3.

## Exact scope

The abstract states that, for every fixed integer \(k\ge2\), the positive
integers representable as two squares plus one power of \(k\) have positive
density.  It then observes that allowing at most two powers also has positive
density.

The paper's stated main purpose and numbered theorems are different: they prove
that infinitely many positive integers fail to be representable as two squares
plus two or fewer powers.  For example, Theorem 1 treats \(k=2\) and produces
infinitely many even exceptions.  The article does not prove a lower bound of
order \((\log X)^{3/2}\) for representation multiplicity.

Accordingly:

| Question | Crocker 2008 |
|---|---|
| Positive density for two squares plus one fixed-base power | Stated as established in the abstract. |
| Positive density after allowing two powers | Immediate support consequence stated in the abstract. |
| Asymptotic density with an explicit constant | Not supplied as the central theorem audited here. |
| Growing representation multiplicity | Not supplied. |
| Two independent exponent variables with bases 3 and 5 | Not the specialized theorem of the paper. |
| Universal representation | Explicitly false for every fixed base \(k\) in Crocker's setting, because infinitely many exceptions are proved. |

## Consequence for A303656 support novelty

Take \(k=3\).  A positive-density set of integers has the form

\[
m=a^2+b^2+3^c.
\]

Translation by 1 preserves lower density, so a positive-density set has the
form

\[
n=a^2+b^2+3^c+1,
\]

which is exactly the \(d=0\) subfamily of the A303656 expression.  Therefore
**bare positive-density support is one-dimensional prior art** and cannot be
presented as the novelty of the two-base theorem.

The stronger claim that a positive proportion has
\(\Omega((\log X)^{3/2})\) exponent-pair representations is not Crocker's
claim, but it is substantially subsumed by Radomskii v6.
