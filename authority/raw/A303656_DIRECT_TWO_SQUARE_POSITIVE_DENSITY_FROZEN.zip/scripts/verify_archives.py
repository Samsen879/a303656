#!/usr/bin/env python3
"""Read-only safe audit of the two original evidence ZIPs."""
from __future__ import annotations
import argparse
import hashlib
import os
import re
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

EXPECTED = {
    "ORIGINAL_PHASE_A_DRAFT/A303656_DIRECT_TWO_SQUARE_PHASE_A_DRAFT(2).zip":
        "a1fa61b65ed734133046410d1ab3f8ac1aa697f88cc9de0e10bd5d8f094b2375",
    "FORMAL_AUDIT/A303656_DIRECT_TWO_SQUARE_PHASE_A_FORMAL_AUDIT(1).zip":
        "e3d8559c32bc64e046b85032c4111145092f4f63e373e0d0355932a43f972e15",
}

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def safe_name(name: str) -> bool:
    p = PurePosixPath(name)
    return not p.is_absolute() and ".." not in p.parts and not re.match(r"^[A-Za-z]:", name)

def is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--package-root", required=True)
    ns = ap.parse_args()
    root = Path(ns.package_root)
    errors = []
    for rel, expected in EXPECTED.items():
        path = root / rel
        got = sha(path)
        print(f"{rel}: sha256={got}")
        if got != expected:
            errors.append(f"outer hash mismatch: {rel}")
        with zipfile.ZipFile(path) as zf:
            bad_names = [i.filename for i in zf.infolist() if not safe_name(i.filename)]
            links = [i.filename for i in zf.infolist() if is_symlink(i)]
            crc_bad = zf.testzip()
            print(f"  files={sum(not i.is_dir() for i in zf.infolist())} unsafe={len(bad_names)} symlinks={len(links)} crc_bad={crc_bad}")
            if bad_names or links or crc_bad:
                errors.append(f"ZIP safety/CRC failure: {rel}")
            if "DRAFT" in rel:
                manifest_name = "A303656_phaseA_package/SHA256SUMS.txt"
                lines = zf.read(manifest_name).decode("utf-8").splitlines()
                passed = 0
                for line in lines:
                    digest, name = line.split("  ", 1)
                    clean = name.removeprefix("./")
                    data = zf.read("A303656_phaseA_package/" + clean)
                    if hashlib.sha256(data).hexdigest() != digest:
                        errors.append(f"internal manifest mismatch: {clean}")
                    else:
                        passed += 1
                print(f"  internal_manifest={passed}/{len(lines)}")
            else:
                names = {i.filename for i in zf.infolist()}
                if any(n.endswith("SHA256SUMS.txt") for n in names):
                    errors.append("unexpected audit manifest status")
                print("  internal_manifest=ABSENT")
    if errors:
        print("FAIL")
        for e in errors:
            print(e)
        return 1
    print("PASS")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
