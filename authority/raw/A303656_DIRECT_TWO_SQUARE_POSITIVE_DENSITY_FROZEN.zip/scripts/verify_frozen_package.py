#!/usr/bin/env python3
"""Read-only verifier for manifests, core, required files, and evidence locks."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

REQUIRED = {
"FINAL_REPORT.md","EXECUTIVE_VERDICT.md","FINAL_VERDICT.json",
"THEOREM_POSITIVE_DENSITY.md","LEMMA_SHIFT_DOMAIN.md","LEMMA_COLLISIONS.md",
"LEMMA_ADDITIVE_ENERGY.md","LEMMA_SINGULAR_FACTOR_AVERAGE.md",
"LEMMA_INDICATOR_CORRELATION.md","PROOF_FIRST_MOMENT.md",
"PROOF_SECOND_MOMENT.md","PROOF_POSITIVE_DENSITY.md",
"RADOMSKII_CONDITION_CROSSWALK.md","RADOMSKII_SUBSUMPTION_VERDICT.md",
"CROCKER_PRIOR_ART_AUDIT.md","NOVELTY_CLASSIFICATION.md",
"ALMOST_ALL_BLOCKER.md","BIBLIOGRAPHY.md","SOURCE_CORRECTIONS.md",
"LIMITATIONS.md","REPRODUCIBILITY.md","environment.json",
"SCIENTIFIC_CORE.json","SCIENTIFIC_CORE.sha256","SHA256SUMS.txt"
}

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--package-root", required=True)
    ns = ap.parse_args()
    root = Path(ns.package_root)
    errors = []
    missing = sorted(p for p in REQUIRED if not (root / p).is_file())
    if missing:
        errors.extend(f"missing required file: {p}" for p in missing)
    manifest_bytes = (root / "SCIENTIFIC_CORE.json").read_bytes()
    expected_core_hash = (root / "SCIENTIFIC_CORE.sha256").read_text("utf-8").split()[0]
    if hashlib.sha256(manifest_bytes).hexdigest() != expected_core_hash:
        errors.append("SCIENTIFIC_CORE.sha256 mismatch")
    core = json.loads(manifest_bytes)
    for item in core["files"]:
        p = root / item["path"]
        if not p.is_file() or p.stat().st_size != item["bytes"] or sha(p) != item["sha256"]:
            errors.append(f"scientific core mismatch: {item['path']}")
            continue
        data = p.read_bytes()
        bad = [(offset, value) for offset, value in enumerate(data)
               if value < 32 and value not in (9, 10)]
        if bad:
            preview = ", ".join(f"offset={offset}:0x{value:02x}" for offset, value in bad[:8])
            errors.append(f"unexpected control byte in {item['path']}: {preview}")
    for line in (root / "SHA256SUMS.txt").read_text("utf-8").splitlines():
        digest, rel = line.split("  ", 1)
        p = root / rel
        if not p.is_file() or sha(p) != digest:
            errors.append(f"full manifest mismatch: {rel}")
    if errors:
        print("FAIL")
        for e in errors:
            print(e)
        return 1
    print("PASS")
    print(f"scientific_core_files={len(core['files'])}")
    print(f"scientific_core_sha256={expected_core_hash}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
