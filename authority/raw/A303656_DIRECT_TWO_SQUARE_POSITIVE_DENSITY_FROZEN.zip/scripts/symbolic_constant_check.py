#!/usr/bin/env python3
"""Exact exponent-pair check for the primitive two-square constant."""
from fractions import Fraction
import json

# A monomial 2^a P^b is represented by (a,b).
K = (Fraction(-1, 2), Fraction(-1, 2))
kappa = (Fraction(-3, 2), Fraction(1, 2))
printed = (Fraction(-3, 2), Fraction(-1, 2))  # K/2
product = (K[0] + kappa[0], K[1] + kappa[1])
result = {
    "basis": ["2", "P"],
    "K_exponents": [str(x) for x in K],
    "kappa_exponents": [str(x) for x in kappa],
    "kappa_times_K_exponents": [str(x) for x in product],
    "kappa_times_K_equals_one_quarter": product == (Fraction(-2), Fraction(0)),
    "kappa_equals_one_over_4K": product == (Fraction(-2), Fraction(0)),
    "printed_K_over_2_exponents": [str(x) for x in printed],
    "printed_K_over_2_equals_kappa": printed == kappa,
}
print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
