# Deterministic scripts

- `generate_scientific_core.py`: self-contained canonical core generator.
- `replay_scientific_core.py`: byte-comparison wrapper; read-only on the frozen root.
- `verify_archives.py`: safe ZIP and internal-manifest audit.
- `symbolic_constant_check.py`: exact primitive-constant algebra.
- `verify_frozen_package.py`: full read-only verifier.
- `build_deterministic_zip.py`: sorted, fixed-timestamp, stored ZIP builder.

No script computes new \(T(n)\), scans intervals, searches counterexamples, or
runs an almost-all campaign.
