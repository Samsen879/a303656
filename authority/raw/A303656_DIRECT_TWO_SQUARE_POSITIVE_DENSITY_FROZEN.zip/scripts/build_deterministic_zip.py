#!/usr/bin/env python3
"""Build a byte-deterministic ZIP using stored entries and fixed metadata."""
from __future__ import annotations
import argparse
import os
import zipfile
from pathlib import Path

FIXED_DATE = (1980, 1, 1, 0, 0, 0)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True)
    ap.add_argument("--output", required=True)
    ns = ap.parse_args()
    root = Path(ns.source).resolve()
    out = Path(ns.output).resolve()
    paths = sorted(
        (p for p in root.rglob("*") if p.is_file()),
        key=lambda p: p.relative_to(root).as_posix().encode("utf-8"),
    )
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as zf:
        for path in paths:
            rel = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(rel, FIXED_DATE)
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = (0o100644 << 16)
            info.flag_bits |= 0x800
            with path.open("rb") as fh:
                zf.writestr(info, fh.read())
    print(out)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
