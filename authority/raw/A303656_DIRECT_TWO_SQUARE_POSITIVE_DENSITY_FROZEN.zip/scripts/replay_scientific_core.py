#!/usr/bin/env python3
"""Compare two fresh replays with the frozen scientific core; read-only."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--frozen-root", required=True)
    ap.add_argument("--replay-a", required=True)
    ap.add_argument("--replay-b", required=True)
    ns = ap.parse_args()
    roots = [Path(ns.frozen_root), Path(ns.replay_a), Path(ns.replay_b)]
    manifests = [json.loads((r / "SCIENTIFIC_CORE.json").read_text("utf-8")) for r in roots]
    expected_paths = [item["path"] for item in manifests[0]["files"]]
    errors = []
    for r in roots[1:]:
        got = [item["path"] for item in json.loads((r / "SCIENTIFIC_CORE.json").read_text("utf-8"))["files"]]
        if got != expected_paths:
            errors.append(f"path-list mismatch: {r}")
    compare_paths = expected_paths + ["SCIENTIFIC_CORE.json", "SCIENTIFIC_CORE.sha256"]
    for rel in compare_paths:
        hashes = [sha(r / rel) for r in roots]
        if len(set(hashes)) != 1:
            errors.append(f"byte mismatch {rel}: {hashes}")
    if errors:
        print("FAIL")
        for e in errors:
            print(e)
        return 1
    print("PASS")
    print(f"compared_files={len(compare_paths)}")
    print(f"scientific_core_sha256={sha(roots[0] / 'SCIENTIFIC_CORE.json')}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
