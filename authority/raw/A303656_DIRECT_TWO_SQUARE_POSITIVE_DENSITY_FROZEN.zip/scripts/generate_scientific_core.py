#!/usr/bin/env python3
"""Generate the deterministic scientific core for the A303656 Phase B freeze.

The scientific payload is generated from literal UTF-8 templates, exact JSON,
and exact symbolic exponent arithmetic.  No wall-clock time, runtime, RSS, or
floating-point numerical experiment enters the scientific core.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import stat
import sys
import textwrap
from fractions import Fraction
from pathlib import Path
from typing import Any

FREEZE_DATE = "2026-07-17"
PACKAGE_NAME = "A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN"
GENERATOR_REL = "scripts/generate_scientific_core.py"
GENERATOR_COMMAND = (
    "python3 scripts/generate_scientific_core.py --output <fresh-directory> --core-only"
)
PYTHON_VERSION = "3.13.5"
PLATFORM_LOCK = "Linux 4.4.0 x86_64"
GCC_VERSION = "gcc (Debian 14.2.0-19) 14.2.0"
COREUTILS_VERSION = "sha256sum (GNU coreutils) 9.7"
ZIP_TOOL_VERSION = "deterministic Python zipfile ZIP_STORED; fixed DOS timestamp 1980-01-01"

INPUT_HASHES = {
    "A303656_DIRECT_TWO_SQUARE_PHASE_A_DRAFT(2).zip": "a1fa61b65ed734133046410d1ab3f8ac1aa697f88cc9de0e10bd5d8f094b2375",
    "A303656_DIRECT_TWO_SQUARE_PHASE_A_FORMAL_AUDIT(1).zip": "e3d8559c32bc64e046b85032c4111145092f4f63e373e0d0355932a43f972e15",
    "Pasted markdown(15).md": "f1e0068430126d751b7c584206fd19e16c9b01792a9c8e464da14786886b746b",
    "分工规则.txt": "94261338e1d2e0a348ff264e9a98322b647918eeca74b0932dcd90bac980b5f6",
    "项目简介.txt": "42903e1adb5731d195786538a1072aa5b54a5c2adbf7fe6b963226fa74a139ae",
}

SOURCE_PDF_HASHES = {
    "crocker_2008.pdf": "8026ccf29f9e0a19215cd81687cdedd667bbf4d99963d1c2159bcff3c61f8f75",
    "delange_1954.pdf": "4934b4bfba12d405fc267fa0c0318c3034ab29c9e8223388019377bb45ca0998",
    "evertse_gyory_1988.pdf": "2b2f0a19781399836ccca57608fb039d39e645d3fea2de2794a33e06d6d990e0",
    "fkr_1701.01157v1.pdf": "523a2921bca1f1a52ea9bef4e00a0a2bde61a26fa967c0ccb164761d05ae8c26",
    "radomskii_2504.09954v6.pdf": "a9a65fcdf0aad4877bbe1fd5ab0f83e39d4cb4bb55c276c2ec3b2ebbb2a4a378",
}

DRAFT_FILES = [
    "EXECUTIVE_VERDICT.md",
    "PACKAGING_NOTES.md",
    "REPORT.md",
    "ROUTE_VERDICT.json",
    "SHA256SUMS.txt",
    "almost_all_analysis.md",
    "candidate_theorems.md",
    "computational_experiments.md",
    "conditional_theorems.md",
    "difference_singular_average.md",
    "environment.json",
    "first_moment.md",
    "indicator_correlation_literature.md",
    "limitations.md",
    "logs/aggregate_crosscheck.log",
    "logs/direct_mark_crosscheck.log",
    "logs/reconstruction_validation.log",
    "logs/representation_aggregate.stderr.log",
    "logs/representation_aggregate.stdout.log",
    "logs/shift_analysis.log",
    "logs/shift_analysis.stderr.log",
    "logs/shift_analysis.stdout.log",
    "mathematical_framework.md",
    "positive_density_theorem.md",
    "results/additive_energy_scaling.csv",
    "results/aggregate_crosscheck.json",
    "results/multiplicity_histograms.json",
    "results/representation_aggregate_statistics.csv",
    "results/shift_statistics.csv",
    "results/singular_factor_averages.csv",
    "results/subfamily_comparison.csv",
    "results/two_square_indicator_crosscheck.json",
    "route_comparison.md",
    "scripts/aggregate_crosscheck.py",
    "scripts/direct_mark_crosscheck.py",
    "scripts/representation_aggregate.cpp",
    "scripts/run_all.sh",
    "scripts/shift_analysis.py",
    "second_moment_identity.md",
    "shift_domain_and_collisions.md",
    "shift_subfamily_comparison.md",
    "sieve_correlation_bounds.md",
]
AUDIT_FILES = ["AUDIT_VERDICT.json", "REPORT.md", "SOURCE_CORRECTIONS.md"]


def md(text: str) -> str:
    return textwrap.dedent(text).strip() + "\n"


TEXT_FILES: dict[str, str] = {}

TEXT_FILES["README.md"] = md(r"""
# A303656 Direct Two-Square Positive-Density Theorem — Phase B Frozen Package

Freeze date: **2026-07-17**  
Scientific status: **PROVED / SUBSTANTIALLY SUBSUMED**  
Route: **FREEZE AND STOP**

This package freezes a formal dyadic positive-density theorem for

\[
n=a^2+b^2+3^c+5^d,
\qquad a,b,c,d\in\mathbb Z_{\ge0},
\]

including the curved shift-domain count, global collision finiteness, bounded
multiplicity, Sidon-scale additive energy, an indicator-level correlation input,
a structured singular-factor average, exact first and second moments, and the
Paley–Zygmund conclusion.  It also freezes the Radomskii v6 subsumption audit,
Crocker prior-art audit, bibliography corrections, and the unresolved almost-all
covariance blocker.

The global OEIS problem is not solved:

\[
\boxed{\text{OEIS A303656: UNRESOLVED}.}
\]

## Package layers

- `ORIGINAL_PHASE_A_DRAFT/`: the untouched uploaded Phase A ZIP and its
  authenticated listing.  Several files inside that historical ZIP were already
  described by its own packaging notes as reconstructed; this package does not
  relabel them as original web-session artifacts.
- `FORMAL_AUDIT/`: the untouched uploaded referee ZIP.  It is evidence, not a
  mathematical authority.
- Top-level proof files and `FINAL_FROZEN_PROOF/`: the final Phase B proof layer.
- `NONDETERMINISTIC_DIAGNOSTICS/`: the only permitted location for runtime/RSS
  diagnostics; it is excluded from the scientific-core hash.

Start with `EXECUTIVE_VERDICT.md`, then `FINAL_REPORT.md`.  Verification and
replay commands are in `REPRODUCIBILITY.md`.
""")

TEXT_FILES["EXECUTIVE_VERDICT.md"] = md(r"""
# Executive Verdict

## One-sentence verdict

**The dyadic positive-density many-representation theorem is formally proved,
but its headline phenomenon is substantially subsumed by Artyom Radomskii's
Theorem 1.1 in arXiv:2504.09954v6; the correct route is `FREEZE AND STOP`.**

## Formal route verdict

\[
\boxed{\text{ACCEPT PROOF / SUBSTANTIALLY SUBSUMED}.}
\]

| Item | Frozen status |
|---|---|
| Positive lower density | **PROVED** |
| \(\Omega((\log X)^{3/2})\) exponent-pair representations on a positive proportion of every dyadic interval | **PROVED** |
| Distinct-shift version | **PROVED** |
| Sidon-scale additive energy \(E_X\ll |\mathcal D_X|^2\) | **PROVED; POTENTIALLY NEW LEMMA / NOVELTY NOT ESTABLISHED** |
| Structured singular-factor average | **PROVED; POTENTIALLY NEW LEMMA / NOVELTY NOT ESTABLISHED** |
| Radomskii v6 subsumption | **SUBSTANTIALLY SUBSUMED** |
| Bare support positive density | **PRIOR ART; already visible from a one-dimensional subfamily** |
| Almost-all representability | **NOT PROVED; covariance blocker frozen** |
| Universal A303656 statement | **UNRESOLVED** |

## Source corrections that affect the freeze

1. The author of *Variants of Romanoff's theorem* is **Artyom Radomskii**, not
   Konstantin Radomskii.
2. The correct FKR paper is *Poisson distribution for gaps between sums of two
   squares and level spacings for toral point scatterers*, *Communications in
   Number Theory and Physics* **11** (2017), no. 4, 837–877.
3. For the odd primitive set \(\mathcal S'_2=\langle P_1\rangle\), the
   Selberg–Delange constant is \(1/(4K)\), not \(K/2\).  This correction does
   not affect Radomskii subsumption, which uses order of magnitude and an upper
   correlation bound.
4. Crocker's 2008 paper records one-power positive density in its abstract; its
   numbered main theorems concern infinitely many nonrepresentable integers and
   do not provide the present many-representation threshold.

No claim of almost-all or universal representability is made.

## Frozen authority hierarchy

### Accepted

- Direct dyadic positive-density theorem: **PROVED**.
- Distinct-shift dyadic theorem: **PROVED**.
- Finite nontrivial shift collisions: **PROVED**.
- Bounded shift multiplicity: **PROVED**.
- Sidon-scale additive energy: **PROVED; NOVELTY NOT ESTABLISHED**.
- Structured singular-factor average: **PROVED; NOVELTY NOT ESTABLISHED**.
- FKR indicator-level correlation input: **VERIFIED**.
- Radomskii v6 subsumption: **SUBSTANTIALLY SUBSUMED**.
- Crocker bare positive-density prior art: **VERIFIED**.

### Rejected or deprecated

- Author “Konstantin Radomskii”: **REJECTED**; the correct author is Artyom
  Radomskii.
- Primitive-subset constant \(K/2\): **REJECTED FOR THIS SET**; the corrected
  value is \(1/(4K)\).
- Headline classification `NEW THEOREM`: **REJECTED**.
- Almost-all inference from the second moment: **REJECTED**.
- Universal inference: **REJECTED**.

### Unresolved

- Almost-all representability: **NOT PROVED**.
- Universal A303656: **UNRESOLVED**.
- Novelty of the two structural lemmas: **NOT ESTABLISHED**.
- Certified counterexample: **NONE**.
""")

TEXT_FILES["FINAL_REPORT.md"] = md(r"""
# Final Report

## 1. Scope and final classification

The Phase B task was a proof-freeze and source-correction stage, not a search for
new values of \(T(n)\), a counterexample, an almost-all theorem, or a universal
proof.  The frozen conclusion is

\[
\boxed{\text{ACCEPT PROOF / SUBSTANTIALLY SUBSUMED}},
\qquad
\boxed{\text{Route: FREEZE AND STOP}}.
\]

The global problem remains

\[
\boxed{\text{OEIS A303656: UNRESOLVED}}.
\]

For integer \(X\ge1\), put

\[
\mathcal D_X=\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le X/2\},
\quad N_X=|\mathcal D_X|,
\]
\[
w_X(s)=\#\{(c,d)\in\mathcal D_X:3^c+5^d=s\},
\]
\[
R_X(n)=\sum_s w_X(s)\mathbf 1_{\mathcal S_2}(n-s),
\qquad
R_X^{\rm dist}(n)=\sum_{s:w_X(s)>0}\mathbf 1_{\mathcal S_2}(n-s).
\]

The final theorem states that constants \(c_0,c_1,X_0>0\), depending only on
bases 3 and 5 and the cited absolute sieve constants, satisfy

\[
\#\{n\in[X,2X]\cap\mathbb Z:R_X(n)\ge c_0(\log X)^{3/2}\}\ge c_1X
\]

for every integer \(X\ge X_0\), and the same is true with
\(R_X^{\rm dist}\).  This is a positive-lower-density theorem only.

## 2. Archive integrity and provenance

The uploaded draft ZIP has SHA256
`a1fa61b65ed734133046410d1ab3f8ac1aa697f88cc9de0e10bd5d8f094b2375`.
It has 42 files, no unsafe path, no symlink entry, and no CRC failure.  Its
internal manifest authenticates all 41 files it lists; the manifest does not
list itself.

The uploaded formal-audit ZIP has SHA256
`e3d8559c32bc64e046b85032c4111145092f4f63e373e0d0355932a43f972e15`.
It has three files, no unsafe path, no symlink entry, and no CRC failure.  It
contains no internal manifest, so its outer ZIP hash is the archival lock.

The source hierarchy used in this report is:

1. exact-version primary literature and the present independent derivation;
2. the task specification for scope and prohibited routes;
3. the Phase A draft as a claim source;
4. the Phase A formal audit as referee evidence.

Where the draft or audit conflicts with a primary source or an independently
checked derivation, the latter prevails.  In particular, the previous audit's
instruction to retain \(K/2\) for the primitive subset is rejected by an exact
Euler-product calculation.

## 3. Load-bearing proof chain

### 3.1 Curved shift domain

The rectangle cut out by \(3^c\le X/2\) and \(5^d\le X/2\) has

\[
\frac{(\log X)^2}{\log3\log5}+O(\log X)
\]

points.  A rectangle point excluded by the true curved boundary has either
\(3^c\in(X/4,X/2]\) or \(5^d\in(X/4,X/2]\).  Each such interval contains at
most one power of the corresponding base, leaving only \(O(\log X)\) excluded
points.  Thus

\[
N_X=\frac{(\log X)^2}{\log3\log5}+O(\log X).
\]

For every fixed \(0<\theta<1\),
\(N_{\theta X}=N_X+O_\theta(\log X)\), hence
\(N_{\theta X}\asymp_\theta N_X\).  This also proves the
\(B(x/2)\gg B(x)\) condition needed in Radomskii's theorem.

### 3.2 Global collisions and bounded multiplicity

The equation

\[
3^c+5^d-3^{c'}-5^{d'}=0
\]

is a homogeneous unit equation in
\(\Gamma=\langle3,5\rangle\subset\mathbb Q^\times\).  Evertse–Győry's
weighted unit theorem gives finitely many nondegenerate projective classes.
For a class containing a pure 3-power slot and a pure 5-power slot, a common
scale \(\gamma\) preserving both slot types lies in
\(\langle3\rangle\cap\langle5\rangle=\{1\}\); projective finiteness therefore
becomes actual exponent finiteness.  Degenerate two-term blocks give only
trivial identities.  Consequently

\[
|\mathcal B_X|=N_X+O(1),\quad \max_sw_X(s)=O(1),\quad
\sum_sw_X(s)^2=N_X+O(1).
\]

No claim is made that 28 is the only global collision.

### 3.3 Sidon-scale energy

The energy equation expands into eight signed pure powers.  Partition the
labeled terms into minimal zero-sum blocks.  A mixed block has \(O(1)\) actual
assignments by the same projective-unit-equation argument.  A pure block over
\(q\in\{3,5\}\) is either a two-term cancellation or impossible: a three-term
block would give \(q^a+q^b=q^c\), and a four-term block would give
\(q^a+q^b=q^c+q^d\), whose base-\(q\) digit uniqueness forces a two-term
zero subblock.  There are at most four free pure cancellations.  Therefore

\[
E_X=\sum_h\nu_X(h)^2\ll(\log X)^4\asymp N_X^2.
\]

### 3.4 First moment

The Landau–Ramanujan/Selberg–Delange estimate, with

\[
K=\frac1{\sqrt2}\prod_{p\equiv3\pmod4}(1-p^{-2})^{-1/2},
\]

is

\[
B_2(y)=K\frac{y}{\sqrt{\log y}}+
O\!\left(\frac{y}{(\log y)^{3/2}}\right).
\]

For every \(s\le X/2\), both translated endpoints remain in a fixed
multiplicative interval, so uniformly

\[
B_2(2X-s)-B_2(X-s-1)
=K\frac X{\sqrt{\log X}}+O\!\left(\frac X{(\log X)^{3/2}}\right).
\]

Summation over \(\mathcal D_X\) gives

\[
M_1(X)=\frac K{\log3\log5}X(\log X)^{3/2}
+O\bigl(X(\log X)^{1/2}\bigr).
\]

Finite collisions leave the distinct-shift leading term unchanged.

### 3.5 Indicator correlation and local-factor average

FKR §2.1 records the Selberg-sieve bound, due in general to Nowak, for the
actual indicator of sums of two squares.  At \(k=2\), uniformly for nonzero
integer \(h\),

\[
\sum_{m\le x}\mathbf1_{\mathcal S_2}(m)
\mathbf1_{\mathcal S_2}(m+h)
\ll \frac{x}{\log x}
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}\left(1+\frac2p\right).
\]

This is not an \(r_2\)-weighted shifted convolution.

For every fixed real \(A>0\), the structured difference family satisfies

\[
\sum_{\substack{u,v\in\mathcal D_X\\b_u\ne b_v}}
\left(\frac{|b_u-b_v|}{\varphi(|b_u-b_v|)}\right)^A\ll_A N_X^2.
\]

The key congruence count is

\[
A_p\ll (\log X)^3+
\frac{(\log X)^4}{\operatorname{ord}_p(5)}\qquad(p\ne5),
\]

and the key absolutely convergent series is

\[
\sum_{p\nmid5}\frac{(\log p)^m}{p\operatorname{ord}_p(5)}<\infty
\quad(m\in\mathbb Z_{\ge1}).
\]

Primes 2 and 5 are separated, the curved boundary only decreases counts, and
the diagonal is omitted.  Since

\[
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}(1+2/p)
\le (|h|/\varphi(|h|))^2,
\]

the averaged FKR factor is \(O(N_X^2)\).

### 3.6 Second moment and Paley–Zygmund

The exact boundary-aware identity is

\[
M_2(X)=\sum_{s,t}w_X(s)w_X(t)
\sum_{m=X-t}^{2X-t}\mathbf1_{\mathcal S_2}(m)
\mathbf1_{\mathcal S_2}(m+t-s).
\]

For \(s,t\le X/2\), both arguments lie in \([X/2,2X]\).  The diagonal is
handled separately:

\[
\nu_X(0)=N_X+O(1),\qquad Q_0(X)\ll X/\sqrt{\log X}.
\]

The off-diagonal FKR bound and structured average give

\[
M_2(X)\ll X(\log X)^3.
\]

Since \(M_1(X)\asymp X(\log X)^{3/2}\), Paley–Zygmund on the uniform measure
of \([X,2X]\cap\mathbb Z\) gives the theorem.  The distinct version follows
in parallel, or from
\(0\le R_X-R_X^{\rm dist}\le N_X-|\mathcal B_X|=O(1)\).

## 4. Radomskii v6 subsumption

The version-locked source is Artyom Radomskii, *Variants of Romanoff's
theorem*, arXiv:2504.09954v6, revised 13 July 2026.  Theorem 1.1 explicitly
allows the shift sequence \(B\) to have multiplicity.  Set

\[
A=\mathcal S'_2=\langle P_1\rangle,
\qquad B=(3^c+5^d)_{c,d\ge0},
\qquad \eta(x)=\sqrt{\log x}.
\]

The primitive set satisfies \(A(x)\asymp x/\eta(x)\) and the required pair
upper bound.  The lemmas in this package give
\(B(x)\asymp(\log x)^2\), \(B(x/2)\gg B(x)\), bounded
\(\rho_B(x)\), and Radomskii's small-prime congruence condition.  The theorem
therefore yields a positive proportion of \(n\le x\) with

\[
r(n)\gg \frac{B(x)}{\eta(x)}\asymp(\log x)^{3/2}.
\]

The same application works for the distinct set of shifts.

This is **substantial** rather than literal full subsumption because Radomskii's
printed conclusion is cumulative on \([1,x]\) and uses its global sequence,
whereas the frozen theorem is a uniform statement on every dyadic interval
\([X,2X]\) with the explicit truncation \(3^c+5^d\le X/2\).  The direct
energy and singular-average lemmas also remain independent proof components.
Radomskii v6 is a recent arXiv preprint and has not completed traditional
journal peer review; that publication status does not negate its mathematical
subsumption.

## 5. Crocker and one-dimensional prior art

Crocker's 2008 article states in its abstract that integers representable as two
squares plus one fixed-base power have positive density.  Its numbered main
results instead prove infinitely many exceptions for two or fewer powers and do
not prove a growing representation multiplicity.  Taking base 3 and translating
by 1 shows that the support-only positive-density phenomenon is already present
in the subfamily

\[
a^2+b^2+3^c+1.
\]

Thus bare positive density is not the contribution of this package.  The stronger
many-representation threshold is itself substantially subsumed by Radomskii v6.

## 6. Novelty verdict

The curved-domain count, collision finiteness, and bounded multiplicity are
standard consequences of elementary lattice counting and unit equations.  The
direct dyadic proof is an independent alternative proof, not a new headline
theorem.  The many-representation and distinct-shift phenomena are subsumed at
the general-theorem level by Radomskii.

The Sidon-scale energy and structured singular-factor average may have
standalone methodological value for sparse two-base sumsets.  This freeze did
not perform an exhaustive novelty search, so both are classified only as
**POTENTIALLY NEW LEMMA / NOVELTY NOT ESTABLISHED**.  They are not promoted
to a major advance.

## 7. Almost-all blocker

The exact variance requires the signed covariance estimate

\[
\sum_{s,t}w_X(s)w_X(t)
\left(C_{s,t}(X)-\frac{A_s(X)A_t(X)}{|I_X|}\right)
=o\!\left(\frac{XN_X^2}{\log X}\right).
\]

Indicator upper bounds, a divergent mean, Sidon-scale energy, and pairwise
upper bounds do not provide this signed cancellation.  An \(r_2\)-weighted
shifted convolution cannot replace indicator covariance.  The blocker is frozen;
no numerical or theoretical almost-all campaign is started.

## 8. Reproducibility result

The scientific core contains no runtime/RSS data and no floating-point research
payload.  It is generated twice in fresh directories and compared byte for byte.
The canonical core manifest and its SHA256 are stored in
`SCIENTIFIC_CORE.json` and `SCIENTIFIC_CORE.sha256`.  The final package manifest
`SHA256SUMS.txt` is generated once after replay evidence is added and is never
modified by a replay script.  The final ZIP is built twice with sorted entries,
fixed timestamps, normalized permissions, and `ZIP_STORED`; both builds are
required to be byte-identical.

The package verifier also rejects every C0 control byte other than horizontal tab
and line feed in the scientific core.  This closes the generator-origin defects
that previously emitted two form-feed bytes and converted one carriage-return
escape into a broken formula line.

## 9. Frozen authority hierarchy

### Accepted

- Direct dyadic positive-density theorem: **PROVED**.
- Distinct-shift dyadic theorem: **PROVED**.
- Finite nontrivial shift collisions: **PROVED**.
- Bounded shift multiplicity: **PROVED**.
- Sidon-scale additive energy: **PROVED; NOVELTY NOT ESTABLISHED**.
- Structured singular-factor average: **PROVED; NOVELTY NOT ESTABLISHED**.
- FKR indicator-level correlation input: **VERIFIED**.
- Radomskii v6 subsumption: **SUBSTANTIALLY SUBSUMED**.
- Crocker bare positive-density prior art: **VERIFIED**.

### Rejected or deprecated

- “Konstantin Radomskii”: **REJECTED**; the author is Artyom Radomskii.
- Primitive-subset constant \(K/2\): **REJECTED FOR THIS SET**; the corrected
  value is \(1/(4K)\).
- `NEW THEOREM` headline classification: **REJECTED**.
- Almost-all inference from the second moment: **REJECTED**.
- Universal inference: **REJECTED**.

### Unresolved

- Almost-all representability: **NOT PROVED**.
- Universal A303656: **UNRESOLVED**.
- Novelty of the two structural lemmas: **NOT ESTABLISHED**.
- Certified counterexample: **NONE**.
""")

TEXT_FILES["LEMMA_SHIFT_DOMAIN.md"] = md(r"""
# Lemma: Curved Shift Domain and Scale Stability

Let \(X\ge4\) be real and put \(Y=X/2\).  Define

\[
\mathcal D_X=\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le Y\},
\qquad N_X=|\mathcal D_X|.
\]

## Lemma 1 (curved-domain asymptotic)

As \(X\to\infty\),

\[
\boxed{N_X=\frac{(\log X)^2}{\log3\,\log5}+O(\log X).}
\]

The implied constant is absolute.

### Proof

Set

\[
C=\left\lfloor\frac{\log Y}{\log3}\right\rfloor,
\qquad
D=\left\lfloor\frac{\log Y}{\log5}\right\rfloor.
\]

Every point of \(\mathcal D_X\) lies in
\(\mathcal R=[0,C]\times[0,D]\cap\mathbb Z^2\), and

\[
|\mathcal R|=(C+1)(D+1)
=\frac{(\log X)^2}{\log3\log5}+O(\log X).
\]

It remains to bound the points of \(\mathcal R\) above the curved boundary.
If \(3^c+5^d>Y\), then at least one summand exceeds \(Y/2\).  The interval
\((Y/2,Y]\) contains at most one power of 3: two such powers would have ratio
at most 2, while two distinct powers of 3 have ratio at least 3.  The same
argument applies to powers of 5.  Hence the excluded set is contained in the
union of at most one complete row and at most one complete column of
\(\mathcal R\), and therefore has at most

\[
(C+1)+(D+1)=O(\log X)
\]

points.  Subtracting this controlled corner proves the formula. \(\square\)

## Lemma 2 (fixed-scale stability)

For every fixed \(0<\theta<1\),

\[
N_{\theta X}=N_X+O_\theta(\log X)
\]

and therefore

\[
\frac{N_{\theta X}}{N_X}=1+O_\theta\!\left(\frac1{\log X}\right),
\qquad
N_{\theta X}\asymp_\theta N_X.
\]

### Proof

Apply Lemma 1 with \(\theta X\):

\[
N_{\theta X}=
\frac{(\log X+\log\theta)^2}{\log3\log5}+O_\theta(\log X).
\]

Expanding the square and comparing with Lemma 1 gives the first assertion.
Since \(N_X\asymp(\log X)^2\), division gives the ratio estimate.  For all
sufficiently large \(X\), the ratio lies, for example, between \(1/2\) and
\(3/2\); enlarging the constants handles the remaining bounded range.
The constants may depend on \(\theta\), and on no other parameter. \(\square\)

## Corollary (Radomskii growth condition)

Let

\[
B(x)=\#\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le x\}.
\]

Then \(B(x)=N_{2x}\), so

\[
B(x)\asymp(\log x)^2,
\qquad B(x/2)=N_x\gg N_{2x}=B(x).
\]
""")

TEXT_FILES["LEMMA_COLLISIONS.md"] = md(r"""
# Lemma: Global Collision Finiteness and Bounded Shift Multiplicity

Write

\[
b_{c,d}=3^c+5^d,
\qquad
\mathcal B_X=\{b_{c,d}:(c,d)\in\mathcal D_X\},
\qquad
w_X(s)=\#\{(c,d)\in\mathcal D_X:b_{c,d}=s\}.
\]

## Primary unit-equation input

Let \(K\) be a finitely generated extension of \(\mathbb Q\), let
\(\Gamma\subset K^\times\) be a finitely generated multiplicative group, and
fix nonzero coefficients \(\alpha_1,\ldots,\alpha_r\in K\).  Evertse–Győry,
Theorem 1, proves that

\[
\alpha_1x_1+\cdots+\alpha_rx_r=1,
\qquad x_i\in\Gamma,
\]

has only finitely many **nondegenerate** solutions, where nondegenerate means
that no nonempty subsum \(\sum_{i\in I}\alpha_ix_i\) vanishes.

Here the ambient group is explicitly

\[
\Gamma=\langle3,5\rangle
=\{3^u5^v:u,v\in\mathbb Z\}\subset\mathbb Q^\times.
\]

## Lemma 1 (projective finiteness for a homogeneous block)

Fix coefficients \(\varepsilon_i\in\{+1,-1\}\).  Homogeneous solutions of

\[
\sum_{i=1}^r\varepsilon_i y_i=0,
\qquad y_i\in\Gamma,
\]

having no proper nonempty zero subsum occupy only finitely many projective
\(\Gamma\)-classes under simultaneous scaling
\((y_1,\ldots,y_r)\mapsto(\gamma y_1,\ldots,\gamma y_r)\).

### Proof

Choose the last coordinate as anchor and divide by
\(-\varepsilon_r y_r\).  The ratios \(x_i=y_i/y_r\) lie in \(\Gamma\) and
satisfy a fixed weighted equation with right side 1.  A zero subsum among its
left-side terms would be a proper zero subsum of the original homogeneous
relation.  Thus the normalized solution is nondegenerate, and Evertse–Győry
gives finitely many ratio tuples.  These ratio tuples are exactly the
projective classes. \(\square\)

## Lemma 2 (loss of projective scaling for mixed pure-power slots)

Suppose a projective class contains an actual assignment with at least one slot
required to be a pure power of 3 and at least one slot required to be a pure
power of 5.  Then that class contains at most one actual assignment with the
same slot requirements.

### Proof

If two actual assignments in the same class differ by \(\gamma\in\Gamma\),
then comparison at a pure-3 slot gives

\[
\gamma=3^{u'-u}\in\langle3\rangle,
\]

whereas comparison at a pure-5 slot gives

\[
\gamma=5^{v'-v}\in\langle5\rangle.
\]

Unique factorization in \(\mathbb Q^\times\) gives

\[
\langle3\rangle\cap\langle5\rangle=\{1\}.
\]

Hence \(\gamma=1\), so every exponent in the two assignments is equal.
\(\square\)

## Theorem (finite nontrivial collisions)

The equation

\[
3^c+5^d=3^{c'}+5^{d'},
\qquad c,d,c',d'\in\mathbb Z_{\ge0},
\]

has only finitely many nontrivial exponent quadruples.

### Proof

Rewrite it as

\[
3^c+5^d-3^{c'}-5^{d'}=0. \tag{1}
\]

First suppose (1) is nondegenerate, meaning that no proper nonempty subset of
its four signed terms sums to zero.  Lemma 1 gives finitely many projective
classes.  Each class has a pure-3 slot and a pure-5 slot, so Lemma 2 makes each
class contain at most one actual exponent assignment.  Hence there are only
finitely many nondegenerate collisions.

Now suppose (1) is degenerate.  A one-term zero block is impossible.  A
three-term zero block would leave a one-term zero complement and is also
impossible.  Thus a proper zero block has two terms of opposite sign.

- A same-base cancellation, such as \(3^c-3^{c'}=0\), forces
  \(c=c'\), and the remaining terms force \(d=d'\).
- A cross-base cancellation forces \(3^c=5^{d'}\).  Unique factorization gives
  \(c=d'=0\); the complementary equality similarly gives \(d=c'=0\).

Every degenerate solution is therefore the trivial identity obtained by matching
the two exponent pairs.  This proves global finiteness of nontrivial collisions.
\(\square\)

## Corollaries

Let

\[
K_{\rm coll}=\sum_s\binom{w_\infty(s)}2,
\]

where the sum ranges over all global shift values and
\(w_\infty(s)=\#\{(c,d):3^c+5^d=s\}\).  The theorem gives
\(K_{\rm coll}<\infty\).  Hence, uniformly in \(X\),

\[
\sum_s\binom{w_X(s)}2\le K_{\rm coll}.
\]

It follows that

\[
\boxed{|\mathcal B_X|=|\mathcal D_X|+O(1)},
\]
\[
\boxed{\max_s w_X(s)=O(1)},
\]
\[
\boxed{\sum_s w_X(s)^2=|\mathcal D_X|+O(1)}.
\]

The constants are absolute but ineffective with the cited form of the
unit-equation theorem.  No enumeration of all collisions, and in particular no
claim that shift 28 is globally unique, is part of the proof.
""")

TEXT_FILES["LEMMA_ADDITIVE_ENERGY.md"] = md(r"""
# Lemma: Sidon-Scale Additive Energy

Define

\[
\nu_X(h)=\sum_{t-s=h}w_X(s)w_X(t),
\qquad
E_X=\sum_{h\in\mathbb Z}\nu_X(h)^2.
\]

Equivalently, \(E_X\) counts ordered exponent-pair quadruples satisfying

\[
(3^{c_1}+5^{d_1})+(3^{c_2}+5^{d_2})
=(3^{c_3}+5^{d_3})+(3^{c_4}+5^{d_4}). \tag{1}
\]

## Theorem

As \(X\to\infty\),

\[
\boxed{E_X\ll |\mathcal D_X|^2.}
\]

More explicitly,

\[
E_X\ll(\log X)^4.
\]

The same estimate holds for the distinct-shift energy.

## Proof

Expand (1) into the signed relation

\[
3^{c_1}+3^{c_2}-3^{c_3}-3^{c_4}
+5^{d_1}+5^{d_2}-5^{d_3}-5^{d_4}=0. \tag{2}
\]

All eight terms are labeled.  Partition them into **minimal zero-sum blocks**:
each block sums to zero and no proper nonempty subblock does.  Every zero-sum
multiset admits such a partition by repeatedly extracting a minimal zero
submultiset.  There are at most the eighth Bell number, \(B_8=4140\), labeled
partition patterns, an absolute constant.

### 1. Mixed blocks

A mixed block contains at least one pure power of 3 and at least one pure power
of 5.  If it has two terms, it is a cross-base cancellation
\(3^a=5^b\), which forces \(a=b=0\), so it has \(O(1)\) assignments.

If it has at least three terms, minimality makes the corresponding homogeneous
unit equation nondegenerate.  The ambient group is
\(\Gamma=\langle3,5\rangle\).  Evertse–Győry gives finitely many projective
classes.  Because the block has both a pure-3 and a pure-5 slot, the
projective-scaling lemma in `LEMMA_COLLISIONS.md` forces the common scale to be
1.  Thus a fixed mixed block pattern has only \(O(1)\) actual assignments,
uniformly in \(X\).

### 2. Pure blocks

A pure block contains powers of one base \(q\in\{3,5\}\).  Across all of (2)
there are only two positive and two negative \(q\)-terms, so a pure block has
size at most four.

- **Size 2.**  Opposite signs force \(q^a=q^b\), hence \(a=b\).  The common
  exponent has \(O(\log X)\) choices.
- **Size 3.**  Up to sign, the equation is \(q^a+q^b=q^c\).  If
  \(a\le b\), division by \(q^a\) gives
  \(1+q^{b-a}=q^{c-a}\).  If \(c>a\), the two sides are incongruent modulo
  \(q\); if \(c=a\), the right side is 1 and the left side exceeds 1.  Hence
  no solution exists.
- **Size 4.**  It necessarily contains two positive and two negative terms,
  so
  \(q^a+q^b=q^c+q^d\).  In base \(q\), each coefficient digit on either
  side is 0, 1, or 2, and \(2<q\).  Uniqueness of base-\(q\) expansion gives
  \(\{a,b\}=\{c,d\}\) as multisets.  A positive term therefore cancels a
  negative term in a proper two-term subblock, contradicting minimality.

Thus every pure minimal block is a two-term cancellation.

### 3. Count by block pattern

A partition pattern contains at most four pure cancellation blocks.  Each such
block contributes one free exponent and hence \(O(\log X)\) choices.  Every
mixed block contributes \(O(1)\).  Therefore each pattern contributes at most
\(O((\log X)^4)\), and the number of patterns is absolute.  Summing gives

\[
E_X\ll(\log X)^4.
\]

By the curved-domain lemma,
\(|\mathcal D_X|\asymp(\log X)^2\), proving the stated Sidon-scale bound.
For distinct shifts, \(\nu_X^{\rm dist}(h)\le\nu_X(h)\) pointwise, so the same
estimate follows. \(\square\)

## Audit status

The proof is global and does not use a finite collision search.  Its novelty is
classified only as **POTENTIALLY NEW LEMMA / NOVELTY NOT ESTABLISHED**.
""")

TEXT_FILES["LEMMA_SINGULAR_FACTOR_AVERAGE.md"] = md(r"""
# Lemma: Structured Singular-Factor Average

Put \(b_{c,d}=3^c+5^d\), \(N_X=|\mathcal D_X|\), and \(L=\log X\).

## Theorem

For every fixed real \(A>0\),

\[
\boxed{
\sum_{\substack{u,v\in\mathcal D_X\\b_u\ne b_v}}
\left(\frac{|b_u-b_v|}{\varphi(|b_u-b_v|)}\right)^A
\ll_A N_X^2.}
\tag{1}
\]

Consequently,

\[
\boxed{
\sum_{h\ne0}\nu_X(h)
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}
\left(1+\frac2p\right)
\ll N_X^2.}
\tag{2}
\]

All implied constants are independent of \(X\).

## 1. Finite divisor-expansion reduction

We use Radomskii v6, Lemma 3.1.  In the notation needed here, if
\(a_1,\ldots,a_J\le M\) are positive integers, repetitions allowed,

\[
\omega(p)=\#\{j:p\mid a_j\},
\]

then for every fixed \(0<\alpha<1\) and positive integer \(m\),

\[
\sum_{j=1}^J\left(\frac{a_j}{\varphi(a_j)}\right)^m
\ll_{\alpha,m}
J+\sum_{p\le(\log M)^\alpha}
\frac{\omega(p)(\log p)^m}{p}. \tag{3}
\]

This is the required divisor expansion: its proof expands the Euler factors of
\(a/\varphi(a)\), separates primes at \((\log M)^\alpha\), and uses the
product constraint \(a\le M\) to absorb the large-prime part into the constant.
Equation (3) is a finite statement for a finite list; no infinite exchange is
hidden in its application below.

Take the list of all ordered nonzero differences

\[
a_{u,v}=|b_u-b_v|,
\qquad u,v\in\mathcal D_X,
\qquad b_u\ne b_v.
\]

Then \(J\le N_X^2\) and \(a_{u,v}<X\).  If

\[
A_p=\#\{(u,v)\in\mathcal D_X^2:b_u\equiv b_v\pmod p\},
\]

then the \(\omega(p)\) for the nonzero-difference list is at most \(A_p\).

## 2. Congruence and order-period count

Embed the curved domain in the rectangle

\[
0\le c\le C\ll L,
\qquad 0\le d\le D\ll L.
\]

For \(p\ne5\), fix \(c,c',d\).  The congruence

\[
3^c+5^d\equiv3^{c'}+5^{d'}\pmod p \tag{4}
\]

asks for \(5^{d'}\) to equal a fixed residue.  If that residue is zero or is
outside \(\langle5\rangle\subset(\mathbb Z/p\mathbb Z)^\times\), there is no
solution.  Otherwise \(d'\) lies in one residue class modulo
\(\operatorname{ord}_p(5)\).  Therefore

\[
A_p\ll L^3+\frac{L^4}{\operatorname{ord}_p(5)}
\qquad(p\ne5). \tag{5}
\]

The estimate remains valid for \(p=3\): only invertibility of 5 was used.
Primes \(p=2\) and \(p=5\) are treated separately by the trivial bound
\(A_p\le N_X^2\).  The curved boundary causes no endpoint loss because the
rectangle is an upper envelope.

## 3. Absolute convergence of the order series

### Lemma

For every fixed integer \(m\ge1\),

\[
\sum_{p\nmid5}\frac{(\log p)^m}{p\operatorname{ord}_p(5)}<\infty. \tag{6}
\]

### Proof

Let

\[
G_m(T)=\sum_{\substack{p\nmid5\\\operatorname{ord}_p(5)\le T}}
\frac{(\log p)^m}{p}.
\]

Every prime counted by \(G_m(T)\) divides

\[
P_T=\prod_{1\le r\le T}(5^r-1),
\]

and

\[
\log P_T\le\sum_{r\le T}r\log5=O(T^2). \tag{7}
\]

For every integer \(M\ge3\),

\[
\sum_{p\mid M}\frac{(\log p)^m}{p}
\ll_m(\log\log(3M))^m. \tag{8}
\]

To prove (8), split at \(z=\log M\).  For \(p\le z\), Chebyshev's bound and
partial summation give

\[
\sum_{p\le z}\frac{(\log p)^m}{p}\ll_m(\log z)^m.
\]

For \(p>z\), the number of distinct prime divisors is at most
\(\log M/\log z\).  For sufficiently large \(z\),
\((\log t)^m/t\) decreases on \([z,\infty)\), so their total contribution is
at most

\[
\frac{\log M}{\log z}\frac{(\log z)^m}{z}
=(\log z)^{m-1}.
\]

The bounded remaining range is absorbed into the constant.  This proves (8).
Applying (8) to \(P_T\) and using (7) yields

\[
G_m(T)\ll_m(\log(2T))^m. \tag{9}
\]

Stieltjes partial summation now gives, for \(U\ge2\),

\[
\sum_{\substack{p\nmid5\\\operatorname{ord}_p(5)\le U}}
\frac{(\log p)^m}{p\operatorname{ord}_p(5)}
=\frac{G_m(U)}U+
\int_{1^-}^{U}\frac{G_m(t)}{t^2}\,dt.
\]

The right side has a finite limit as \(U\to\infty\) by (9), because
\(\int_1^\infty(\log(2t))^m t^{-2}\,dt<\infty\).  This proves absolute
convergence. \(\square\)

## 4. Completion of the totient moment

Let \(m=\lceil A\rceil\).  Since \(n/\varphi(n)\ge1\), the left side of (1)
is bounded by the corresponding \(m\)-th moment.  Apply (3) with any fixed
\(0<\alpha<1\), \(M=X\), and (5).  The primes 2 and 5 contribute
\(O(N_X^2)\).  For the remaining primes,

\[
\sum_{p\le L^\alpha}\frac{A_p(\log p)^m}{p}
\ll
L^3\sum_{p\le L^\alpha}\frac{(\log p)^m}{p}
+L^4\sum_{p\nmid5}
\frac{(\log p)^m}{p\operatorname{ord}_p(5)}.
\]

The first prime sum is \(O_m((\log L)^m)\); the second is finite by (6).
Thus the expression is

\[
O_m(L^3(\log L)^m+L^4)=O_m(L^4).
\]

Since \(N_X\asymp L^2\), (1) follows.  Every sum before the final limiting
order series is finite and nonnegative; the limiting passage in (6) is justified
by monotone convergence and the displayed absolute bound.

## 5. FKR factor and diagonal

For \(h\ne0\),

\[
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}\left(1+\frac2p\right)
\le
\prod_{p\mid h}(1-1/p)^{-2}
=\left(\frac{|h|}{\varphi(|h|)}\right)^2,
\]

because \(1+2/p\le(1-1/p)^{-2}\).  Taking \(A=2\) proves (2).  The diagonal
\(h=0\) is not assigned a totient or singular factor and is handled separately
in the second-moment proof.  The distinct-shift sum is smaller term by term.
\(\square\)

## Audit status

The result is **PROVED**.  It is classified as **POTENTIALLY NEW LEMMA /
NOVELTY NOT ESTABLISHED**, not as a new headline theorem.
""")

TEXT_FILES["LEMMA_INDICATOR_CORRELATION.md"] = md(r"""
# Lemma: Indicator-Level Correlation for Sums of Two Squares

Let

\[
\beta(m)=\mathbf1_{\mathcal S_2}(m),
\qquad
\mathcal S_2=\{a^2+b^2:a,b\in\mathbb Z_{\ge0}\}.
\]

## Primary-source statement

Freiberg–Kurlberg–Rosenzweig, §2.1, page 6 of the published article (page 5
of arXiv:1701.01157v1), gives the following unnumbered Selberg-sieve upper
bound, with the general case credited to Nowak.  For fixed \(k\) and distinct
integer shifts \(h_1,\ldots,h_k\),

\[
\sum_{n\le x}\prod_{i=1}^k\beta(n+h_i)
\ll_k\frac{x}{(\log x)^{k/2}}
\prod_{\substack{p\equiv3\pmod4\\p\mid h_j-h_i\text{ for some }i<j}}
\left(1+\frac{k}{p}\right). \tag{1}
\]

The source's convention states that \(\ll_k\) depends only on \(k\); the
arithmetic dependence on the shifts is displayed in the product.  This is an
indicator theorem, not a theorem for \(r_2(n)r_2(n+h)\).

## Corollary for pairs

For every nonzero integer \(h\),

\[
\boxed{
Q_h(x):=\sum_{m\le x}\beta(m)\beta(m+h)
\ll \frac{x}{\log x}
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}
\left(1+\frac2p\right).}
\tag{2}
\]

For negative \(h\), substitute \(u=m+h\) and use \(|h|\); the same factor
results.  The factor at \(p=2\) is absent from the product in (1) and is absorbed
in the absolute implied constant.

## Boundary-aware envelope used in this project

For \(s,t\le X/2\), set \(h=t-s\).  The exact pair sum in the second moment is

\[
\sum_{m=X-t}^{2X-t}\beta(m)\beta(m+h). \tag{3}
\]

Both \(m\) and \(m+h\) lie in \([X/2,2X]\).  If \(h>0\), (3) is bounded by
\(Q_h(2X)\); if \(h<0\), change variables and bound by \(Q_{|h|}(2X)\).
Moreover \(|h|\le X/2\).  Hence, uniformly for every off-diagonal pair,

\[
(3)\ll\frac{X}{\log X}
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}
\left(1+\frac2p\right). \tag{4}
\]

The interval length and translated endpoints cause only the replacement of
\(x\) by \(2X\), which changes the absolute constant.  The diagonal \(h=0\)
is not inserted into (2); it is bounded by the one-point Landau–Ramanujan
count.

## Bibliographic lock

Tristan Freiberg, Pär Kurlberg, and Lior Rosenzweig,
*Poisson distribution for gaps between sums of two squares and level spacings
for toral point scatterers*, *Communications in Number Theory and Physics*
**11** (2017), no. 4, 837–877, DOI 10.4310/CNTP.2017.v11.n4.a3.

The exact source location is an unnumbered display in §2.1; this package does
not invent a theorem or lemma number.
""")

TEXT_FILES["PROOF_FIRST_MOMENT.md"] = md(r"""
# Proof: Exact First Moment

For real \(y\), define

\[
B_2(y)=\#\{m\in\mathbb Z_{\ge0}:m\le y,\ m\in\mathcal S_2\},
\]

with \(B_2(y)=0\) for \(y<0\).  Let

\[
K=\frac1{\sqrt2}
\prod_{p\equiv3\pmod4}(1-p^{-2})^{-1/2}
\]

be the Landau–Ramanujan constant.

## 1. Selberg–Delange input and constant

The Dirichlet series of the indicator of positive sums of two squares is

\[
F(z)=(1-2^{-z})^{-1}
\prod_{p\equiv1(4)}(1-p^{-z})^{-1}
\prod_{p\equiv3(4)}(1-p^{-2z})^{-1}.
\]

Using the Euler products of \(\zeta(z)\) and \(L(z,\chi_4)\),

\[
F(z)^2=\zeta(z)L(z,\chi_4)(1-2^{-z})^{-1}
\prod_{p\equiv3(4)}(1-p^{-2z})^{-1}.
\]

Thus \(F(z)=\zeta(z)^{1/2}G(z)\), where \(G\) is analytic and nonzero near
1.  Delange's theorem gives

\[
B_2(y)=K\frac{y}{\sqrt{\log y}}+
O\!\left(\frac{y}{(\log y)^{3/2}}\right) \tag{1}
\]

for \(y\ge3\).  Adding the value \(m=0\) changes the counting function by
one and is absorbed by the error term.  Evaluating \(G(1)/\Gamma(1/2)\)
gives exactly the displayed \(K\).

## 2. Uniform translated interval

Fix an integer \(X\) and a shift \(0\le s\le X/2\).  Inclusive endpoints give

\[
\sum_{X\le n\le2X}\beta(n-s)
=B_2(2X-s)-B_2(X-s-1). \tag{2}
\]

For all sufficiently large \(X\), both arguments in (2) lie between
\(X/2-1\) and \(2X\).  Let

\[
f(y)=\frac{y}{\sqrt{\log y}}.
\]

Uniformly on that multiplicative interval,

\[
f'(y)=\frac1{\sqrt{\log y}}-
\frac1{2(\log y)^{3/2}}
=\frac1{\sqrt{\log X}}+O\!\left((\log X)^{-3/2}\right). \tag{3}
\]

The two endpoints in (2) differ by \(X+1\).  The mean-value theorem and (3)
give

\[
f(2X-s)-f(X-s-1)
=\frac X{\sqrt{\log X}}+
O\!\left(\frac X{(\log X)^{3/2}}\right). \tag{4}
\]

The two error terms from (1) are uniformly
\(O(X(\log X)^{-3/2})\).  Combining (1), (2), and (4),

\[
\sum_{X\le n\le2X}\beta(n-s)
=K\frac X{\sqrt{\log X}}+
O\!\left(\frac X{(\log X)^{3/2}}\right), \tag{5}
\]

uniformly for every \(s\le X/2\).  In this range
\(n-s\ge X/2>0\), so \(m=0\) never occurs in the actual translated interval.
The inclusive `+1` in its length contributes only
\(O((\log X)^{-1/2})\), already absorbed in (5).

## 3. Weighted first moment

Interchange the two finite sums:

\[
M_1(X):=\sum_{X\le n\le2X}R_X(n)
=\sum_{(c,d)\in\mathcal D_X}
\sum_{X\le n\le2X}\beta(n-3^c-5^d).
\]

By (5),

\[
M_1(X)=N_XK\frac X{\sqrt{\log X}}+
O\!\left(N_X\frac X{(\log X)^{3/2}}\right).
\]

Using

\[
N_X=\frac{(\log X)^2}{\log3\log5}+O(\log X),
\]

we obtain

\[
\boxed{
M_1(X)=\frac K{\log3\log5}X(\log X)^{3/2}
+O\bigl(X(\log X)^{1/2}\bigr).}
\tag{6}
\]

## 4. Distinct shifts and finite collisions

The collision theorem gives \(|\mathcal B_X|=N_X+O(1)\).  Applying (5) once
for every distinct shift gives

\[
\sum_{X\le n\le2X}R_X^{\rm dist}(n)
=|\mathcal B_X|K\frac X{\sqrt{\log X}}
+O\!\left(|\mathcal B_X|\frac X{(\log X)^{3/2}}\right).
\]

The replacement of \(N_X\) by \(|\mathcal B_X|\) changes the expression by
only \(O(X/\sqrt{\log X})\), which is smaller than the error in (6).  Hence the
distinct-shift first moment has the same leading constant and error term.
\(\square\)

## Primitive-subset warning

No primitive-subset constant enters (6).  For the separate set
\(\mathcal S'_2=\langle P_1\rangle\), exact Euler-product algebra gives
\(1/(4K)\), not \(K/2\); see `SOURCE_CORRECTIONS.md`.
""")

TEXT_FILES["PROOF_SECOND_MOMENT.md"] = md(r"""
# Proof: Boundary-Aware Second Moment

Let \(I_X=[X,2X]\cap\mathbb Z\), \(L=\log X\),
\(N_X=|\mathcal D_X|\), and \(\beta=\mathbf1_{\mathcal S_2}\).

## 1. Exact identity

Since

\[
R_X(n)=\sum_s w_X(s)\beta(n-s),
\]

finite expansion and the substitution \(m=n-t\) give

\[
\begin{aligned}
M_2(X)&:=\sum_{n\in I_X}R_X(n)^2\\
&=\sum_{s,t}w_X(s)w_X(t)
\sum_{n=X}^{2X}\beta(n-s)\beta(n-t)\\
&=\boxed{\sum_{s,t}w_X(s)w_X(t)
\sum_{m=X-t}^{2X-t}\beta(m)\beta(m+t-s).}
\end{aligned} \tag{1}
\]

This is an identity, not a boundary-free approximation.

## 2. Common envelope

Every shift in the sum satisfies \(2\le s,t\le X/2\).  For
\(m\in[X-t,2X-t]\),

\[
X/2\le m\le2X,
\qquad
X/2\le m+t-s\le2X.
\]

Thus both indicator arguments lie in a common positive envelope.  Put
\(h=t-s\) and

\[
\nu_X(h)=\sum_{t-s=h}w_X(s)w_X(t).
\]

## 3. Diagonal

For \(h=0\),

\[
\nu_X(0)=\sum_s w_X(s)^2=N_X+O(1)
\]

by global collision finiteness.  The inner sum in (1) is at most the number of
sums of two squares up to \(2X\), so Landau–Ramanujan gives

\[
Q_0(X)\ll\frac X{\sqrt L}.
\]

Therefore the diagonal contribution is

\[
\ll \frac{XN_X}{\sqrt L}
\ll XL^{3/2}. \tag{2}
\]

The quantity \(h/\varphi(h)\) is never assigned at \(h=0\).

## 4. Off diagonal

For \(h\ne0\), the indicator-level FKR/Nowak bound and the common envelope
give

\[
\sum_{m=X-t}^{2X-t}\beta(m)\beta(m+h)
\ll \frac X{L}
\mathfrak S_+(h),
\]

where

\[
\mathfrak S_+(h)=
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}
\left(1+\frac2p\right).
\]

The structured singular-factor theorem gives

\[
\sum_{h\ne0}\nu_X(h)\mathfrak S_+(h)\ll N_X^2.
\]

Hence the off-diagonal contribution is

\[
\ll \frac X{L}N_X^2\ll XL^3. \tag{3}
\]

Combining (2) and (3),

\[
\boxed{M_2(X)\ll X(\log X)^3.} \tag{4}
\]

For distinct shifts, either repeat the argument with
\(\nu_X^{\rm dist}(h)\le\nu_X(h)\), or note that its diagonal is
\(|\mathcal B_X|\asymp N_X\).  Thus

\[
M_2^{\rm dist}(X)\ll X(\log X)^3.
\]
\(\square\)
""")

TEXT_FILES["PROOF_POSITIVE_DENSITY.md"] = md(r"""
# Proof: Positive Density by Paley–Zygmund

Let

\[
I_X=[X,2X]\cap\mathbb Z,
\qquad |I_X|=X+1
\]

for integer \(X\).  Equip \(I_X\) with the uniform probability measure and
write \(Z(n)=R_X(n)\).

The first-moment theorem gives constants \(a>0\) and \(X_1\) such that

\[
\mathbb E Z=\frac{M_1(X)}{|I_X|}
\ge a(\log X)^{3/2} \tag{1}
\]

for \(X\ge X_1\).  The second-moment theorem gives a constant \(b>0\) and
\(X_2\) such that

\[
\mathbb E Z^2=\frac{M_2(X)}{|I_X|}
\le b(\log X)^3. \tag{2}
\]

For any fixed \(0<\theta<1\), Paley–Zygmund gives

\[
\mathbb P(Z\ge\theta\mathbb EZ)
\ge(1-\theta)^2\frac{(\mathbb EZ)^2}{\mathbb EZ^2}
\ge(1-\theta)^2\frac{a^2}{b}. \tag{3}
\]

Take \(\theta=1/2\).  With

\[
c_0=a/2,
\qquad
c_1=\frac{a^2}{8b},
\]

and after increasing \(X_0=\max(X_1,X_2)\) so that \(X+1\ge X\), (3) yields

\[
\boxed{
\#\{n\in I_X:R_X(n)\ge c_0(\log X)^{3/2}\}\ge c_1X.}
\tag{4}
\]

The exact numerical values of \(a,b,c_0,c_1,X_0\) are not extracted.  Their
dependence is only on bases 3 and 5 and the absolute constants in the
Landau–Ramanujan and FKR/Nowak estimates.

For distinct shifts, the distinct first and second moments give the same proof.
Alternatively, collision finiteness gives uniformly

\[
0\le R_X(n)-R_X^{\rm dist}(n)
\le\sum_s(w_X(s)-1)_+
=N_X-|\mathcal B_X|=O(1).
\]

For large \(X\), subtracting this bounded quantity from the threshold in (4)
and reducing \(c_0\) by a fixed factor proves the distinct statement.

The result is a **positive lower density** theorem.  It says neither “almost
all” nor “all”. \(\square\)
""")

TEXT_FILES["THEOREM_POSITIVE_DENSITY.md"] = md(r"""
# Theorem: Direct Two-Square Positive Density on Every Dyadic Interval

Let

\[
\mathcal D_X=\{(c,d)\in\mathbb Z_{\ge0}^2:3^c+5^d\le X/2\},
\]

\[
R_X(n)=\sum_{(c,d)\in\mathcal D_X}
\mathbf1_{\mathcal S_2}(n-3^c-5^d),
\]

and

\[
R_X^{\rm dist}(n)=
\sum_{s:\,\exists(c,d)\in\mathcal D_X,\ 3^c+5^d=s}
\mathbf1_{\mathcal S_2}(n-s).
\]

## Theorem

There exist constants \(c_0,c_1,X_0>0\) such that for every integer
\(X\ge X_0\),

\[
\boxed{
\#\left\{n\in[X,2X]\cap\mathbb Z:
R_X(n)\ge c_0(\log X)^{3/2}\right\}
\ge c_1X.}
\tag{1}
\]

After changing \(c_0,c_1,X_0\) if necessary,

\[
\boxed{
\#\left\{n\in[X,2X]\cap\mathbb Z:
R_X^{\rm dist}(n)\ge c_0(\log X)^{3/2}\right\}
\ge c_1X.}
\tag{2}
\]

In particular,

\[
\#\{n\in[X,2X]\cap\mathbb Z:R_X(n)>0\}\gg X.
\]

The constants depend only on the fixed bases 3 and 5 and on the absolute
constants in the cited Landau–Ramanujan and indicator-sieve estimates.

## Proof

The curved-domain lemma gives

\[
|\mathcal D_X|=\frac{(\log X)^2}{\log3\log5}+O(\log X).
\]

The collision theorem gives bounded shift multiplicity and
\(\sum_sw_X(s)^2=|\mathcal D_X|+O(1)\).  The first-moment proof gives

\[
\sum_{X\le n\le2X}R_X(n)
=\frac K{\log3\log5}X(\log X)^{3/2}
+O(X(\log X)^{1/2}),
\]

where

\[
K=\frac1{\sqrt2}\prod_{p\equiv3\pmod4}(1-p^{-2})^{-1/2}.
\]

The indicator-level FKR/Nowak bound, together with the structured
singular-factor average, yields

\[
\sum_{X\le n\le2X}R_X(n)^2\ll X(\log X)^3,
\]

with the diagonal handled separately.  Paley–Zygmund therefore gives (1).
The distinct first and second moments give (2); equivalently, bounded global
collision excess changes every representation count by only \(O(1)\).
Full details are in `PROOF_FIRST_MOMENT.md`, `PROOF_SECOND_MOMENT.md`, and
`PROOF_POSITIVE_DENSITY.md`. \(\square\)

## Logical scope

This theorem gives a positive proportion in every sufficiently large dyadic
interval and a growing number of exponent-pair representations on that
proportion.  It does not imply density one, almost-all representability, or the
universal A303656 statement.

## Novelty status

The theorem is **PROVED**, but its headline many-representation phenomenon is
**SUBSTANTIALLY SUBSUMED** by Radomskii v6.  The exact dyadic truncation and
direct proof are an **INDEPENDENT ALTERNATIVE PROOF**, not a claim of a new
headline theorem.
""")

TEXT_FILES["RADOMSKII_CONDITION_CROSSWALK.md"] = md(r"""
# Radomskii v6 — Condition Crosswalk

Version lock: **Artyom Radomskii**, *Variants of Romanoff's theorem*,
arXiv:2504.09954v6, revised 13 July 2026.

Radomskii defines sequences \(A=(a_i)\) and \(B=(b_j)\), permits repetitions
in \(B\), and writes

\[
r(n)=\#\{(i,j):a_i+b_j=n\},
\qquad
\rho_B(x)=\max_{v\le x}\operatorname{ord}_B(v).
\]

Use

\[
A=\mathcal S'_2=\langle P_1\rangle,
\qquad
B=(3^c+5^d)_{c,d\ge0},
\qquad
\eta(x)=\sqrt{\log x}.
\]

| Radomskii Theorem 1.1 condition | Verification for the shift family | Frozen lemma/source |
|---|---|---|
| \(A\) strictly increasing | Enumerate the distinct primitive odd sums \(\mathcal S'_2\) increasingly. | Radomskii Example 2; exact set identity \(\mathcal S'_2=\langle P_1\rangle\). |
| \(A(x)\asymp x/\eta(x)\) | Selberg–Delange gives \(A(x)\asymp x/\sqrt{\log x}\).  Only comparability is needed. | Radomskii Example 2; `SOURCE_CORRECTIONS.md` for the corrected leading constant. |
| \(A(x/2)\gg A(x)\) | Immediate from the same asymptotic. | Selberg–Delange. |
| Pair hypothesis \(A(x,r)\ll (r/\varphi(r))x/\eta(x)^2\) | Primitive-set sieve gives \(A(x,r)\ll(r/\varphi(r))x/\log x\). | Radomskii Example 2, citing Halberstam–Richert. |
| \(B\) may have multiplicity | The theorem explicitly says \(b_n\) need not be distinct, while each value has finite multiplicity. | Radomskii Theorem 1.1. |
| \(B(x)\) | \(B(x)=\#\{(c,d):3^c+5^d\le x\}\asymp(\log x)^2\). | `LEMMA_SHIFT_DOMAIN.md`. |
| \(B(x/2)\gg B(x)\) | Fixed-scale stability gives ratio tending to 1. | `LEMMA_SHIFT_DOMAIN.md`. |
| Finite value multiplicity and \(\rho_B(x)\) | Global unit-equation finiteness gives \(\rho_B(x)=O(1)\). | `LEMMA_COLLISIONS.md`. |
| Small-prime condition (1.4) | Its left side equals \(\sum_{p\le(\log x)^\alpha}A_p\log p/p\), where \(A_p\ll L^3+L^4/\operatorname{ord}_p(5)\); the order series converges, so it is \(O(L^4)=O(B(x)^2)\). | `LEMMA_SINGULAR_FACTOR_AVERAGE.md` with \(m=1\). |
| Resulting threshold | \(B(x)/\eta(x)\asymp(\log x)^{3/2}\). | Algebra from the two growth laws. |
| Resulting density factor | \(B(x)/(B(x)+\rho_B(x)\eta(x))\to1\), hence the lower bound is \(\gg x\). | Bounded \(\rho_B\), \(B\asymp L^2\), \(\eta\asymp L^{1/2}\). |
| Primitive subset role | Each primitive representation is a full sum-of-two-squares representation, so Radomskii's lower bound transfers to the original indicator family. | Set inclusion \(\mathcal S'_2\subset\mathcal S_2\). |
| Distinct shifts | Replace the multisequence by its distinct value set.  Then \(\rho_B=1\), the count remains \(\asymp L^2\), and all congruence counts decrease. | Collision theorem and monotonicity. |

## Exact theorem output

Radomskii obtains constants \(c_1,c_2>0\) such that

\[
\#\left\{n\le x:r(n)\ge c_1\frac{B(x)}{\eta(x)}\right\}
\ge c_2x\frac{B(x)}{B(x)+\rho_B(x)\eta(x)}.
\]

For the present family this is

\[
\#\{n\le x:r(n)\gg(\log x)^{3/2}\}\gg x.
\]

The theorem is cumulative and is not printed as a statement on every dyadic
interval with the project-specific truncation \(b\le X/2\).  This distinction
controls the final subsumption label.
""")

TEXT_FILES["RADOMSKII_SUBSUMPTION_VERDICT.md"] = md(r"""
# Radomskii v6 Subsumption Verdict

## Version and author correction

The locked source is

> **Artyom Radomskii**, *Variants of Romanoff's theorem*,
> arXiv:2504.09954v6, 13 July 2026.

The task text's forename “Konstantin” is incorrect.

## Verdict

\[
\boxed{\text{SUBSTANTIALLY SUBSUMED}.}
\]

## What is subsumed

After taking \(A=\mathcal S'_2\),
\(B=(3^c+5^d)_{c,d\ge0}\), and
\(\eta(x)=\sqrt{\log x}\), every hypothesis of Radomskii Theorem 1.1 is
verified by the frozen lemmas.  The theorem explicitly permits multiplicity in
\(B\).  It yields a positive proportion of integers \(n\le x\) having

\[
\Omega\!\left(\frac{B(x)}{\eta(x)}\right)
=\Omega((\log x)^{3/2})
\]

representations.  The distinct set of shifts also satisfies the theorem.
Therefore the headline statement “positive density with
\(\Omega((\log x)^{3/2})\) two-base shift representations” is not a new
specialized theorem after v6.

## Why the label is not `FULLY SUBSUMED`

Radomskii's printed conclusion is cumulative on \([1,x]\) and uses the global
sequence \(B\).  The present theorem is uniform on **every** sufficiently large
\([X,2X]\) and deliberately restricts the shifts to
\(3^c+5^d\le X/2\), so every translated two-square argument remains in a
controlled common interval.  A cumulative lower bound alone does not logically
force the same lower bound in each dyadic shell.  The present direct first/second
moment proof supplies that stronger localization.

The Sidon-scale energy lemma and the structured singular-factor average are
also independent structural statements rather than conclusions of Theorem 1.1.

## Remaining independent contribution

- exact curved-domain bookkeeping;
- a fully typeset projective-to-actual collision argument;
- Sidon-scale energy for \(\{3^c+5^d\}\);
- structured totient/singular-factor averaging;
- a direct indicator-level proof on every dyadic interval;
- the explicit almost-all covariance blocker.

These are specialized contributions.  Their publication novelty, especially
for the two structural lemmas, is not established by this freeze.

## Publication status caveat

arXiv:2504.09954v6 is a recent preprint and has not completed traditional
journal peer review.  That status is relevant to bibliographic caution but is
not a reason to ignore a mathematically applicable general theorem.
""")

TEXT_FILES["CROCKER_PRIOR_ART_AUDIT.md"] = md(r"""
# Crocker and One-Dimensional Prior-Art Audit

## Locked source

Roger Clement Crocker, *On the sum of two squares and two powers of k*,
*Colloquium Mathematicum* **112** (2008), no. 2, 235–267,
DOI 10.4064/cm112-2-3.

## Exact scope

The abstract states that, for every fixed integer \(k\ge2\), the positive
integers representable as two squares plus one power of \(k\) have positive
density.  It then observes that allowing at most two powers also has positive
density.

The paper's stated main purpose and numbered theorems are different: they prove
that infinitely many positive integers fail to be representable as two squares
plus two or fewer powers.  For example, Theorem 1 treats \(k=2\) and produces
infinitely many even exceptions.  The article does not prove a lower bound of
order \((\log X)^{3/2}\) for representation multiplicity.

Accordingly:

| Question | Crocker 2008 |
|---|---|
| Positive density for two squares plus one fixed-base power | Stated as established in the abstract. |
| Positive density after allowing two powers | Immediate support consequence stated in the abstract. |
| Asymptotic density with an explicit constant | Not supplied as the central theorem audited here. |
| Growing representation multiplicity | Not supplied. |
| Two independent exponent variables with bases 3 and 5 | Not the specialized theorem of the paper. |
| Universal representation | Explicitly false for every fixed base \(k\) in Crocker's setting, because infinitely many exceptions are proved. |

## Consequence for A303656 support novelty

Take \(k=3\).  A positive-density set of integers has the form

\[
m=a^2+b^2+3^c.
\]

Translation by 1 preserves lower density, so a positive-density set has the
form

\[
n=a^2+b^2+3^c+1,
\]

which is exactly the \(d=0\) subfamily of the A303656 expression.  Therefore
**bare positive-density support is one-dimensional prior art** and cannot be
presented as the novelty of the two-base theorem.

The stronger claim that a positive proportion has
\(\Omega((\log X)^{3/2})\) exponent-pair representations is not Crocker's
claim, but it is substantially subsumed by Radomskii v6.
""")

TEXT_FILES["NOVELTY_CLASSIFICATION.md"] = md(r"""
# Novelty Classification

The following labels are mathematical-publication classifications, not
correctness grades.

| Item | Classification | Reason |
|---|---|---|
| 1. Curved-domain asymptotic | **STANDARD CONSEQUENCE** | Elementary rectangle count plus an \(O(\log X)\) curved-corner estimate. |
| 2. Finite collision theorem | **STANDARD CONSEQUENCE** | Direct application of a weighted unit equation plus a necessary scaling argument. |
| 3. Bounded multiplicity | **STANDARD CONSEQUENCE** | Immediate from global collision finiteness. |
| 4. Sidon-scale additive energy | **POTENTIALLY NEW LEMMA** | The proof is rigorous and structurally specific; no exhaustive novelty search was completed. |
| 5. Structured singular-factor average | **POTENTIALLY NEW LEMMA** | The order-period averaging argument is rigorous; independent prior-art coverage was not established. |
| 6. Direct dyadic positive-density proof | **INDEPENDENT ALTERNATIVE PROOF** | It localizes to every dyadic interval and uses the full indicator; it is not a new headline phenomenon after Radomskii v6. |
| 7. Many-representation theorem | **SUBSUMED** | Radomskii Theorem 1.1 gives the same threshold scale and positive-proportion phenomenon once the present hypotheses are verified. |
| 8. Distinct-shift theorem | **SUBSUMED** | The distinct shift set also satisfies Radomskii; the exact dyadic localization remains an independent proof detail. |
| 9. Almost-all covariance formulation | **UNKNOWN** | It is a precise blocker/reduction, not a proved theorem, and its novelty was not searched exhaustively. |

## Methodological-value assessment

The two plausible standalone technical contributions are the Sidon-scale energy
lemma and the structured singular-factor average.  They may be reusable for
other sparse sumsets of multiplicatively independent powers.  At present they
are only `POTENTIALLY NEW LEMMA / NOVELTY NOT ESTABLISHED`; combining them with
standard lemmas does not justify describing the package as a major advance.

## Headline classification

\[
\boxed{\text{SPECIALIZED APPLICATION + INDEPENDENT ALTERNATIVE PROOF}.}
\]

A `NEW THEOREM` label is not supported.
""")

TEXT_FILES["ALMOST_ALL_BLOCKER.md"] = md(r"""
# Almost-All Blocker — Frozen

Let \(I_X=[X,2X]\cap\mathbb Z\), \(\beta=\mathbf1_{\mathcal S_2}\), and

\[
A_s(X)=\sum_{n\in I_X}\beta(n-s),
\qquad
C_{s,t}(X)=\sum_{n\in I_X}\beta(n-s)\beta(n-t).
\]

Since

\[
R_X(n)=\sum_s w_X(s)\beta(n-s),
\qquad
\mu_X=\frac1{|I_X|}\sum_{n\in I_X}R_X(n),
\]

finite expansion gives the exact variance identity

\[
\boxed{
\sum_{n\in I_X}(R_X(n)-\mu_X)^2
=\sum_{s,t}w_X(s)w_X(t)
\left(C_{s,t}(X)-\frac{A_s(X)A_t(X)}{|I_X|}\right).}
\tag{1}
\]

A sufficient concentration input would be

\[
\boxed{
\sum_{s,t}w_X(s)w_X(t)
\left(C_{s,t}(X)-\frac{A_s(X)A_t(X)}{|I_X|}\right)
=o\!\left(\frac{X|\mathcal D_X|^2}{\log X}\right).}
\tag{2}
\]

Indeed, the square of the mean is of order
\(|\mathcal D_X|^2/\log X\); (2) and Chebyshev would make the exceptional
proportion tend to zero.

## Why the frozen inputs do not prove (2)

1. **Indicator upper bounds are unsigned.**  FKR/Nowak controls
   \(C_{s,t}\) from above but does not approximate it by the product of the two
   one-point densities with a signed error.
2. **A growing mean is not concentration.**  The fact that
   \(\mu_X\asymp(\log X)^{3/2}\to\infty\) permits large variance.
3. **Sidon-scale energy is combinatorial, not probabilistic.**  It controls how
   often differences repeat, but it gives no cancellation in the covariance
   attached to a difference.
4. **Pair upper bounds do not yield a variance asymptotic.**  They are sufficient
   for a bounded second-moment ratio and positive density, not for a ratio
   tending to 1.
5. **An \(r_2\)-weighted convolution is the wrong observable.**  Representation
   weights can be highly nonuniform; estimates for
   \(r_2(m)r_2(m+h)\) do not replace covariance of the 0–1 indicator.
6. **Boundary dependence matters.**  The intervals in \(C_{s,t}(X)\) vary with
   both shifts; any future theorem must be uniform over the growing structured
   family and preserve the exact dyadic boundary.

## Frozen status

\[
\boxed{\text{ALMOST ALL: NOT PROVED}.}
\]

No numerical covariance campaign, no further almost-all route, and no density-1
claim is authorized in this phase.
""")

TEXT_FILES["SOURCE_CORRECTIONS.md"] = md(r"""
# Source and Metadata Corrections

## 1. Radomskii author and version

Incorrect: “Konstantin Radomskii”.  
Correct: **Artyom Radomskii**, *Variants of Romanoff's theorem*,
arXiv:2504.09954v6, revised **13 July 2026**.

## 2. FKR bibliography

Correct citation:

> Tristan Freiberg, Pär Kurlberg, and Lior Rosenzweig,
> *Poisson distribution for gaps between sums of two squares and level spacings
> for toral point scatterers*, *Communications in Number Theory and Physics*
> **11** (2017), no. 4, 837–877,
> DOI 10.4310/CNTP.2017.v11.n4.a3.

The needed indicator upper bound is the **unnumbered display in §2.1**.  The
package does not assign it a nonexistent theorem or lemma number.  The general
case is credited there to Nowak.

## 3. Primitive-subset leading constant

Let

\[
\mathcal S'_2=\langle P_1\rangle
\]

be the positive integers composed only of primes \(1\pmod4\), and

\[
H(z)=\prod_{p\equiv1(4)}(1-p^{-z})^{-1}.
\]

Then

\[
H(z)^2=\zeta(z)L(z,\chi_4)(1-2^{-z})
\prod_{p\equiv3(4)}(1-p^{-2z}).
\]

Selberg–Delange therefore gives

\[
\#\{n\le x:n\in\mathcal S'_2\}
\sim \kappa\frac{x}{\sqrt{\log x}},
\]

where

\[
\kappa=\frac1{2\sqrt2}
\prod_{p\equiv3(4)}(1-p^{-2})^{1/2}
=\frac1{4K}.
\]

Radomskii v6 Example 2 prints the inverse Euler-product exponent, yielding
\(K/2\).  That printed constant is inconsistent with the displayed set identity
\(\mathcal S'_2=\langle P_1\rangle\).  The previous formal audit's instruction
to retain \(K/2\) is therefore superseded.  The subsumption argument uses only
\(A(x)\asymp x/\sqrt{\log x}\), so it survives unchanged.

## 4. Crocker scope

Crocker 2008 records one-power positive density in the abstract.  Its numbered
main theorems prove infinitely many nonrepresentable integers for two or fewer
powers; they do not establish the present \((\log X)^{3/2}\) multiplicity
threshold.

## 5. Provenance language

The Phase A draft's own packaging notes identify reconstructed files and
nondeterministic diagnostics.  This Phase B package preserves the uploaded ZIP
unchanged and never describes reconstructed content as an original web-session
artifact.

## 6. Mathematical authority hierarchy

The Phase A formal audit is referee evidence, not an authority.  Primary-source
statements and the independent Phase B derivation control every conflict.

### Accepted

- Direct dyadic positive-density theorem: **PROVED**.
- Distinct-shift dyadic theorem: **PROVED**.
- Finite nontrivial shift collisions: **PROVED**.
- Bounded shift multiplicity: **PROVED**.
- Sidon-scale additive energy: **PROVED; NOVELTY NOT ESTABLISHED**.
- Structured singular-factor average: **PROVED; NOVELTY NOT ESTABLISHED**.
- FKR indicator-level correlation input: **VERIFIED**.
- Radomskii v6 subsumption: **SUBSTANTIALLY SUBSUMED**.
- Crocker bare positive-density prior art: **VERIFIED**.

### Rejected or deprecated

- Author “Konstantin Radomskii”: **REJECTED**; the correct author is Artyom
  Radomskii.
- Primitive-subset constant \(K/2\): **REJECTED FOR THIS SET**; the corrected
  value is \(1/(4K)\).
- Headline classification `NEW THEOREM`: **REJECTED**.
- Almost-all inference from the second moment: **REJECTED**.
- Universal inference: **REJECTED**.

### Unresolved

- Almost-all representability: **NOT PROVED**.
- Universal A303656: **UNRESOLVED**.
- Novelty of the two structural lemmas: **NOT ESTABLISHED**.
- Certified counterexample: **NONE**.

## 7. Novelty wording

Replace `NEW THEOREM` by

\[
\text{SPECIALIZED APPLICATION / INDEPENDENT ALTERNATIVE PROOF},
\]

with the headline phenomenon marked `SUBSTANTIALLY SUBSUMED` by Radomskii v6.
""")

TEXT_FILES["BIBLIOGRAPHY.md"] = md(r"""
# Frozen Bibliography

1. **Edmund Landau**, “Über die Einteilung der positiven ganzen Zahlen in vier
   Klassen nach der Mindestzahl der zu ihrer additiven Zusammensetzung
   erforderlichen Quadrate,” *Archiv der Mathematik und Physik*, series 3,
   **13** (1908), 305–312.

2. **Hubert Delange**, “Généralisation du théorème de Ikehara,” *Annales
   scientifiques de l'École Normale Supérieure*, 3e série, **71** (1954),
   no. 3, 213–242.  NUMDAM item `ASENS_1954_3_71_3_213_0`.

3. **J. H. Evertse and K. Győry**, “On the numbers of solutions of weighted
   unit equations,” *Compositio Mathematica* **66** (1988), no. 3, 329–354.
   NUMDAM item `CM_1988__66_3_329_0`.

4. **H. Halberstam and H. E. Richert**, *Sieve Methods*, London Mathematical
   Society Monographs, Academic Press, 1974.  This is the source cited by
   Radomskii for the primitive-set pair upper bound.

5. **Werner Georg Nowak**, “On the distribution of M-tuples of B-numbers,”
   *Publications de l'Institut Mathématique (Nouvelle série)* **77(91)**
   (2005), 71–78.  DOI 10.2298/PIM0591071N; arXiv:math/0410010.

6. **Roger Clement Crocker**, “On the sum of two squares and two powers of
   k,” *Colloquium Mathematicum* **112** (2008), no. 2, 235–267.
   DOI 10.4064/cm112-2-3.

7. **John Friedlander and Henryk Iwaniec**, *Opera de Cribro*, American
   Mathematical Society Colloquium Publications, vol. 57, AMS, 2010.

8. **Tristan Freiberg, Pär Kurlberg, and Lior Rosenzweig**, “Poisson
   distribution for gaps between sums of two squares and level spacings for
   toral point scatterers,” *Communications in Number Theory and Physics*
   **11** (2017), no. 4, 837–877.
   DOI 10.4310/CNTP.2017.v11.n4.a3; arXiv:1701.01157.

9. **Artyom Radomskii**, “On Romanoff's theorem,” *Izvestiya: Mathematics*
   **87** (2023), no. 1, 113–153.  Cited in Radomskii v6 for the totient-moment
   divisor-expansion lemma.

10. **Artyom Radomskii**, “Variants of Romanoff's theorem,”
    arXiv:2504.09954v6, revised 13 July 2026.  Version lock applies throughout
    this package.

Exact inspected-PDF hashes and source locations are in
`results/source_locks.json`.
""")

TEXT_FILES["LIMITATIONS.md"] = md(r"""
# Limitations

1. **No universal theorem.**  The assertion that every \(n>1\) has the target
   representation remains unresolved.
2. **No almost-all theorem.**  The signed indicator covariance estimate in
   `ALMOST_ALL_BLOCKER.md` is missing.
3. **No new \(T(n)\) computation.**  This phase performs no interval scan,
   low-\(T\) search, counterexample search, or production computation.
4. **No global collision enumeration.**  The unit-equation theorem proves
   finiteness but does not identify every collision or prove that 28 is unique.
5. **Ineffective structural constants.**  The cited Evertse–Győry bound is
   finite but not made numerically effective here; the positive-density constants
   and threshold \(X_0\) are not extracted.
6. **Recent-preprint dependence in the novelty audit.**  Radomskii v6 is an
   arXiv preprint dated 13 July 2026 and has not completed traditional journal
   peer review.
7. **Novelty search is not exhaustive.**  The energy and singular-factor lemmas
   are only marked potentially new; no publication claim is frozen.
8. **Crocker wording is limited.**  One-power positive density is recorded in
   the abstract, while the body focuses on infinite exceptional sets.
9. **Primitive constant correction.**  The corrected \(1/(4K)\) is an exact
   Euler-product derivation; it is not needed in the full-set first moment.
10. **No repository integration.**  No Codex, Codex Ultra, Git, WSL repository,
    build system, or production artifact was used.
11. **No source PDFs redistributed.**  The package freezes hashes and metadata,
    not copies of copyrighted primary-source PDFs.
12. **Determinism scope.**  Byte identity is asserted for the scientific core
    and for two ZIP builds in the locked environment.  Runtime/RSS is excluded.
""")

TEXT_FILES["REPRODUCIBILITY.md"] = md(r"""
# Reproducibility and Deterministic Freeze

## Locked environment

- Python: 3.13.5
- Platform: Linux 4.4.0 x86_64
- GCC metadata: gcc (Debian 14.2.0-19) 14.2.0
- SHA256 utility metadata: GNU coreutils 9.7
- ZIP format: Python `zipfile`, `ZIP_STORED`, sorted entries, fixed timestamp
  `1980-01-01 00:00:00`, normalized regular-file mode `0644`
- Text encoding: UTF-8, LF endings
- Locale for sorted manifests: bytewise path order implemented in Python

## Scientific core

`SCIENTIFIC_CORE.json` is canonical JSON with sorted keys and compact
separators.  It lists every scientific-core file, byte size, and SHA256, plus
the authenticated input hashes.  It excludes:

- the two original evidence ZIP copies;
- `ORIGINAL_PHASE_A_DRAFT/` and `FORMAL_AUDIT/` wrapper metadata;
- `NONDETERMINISTIC_DIAGNOSTICS/`;
- replay and packaging logs;
- `results/replay_report.json`;
- `SCIENTIFIC_CORE.json`, `SCIENTIFIC_CORE.sha256`, and `SHA256SUMS.txt` from
  their own input set.

`SCIENTIFIC_CORE.sha256` is the SHA256 of the exact canonical JSON bytes.

## Replay command

From the unpacked package root:

```bash
python3 scripts/generate_scientific_core.py \
  --output /tmp/a303656-replay-1 --core-only
python3 scripts/generate_scientific_core.py \
  --output /tmp/a303656-replay-2 --core-only
python3 scripts/replay_scientific_core.py \
  --frozen-root . \
  --replay-a /tmp/a303656-replay-1 \
  --replay-b /tmp/a303656-replay-2
```

The wrapper compares every path listed in the canonical manifest, as well as
the two generated core manifests and their hashes.  It is read-only with
respect to the frozen package and never changes `SHA256SUMS.txt`.

## Archive verification

```bash
python3 scripts/verify_archives.py --package-root .
```

This checks outer SHA256, ZIP CRC, path traversal, symlink entries, file lists,
and the 41-entry internal draft manifest.  The formal-audit archive has no
internal manifest, which is reported rather than concealed.

## Symbolic constant check

```bash
python3 scripts/symbolic_constant_check.py
```

The script uses exact rational exponent pairs for the factors 2 and the Euler
product \(P=\prod_{p\equiv3(4)}(1-p^{-2})\).  It verifies
\(\kappa K=1/4\) and therefore \(\kappa=1/(4K)\), while rejecting
\(\kappa=K/2\).

## Frozen-package verification

```bash
python3 scripts/verify_frozen_package.py --package-root .
```

The verifier checks the canonical core, `SCIENTIFIC_CORE.sha256`, the full
`SHA256SUMS.txt`, required deliverables, source ZIP locks, and the absence of
unexpected C0 control bytes in every scientific-core file.  Only horizontal tab
and line feed are allowed.  It does not write any file.

## Deterministic ZIP replay

```bash
python3 scripts/build_deterministic_zip.py \
  --source . --output /tmp/frozen-a.zip
python3 scripts/build_deterministic_zip.py \
  --source . --output /tmp/frozen-b.zip
sha256sum /tmp/frozen-a.zip /tmp/frozen-b.zip
cmp /tmp/frozen-a.zip /tmp/frozen-b.zip
```

The final outer ZIP hash cannot be embedded inside itself without a circular
mutation; it is reported externally with the download artifact.

## Generation provenance

All core files are generated by `scripts/generate_scientific_core.py` using the
command and input hashes recorded in `results/generation_provenance.json`.
Nondeterministic timing and memory diagnostics, if any are later collected, must
remain under `NONDETERMINISTIC_DIAGNOSTICS/` and never enter a scientific hash.
""")

TEXT_FILES["FINAL_FROZEN_PROOF/README.md"] = md(r"""
# Final Frozen Proof Layer

The authoritative Phase B proof is the set of top-level theorem, lemma, proof,
source-audit, novelty, limitation, and reproducibility files authenticated by
`SCIENTIFIC_CORE.json`.

This directory marker distinguishes that layer from the untouched historical
ZIPs in `ORIGINAL_PHASE_A_DRAFT/` and `FORMAL_AUDIT/`.  No reconstructed Phase A
file is relabeled as an original session artifact.
""")

TEXT_FILES["scripts/README.md"] = md(r"""
# Deterministic scripts

- `generate_scientific_core.py`: self-contained canonical core generator.
- `replay_scientific_core.py`: byte-comparison wrapper; read-only on the frozen root.
- `verify_archives.py`: safe ZIP and internal-manifest audit.
- `symbolic_constant_check.py`: exact primitive-constant algebra.
- `verify_frozen_package.py`: full read-only verifier.
- `build_deterministic_zip.py`: sorted, fixed-timestamp, stored ZIP builder.

No script computes new \(T(n)\), scans intervals, searches counterexamples, or
runs an almost-all campaign.
""")

DRAFT_LISTING_TEXT = "\n".join(DRAFT_FILES) + "\n"
AUDIT_LISTING_TEXT = "\n".join(AUDIT_FILES) + "\n"
TEXT_FILES["results/draft_file_listing.txt"] = DRAFT_LISTING_TEXT
TEXT_FILES["results/audit_file_listing.txt"] = AUDIT_LISTING_TEXT

# Scripts other than this generator are embedded for deterministic replay.
TEXT_FILES["scripts/symbolic_constant_check.py"] = md(r'''#!/usr/bin/env python3
"""Exact exponent-pair check for the primitive two-square constant."""
from fractions import Fraction
import json

# A monomial 2^a P^b is represented by (a,b).
K = (Fraction(-1, 2), Fraction(-1, 2))
kappa = (Fraction(-3, 2), Fraction(1, 2))
printed = (Fraction(-3, 2), Fraction(-1, 2))  # K/2
product = (K[0] + kappa[0], K[1] + kappa[1])
result = {
    "basis": ["2", "P"],
    "K_exponents": [str(x) for x in K],
    "kappa_exponents": [str(x) for x in kappa],
    "kappa_times_K_exponents": [str(x) for x in product],
    "kappa_times_K_equals_one_quarter": product == (Fraction(-2), Fraction(0)),
    "kappa_equals_one_over_4K": product == (Fraction(-2), Fraction(0)),
    "printed_K_over_2_exponents": [str(x) for x in printed],
    "printed_K_over_2_equals_kappa": printed == kappa,
}
print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
''')

TEXT_FILES["scripts/build_deterministic_zip.py"] = md(r'''#!/usr/bin/env python3
"""Build a byte-deterministic ZIP using stored entries and fixed metadata."""
from __future__ import annotations
import argparse
import os
import zipfile
from pathlib import Path

FIXED_DATE = (1980, 1, 1, 0, 0, 0)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True)
    ap.add_argument("--output", required=True)
    ns = ap.parse_args()
    root = Path(ns.source).resolve()
    out = Path(ns.output).resolve()
    paths = sorted(
        (p for p in root.rglob("*") if p.is_file()),
        key=lambda p: p.relative_to(root).as_posix().encode("utf-8"),
    )
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as zf:
        for path in paths:
            rel = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(rel, FIXED_DATE)
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = (0o100644 << 16)
            info.flag_bits |= 0x800
            with path.open("rb") as fh:
                zf.writestr(info, fh.read())
    print(out)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
''')

TEXT_FILES["scripts/replay_scientific_core.py"] = md(r'''#!/usr/bin/env python3
"""Compare two fresh replays with the frozen scientific core; read-only."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--frozen-root", required=True)
    ap.add_argument("--replay-a", required=True)
    ap.add_argument("--replay-b", required=True)
    ns = ap.parse_args()
    roots = [Path(ns.frozen_root), Path(ns.replay_a), Path(ns.replay_b)]
    manifests = [json.loads((r / "SCIENTIFIC_CORE.json").read_text("utf-8")) for r in roots]
    expected_paths = [item["path"] for item in manifests[0]["files"]]
    errors = []
    for r in roots[1:]:
        got = [item["path"] for item in json.loads((r / "SCIENTIFIC_CORE.json").read_text("utf-8"))["files"]]
        if got != expected_paths:
            errors.append(f"path-list mismatch: {r}")
    compare_paths = expected_paths + ["SCIENTIFIC_CORE.json", "SCIENTIFIC_CORE.sha256"]
    for rel in compare_paths:
        hashes = [sha(r / rel) for r in roots]
        if len(set(hashes)) != 1:
            errors.append(f"byte mismatch {rel}: {hashes}")
    if errors:
        print("FAIL")
        for e in errors:
            print(e)
        return 1
    print("PASS")
    print(f"compared_files={len(compare_paths)}")
    print(f"scientific_core_sha256={sha(roots[0] / 'SCIENTIFIC_CORE.json')}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
''')

TEXT_FILES["scripts/verify_archives.py"] = md(r'''#!/usr/bin/env python3
"""Read-only safe audit of the two original evidence ZIPs."""
from __future__ import annotations
import argparse
import hashlib
import os
import re
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

EXPECTED = {
    "ORIGINAL_PHASE_A_DRAFT/A303656_DIRECT_TWO_SQUARE_PHASE_A_DRAFT(2).zip":
        "a1fa61b65ed734133046410d1ab3f8ac1aa697f88cc9de0e10bd5d8f094b2375",
    "FORMAL_AUDIT/A303656_DIRECT_TWO_SQUARE_PHASE_A_FORMAL_AUDIT(1).zip":
        "e3d8559c32bc64e046b85032c4111145092f4f63e373e0d0355932a43f972e15",
}

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def safe_name(name: str) -> bool:
    p = PurePosixPath(name)
    return not p.is_absolute() and ".." not in p.parts and not re.match(r"^[A-Za-z]:", name)

def is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--package-root", required=True)
    ns = ap.parse_args()
    root = Path(ns.package_root)
    errors = []
    for rel, expected in EXPECTED.items():
        path = root / rel
        got = sha(path)
        print(f"{rel}: sha256={got}")
        if got != expected:
            errors.append(f"outer hash mismatch: {rel}")
        with zipfile.ZipFile(path) as zf:
            bad_names = [i.filename for i in zf.infolist() if not safe_name(i.filename)]
            links = [i.filename for i in zf.infolist() if is_symlink(i)]
            crc_bad = zf.testzip()
            print(f"  files={sum(not i.is_dir() for i in zf.infolist())} unsafe={len(bad_names)} symlinks={len(links)} crc_bad={crc_bad}")
            if bad_names or links or crc_bad:
                errors.append(f"ZIP safety/CRC failure: {rel}")
            if "DRAFT" in rel:
                manifest_name = "A303656_phaseA_package/SHA256SUMS.txt"
                lines = zf.read(manifest_name).decode("utf-8").splitlines()
                passed = 0
                for line in lines:
                    digest, name = line.split("  ", 1)
                    clean = name.removeprefix("./")
                    data = zf.read("A303656_phaseA_package/" + clean)
                    if hashlib.sha256(data).hexdigest() != digest:
                        errors.append(f"internal manifest mismatch: {clean}")
                    else:
                        passed += 1
                print(f"  internal_manifest={passed}/{len(lines)}")
            else:
                names = {i.filename for i in zf.infolist()}
                if any(n.endswith("SHA256SUMS.txt") for n in names):
                    errors.append("unexpected audit manifest status")
                print("  internal_manifest=ABSENT")
    if errors:
        print("FAIL")
        for e in errors:
            print(e)
        return 1
    print("PASS")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
''')

TEXT_FILES["scripts/verify_frozen_package.py"] = md(r'''#!/usr/bin/env python3
"""Read-only verifier for manifests, core, required files, and evidence locks."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

REQUIRED = {
"FINAL_REPORT.md","EXECUTIVE_VERDICT.md","FINAL_VERDICT.json",
"THEOREM_POSITIVE_DENSITY.md","LEMMA_SHIFT_DOMAIN.md","LEMMA_COLLISIONS.md",
"LEMMA_ADDITIVE_ENERGY.md","LEMMA_SINGULAR_FACTOR_AVERAGE.md",
"LEMMA_INDICATOR_CORRELATION.md","PROOF_FIRST_MOMENT.md",
"PROOF_SECOND_MOMENT.md","PROOF_POSITIVE_DENSITY.md",
"RADOMSKII_CONDITION_CROSSWALK.md","RADOMSKII_SUBSUMPTION_VERDICT.md",
"CROCKER_PRIOR_ART_AUDIT.md","NOVELTY_CLASSIFICATION.md",
"ALMOST_ALL_BLOCKER.md","BIBLIOGRAPHY.md","SOURCE_CORRECTIONS.md",
"LIMITATIONS.md","REPRODUCIBILITY.md","environment.json",
"SCIENTIFIC_CORE.json","SCIENTIFIC_CORE.sha256","SHA256SUMS.txt"
}

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--package-root", required=True)
    ns = ap.parse_args()
    root = Path(ns.package_root)
    errors = []
    missing = sorted(p for p in REQUIRED if not (root / p).is_file())
    if missing:
        errors.extend(f"missing required file: {p}" for p in missing)
    manifest_bytes = (root / "SCIENTIFIC_CORE.json").read_bytes()
    expected_core_hash = (root / "SCIENTIFIC_CORE.sha256").read_text("utf-8").split()[0]
    if hashlib.sha256(manifest_bytes).hexdigest() != expected_core_hash:
        errors.append("SCIENTIFIC_CORE.sha256 mismatch")
    core = json.loads(manifest_bytes)
    for item in core["files"]:
        p = root / item["path"]
        if not p.is_file() or p.stat().st_size != item["bytes"] or sha(p) != item["sha256"]:
            errors.append(f"scientific core mismatch: {item['path']}")
            continue
        data = p.read_bytes()
        bad = [(offset, value) for offset, value in enumerate(data)
               if value < 32 and value not in (9, 10)]
        if bad:
            preview = ", ".join(f"offset={offset}:0x{value:02x}" for offset, value in bad[:8])
            errors.append(f"unexpected control byte in {item['path']}: {preview}")
    for line in (root / "SHA256SUMS.txt").read_text("utf-8").splitlines():
        digest, rel = line.split("  ", 1)
        p = root / rel
        if not p.is_file() or sha(p) != digest:
            errors.append(f"full manifest mismatch: {rel}")
    if errors:
        print("FAIL")
        for e in errors:
            print(e)
        return 1
    print("PASS")
    print(f"scientific_core_files={len(core['files'])}")
    print(f"scientific_core_sha256={expected_core_hash}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
''')

# Structured JSON payloads.
FINAL_VERDICT = {
    "freeze_date": FREEZE_DATE,
    "artifact_revision": "phase-b-control-byte-repair-r1",
    "authority_hierarchy": {
        "accepted": {
            "direct_dyadic_positive_density_theorem": "PROVED",
            "distinct_shift_dyadic_theorem": "PROVED",
            "finite_nontrivial_shift_collisions": "PROVED",
            "bounded_shift_multiplicity": "PROVED",
            "sidon_scale_additive_energy": "PROVED; NOVELTY_NOT_ESTABLISHED",
            "structured_singular_factor_average": "PROVED; NOVELTY_NOT_ESTABLISHED",
            "fkr_indicator_level_correlation_input": "VERIFIED",
            "radomskii_v6_subsumption": "SUBSTANTIALLY_SUBSUMED",
            "crocker_bare_positive_density_prior_art": "VERIFIED",
        },
        "rejected_or_deprecated": {
            "author_konstantin_radomskii": "REJECTED; correct_author=Artyom_Radomskii",
            "primitive_subset_constant_K_over_2": "REJECTED_FOR_THIS_SET; corrected=1/(4K)",
            "headline_new_theorem": "REJECTED",
            "almost_all_inference_from_second_moment": "REJECTED",
            "universal_inference": "REJECTED",
        },
        "unresolved": {
            "almost_all_representability": "NOT_PROVED",
            "universal_A303656": "UNRESOLVED",
            "structural_lemma_novelty": "NOT_ESTABLISHED",
            "certified_counterexample": "NONE",
        },
    },
    "global_status": "OEIS A303656: UNRESOLVED",
    "mathematical_status": {
        "positive_density": "PROVED",
        "many_representations": "PROVED",
        "distinct_shift_version": "PROVED",
        "sidon_scale_energy": "PROVED",
        "structured_singular_factor_average": "PROVED",
        "almost_all": "NOT_PROVED",
        "universal": "UNRESOLVED",
    },
    "novelty_status": {
        "headline": "SUBSTANTIALLY_SUBSUMED_BY_RADOMSKII_V6",
        "direct_dyadic_proof": "INDEPENDENT_ALTERNATIVE_PROOF",
        "energy_lemma": "POTENTIALLY_NEW_LEMMA_NOVELTY_NOT_ESTABLISHED",
        "singular_factor_lemma": "POTENTIALLY_NEW_LEMMA_NOVELTY_NOT_ESTABLISHED",
        "bare_positive_density": "ONE_DIMENSIONAL_PRIOR_ART",
    },
    "project": "A303656 additive number theory research",
    "route_status": "FREEZE_AND_STOP",
    "route_verdict": "ACCEPT PROOF / SUBSTANTIALLY SUBSUMED",
    "subsumption": {
        "classification": "SUBSTANTIALLY_SUBSUMED",
        "source": "Artyom Radomskii, Variants of Romanoff's theorem, arXiv:2504.09954v6, 2026-07-13",
        "traditional_peer_review_complete": False,
    },
    "theorem": {
        "domain": "integer X >= X0",
        "statement": "positive proportion of n in [X,2X] have at least c0*(log X)^(3/2) exponent-pair representations; same for distinct shifts",
        "type": "positive_lower_density_only",
    },
}

ARCHIVE_INTEGRITY = {
    "audit_zip": {
        "crc": "PASS",
        "file_count": 3,
        "internal_manifest": "ABSENT",
        "path_traversal": "PASS",
        "sha256": INPUT_HASHES["A303656_DIRECT_TWO_SQUARE_PHASE_A_FORMAL_AUDIT(1).zip"],
        "symlink_entries": "PASS",
        "zip_entry_count": 4,
    },
    "draft_zip": {
        "crc": "PASS",
        "file_count": 42,
        "internal_manifest_entries": 41,
        "internal_manifest_passed": 41,
        "path_traversal": "PASS",
        "sha256": INPUT_HASHES["A303656_DIRECT_TWO_SQUARE_PHASE_A_DRAFT(2).zip"],
        "symlink_entries": "PASS",
        "zip_entry_count": 46,
    },
    "method": "Python zipfile safe-name, Unix mode, CRC, and SHA256 audit",
}

SOURCE_HIERARCHY = {
    "conflict_rule": "Primary literature and the independent Phase B proof prevail over draft claims and prior audit corrections.",
    "accepted": {
        "direct_dyadic_positive_density_theorem": "PROVED",
        "distinct_shift_dyadic_theorem": "PROVED",
        "finite_nontrivial_shift_collisions": "PROVED",
        "bounded_shift_multiplicity": "PROVED",
        "sidon_scale_additive_energy": "PROVED; NOVELTY_NOT_ESTABLISHED",
        "structured_singular_factor_average": "PROVED; NOVELTY_NOT_ESTABLISHED",
        "fkr_indicator_level_correlation_input": "VERIFIED",
        "radomskii_v6_subsumption": "SUBSTANTIALLY_SUBSUMED",
        "crocker_bare_positive_density_prior_art": "VERIFIED",
    },
    "rejected_or_deprecated": {
        "author_konstantin_radomskii": "REJECTED; correct_author=Artyom_Radomskii",
        "primitive_subset_constant_K_over_2": "REJECTED_FOR_THIS_SET; corrected=1/(4K)",
        "headline_new_theorem": "REJECTED",
        "almost_all_inference_from_second_moment": "REJECTED",
        "universal_inference": "REJECTED",
    },
    "unresolved": {
        "almost_all_representability": "NOT_PROVED",
        "universal_A303656": "UNRESOLVED",
        "structural_lemma_novelty": "NOT_ESTABLISHED",
        "certified_counterexample": "NONE",
    },
    "levels": [
        {"rank": 1, "sources": ["exact-version primary literature", "Phase B independent derivation"], "role": "mathematical authority"},
        {"rank": 2, "sources": ["Phase B task specification", "project execution rules"], "role": "scope and prohibited-route authority"},
        {"rank": 3, "sources": ["original Phase A draft ZIP"], "role": "claim and computational-evidence source"},
        {"rank": 4, "sources": ["Phase A formal audit ZIP"], "role": "referee evidence only"},
    ],
}

SOURCE_LOCKS = {
    "crocker_2008": {
        "citation": "Roger Clement Crocker, On the sum of two squares and two powers of k, Colloquium Mathematicum 112 (2008), no. 2, 235-267",
        "doi": "10.4064/cm112-2-3",
        "inspected_pdf_sha256": SOURCE_PDF_HASHES["crocker_2008.pdf"],
        "scope_location": "abstract; main proposition and Theorem 1 on p. 236",
    },
    "delange_1954": {
        "citation": "Hubert Delange, Generalisation du theoreme de Ikehara, Annales scientifiques de l'ENS (3) 71 (1954), no. 3, 213-242",
        "inspected_pdf_sha256": SOURCE_PDF_HASHES["delange_1954.pdf"],
        "numdam_item": "ASENS_1954_3_71_3_213_0",
    },
    "evertse_gyory_1988": {
        "citation": "J. H. Evertse and K. Gyory, On the numbers of solutions of weighted unit equations, Compositio Mathematica 66 (1988), no. 3, 329-354",
        "inspected_pdf_sha256": SOURCE_PDF_HASHES["evertse_gyory_1988.pdf"],
        "location": "Theorem 1, section 1",
        "numdam_item": "CM_1988__66_3_329_0",
    },
    "fkr_2017": {
        "arxiv": "1701.01157v1",
        "citation": "Tristan Freiberg, Pär Kurlberg, Lior Rosenzweig, Poisson distribution for gaps between sums of two squares and level spacings for toral point scatterers, CNTP 11 (2017), no. 4, 837-877",
        "doi": "10.4310/CNTP.2017.v11.n4.a3",
        "inspected_pdf_sha256": SOURCE_PDF_HASHES["fkr_1701.01157v1.pdf"],
        "location": "section 2.1, unnumbered indicator upper-bound display",
    },
    "nowak_2005": {
        "arxiv": "math/0410010",
        "citation": "Werner Georg Nowak, On the distribution of M-tuples of B-numbers, Publications de l'Institut Mathematique 77(91) (2005), 71-78",
        "doi": "10.2298/PIM0591071N",
        "inspected_pdf_sha256": None,
    },
    "radomskii_v6": {
        "arxiv": "2504.09954v6",
        "author": "Artyom Radomskii",
        "inspected_pdf_sha256": SOURCE_PDF_HASHES["radomskii_2504.09954v6.pdf"],
        "locations": ["Theorem 1.1", "Example 2", "Lemma 3.1"],
        "revision_date": "2026-07-13",
        "traditional_peer_review_complete": False,
    },
}

PROOF_GRAPH = {
    "positive_density_theorem": ["first_moment", "second_moment", "Paley-Zygmund"],
    "first_moment": ["curved_shift_domain", "Landau-Ramanujan/Selberg-Delange"],
    "second_moment": ["collision_diagonal", "indicator_correlation", "structured_singular_average"],
    "collision_diagonal": ["Evertse-Gyory weighted unit equation", "projective_scaling_uniqueness"],
    "structured_singular_average": ["Radomskii Lemma 3.1", "order-period congruence count", "absolute convergence of order series"],
    "distinct_shift_theorem": ["collision_finiteness", "weighted theorem or parallel moments"],
    "almost_all": ["UNRESOLVED signed indicator covariance cancellation"],
}


def exact_symbolic_result() -> dict[str, Any]:
    # Monomial basis (2, P), with P=prod_{p=3 mod 4}(1-p^-2).
    K = (Fraction(-1, 2), Fraction(-1, 2))
    kappa = (Fraction(-3, 2), Fraction(1, 2))
    printed = (Fraction(-3, 2), Fraction(-1, 2))
    product = (K[0] + kappa[0], K[1] + kappa[1])
    return {
        "basis": ["2", "P"],
        "K_exponents": [str(x) for x in K],
        "kappa_exponents": [str(x) for x in kappa],
        "kappa_times_K_equals_one_quarter": product == (Fraction(-2), Fraction(0)),
        "kappa_times_K_exponents": [str(x) for x in product],
        "printed_K_over_2_equals_kappa": printed == kappa,
        "printed_K_over_2_exponents": [str(x) for x in printed],
        "status": "PASS",
    }


def environment_payload() -> dict[str, Any]:
    return {
        "freeze_date": FREEZE_DATE,
        "artifact_revision": "phase-b-control-byte-repair-r1",
        "generator": GENERATOR_REL,
        "gcc": GCC_VERSION,
        "locale_policy": "bytewise UTF-8 path order; LF text",
        "platform": PLATFORM_LOCK,
        "python": PYTHON_VERSION,
        "sha256_utility": COREUTILS_VERSION,
        "zip_policy": ZIP_TOOL_VERSION,
    }


def json_bytes(obj: Any, *, canonical: bool = False) -> bytes:
    if canonical:
        text = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    else:
        text = json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    return text.encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write_bytes(root: Path, rel: str, data: bytes) -> None:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    os.chmod(path, 0o644)


def write_text(root: Path, rel: str, text: str) -> None:
    write_bytes(root, rel, text.replace("\r\n", "\n").encode("utf-8"))


def expected_core_paths() -> list[str]:
    paths = set(TEXT_FILES)
    paths.add(GENERATOR_REL)
    paths.update({
        "FINAL_VERDICT.json",
        "environment.json",
        "results/archive_integrity.json",
        "results/source_hierarchy.json",
        "results/source_locks.json",
        "results/proof_dependency_graph.json",
        "results/symbolic_constant_check.json",
        "results/generation_provenance.json",
        "results/scientific_core_paths.txt",
    })
    return sorted(paths, key=lambda x: x.encode("utf-8"))


def generate_core(root: Path) -> None:
    root.mkdir(parents=True, exist_ok=True)
    for rel, text in TEXT_FILES.items():
        write_text(root, rel, text)

    # Freeze the generator itself as part of the scientific core.
    generator_source = Path(__file__).resolve()
    generator_target = root / GENERATOR_REL
    generator_target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(generator_source, generator_target)
    os.chmod(generator_target, 0o644)

    structured = {
        "FINAL_VERDICT.json": FINAL_VERDICT,
        "environment.json": environment_payload(),
        "results/archive_integrity.json": ARCHIVE_INTEGRITY,
        "results/source_hierarchy.json": SOURCE_HIERARCHY,
        "results/source_locks.json": SOURCE_LOCKS,
        "results/proof_dependency_graph.json": PROOF_GRAPH,
        "results/symbolic_constant_check.json": exact_symbolic_result(),
    }
    for rel, obj in structured.items():
        write_bytes(root, rel, json_bytes(obj))

    core_paths = expected_core_paths()
    provenance = {
        "artifact_revision": "phase-b-control-byte-repair-r1",
        "command": GENERATOR_COMMAND,
        "compiler_version": GCC_VERSION,
        "files_generated": core_paths + ["SCIENTIFIC_CORE.json", "SCIENTIFIC_CORE.sha256"],
        "freeze_date": FREEZE_DATE,
        "input_hashes": INPUT_HASHES,
        "platform": PLATFORM_LOCK,
        "python_version": PYTHON_VERSION,
        "source_pdf_hashes": SOURCE_PDF_HASHES,
        "source_script": GENERATOR_REL,
    }
    write_bytes(root, "results/generation_provenance.json", json_bytes(provenance))
    write_text(root, "results/scientific_core_paths.txt", "\n".join(core_paths) + "\n")

    # Validate that every expected core file now exists.
    missing = [rel for rel in core_paths if not (root / rel).is_file()]
    if missing:
        raise RuntimeError(f"missing core files: {missing}")

    files = []
    for rel in core_paths:
        path = root / rel
        files.append({"bytes": path.stat().st_size, "path": rel, "sha256": sha256_file(path)})
    manifest = {
        "canonicalization": "UTF-8 LF; JSON sorted keys; compact separators; trailing LF",
        "excluded_from_scientific_core": [
            "ORIGINAL_PHASE_A_DRAFT/**",
            "FORMAL_AUDIT/**",
            "NONDETERMINISTIC_DIAGNOSTICS/**",
            "logs/**",
            "results/replay_report.json",
            "SCIENTIFIC_CORE.json",
            "SCIENTIFIC_CORE.sha256",
            "SHA256SUMS.txt",
        ],
        "files": files,
        "freeze_date": FREEZE_DATE,
        "input_hashes": INPUT_HASHES,
        "package": PACKAGE_NAME,
        "schema_version": 1,
        "source_pdf_hashes": SOURCE_PDF_HASHES,
    }
    manifest_data = json_bytes(manifest, canonical=True)
    write_bytes(root, "SCIENTIFIC_CORE.json", manifest_data)
    digest = sha256_bytes(manifest_data)
    write_text(root, "SCIENTIFIC_CORE.sha256", f"{digest}  SCIENTIFIC_CORE.json\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--core-only", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    out = Path(args.output).resolve()
    if out.exists() and any(out.iterdir()):
        if not args.force:
            raise SystemExit(f"output is not empty: {out}; use --force")
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    generate_core(out)
    print(out)
    print((out / "SCIENTIFIC_CORE.sha256").read_text("utf-8").strip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
