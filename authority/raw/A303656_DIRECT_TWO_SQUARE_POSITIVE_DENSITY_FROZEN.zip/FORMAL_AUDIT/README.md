# Phase A Formal Audit Evidence

This directory contains the untouched uploaded ZIP
`A303656_DIRECT_TWO_SQUARE_PHASE_A_FORMAL_AUDIT(1).zip`.

- Outer SHA256: `e3d8559c32bc64e046b85032c4111145092f4f63e373e0d0355932a43f972e15`
- ZIP CRC: PASS
- Unsafe paths: none
- Symlink entries: none
- Files: 3
- Internal manifest: ABSENT

The audit is referee evidence, not mathematical authority. In particular, its
instruction to retain `K/2` for the primitive-set leading constant is superseded
by the exact Phase B Euler-product derivation `1/(4K)`.

The authenticated extracted-file list is in
`results/audit_file_listing.txt` at the package root.
