# Novelty Classification

The following labels are mathematical-publication classifications, not
correctness grades.

| Item | Classification | Reason |
|---|---|---|
| 1. Curved-domain asymptotic | **STANDARD CONSEQUENCE** | Elementary rectangle count plus an \(O(\log X)\) curved-corner estimate. |
| 2. Finite collision theorem | **STANDARD CONSEQUENCE** | Direct application of a weighted unit equation plus a necessary scaling argument. |
| 3. Bounded multiplicity | **STANDARD CONSEQUENCE** | Immediate from global collision finiteness. |
| 4. Sidon-scale additive energy | **POTENTIALLY NEW LEMMA** | The proof is rigorous and structurally specific; no exhaustive novelty search was completed. |
| 5. Structured singular-factor average | **POTENTIALLY NEW LEMMA** | The order-period averaging argument is rigorous; independent prior-art coverage was not established. |
| 6. Direct dyadic positive-density proof | **INDEPENDENT ALTERNATIVE PROOF** | It localizes to every dyadic interval and uses the full indicator; it is not a new headline phenomenon after Radomskii v6. |
| 7. Many-representation theorem | **SUBSUMED** | Radomskii Theorem 1.1 gives the same threshold scale and positive-proportion phenomenon once the present hypotheses are verified. |
| 8. Distinct-shift theorem | **SUBSUMED** | The distinct shift set also satisfies Radomskii; the exact dyadic localization remains an independent proof detail. |
| 9. Almost-all covariance formulation | **UNKNOWN** | It is a precise blocker/reduction, not a proved theorem, and its novelty was not searched exhaustively. |

## Methodological-value assessment

The two plausible standalone technical contributions are the Sidon-scale energy
lemma and the structured singular-factor average.  They may be reusable for
other sparse sumsets of multiplicatively independent powers.  At present they
are only `POTENTIALLY NEW LEMMA / NOVELTY NOT ESTABLISHED`; combining them with
standard lemmas does not justify describing the package as a major advance.

## Headline classification

\[
\boxed{\text{SPECIALIZED APPLICATION + INDEPENDENT ALTERNATIVE PROOF}.}
\]

A `NEW THEOREM` label is not supported.
