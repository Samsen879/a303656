# Proof: Boundary-Aware Second Moment

Let \(I_X=[X,2X]\cap\mathbb Z\), \(L=\log X\),
\(N_X=|\mathcal D_X|\), and \(\beta=\mathbf1_{\mathcal S_2}\).

## 1. Exact identity

Since

\[
R_X(n)=\sum_s w_X(s)\beta(n-s),
\]

finite expansion and the substitution \(m=n-t\) give

\[
\begin{aligned}
M_2(X)&:=\sum_{n\in I_X}R_X(n)^2\\
&=\sum_{s,t}w_X(s)w_X(t)
\sum_{n=X}^{2X}\beta(n-s)\beta(n-t)\\
&=\boxed{\sum_{s,t}w_X(s)w_X(t)
\sum_{m=X-t}^{2X-t}\beta(m)\beta(m+t-s).}
\end{aligned} \tag{1}
\]

This is an identity, not a boundary-free approximation.

## 2. Common envelope

Every shift in the sum satisfies \(2\le s,t\le X/2\).  For
\(m\in[X-t,2X-t]\),

\[
X/2\le m\le2X,
\qquad
X/2\le m+t-s\le2X.
\]

Thus both indicator arguments lie in a common positive envelope.  Put
\(h=t-s\) and

\[
\nu_X(h)=\sum_{t-s=h}w_X(s)w_X(t).
\]

## 3. Diagonal

For \(h=0\),

\[
\nu_X(0)=\sum_s w_X(s)^2=N_X+O(1)
\]

by global collision finiteness.  The inner sum in (1) is at most the number of
sums of two squares up to \(2X\), so Landau–Ramanujan gives

\[
Q_0(X)\ll\frac X{\sqrt L}.
\]

Therefore the diagonal contribution is

\[
\ll \frac{XN_X}{\sqrt L}
\ll XL^{3/2}. \tag{2}
\]

The quantity \(h/\varphi(h)\) is never assigned at \(h=0\).

## 4. Off diagonal

For \(h\ne0\), the indicator-level FKR/Nowak bound and the common envelope
give

\[
\sum_{m=X-t}^{2X-t}\beta(m)\beta(m+h)
\ll \frac X{L}
\mathfrak S_+(h),
\]

where

\[
\mathfrak S_+(h)=
\prod_{\substack{p\equiv3\pmod4\\p\mid h}}
\left(1+\frac2p\right).
\]

The structured singular-factor theorem gives

\[
\sum_{h\ne0}\nu_X(h)\mathfrak S_+(h)\ll N_X^2.
\]

Hence the off-diagonal contribution is

\[
\ll \frac X{L}N_X^2\ll XL^3. \tag{3}
\]

Combining (2) and (3),

\[
\boxed{M_2(X)\ll X(\log X)^3.} \tag{4}
\]

For distinct shifts, either repeat the argument with
\(\nu_X^{\rm dist}(h)\le\nu_X(h)\), or note that its diagonal is
\(|\mathcal B_X|\asymp N_X\).  Thus

\[
M_2^{\rm dist}(X)\ll X(\log X)^3.
\]
\(\square\)
