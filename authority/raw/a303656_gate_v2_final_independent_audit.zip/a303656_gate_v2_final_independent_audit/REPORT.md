# OEIS A303656 — Gate V2 Forensic Recovery Final Independent Audit

## One-sentence verdict

**REJECT / FIX REQUIRED:** archive bytes and the principal 27/28 plus 253M/533.2M reconciliations are credible, but registry v2 loses known confirmed exposure semantics, the repaired verifier still admits 15 material bypasses, 52-way provenance remains unrecoverable, Gate V2 therefore **FAILS**, and no new \(T(n)\) is authorized.

## Scope and evidence discipline

This audit used only the uploaded standalone bundle and its bundled Git object database. It did not access Samsen’s WSL repository, did not compute or inspect any new \(T(n)\), and did not run a two-square oracle, factorization, P5/P6 search, arbitrary interval scan, adaptive low-\(T\) search, or Gate V3 implementation. Git conclusions are phrased as **bundle evidence internally supports**. Finite computation and byte replay are not treated as a proof of the universal A303656 statement.

Global status throughout:

\[
\boxed{\text{OEIS A303656: UNRESOLVED}}
\]

## Layered verdict

| Layer | Verdict |
|---|---|
| Archive integrity | **ACCEPT WITH CONDITIONS** |
| Commit/provenance evidence | **ACCEPT WITH CONDITIONS** — internal bundle object-chain evidence only |
| Forensic reconciliation | **ACCEPT** for 27/28 and 253M/533.2M |
| Orphan-source recovery | **Artifact recovery ACCEPT; registry integration FAIL** |
| Interrupted-run recovery | **PARTIAL; historical completeness NOT_ESTABLISHED** |
| Registry v2 | **REJECTED** |
| Semantic verifier | **REJECT / FIX REQUIRED** |
| Bundled 32-test suite | **32/32 specified tests PASS; coverage PARTIAL; soundness NOT_ESTABLISHED** |
| Gate V2 | **FAIL** |
| Design A | **Level 1 conditional candidate only** |
| New \(T(n)\) authorization | **NOT AUTHORIZED** |
| Route decision | **REJECT_BUNDLE** |
| Overall | **REJECT / FIX REQUIRED** |

## 1. Archive integrity and standalone contents

- Archive SHA256: `39f0dad3a3e7ce9705c30ed69875d85fe84a51ed4290d05dbca85494b9df3a40` — exact match to the expected hash.
- Tar members: 15,589; regular files: 14,806; directories: 783.
- No duplicate path, path traversal, absolute member path, symlink, hardlink, or special file was found.
- The top `SHA256SUMS.txt` has 14,798 entries and passes direct archive-stream verification.
- Eight regular files are unhashed, all of them `SHA256SUMS.txt` manifests.
- `repository/SHA256SUMS.txt` is stale for two source files: `src/search_twosquares_bitset.cpp` and `src/search_twosquares_clean.cpp`.
- Five legacy reproduction manifests contain non-relocatable absolute `/mnt/data/a303656_bounded_counterexample/...` paths.
- There are 3,677 zero-byte files, including 1,109 log-like files; the top-level `standalone_full_replay.log` is zero bytes.

These conditions do not change the outer archive-byte identity, but they prevent an unconditional standalone-integrity PASS.

## 2. Commit and provenance evidence

The bundled Git object database verifies the chain:

`339df087` → `aa63d323` → `9b390390` → `7b3d9811` → `072c1a9f`.

Bundle changed-path evidence supports:

- correction 1 is a distinct commit changing only `build_recovery_v2.py`, with the authority-path correction;
- correction 2 is a distinct commit changing only `run_semantic_tests_v2.py` and `semantic_verifier_v2.py`, with mutation/exposure-precedence changes;
- SOURCE Y contains no `results_recovery_v2` scientific-result subtree;
- RESULTS Z adds only result/report/provenance files under that subtree;
- selected protected blobs remain unchanged across the chain.

Limitations:

1. `commit_provenance.json` gives a wrong full hash for the first SOURCE Y commit;
2. `RESULTS_Z` remains a placeholder in that file;
3. `worktree_initially_clean=false` and `preexisting_untracked_preserved=true` do not exclude original untracked scientific inputs;
4. the packaged checkout being clean does not prove the original WSL worktree was clean.

Therefore the strongest accepted statement is: **bundle evidence internally supports the commit chain and narrow changed-path scopes**.

## 3. Forensic reconciliation

| Claim | Independent reconstruction | Adjudication |
|---|---:|---|
| 27/28 interval record mismatch | 37 raw records normalize to **28** closed disjoint records; old embedded list also has 28 | **ACCEPT** — old 27 was metadata subtract-one, no silent deletion |
| Four direct dual datasets | **253,000,000** unique integers; sum equals normalized union; categories are disjoint | **ACCEPT** |
| Broader registered union excluding 1.6B | **533,200,000** unique integers | **ACCEPT** |
| Difference | **280,200,000 = 200,000 + 90,000,000 + 90,000,000 + 100,000,000** | **ACCEPT** |
| Orphan source bytes/counts | 1,285 / 73 / 457, hashes and bundled Git blobs match | **ACCEPT for recovery evidence** |
| Orphan mappings in registry v2 | E4 count is 0; recovered direct sources are not mapped | **FAIL** |
| 52-way input/touched set | only 52×100M shape and rc=143 retained; no numeric starts/manifest/ledger | **NOT_ESTABLISHED** |

The full 28-row interval crosswalk is in `interval_27_28_crosswalk.csv`. Closed-interval counts use \(b-a+1\); overlaps and adjacency are normalized before union length is computed.

## 4. Orphan-source recovery

All three source artifacts are physically present in the bundle and match the recorded SHA256/Git blob evidence:

| Source | Rows/points | SHA256 | Outcome influenced selection? |
|---|---:|---|---|
| `K4_PROGRESSION_PANEL` | 1,285 | `dad853ae1b385ef44ef67b442d5b3b82c78614a4fc99c77530ba6903ede49e23` | No for panel construction |
| `K4_DIRECT_VERIFICATION` | 73 | `3ec8be67747e64d5046dc9c3591c8885865b897f3d02c18be8fd5b01ee201794` | **Yes** — selected by \(T\)-conditioned reasons/minima |
| `P4_DIRECT_VERIFICATION` | 457 | `246d4067b4f7f80d88377ef17fa5732d0c4a9bf998ccd79c0dda94b0938abbaf` | **Yes** — includes \(T\)-threshold/minimum policies |

Recovery evidence is accepted. Registry integration is not: those E4 exposures are declared in component metadata but absent from registry v2 rows.

## 5. Interrupted-run audit

| Run | Certainty | Possible levels | Conservative superset | Catalogue/stage internally consistent? |
|---|---|---|---|---|
| INT-DIRECT-100M-256 | CONSERVATIVE_SUPERSET | ['E1_BINARY_REPRESENTABILITY_CHECK'] | [240000000001, 240100000000] (100,000,000) | False |
| INT-FIXEDPOOL-10M-512 | CONSERVATIVE_SUPERSET | ['E1_BINARY_REPRESENTABILITY_CHECK'] | [240000000001, 240010000000] (10,000,000) | False |
| INT-SMT-K16-K32 | CONSERVATIVE_SUPERSET | ['E0_DESIGN_ONLY'] | [240000000001, 240000000100] (100) | False |
| INT-STAGE0-REDUNDANT | CONFIRMED | ['E0_DESIGN_ONLY'] | NOT_NUMERICALLY_RECOVERABLE | True |
| INT-DIRECT-52WAY | UNKNOWN | ['E1_BINARY_REPRESENTABILITY_CHECK'] | NOT_NUMERICALLY_RECOVERABLE | False |
| ABANDONED-K4-PRE-C | CONSERVATIVE_SUPERSET | ['E2_EXACT_T_COUNT', 'E3_COMPLETE_WINNER_MASK', 'E4_DIRECT_ORACLE_OR_WITNESS_VERIFIED'] | analysis/k4_ap_pilot/backend_a_counts.csv / 1285 rows | True |

### Decisive 52-way blocker

The bundle does not recover numeric chunk starts, worker assignments, scheduler arguments, shell history, authenticated command line, runner hash, input manifest, deterministic partition function, checkpoints, temporary output, nonempty stdout/stderr, or last committed row. All 52 `.log` and 52 `.time` files are zero bytes; only `chunk_0014.rc=143` is nonempty.

Consequences:

- the complete numeric input universe is not recoverable;
- only the declared shape/cardinality 52×100M is known;
- no finite numeric conservative superset can be constructed from bundle evidence;
- zero Design A rows can be independently proved untouched;
- `UNKNOWN 384/384` is a defensible fail-closed classification, but not a computed intersection with an explicit superset;
- exact-\(T\) never-entered is not proved; absence of output is not absence of evaluator calls.

Any-evaluation historical completeness and exact-\(T\) historical completeness are both **NOT_ESTABLISHED**.

## 6. Registry v2 independent reconstruction

Current registry v2 contains 6,129 sparse integer rows and 28 interval records, but all sparse rows are attributed to the legacy source. Its level distribution has **E4 count 0**.

Independent source reconstruction finds:

- 6,583 confirmed distinct sparse integers;
- 983 integers with E4 exposure;
- 454 P5 Family U distinct integers omitted from v2;
- 73 K4 and 457 P4 direct-verification mappings not represented as E4;
- two confirmed exact-\(T\)/winner-mask interval records (`PILOT-A`, `PILOT-B`) omitted;
- conservative-superset/UNKNOWN records not represented in registry rows.

This is a known semantic loss, not merely unresolved historical completeness. Therefore:

\[
\boxed{\text{Registry v2: REJECTED}}
\]

Even after repairing these defects, the 52-way blocker would keep the registry **PARTIAL**, not COMPLETE.

## 7. Semantic verifier and test suite

The detached replay reproduces the bundled 32/32 result:

- 15 retained corruption tests: PASS;
- 7 known bypass regressions: PASS for the exact expected error code/category;
- 10 property/metamorphic tests: PASS;
- unrelated-earlier-failure masking detected in those 32 tests: 0.

However, active independent probes found **15 material accepted bypasses**, including:

- imported-helper, dynamic-key, nested and `getattr` outcome access;
- prefiltered candidate-universe import;
- interval/source mutations followed by self-redigest;
- blank/duplicate/contradictory registry provenance;
- self-consistent selection-index/integer tampering;
- candidate registry/prior-design identity tampering;
- forged gate PASS without evidence derivation;
- arbitrary self-authored manifest hashes;
- baseline acceptance despite E4=0 and 454 omitted P5 rows.

The verifier primarily establishes internal self-consistency, not source-grounded semantic identity. Thus:

- specified suite: **PASS 32/32**;
- semantic coverage: **PARTIAL**;
- verifier soundness: **NOT_ESTABLISHED**;
- verifier verdict: **REJECT / FIX REQUIRED**.

## 8. Gate V2 nine-item recomputation

| Gate | Independent status | Reason |
|---|---|---|
| V2.1_CORE_EXACT_RESULT | **PASS** | protected fixed-P4 values/hash and selected protected blobs show no drift |
| V2.2_REGISTRY_INTEGRITY | **FAIL** | registry v2 loses confirmed E4/P5/interval semantics and is therefore REJECTED |
| V2.3_ANY_RECORDED_EVALUATION_NON_REUSE | **NOT_ESTABLISHED** | 52-way numeric input universe/touched set is unrecoverable; 384/384 remain fail-closed unknown |
| V2.4_EXACT_T_NON_REUSE | **NOT_ESTABLISHED** | exact-T started/completed history is not exhaustively logged and two confirmed E2/E3 intervals are omitted by v2 |
| V2.5_SELECTION_T_BLIND | **PASS** | manual inspection of the actual frozen build_candidates.py shows no T/outcome read; this does not validate the generic AST verifier |
| V2.6_HIERARCHICAL_BALANCE | **PASS** | 384-row arithmetic identity and 2/4/16/128 per-band hierarchy independently reconstructed |
| V2.7_CONTROLLED_COMPARISON | **PASS** | comparison structure and outcome-blind replacement text are frozen; no outcomes are present |
| V2.8_IMMUTABLE_PREREGISTRATION | **NOT_ESTABLISHED** | authorization hash/commit is pending and fail-closed exposure policy conflicts with publishing 384 unknown rows as a candidate object |
| V2.9_INDEPENDENT_AUTHORIZATION | **NOT_ESTABLISHED** | this independent audit rejects registry/verifier and therefore does not authorize execution |

Overall rule gives **FAIL** because V2.2 fails. This is stricter than the submitted `NOT_ESTABLISHED` result.

## 9. Design A and replacement protocol

The prior Design A identity is preserved:

- old file SHA256: `3af58aaa707ab5dbdab22aa5e47ae4b1e24ee838311c94b734fdd550817b8772` — matches;
- old canonical digest: `ef52792fb68815c5bbaf1a4f33fab60592689199348cc625f5e24a8b245a03d9` — matches;
- 48 class rows; 384 distinct integers; no collision;
- bands \(H_8=199,200,201\), each with 2 projections, 4 masks, 16 CRT classes, and 128 integers;
- raw \(G=227\), \(t_3=2\), selected indices `[0,7,14,21,28,35,42,49]`;
- confirmed registry intersection: 0;
- unknown any-evaluation: 384/384;
- unknown possible exact-\(T\): 384/384;
- `authorization=false`.

The replacement protocol is outcome-blind on its face and requires the same band/projection/mask/class, next deterministic eligible index, unchanged unaffected rows, and STOP on class exhaustion. It does not cure unknown historical exposure. Design A remains **Level 1 conditional candidate only**.

## 10. Standalone replay

A clean detached SOURCE Y tip was replayed without the original repository and without any evaluator invocation. The exact source build/verifier/tests produced:

- 75 files common with the bundled results;
- 74 byte-identical;
- one difference: `commit_provenance.json`, because SOURCE Y generates placeholders and RESULTS Z manually patches it;
- the independently reconstructed transparent core-25 set below is 25/25 byte-identical.

The bundle’s `standalone_replay_report.json` does **not** enumerate its claimed 25 artifacts or hashes. The following is this audit’s explicit reconstruction and is not claimed to be cryptographically identical to the submitter’s unstated set:

| # | Artifact | SHA256 | Byte-identical? |
|---:|---|---|---|
| 1 | `historical_exposure_components_v2.json` | `da2abbabe06ee26f258b2ccedb615a3a89f7cf8a3b0f5c9c5fc0ba0c6145e105` | YES |
| 2 | `historical_exposure_registry_v2.json` | `6149db723eb93839446f2cf293efe58329508c5fced6ebdfbc627e4ff6a6b147` | YES |
| 3 | `historical_exposure_registry_v2.csv` | `521ac47915dc4bf713e8e4e51e0b6601991fc0cd82af11d6c2c8c4385e452d6a` | YES |
| 4 | `historical_exposure_intervals_v2.csv` | `611b0dc91e79c0d1602571a89a26e73d4055b0646c553e86b3c58604146bf363` | YES |
| 5 | `historical_exposure_registry_diff.json` | `788444284f52ddf5995d52a8db498b7977520f0a42ad3815353657dc8df8ff1d` | YES |
| 6 | `historical_exposure_limitations_v2.md` | `83105ad8c623c79cb56d3d4542082f185c971f71451b58819398a43a36f94099` | YES |
| 7 | `historical_exposure_manifest_v2.json` | `51304d05f679f2a7374c52dad7d91cb56af846bce1d5c3588ad594ef25765218` | YES |
| 8 | `interrupted_run_catalog.json` | `755cc159adfb555404eb1daa6d1a4f94aad3be7e96c8d60389a2b8938d6db587` | YES |
| 9 | `interrupted_run_stage_reachability.json` | `36541fbeba7a21bcf3b8b72b0c6720396bff83492cbecd62ed4f867c40245911` | YES |
| 10 | `interrupted_run_limitations.md` | `37dacbb2aca0b10344f5d1eaef7220816a34ca8490226883eb863349d40f5a2b` | YES |
| 11 | `design_A_preregistration_candidate_v2.json` | `90cfd793bdd752ec1613e69843605af9ca24e80743bb5d17ba049a8c434e9d66` | YES |
| 12 | `design_A_exposure_crosswalk_v2.csv` | `7db005b4c291e41525847ba84600d932703bb15a5b1f4105795a3e8be9a920ee` | YES |
| 13 | `design_A_replacement_protocol_v2.json` | `b7f0972494e9e634df8a43ba4f586def4cfaf9e5f94ded358b026887fa600338` | YES |
| 14 | `immutable_preregistration_schema.json` | `85500187b846715bc423d3fce615e9f5b1cca3cd9fcc7a1a3ce4e0552595975a` | YES |
| 15 | `prospective_gate_v2_nine_item.json` | `6754b948e04bae65135c7802c42652d2877fad545386291273066989a37a29a2` | YES |
| 16 | `selection_blindness_audit.json` | `8736296db00eb0d6e422967ddbbf756f78c8c88e6d1c360669d4799e1e2550a8` | YES |
| 17 | `protected_authorities.json` | `ed2cbb4fa5209732664b6c1982c10d0ff924d627cb3912ccf514b98d892fa61e` | YES |
| 18 | `semantic_test_matrix.json` | `6b4f8b8f70b2eedc38aebc80f586fc53f251d2e613bc992c795ceaecc106e729` | YES |
| 19 | `REPORT.md` | `9d02b337f4abb87cd88c330facc177ffdc2aa3c2d576667cab60637d66e5a00c` | YES |
| 20 | `AUDIT_READY_SUMMARY.md` | `c200864635cc4e3e72c9820406e4a2bd8ef0fb4da5f7c4c231b128c1275557ed` | YES |
| 21 | `limitations.md` | `1f32691b59b4712ebbea2b461042fca1ae3e5ed3c414c0e17dc5f7f0dbfab3ac` | YES |
| 22 | `return_codes.json` | `c5f220fc9c52cc3620ca664032ed168e9c63ae6ad401280b35722db3c534d70e` | YES |
| 23 | `execution_logs/build.log` | `61b726eac3a45b4e168ea05b299811441d717028bea48c35ed936ccfb1c861f9` | YES |
| 24 | `execution_logs/verify.log` | `f4f16194be3350a99f2f5a055eab08b47ff0bc1b782a132e7b24f808eb1f0129` | YES |
| 25 | `execution_logs/tests.log` | `61b726eac3a45b4e168ea05b299811441d717028bea48c35ed936ccfb1c861f9` | YES |

Byte replay is therefore **ACCEPT WITH CONDITIONS**. Scientific standalone status remains **NOT_ESTABLISHED** because the replay consumes five precomputed inventory inputs rather than rebuilding them from raw sources, the registry/verifier semantics fail, and the claimed core-25 scope is unstated.

## 11. Route 2 adjudication

1. 52-way exposure provenance sufficient for Design A? **NO**.
2. Registry upgradeable to COMPLETE? **NO**.
3. V2.3/V2.4 can PASS? **NO**.
4. V2.8 can PASS? **NO**.
5. Gate V2 can authorize \(T\)? **NO**.

Required route decision for this submission:

```text
REJECT_BUNDLE
```

No specific, unchecked, high-probability 52-way command/manifest/ledger artifact is identified. Accordingly, after software/artifact defects are repaired, further open-ended historical recovery should be closed as `CLOSE_GATE_V2_ROUTE_2`, not continued speculatively.

## 12. Gate V3 recommendation

Do not implement Gate V3 from this submission. Under strict non-reuse, no sealed region can currently be proved disjoint from the unknown 52-way input universe; changing activation cells alone does not prove disjointness. A genuine cell change would require a fresh active-pair/\(H_8\) analysis unless domain invariance is separately proved. Because \(H_8:199\to201\) adds only two live pairs, the marginal empirical value is low. Analytic bad-prime anti-cover / second-moment work has higher expected value for the universal problem; Gate V3 should be secondary and cost-capped.

## Final authorization and verdict

```text
New T(n): NOT AUTHORIZED
Route decision: REJECT_BUNDLE
Overall verdict: REJECT / FIX REQUIRED
```

\[
\boxed{\text{OEIS A303656: UNRESOLVED}}
\]
