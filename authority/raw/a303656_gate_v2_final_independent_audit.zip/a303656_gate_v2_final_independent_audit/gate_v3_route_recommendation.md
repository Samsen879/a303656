# Gate V3 route recommendation

## Decision

Do **not** implement Gate V3 from this bundle. First repair and re-audit the registry/verifier layer; then treat Gate V3 only as a separately frozen clean-room route. No candidate integers or new \(T(n)\) values were generated in this audit.

## Required questions

### 1. Can the current fixed-\(P_4\) activation cell supply a provably fresh sealed region?

**Not from current evidence.** `INT-DIRECT-52WAY` has no authenticated numeric chunk starts or finite numeric input universe. Therefore no proposed region in the current activation cell can be proved disjoint from that historical input universe. A high-looking or randomly selected region would give only probabilistic comfort, not proof of non-reuse.

### 2. Is a different activation cell required?

A different cell may be needed for scientific diversity, but **changing cells alone does not solve provenance**. Unless bundle evidence proves that the historical 52-way runner was confined to the old cell, its unknown numeric universe may still overlap integers in a new cell. Strict Gate V3 therefore needs either:

1. authenticated historical numeric bounds that exclude the new sealed region; or
2. a reformulated prospective criterion based on a fully new process rather than an unprovable historical-integer non-reuse claim.

The latter would be a new gate specification and must not be presented as Gate V2 repair.

### 3. Does changing activation cell change the 407-pair domain or the mod-8 lemma?

The **mod-8 lemma remains mathematically valid** as an algebraic statement. What changes is its instantiated input: the active \((c,d)\) subset, weights, and possibly the exponent cutoff/domain. If the ambient 407-pair list is tied to the same exponent bounds it may remain an ambient list, but the live/active partition changes; if the range/cutoff changes, even the domain cardinality may change. The previous 407-pair activation data therefore cannot be silently inherited.

### 4. Must the \(H_8\) landscape be recomputed?

**Yes, unless a separate proof establishes that the active pair domain, residues, and weighting are identical.** For a genuinely new activation cell the safe default is a fresh protected \(H_8\) landscape computation with independent implementations and new authenticated hashes. This is modular computation only; it does not itself justify any \(T(n)\) evaluation.

### 5. Is Gate V3 mathematically worthwhile when \(H_8:199\to201\) adds only two live pairs?

Its marginal empirical value is low. The top band improves the live-pair count by only 2, so a 384-point exact-\(T\) panel would remain a descriptive finite experiment with limited leverage on the universal statement. It may be worthwhile as a small, cost-capped provenance/experimental-design exercise, but not as a high-priority route to a general proof.

### 6. Relative value versus analytic bad-prime anti-cover / second-moment work

The analytic route has higher expected research value because it can address a mechanism that scales beyond a frozen panel: controlling bad-prime covers, dependencies among \((c,d)\) pairs, or obtaining a second-moment/anti-concentration estimate. Gate V3 should be secondary and should proceed only after:

- a provably sealed region criterion exists;
- append-only crash-safe pre-read and exact-\(T\) started/completed ledgers are implemented;
- the candidate manifest and analysis plan are immutable;
- independent authorization is recorded before execution;
- no adaptive replacement is possible.

## Recommended priority

1. Repair registry and verifier semantics and close Gate V2 Route 2.
2. Prioritize analytic bad-prime anti-cover / second-moment research.
3. Consider a small Gate V3 pilot only if strict provenance freshness can be proved without guessing historical bounds.

Global status remains **OEIS A303656: UNRESOLVED**.
