#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    'REPORT.md','AUDIT_VERDICT.json','archive_inventory.csv','archive_sha256_verification.json',
    'commit_provenance_audit.md','interval_27_28_crosswalk.csv','interval_253M_533M_reconstruction.json',
    'orphan_source_audit.json','interrupted_run_audit.json','run_52way_exposure_analysis.md',
    'registry_v2_recomputed.json','registry_v2_crosswalk.csv','gate_v2_nine_item_recomputed.json',
    'bypass_regression_audit.json','semantic_test_matrix_recomputed.json','new_adversarial_probes.json',
    'design_A_regression.json','design_A_row_crosswalk.csv','replacement_protocol_audit.md',
    'standalone_replay_audit.json','route_2_adjudication.json','gate_v3_route_recommendation.md',
    'limitations.md','SHA256SUMS.txt'
]

def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''): h.update(block)
    return h.hexdigest()

def main() -> int:
    errors=[]
    for rel in REQUIRED:
        p=ROOT/rel
        if not p.is_file() or p.stat().st_size==0: errors.append(f'missing/empty: {rel}')
    for p in ROOT.rglob('*.json'):
        try: json.loads(p.read_text())
        except Exception as exc: errors.append(f'invalid json {p.relative_to(ROOT)}: {exc}')
    v=json.loads((ROOT/'AUDIT_VERDICT.json').read_text())
    if v.get('overall_verdict')!='REJECT / FIX REQUIRED': errors.append('overall verdict drift')
    if v.get('route_decision')!='REJECT_BUNDLE': errors.append('route decision drift')
    if v.get('new_T_authorization')!='NOT AUTHORIZED': errors.append('authorization drift')
    g=json.loads((ROOT/'gate_v2_nine_item_recomputed.json').read_text())
    if g.get('overall_status')!='FAIL': errors.append('Gate V2 overall drift')
    s=json.loads((ROOT/'semantic_test_matrix_recomputed.json').read_text())
    if (s.get('specified_suite_pass_count'),s.get('specified_test_count'))!=(32,32): errors.append('32-test count drift')
    if s.get('material_new_bypass_count')!=15: errors.append('adversarial bypass count drift')
    st=json.loads((ROOT/'standalone_replay_audit.json').read_text())
    if len(st.get('independently_reconstructed_core25',[]))!=25: errors.append('core25 count drift')
    if not st.get('independently_reconstructed_core25_all_byte_identical'): errors.append('core25 replay drift')
    manifest=ROOT/'SHA256SUMS.txt'
    if manifest.is_file():
        for line in manifest.read_text().splitlines():
            if not line.strip(): continue
            expected, rel = line.split('  ',1)
            p=ROOT/rel
            if not p.is_file(): errors.append(f'manifest missing: {rel}')
            elif sha(p)!=expected: errors.append(f'manifest mismatch: {rel}')
    if errors:
        print('\n'.join(errors),file=sys.stderr)
        return 1
    print(json.dumps({'status':'PASS','required_files':len(REQUIRED),'overall_verdict':v['overall_verdict'],'gate_v2':g['overall_status'],'new_T':v['new_T_authorization']},sort_keys=True))
    return 0
if __name__=='__main__': raise SystemExit(main())
