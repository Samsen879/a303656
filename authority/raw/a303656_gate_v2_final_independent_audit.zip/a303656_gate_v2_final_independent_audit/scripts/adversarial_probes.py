#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, hashlib, json, pathlib, sys, tempfile

def write_json(p,x): p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--repo',type=pathlib.Path,required=True); ap.add_argument('--package',type=pathlib.Path,required=True); a=ap.parse_args()
    repo=a.repo.resolve(); pkg=a.package.resolve(); logs=pkg/'logs'/'adversarial_probes'; logs.mkdir(parents=True,exist_ok=True)
    rec=repo/'analysis/p4_prospective_gate_v2/recovery'; sys.path.insert(0,str(rec))
    from common_v2 import close, sha256_file
    from semantic_verifier_v2 import SemanticError, audit_selection_source, verify_registry, verify_candidate, verify_gate, levels_for, class_members
    out=repo/'analysis/p4_prospective_gate_v2/results_recovery_v2'
    reg=json.loads((out/'historical_exposure_registry_v2.json').read_text()); comps=json.loads((out/'historical_exposure_components_v2.json').read_text()); man=json.loads((out/'historical_exposure_manifest_v2.json').read_text()); cand=json.loads((out/'design_A_preregistration_candidate_v2.json').read_text()); gate=json.loads((out/'prospective_gate_v2_nine_item.json').read_text())
    results=[]
    def run(pid,mutation,expected_code,expected_category,fn,security_expectation='REJECT'):
        try:
            ret=fn(); actual_code='ACCEPTED'; actual_category='none'; accepted=True; detail=ret
        except SemanticError as e:
            actual_code=e.code; actual_category=e.category; accepted=False; detail=None
        bypass=(security_expectation=='REJECT' and accepted) or (security_expectation=='ACCEPT' and not accepted)
        sem_ok=(not bypass and ((security_expectation=='ACCEPT') or (actual_code==expected_code and actual_category==expected_category)))
        row={'probe_id':pid,'mutation':mutation,'security_expectation':security_expectation,'expected_code':expected_code,'expected_category':expected_category,'actual_code':actual_code,'actual_category':actual_category,'accepted':accepted,'material_bypass':bypass,'semantically_correct':sem_ok,'detail':detail}
        results.append(row); write_json(logs/f'{len(results):02d}_{pid}.json',row)
    def redoc(x): x.pop('canonical_digest',None); return close(x)
    with tempfile.TemporaryDirectory() as td:
        td=pathlib.Path(td)
        helper=td/'helper.py'; helper.write_text('def choose(rows):\n    return sorted(rows, key=lambda r: r["T"])\n')
        mainp=td/'main.py'; mainp.write_text('from helper import choose\ndef build(rows):\n    return choose(rows)\n')
        run('IMPORTED_HELPER_OUTCOME_READ','main source imports helper that sorts by T; helper is outside AST traversal','FORBIDDEN_OUTCOME_DATAFLOW','selection_blindness',lambda:audit_selection_source(mainp,sha256_file(mainp)))
    with tempfile.TemporaryDirectory() as td:
        p=pathlib.Path(td)/'dynamic.py'; p.write_text("key=''.join(['win','ner_mask'])\nx=payload['metrics'][key]\n")
        run('DYNAMIC_NESTED_OUTCOME_KEY','construct winner_mask dynamically under nested mapping','FORBIDDEN_OUTCOME_DATAFLOW','selection_blindness',lambda:audit_selection_source(p,sha256_file(p)))
    with tempfile.TemporaryDirectory() as td:
        td=pathlib.Path(td); (td/'prepared.py').write_text('candidates=[]\n# external generator may filter on T before export\n'); p=td/'main.py'; p.write_text('from prepared import candidates\nselected=candidates[:384]\n')
        run('PREFILTERED_CANDIDATE_UNIVERSE_IMPORT','candidate universe is imported after possible outcome-conditioned preprocessing','FORBIDDEN_OUTCOME_DATAFLOW','selection_blindness',lambda:audit_selection_source(p,sha256_file(p)))
    with tempfile.TemporaryDirectory() as td:
        p=pathlib.Path(td)/'getattr.py'; p.write_text('x=getattr(row,"T")\n')
        run('GETATTR_T_ALIAS','access exact T via getattr rather than subscript/get','FORBIDDEN_OUTCOME_DATAFLOW','selection_blindness',lambda:audit_selection_source(p,sha256_file(p)))
    x=copy.deepcopy(reg); x['interval_records'][0]['normalized_low']+=1; x['interval_records'][0]['normalized_high']+=1; x['interval_records'][0]['original_low']+=1; x['interval_records'][0]['original_high']+=1; redoc(x)
    run('REGISTRY_INTERVAL_SHIFT_REDIGEST','shift authoritative first interval by +1 while preserving length and self-digest','SOURCE_ARTIFACT_INTERVAL_MISMATCH','source_provenance',lambda:verify_registry(x,comps,man))
    x=copy.deepcopy(reg); x['integer_records'][0]['source_artifact_sha256']=''; redoc(x)
    run('REGISTRY_INTEGER_SOURCE_HASH_BLANK','blank integer-row source hash and redigest','COMPLETE_SOURCE_HASH_MISSING','source_provenance',lambda:verify_registry(x,comps,man))
    x=copy.deepcopy(comps); x['components'].append(copy.deepcopy(x['components'][3])); redoc(x)
    run('DUPLICATE_EXPOSURE_SOURCE','duplicate K4_PROGRESSION_PANEL component with identical source_id','DUPLICATE_SOURCE_ID','source_provenance',lambda:verify_registry(reg,x,man))
    x=copy.deepcopy(reg); x['integer_records'][0]['certainty']='UNKNOWN'; x['integer_records'][0]['provenance_completeness']='COMPLETE'; redoc(x)
    run('CONTRADICTORY_CERTAINTY_FIELDS','integer row says UNKNOWN but provenance COMPLETE and exposure is asserted','CERTAINTY_CONTRADICTION','registry_consistency',lambda:verify_registry(x,comps,man))
    # Selection-index + integer self-consistent tamper.
    x=copy.deepcopy(cand); row=x['class_rows'][0]; members=class_members(row['class_residue_mod_L4']); eligible=[n for n in members if not levels_for(n,reg)]
    all_selected={int(it['n']) for r in x['class_rows'] for it in r['selected_integers']}; oldn=int(row['selected_integers'][0]['n']); all_selected.remove(oldn)
    alt=None
    for idx,n in enumerate(eligible):
        if idx not in x['integer_indices'] and n not in all_selected: alt=(idx,n); break
    assert alt
    row['selected_integers'][0]['selection_index']=alt[0]; row['selected_integers'][0]['n']=alt[1]
    ns=[int(it['n']) for r in x['class_rows'] for it in r['selected_integers']]; x['minimum_integer']=min(ns); x['maximum_integer']=max(ns); redoc(x)
    run('SELECTION_INDEX_AND_INTEGER_SELF_CONSISTENT_TAMPER',f'replace frozen slot (index 0,n={oldn}) by eligible index {alt[0]},n={alt[1]}, then update min/max/digest','PRIOR_DESIGN_ROW_IDENTITY_MISMATCH','immutable_preregistration',lambda:verify_candidate(x,reg,man['prior_design_A_file_sha256']))
    x=copy.deepcopy(cand); x['registry_digest']='0'*64; redoc(x)
    run('CANDIDATE_REGISTRY_DIGEST_MISMATCH','replace candidate registry_digest by zeros and redigest','CANDIDATE_REGISTRY_DIGEST_MISMATCH','hash_closure',lambda:verify_candidate(x,reg,man['prior_design_A_file_sha256']))
    x=copy.deepcopy(cand); x['prior_design_A_canonical_digest']='0'*64; redoc(x)
    run('PRIOR_DESIGN_CANONICAL_IDENTITY_MISMATCH','change prior Design A canonical digest while retaining file-sha field','PRIOR_DESIGN_CANONICAL_MISMATCH','immutable_preregistration',lambda:verify_candidate(x,reg,man['prior_design_A_file_sha256']))
    x=copy.deepcopy(gate); x['items']['V2.2_REGISTRY_INTEGRITY']['status']='PASS'; x['overall_status']='NOT_ESTABLISHED'; redoc(x)
    run('GATE_V2_2_FORGED_PASS','set V2.2 PASS without changing registry evidence; other NE items keep overall NE','GATE_EVIDENCE_DERIVATION_MISMATCH','gate_semantics',lambda:verify_gate(x))
    x=copy.deepcopy(gate); x['items']['V2.1_CORE_EXACT_RESULT']['evidence_references']=[]; x['items']['V2.1_CORE_EXACT_RESULT']['required_hashes']=[]; redoc(x)
    run('GATE_V2_1_PASS_WITHOUT_EVIDENCE','remove all V2.1 evidence/hashes while retaining PASS','GATE_EVIDENCE_MISSING','gate_semantics',lambda:verify_gate(x))
    x=copy.deepcopy(man); x['expected_hashes']['registry']='f'*64; x['registry_digest']='e'*64; redoc(x)
    run('MANIFEST_REGISTRY_HASH_SELF_AUTHORED','replace registry hashes by arbitrary 64-char strings and redigest','REGISTRY_MANIFEST_BINDING_MISMATCH','hash_closure',lambda:verify_registry(reg,comps,x))
    # Baseline known omission is accepted by the verifier.
    run('BASELINE_OMITS_E4_AND_P5_BUT_ACCEPTS','unmodified v2 has E4 count 0 and omits 454 P5-U integers','REGISTRY_SEMANTIC_COVERAGE_MISMATCH','source_provenance',lambda:verify_registry(reg,comps,man))
    # Controls: expected rejection to ensure harness distinguishes real bypasses from generic failure.
    with tempfile.TemporaryDirectory() as td:
        p=pathlib.Path(td)/'direct.py'; p.write_text('x=row["T"]\n')
        run('CONTROL_DIRECT_T_SUBSCRIPT','direct T subscript','FORBIDDEN_OUTCOME_DATAFLOW','selection_blindness',lambda:audit_selection_source(p,sha256_file(p)),security_expectation='REJECT')
    x=copy.deepcopy(cand); x['class_rows'][0]['tuple'][1]+=49; redoc(x)
    run('CONTROL_NONNORMALIZED_CRT','add modulus to CRT component','CRT_TUPLE_NOT_NORMALIZED','arithmetic',lambda:verify_candidate(x,reg,man['prior_design_A_file_sha256']),security_expectation='REJECT')
    material=[r for r in results if r['material_bypass']]
    report={'schema':'independent-new-adversarial-probes-v1','probe_count':len(results),'material_bypass_count':len(material),'verifier_verdict':'REJECT / FIX REQUIRED' if material else 'NO_MATERIAL_BYPASS_FOUND','results':results,'coverage_note':'These probes test source anchoring, transitive dataflow, registry row semantics, immutable candidate identity, and evidence-derived gate status. They do not claim exhaustive program verification.'}
    write_json(pkg/'new_adversarial_probes.json',report)
    print(json.dumps({'probe_count':len(results),'material_bypass_count':len(material),'verdict':report['verifier_verdict']},sort_keys=True))
if __name__=='__main__': main()
