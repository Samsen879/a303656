#!/usr/bin/env python3
"""Verify protected Design A identity, rows, hierarchy, and registry intersections.

No new candidate generation and no T(n) evaluation are performed.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from independent_audit_core import recompute_registry, design_a_audit


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--repository', type=Path, required=True)
    ap.add_argument('--output-dir', type=Path, required=True)
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    registry = recompute_registry(args.repository.resolve(), args.output_dir.resolve())
    result = design_a_audit(args.repository.resolve(), args.output_dir.resolve(), registry)
    (args.output_dir / 'design_A_regression.json').write_text(
        json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + '\n'
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
