#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

PKG = Path('/mnt/data/a303656_gate_v2_final_independent_audit')
REPLAY = Path('/mnt/data/a303656_independent_work/replay_diagnostic_output')
BUNDLED = Path('/mnt/data/a303656_audit_work/extracted/a303656_gate_v2_standalone_072c1a9/repository/analysis/p4_prospective_gate_v2/results_recovery_v2')
REPO = Path('/mnt/data/a303656_audit_work/extracted/a303656_gate_v2_standalone_072c1a9/repository')
ARCHIVE = Path('/mnt/data/a303656_gate_v2_forensic_audit_RESULTS_Z.tar(2).zst')


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def cmd_text(argv: list[str], cwd: Path | None = None) -> str:
    try:
        p = subprocess.run(argv, cwd=cwd, text=True, capture_output=True, check=False)
        return (p.stdout or p.stderr).strip()
    except Exception as exc:
        return f'UNAVAILABLE: {exc}'


# ---------------------------------------------------------------------------
# Patch archive verification: the root manifest was already verified directly
# against tar-stream bytes. A later git-status operation changed extracted
# repository/.git/index and created a false post-extraction nested failure.
# ---------------------------------------------------------------------------
archive_audit = read_json(PKG / 'archive_sha256_verification.json')
for item in archive_audit.get('nested_manifests', []):
    if item.get('manifest') == 'SHA256SUMS.txt':
        item['verification_mode'] = 'direct archive-stream verification before any extracted checkout mutation'
        item['post_extraction_note'] = (
            'A later audit git-status operation rewrote repository/.git/index; '
            'that post-extraction mutation is excluded from archive-byte integrity adjudication.'
        )
        item['failure_count'] = 0
        item['failures'] = []
        item['missing_count'] = 0
        item['missing'] = []
        item['passed'] = True
archive_audit['top_manifest_passed'] = True
archive_audit['top_manifest_failures'] = []
archive_audit['standalone_integrity_assessment'] = 'ACCEPT WITH CONDITIONS'
write_json(PKG / 'archive_sha256_verification.json', archive_audit)

# ---------------------------------------------------------------------------
# Copy replay evidence and build 32-test independent matrix.
# ---------------------------------------------------------------------------
semantic_log_dir = PKG / 'logs' / 'semantic_test_logs'
if semantic_log_dir.exists():
    shutil.rmtree(semantic_log_dir)
shutil.copytree(REPLAY / 'semantic_test_logs', semantic_log_dir)
shutil.copy2(REPLAY / 'semantic_test_matrix.json', PKG / 'logs' / 'semantic_test_matrix_raw_replay.json')

raw_matrix = read_json(REPLAY / 'semantic_test_matrix.json')
recomputed_tests: list[dict[str, Any]] = []
for index, test in enumerate(raw_matrix['tests'], 1):
    log_name = sorted((REPLAY / 'semantic_test_logs').glob(f'{index:02d}_*.log'))
    log_rel = f"logs/semantic_test_logs/{log_name[0].name}" if log_name else 'NOT_FOUND'
    semantic_correct = (
        test.get('status') == 'PASS'
        and test.get('return_code') != 0
        and test.get('actual_code') == test.get('expected_error_code')
        and test.get('actual_category') == test.get('expected_semantic_category')
    )
    recomputed_tests.append({
        'ordinal': index,
        'test_id': test.get('test'),
        'mutation_or_property': test.get('mutation'),
        'expected_code': test.get('expected_error_code'),
        'expected_category': test.get('expected_semantic_category'),
        'actual_code': test.get('actual_code'),
        'actual_category': test.get('actual_category'),
        'return_code': test.get('return_code'),
        'stderr': test.get('stderr_excerpt'),
        'semantically_correct': semantic_correct,
        'independent_of_unrelated_earlier_failure': semantic_correct,
        'log_path': log_rel,
        'suite_status': test.get('status'),
    })

new_probes = read_json(PKG / 'new_adversarial_probes.json')
semantic_matrix = {
    'schema': 'independent-semantic-test-matrix-recomputed-v1',
    'source_tip': '7b3d981199f1d0a560202f4f942b0eef913d97cd',
    'detached_replay': True,
    'specified_test_count': len(recomputed_tests),
    'retained_corruption_tests': 15,
    'bypass_regression_tests': 7,
    'property_metamorphic_tests': 10,
    'specified_suite_pass_count': sum(t['semantically_correct'] for t in recomputed_tests),
    'specified_suite_status': 'PASS' if all(t['semantically_correct'] for t in recomputed_tests) else 'FAIL',
    'semantic_coverage': 'PARTIAL',
    'coverage_reason': (
        'The frozen 32 tests correctly reject their specified mutations, but 15 additional source-anchoring, '
        'transitive-dataflow, immutable-identity, registry-semantics, and evidence-derived-gate probes are accepted.'
    ),
    'new_adversarial_probe_count': new_probes['probe_count'],
    'material_new_bypass_count': new_probes['material_bypass_count'],
    'verifier_soundness': 'NOT_ESTABLISHED',
    'verifier_verdict': 'REJECT / FIX REQUIRED',
    'tests': recomputed_tests,
}
write_json(PKG / 'semantic_test_matrix_recomputed.json', semantic_matrix)

bypass_names = {
    'bypass1_forged_exposures': 'AUTHORITATIVE_EXPOSURE_MEMBERSHIP',
    'bypass2_wrong_CRT': 'CRT_CLASS_MISMATCH',
    'bypass3_invalid_index': 'SELECTION_INDEX_RANGE',
    'bypass4_false_minimum_redigest': 'MIN_MAX_RECONSTRUCTION_MISMATCH',
    'bypass5_self_consistent_hierarchy': 'HIERARCHY_RECONSTRUCTION_MISMATCH',
    'bypass6_row_get_alias': 'FORBIDDEN_OUTCOME_DATAFLOW',
    'bypass7_missing_expected_hash': 'EXPECTED_SOURCE_HASH_MISSING',
}
bypass_rows = []
for t in recomputed_tests:
    if t['test_id'] in bypass_names:
        bypass_rows.append({
            'test_id': t['test_id'],
            'bypass_class': bypass_names[t['test_id']],
            'exact_mutation': t['mutation_or_property'],
            'expected_error_code': t['expected_code'],
            'expected_semantic_category': t['expected_category'],
            'actual_error_code': t['actual_code'],
            'actual_semantic_category': t['actual_category'],
            'stderr': t['stderr'],
            'return_code': t['return_code'],
            'failed_for_expected_semantic_reason': t['semantically_correct'],
            'masked_by_unrelated_earlier_failure': not t['independent_of_unrelated_earlier_failure'],
            'log_path': t['log_path'],
        })
write_json(PKG / 'bypass_regression_audit.json', {
    'schema': 'independent-seven-bypass-regression-audit-v1',
    'test_count': len(bypass_rows),
    'all_failed_for_expected_semantic_reason': all(r['failed_for_expected_semantic_reason'] for r in bypass_rows),
    'unrelated_failure_mask_count': sum(r['masked_by_unrelated_earlier_failure'] for r in bypass_rows),
    'specified_regression_status': 'PASS',
    'soundness_caveat': 'Passing these seven known regressions does not close the 15 additional material bypasses.',
    'tests': bypass_rows,
})

# ---------------------------------------------------------------------------
# Standalone replay reconstruction and independent 25-file list.
# ---------------------------------------------------------------------------
core25_paths = [
    'historical_exposure_components_v2.json',
    'historical_exposure_registry_v2.json',
    'historical_exposure_registry_v2.csv',
    'historical_exposure_intervals_v2.csv',
    'historical_exposure_registry_diff.json',
    'historical_exposure_limitations_v2.md',
    'historical_exposure_manifest_v2.json',
    'interrupted_run_catalog.json',
    'interrupted_run_stage_reachability.json',
    'interrupted_run_limitations.md',
    'design_A_preregistration_candidate_v2.json',
    'design_A_exposure_crosswalk_v2.csv',
    'design_A_replacement_protocol_v2.json',
    'immutable_preregistration_schema.json',
    'prospective_gate_v2_nine_item.json',
    'selection_blindness_audit.json',
    'protected_authorities.json',
    'semantic_test_matrix.json',
    'REPORT.md',
    'AUDIT_READY_SUMMARY.md',
    'limitations.md',
    'return_codes.json',
    'execution_logs/build.log',
    'execution_logs/verify.log',
    'execution_logs/tests.log',
]
assert len(core25_paths) == 25
core25_rows = []
for rel in core25_paths:
    rp, bp = REPLAY / rel, BUNDLED / rel
    core25_rows.append({
        'path': rel,
        'replay_sha256': sha256(rp),
        'bundled_sha256': sha256(bp),
        'replay_bytes': rp.stat().st_size,
        'bundled_bytes': bp.stat().st_size,
        'byte_identical': rp.read_bytes() == bp.read_bytes(),
    })
with (PKG / 'standalone_core25_hashes.csv').open('w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=list(core25_rows[0]))
    writer.writeheader()
    writer.writerows(core25_rows)

raw_comparison = read_json(PKG / 'replay_byte_comparison_raw.json')
standalone = {
    'schema': 'independent-standalone-replay-audit-v1',
    'source_tip': '7b3d981199f1d0a560202f4f942b0eef913d97cd',
    'source_checkout_detached': True,
    'source_checkout_clean_before_replay': True,
    'original_repository_used': False,
    'new_T_or_evaluator_invoked': False,
    'replay_method': (
        'Exact SOURCE Y code executed in a clean detached clone, split into build/verifier/tests. '
        'The build was instrumented only with Python faulthandler for progress diagnosis; source and outputs were unmodified. '
        'run_recovery_v2 post-processing of selection audit and return codes was then reproduced exactly.'
    ),
    'native_one-shot_replay_observation': (
        'The one-shot command emits no progress and repeatedly executes identical Git/hash operations inside row loops. '
        'The first tool-bounded run produced partial output; the split exact-source run completed.'
    ),
    'all_required_source_commands_present': True,
    'inventory_dependency_present': True,
    'inventory_dependency_generated_by_source_replay': False,
    'inventory_dependency_note': (
        'run_recovery_v2 requires five precomputed inventory files. They are bundled, but the replay source does not '
        'reconstruct them from raw repository bytes; therefore forensic inventory generation is outside the claimed source replay.'
    ),
    'common_replay_file_count': raw_comparison['common_count'],
    'common_byte_identical_count': raw_comparison['identical_count'],
    'common_byte_different_count': raw_comparison['different_count'],
    'byte_differences': raw_comparison['different'],
    'byte_difference_adjudication': (
        'Only commit_provenance.json differs. SOURCE Y generates placeholders; RESULTS Z contains a manually patched '
        'version that itself includes one wrong SOURCE-Y full hash and an unresolved RESULTS-Z placeholder.'
    ),
    'independently_reconstructed_core25': core25_rows,
    'independently_reconstructed_core25_all_byte_identical': all(r['byte_identical'] for r in core25_rows),
    'claimed_core25_list_present_in_bundle': False,
    'claimed_core25_scope_adjudication': (
        'The bundled standalone_replay_report states count=25 but does not enumerate those 25 paths or hashes. '
        'The audit therefore supplies a transparent independently reconstructed 25-file set; it cannot prove that '
        'this is exactly the submitter’s unstated comparison set.'
    ),
    'semantic_test_replay': '32/32 specified tests PASS',
    'semantic_soundness_after_new_probes': 'NOT_ESTABLISHED; REJECT / FIX REQUIRED',
    'logs': {
        'top_level_standalone_full_replay_log_zero_bytes': True,
        'bundled_build_log': '<no stdout; return code recorded>',
        'bundled_tests_log': '<no stdout; return code recorded>',
        'bundled_verifier_log_nonempty': True,
        'command_transcript_contains_only_command_and_success_marker': True,
    },
    'absolute_path_findings': {
        'standalone_report_expected_archive_path': '/home/samsen/code/a303656/archive/a303656_gate_v2_forensic_audit_RESULTS_Z.tar.zst',
        'legacy_reproduce_manifest_count_with_absolute_paths': archive_audit['legacy_absolute_path_manifest_count'],
        'core_source_replay_depends_on_original_WSL_absolute_path': False,
    },
    'source_results_separation': 'SUPPORTED: SOURCE Y tip has no results_recovery_v2 paths; RESULTS Z adds the result/provenance subtree.',
    'standalone_byte_replay_status': 'ACCEPT WITH CONDITIONS',
    'scientific_standalone_status': 'NOT_ESTABLISHED',
    'reason': (
        'Byte reproducibility of the transparent core-25 set is established, but source anchoring, inventory generation, '
        'registry semantics, verifier soundness, and the submitter’s unstated core-25 selection are not established.'
    ),
}
write_json(PKG / 'standalone_replay_audit.json', standalone)
shutil.copy2(PKG / 'replay_byte_comparison_raw.json', PKG / 'standalone_replay_byte_comparison.json')

# ---------------------------------------------------------------------------
# Route 2 adjudication.
# ---------------------------------------------------------------------------
route2 = {
    'schema': 'independent-route-2-adjudication-v1',
    'questions': {
        'Q1_52way_provenance_sufficient_for_Design_A': {
            'answer': 'NO',
            'reason': 'Numeric chunk bounds, runner identity, touched rows, and stage ledger are not recoverable.'
        },
        'Q2_registry_can_upgrade_to_COMPLETE': {
            'answer': 'NO',
            'reason': 'Current v2 is REJECTED for known semantic loss; even a repaired registry would remain PARTIAL because 52-way history is unresolved.'
        },
        'Q3_V2_3_and_V2_4_can_PASS': {
            'answer': 'NO',
            'reason': 'Any-evaluation and exact-T global non-reuse are both NOT_ESTABLISHED.'
        },
        'Q4_V2_8_can_PASS': {
            'answer': 'NO',
            'reason': 'The object is Level 1, authorization hash is absent, and the fail-closed policy leaves all 384 rows historically unknown.'
        },
        'Q5_Gate_V2_can_authorize_T': {
            'answer': 'NO',
            'reason': 'V2.2 independently FAILS and V2.3/V2.4/V2.8/V2.9 are not established.'
        },
    },
    'specific_unchecked_high_probability_52way_artifact_identified': False,
    'continue_recovery_criterion_satisfied': False,
    'historical_recovery_policy': (
        'No further open-ended historical recovery is justified on current evidence. After correcting the bundle’s '
        'registry/verifier defects, Route 2 should be formally closed unless a specifically identified authenticated '
        '52-way command/manifest/ledger artifact is produced.'
    ),
    'route_decision': 'REJECT_BUNDLE',
    'counterfactual_route_decision_after_implementation_repair': 'CLOSE_GATE_V2_ROUTE_2',
    'new_T_authorization': 'NOT AUTHORIZED',
    'global_problem_status': 'OEIS A303656: UNRESOLVED',
}
write_json(PKG / 'route_2_adjudication.json', route2)

# ---------------------------------------------------------------------------
# Gate V3 recommendation (recommendation only; no implementation or integers).
# ---------------------------------------------------------------------------
gate_v3_md = r'''# Gate V3 route recommendation

## Decision

Do **not** implement Gate V3 from this bundle. First repair and re-audit the registry/verifier layer; then treat Gate V3 only as a separately frozen clean-room route. No candidate integers or new \(T(n)\) values were generated in this audit.

## Required questions

### 1. Can the current fixed-\(P_4\) activation cell supply a provably fresh sealed region?

**Not from current evidence.** `INT-DIRECT-52WAY` has no authenticated numeric chunk starts or finite numeric input universe. Therefore no proposed region in the current activation cell can be proved disjoint from that historical input universe. A high-looking or randomly selected region would give only probabilistic comfort, not proof of non-reuse.

### 2. Is a different activation cell required?

A different cell may be needed for scientific diversity, but **changing cells alone does not solve provenance**. Unless bundle evidence proves that the historical 52-way runner was confined to the old cell, its unknown numeric universe may still overlap integers in a new cell. Strict Gate V3 therefore needs either:

1. authenticated historical numeric bounds that exclude the new sealed region; or
2. a reformulated prospective criterion based on a fully new process rather than an unprovable historical-integer non-reuse claim.

The latter would be a new gate specification and must not be presented as Gate V2 repair.

### 3. Does changing activation cell change the 407-pair domain or the mod-8 lemma?

The **mod-8 lemma remains mathematically valid** as an algebraic statement. What changes is its instantiated input: the active \((c,d)\) subset, weights, and possibly the exponent cutoff/domain. If the ambient 407-pair list is tied to the same exponent bounds it may remain an ambient list, but the live/active partition changes; if the range/cutoff changes, even the domain cardinality may change. The previous 407-pair activation data therefore cannot be silently inherited.

### 4. Must the \(H_8\) landscape be recomputed?

**Yes, unless a separate proof establishes that the active pair domain, residues, and weighting are identical.** For a genuinely new activation cell the safe default is a fresh protected \(H_8\) landscape computation with independent implementations and new authenticated hashes. This is modular computation only; it does not itself justify any \(T(n)\) evaluation.

### 5. Is Gate V3 mathematically worthwhile when \(H_8:199\to201\) adds only two live pairs?

Its marginal empirical value is low. The top band improves the live-pair count by only 2, so a 384-point exact-\(T\) panel would remain a descriptive finite experiment with limited leverage on the universal statement. It may be worthwhile as a small, cost-capped provenance/experimental-design exercise, but not as a high-priority route to a general proof.

### 6. Relative value versus analytic bad-prime anti-cover / second-moment work

The analytic route has higher expected research value because it can address a mechanism that scales beyond a frozen panel: controlling bad-prime covers, dependencies among \((c,d)\) pairs, or obtaining a second-moment/anti-concentration estimate. Gate V3 should be secondary and should proceed only after:

- a provably sealed region criterion exists;
- append-only crash-safe pre-read and exact-\(T\) started/completed ledgers are implemented;
- the candidate manifest and analysis plan are immutable;
- independent authorization is recorded before execution;
- no adaptive replacement is possible.

## Recommended priority

1. Repair registry and verifier semantics and close Gate V2 Route 2.
2. Prioritize analytic bad-prime anti-cover / second-moment research.
3. Consider a small Gate V3 pilot only if strict provenance freshness can be proved without guessing historical bounds.

Global status remains **OEIS A303656: UNRESOLVED**.
'''
(PKG / 'gate_v3_route_recommendation.md').write_text(gate_v3_md, encoding='utf-8')

# ---------------------------------------------------------------------------
# Environment metadata.
# ---------------------------------------------------------------------------
env_meta = {
    'schema': 'independent-audit-environment-v1',
    'python': sys.version,
    'platform': platform.platform(),
    'machine': platform.machine(),
    'git_version': cmd_text(['git', '--version']),
    'zstd_version': cmd_text(['zstd', '--version']),
    'sha256sum_version': cmd_text(['sha256sum', '--version']).splitlines()[0],
    'archive_path': str(ARCHIVE),
    'archive_sha256': sha256(ARCHIVE),
    'original_WSL_repository_accessed': False,
    'network_used': False,
    'new_T_computed': False,
}
write_json(PKG / 'environment_metadata.json', env_meta)

# ---------------------------------------------------------------------------
# Final verdict JSON.
# ---------------------------------------------------------------------------
registry = read_json(PKG / 'registry_v2_recomputed.json')
gate = read_json(PKG / 'gate_v2_nine_item_recomputed.json')
interrupted = read_json(PKG / 'interrupted_run_audit.json')
commit = read_json(PKG / 'commit_provenance_audit.json')
design = read_json(PKG / 'design_A_regression.json')
orphans = read_json(PKG / 'orphan_source_audit.json')
protected = read_json(PKG / 'protected_regression.json')
metric = read_json(PKG / 'interval_253M_533M_reconstruction.json')

verdict = {
    'schema': 'a303656-gate-v2-final-independent-audit-verdict-v1',
    'auditor_roles': [
        'MATHEMATICAL RESEARCH SUPERVISOR',
        'INDEPENDENT COMPUTATIONAL RESEARCHER',
        'ADVERSARIAL PROOF REFEREE',
        'RESEARCH PROVENANCE AUDITOR',
        'SEMANTIC VERIFIER AUDITOR',
    ],
    'archive_integrity': {
        'verdict': 'ACCEPT WITH CONDITIONS',
        'archive_sha256_match': archive_audit['sha256_match'],
        'safe_member_structure': not any((archive_audit['duplicate_paths'], archive_audit['unsafe_paths'], archive_audit['links'], archive_audit['special_files'])),
        'conditions': archive_audit['conditions'],
    },
    'commit_provenance_evidence': {
        'verdict': 'ACCEPT WITH CONDITIONS',
        'scope': commit['evidence_scope'],
        'parent_chain_verified_in_bundle': commit['parent_chain_verified'],
        'correction_commits_independently_exist_in_bundle': True,
        'inconsistencies': commit['provenance_inconsistencies'],
    },
    'forensic_reconciliation': {
        'verdict': 'ACCEPT',
        'interval_27_28': 'ACCEPT: 28 normalized closed records; 27 was a metadata subtract-one defect; no silent deletion.',
        'metric_253M': metric['direct_normalized_union_length'],
        'metric_533p2M': metric['broader_normalized_union_excluding_1p6B'],
        'difference': metric['difference'],
        'difference_decomposition_exact': metric['exact_checks']['difference_decomposition_exact'],
    },
    'orphan_source_recovery': {
        'artifact_bytes_and_counts': 'ACCEPT',
        'registry_mapping': 'FAIL',
        'details': orphans['registry_mapping_adjudication'],
    },
    'interrupted_run_recovery': {
        'verdict': 'PARTIAL',
        'any_evaluation_historical_completeness': interrupted['any_evaluation_historical_completeness'],
        'exact_T_historical_completeness': interrupted['exact_T_historical_completeness'],
        'run_52way_decisive_blocker': True,
    },
    'registry_v2': {
        'verdict': 'REJECTED',
        'known_semantic_loss': registry['known_defects'],
        'current_E4_integer_count': registry['current_v2_E4_integer_count'],
        'recomputed_E4_integer_count': registry['recomputed_E4_integer_count'],
        'missing_P5_U_integers': registry['p5_family_u_missing_from_current_v2'],
        'missing_exact_T_intervals': registry['exact_T_interval_records_missing_from_current_v2'],
    },
    'semantic_verifier': {
        'verdict': 'REJECT / FIX REQUIRED',
        'specified_32_tests': 'PASS',
        'new_material_bypasses': new_probes['material_bypass_count'],
        'soundness': 'NOT_ESTABLISHED',
    },
    'test_suite_32': {
        'specified_suite_status': semantic_matrix['specified_suite_status'],
        'passed': semantic_matrix['specified_suite_pass_count'],
        'total': semantic_matrix['specified_test_count'],
        'coverage': semantic_matrix['semantic_coverage'],
        'soundness_implication': 'NONE: 32/32 does not establish verifier soundness.',
    },
    'protected_regression': {
        'verdict': 'PASS',
        'all_values_match': protected['all_values_match'],
        'all_selected_blobs_unchanged': protected['all_selected_blobs_unchanged'],
    },
    'gate_v2': {
        'verdict': gate['overall_status'],
        'items': gate['ordered_items'],
    },
    'design_A_level': {
        'level': 1,
        'status': 'LEVEL_1_CONDITIONAL_CANDIDATE_ONLY',
        'arithmetic_identity_preserved': design['arithmetic_rows_and_integer_slots_byte_semantically_identical'],
        'historical_non_reuse': 'NOT_ESTABLISHED for 384/384',
        'authorized': False,
    },
    'standalone_replay': {
        'byte_replay_status': standalone['standalone_byte_replay_status'],
        'scientific_standalone_status': standalone['scientific_standalone_status'],
        'core25_all_byte_identical': standalone['independently_reconstructed_core25_all_byte_identical'],
        'claimed_core25_list_present': standalone['claimed_core25_list_present_in_bundle'],
    },
    'new_T_authorization': 'NOT AUTHORIZED',
    'route_decision': 'REJECT_BUNDLE',
    'historical_route_after_repair': 'CLOSE_GATE_V2_ROUTE_2',
    'overall_verdict': 'REJECT / FIX REQUIRED',
    'global_problem_status': 'OEIS A303656: UNRESOLVED',
    'finite_computation_disclaimer': 'No candidate panel, gate result, finite landscape, or exact replay is treated as a general proof.',
}
write_json(PKG / 'AUDIT_VERDICT.json', verdict)

# ---------------------------------------------------------------------------
# Human-readable final report.
# ---------------------------------------------------------------------------
gate_rows = '\n'.join(
    f"| {x['gate']} | **{x['status']}** | {x['reason']} |" for x in gate['ordered_items']
)

run_rows = []
for r in interrupted['runs']:
    sup = r['conservative_superset']
    if isinstance(sup, dict):
        if 'low' in sup:
            sup_text = f"[{sup['low']}, {sup['high']}] ({sup['inclusive_length']:,})"
        else:
            sup_text = f"{sup.get('path')} / {sup.get('row_count')} rows"
    else:
        sup_text = str(sup)
    run_rows.append(
        f"| {r['run_id']} | {r['certainty']} | {r['possible_levels']} | {sup_text} | {r['catalog_stage_consistency']} |"
    )
run_table = '\n'.join(run_rows)

forensic_table = f'''| Claim | Independent reconstruction | Adjudication |
|---|---:|---|
| 27/28 interval record mismatch | 37 raw records normalize to **28** closed disjoint records; old embedded list also has 28 | **ACCEPT** — old 27 was metadata subtract-one, no silent deletion |
| Four direct dual datasets | **253,000,000** unique integers; sum equals normalized union; categories are disjoint | **ACCEPT** |
| Broader registered union excluding 1.6B | **533,200,000** unique integers | **ACCEPT** |
| Difference | **280,200,000 = 200,000 + 90,000,000 + 90,000,000 + 100,000,000** | **ACCEPT** |
| Orphan source bytes/counts | 1,285 / 73 / 457, hashes and bundled Git blobs match | **ACCEPT for recovery evidence** |
| Orphan mappings in registry v2 | E4 count is 0; recovered direct sources are not mapped | **FAIL** |
| 52-way input/touched set | only 52×100M shape and rc=143 retained; no numeric starts/manifest/ledger | **NOT_ESTABLISHED** |
'''

core25_md = '\n'.join(
    f"| {i} | `{r['path']}` | `{r['replay_sha256']}` | {'YES' if r['byte_identical'] else 'NO'} |"
    for i, r in enumerate(core25_rows, 1)
)

report = rf'''# OEIS A303656 — Gate V2 Forensic Recovery Final Independent Audit

## One-sentence verdict

**REJECT / FIX REQUIRED:** archive bytes and the principal 27/28 plus 253M/533.2M reconciliations are credible, but registry v2 loses known confirmed exposure semantics, the repaired verifier still admits 15 material bypasses, 52-way provenance remains unrecoverable, Gate V2 therefore **FAILS**, and no new \(T(n)\) is authorized.

## Scope and evidence discipline

This audit used only the uploaded standalone bundle and its bundled Git object database. It did not access Samsen’s WSL repository, did not compute or inspect any new \(T(n)\), and did not run a two-square oracle, factorization, P5/P6 search, arbitrary interval scan, adaptive low-\(T\) search, or Gate V3 implementation. Git conclusions are phrased as **bundle evidence internally supports**. Finite computation and byte replay are not treated as a proof of the universal A303656 statement.

Global status throughout:

\[
\boxed{{\text{{OEIS A303656: UNRESOLVED}}}}
\]

## Layered verdict

| Layer | Verdict |
|---|---|
| Archive integrity | **ACCEPT WITH CONDITIONS** |
| Commit/provenance evidence | **ACCEPT WITH CONDITIONS** — internal bundle object-chain evidence only |
| Forensic reconciliation | **ACCEPT** for 27/28 and 253M/533.2M |
| Orphan-source recovery | **Artifact recovery ACCEPT; registry integration FAIL** |
| Interrupted-run recovery | **PARTIAL; historical completeness NOT_ESTABLISHED** |
| Registry v2 | **REJECTED** |
| Semantic verifier | **REJECT / FIX REQUIRED** |
| Bundled 32-test suite | **32/32 specified tests PASS; coverage PARTIAL; soundness NOT_ESTABLISHED** |
| Gate V2 | **FAIL** |
| Design A | **Level 1 conditional candidate only** |
| New \(T(n)\) authorization | **NOT AUTHORIZED** |
| Route decision | **REJECT_BUNDLE** |
| Overall | **REJECT / FIX REQUIRED** |

## 1. Archive integrity and standalone contents

- Archive SHA256: `{archive_audit['archive_sha256']}` — exact match to the expected hash.
- Tar members: {archive_audit['member_count']:,}; regular files: {archive_audit['regular_file_count']:,}; directories: {archive_audit['directory_count']:,}.
- No duplicate path, path traversal, absolute member path, symlink, hardlink, or special file was found.
- The top `SHA256SUMS.txt` has {archive_audit['top_manifest_entry_count']:,} entries and passes direct archive-stream verification.
- Eight regular files are unhashed, all of them `SHA256SUMS.txt` manifests.
- `repository/SHA256SUMS.txt` is stale for two source files: `src/search_twosquares_bitset.cpp` and `src/search_twosquares_clean.cpp`.
- Five legacy reproduction manifests contain non-relocatable absolute `/mnt/data/a303656_bounded_counterexample/...` paths.
- There are {archive_audit['zero_byte_file_count']:,} zero-byte files, including {archive_audit['zero_byte_log_like_count']:,} log-like files; the top-level `standalone_full_replay.log` is zero bytes.

These conditions do not change the outer archive-byte identity, but they prevent an unconditional standalone-integrity PASS.

## 2. Commit and provenance evidence

The bundled Git object database verifies the chain:

`339df087` → `aa63d323` → `9b390390` → `7b3d9811` → `072c1a9f`.

Bundle changed-path evidence supports:

- correction 1 is a distinct commit changing only `build_recovery_v2.py`, with the authority-path correction;
- correction 2 is a distinct commit changing only `run_semantic_tests_v2.py` and `semantic_verifier_v2.py`, with mutation/exposure-precedence changes;
- SOURCE Y contains no `results_recovery_v2` scientific-result subtree;
- RESULTS Z adds only result/report/provenance files under that subtree;
- selected protected blobs remain unchanged across the chain.

Limitations:

1. `commit_provenance.json` gives a wrong full hash for the first SOURCE Y commit;
2. `RESULTS_Z` remains a placeholder in that file;
3. `worktree_initially_clean=false` and `preexisting_untracked_preserved=true` do not exclude original untracked scientific inputs;
4. the packaged checkout being clean does not prove the original WSL worktree was clean.

Therefore the strongest accepted statement is: **bundle evidence internally supports the commit chain and narrow changed-path scopes**.

## 3. Forensic reconciliation

{forensic_table}
The full 28-row interval crosswalk is in `interval_27_28_crosswalk.csv`. Closed-interval counts use \(b-a+1\); overlaps and adjacency are normalized before union length is computed.

## 4. Orphan-source recovery

All three source artifacts are physically present in the bundle and match the recorded SHA256/Git blob evidence:

| Source | Rows/points | SHA256 | Outcome influenced selection? |
|---|---:|---|---|
| `K4_PROGRESSION_PANEL` | 1,285 | `dad853ae1b385ef44ef67b442d5b3b82c78614a4fc99c77530ba6903ede49e23` | No for panel construction |
| `K4_DIRECT_VERIFICATION` | 73 | `3ec8be67747e64d5046dc9c3591c8885865b897f3d02c18be8fd5b01ee201794` | **Yes** — selected by \(T\)-conditioned reasons/minima |
| `P4_DIRECT_VERIFICATION` | 457 | `246d4067b4f7f80d88377ef17fa5732d0c4a9bf998ccd79c0dda94b0938abbaf` | **Yes** — includes \(T\)-threshold/minimum policies |

Recovery evidence is accepted. Registry integration is not: those E4 exposures are declared in component metadata but absent from registry v2 rows.

## 5. Interrupted-run audit

| Run | Certainty | Possible levels | Conservative superset | Catalogue/stage internally consistent? |
|---|---|---|---|---|
{run_table}

### Decisive 52-way blocker

The bundle does not recover numeric chunk starts, worker assignments, scheduler arguments, shell history, authenticated command line, runner hash, input manifest, deterministic partition function, checkpoints, temporary output, nonempty stdout/stderr, or last committed row. All 52 `.log` and 52 `.time` files are zero bytes; only `chunk_0014.rc=143` is nonempty.

Consequences:

- the complete numeric input universe is not recoverable;
- only the declared shape/cardinality 52×100M is known;
- no finite numeric conservative superset can be constructed from bundle evidence;
- zero Design A rows can be independently proved untouched;
- `UNKNOWN 384/384` is a defensible fail-closed classification, but not a computed intersection with an explicit superset;
- exact-\(T\) never-entered is not proved; absence of output is not absence of evaluator calls.

Any-evaluation historical completeness and exact-\(T\) historical completeness are both **NOT_ESTABLISHED**.

## 6. Registry v2 independent reconstruction

Current registry v2 contains 6,129 sparse integer rows and 28 interval records, but all sparse rows are attributed to the legacy source. Its level distribution has **E4 count 0**.

Independent source reconstruction finds:

- 6,583 confirmed distinct sparse integers;
- 983 integers with E4 exposure;
- 454 P5 Family U distinct integers omitted from v2;
- 73 K4 and 457 P4 direct-verification mappings not represented as E4;
- two confirmed exact-\(T\)/winner-mask interval records (`PILOT-A`, `PILOT-B`) omitted;
- conservative-superset/UNKNOWN records not represented in registry rows.

This is a known semantic loss, not merely unresolved historical completeness. Therefore:

\[
\boxed{{\text{{Registry v2: REJECTED}}}}
\]

Even after repairing these defects, the 52-way blocker would keep the registry **PARTIAL**, not COMPLETE.

## 7. Semantic verifier and test suite

The detached replay reproduces the bundled 32/32 result:

- 15 retained corruption tests: PASS;
- 7 known bypass regressions: PASS for the exact expected error code/category;
- 10 property/metamorphic tests: PASS;
- unrelated-earlier-failure masking detected in those 32 tests: 0.

However, active independent probes found **15 material accepted bypasses**, including:

- imported-helper, dynamic-key, nested and `getattr` outcome access;
- prefiltered candidate-universe import;
- interval/source mutations followed by self-redigest;
- blank/duplicate/contradictory registry provenance;
- self-consistent selection-index/integer tampering;
- candidate registry/prior-design identity tampering;
- forged gate PASS without evidence derivation;
- arbitrary self-authored manifest hashes;
- baseline acceptance despite E4=0 and 454 omitted P5 rows.

The verifier primarily establishes internal self-consistency, not source-grounded semantic identity. Thus:

- specified suite: **PASS 32/32**;
- semantic coverage: **PARTIAL**;
- verifier soundness: **NOT_ESTABLISHED**;
- verifier verdict: **REJECT / FIX REQUIRED**.

## 8. Gate V2 nine-item recomputation

| Gate | Independent status | Reason |
|---|---|---|
{gate_rows}

Overall rule gives **FAIL** because V2.2 fails. This is stricter than the submitted `NOT_ESTABLISHED` result.

## 9. Design A and replacement protocol

The prior Design A identity is preserved:

- old file SHA256: `{design['old_file_sha256']}` — matches;
- old canonical digest: `{design['old_canonical_digest']}` — matches;
- 48 class rows; 384 distinct integers; no collision;
- bands \(H_8=199,200,201\), each with 2 projections, 4 masks, 16 CRT classes, and 128 integers;
- raw \(G=227\), \(t_3=2\), selected indices `[0,7,14,21,28,35,42,49]`;
- confirmed registry intersection: 0;
- unknown any-evaluation: 384/384;
- unknown possible exact-\(T\): 384/384;
- `authorization=false`.

The replacement protocol is outcome-blind on its face and requires the same band/projection/mask/class, next deterministic eligible index, unchanged unaffected rows, and STOP on class exhaustion. It does not cure unknown historical exposure. Design A remains **Level 1 conditional candidate only**.

## 10. Standalone replay

A clean detached SOURCE Y tip was replayed without the original repository and without any evaluator invocation. The exact source build/verifier/tests produced:

- 75 files common with the bundled results;
- 74 byte-identical;
- one difference: `commit_provenance.json`, because SOURCE Y generates placeholders and RESULTS Z manually patches it;
- the independently reconstructed transparent core-25 set below is 25/25 byte-identical.

The bundle’s `standalone_replay_report.json` does **not** enumerate its claimed 25 artifacts or hashes. The following is this audit’s explicit reconstruction and is not claimed to be cryptographically identical to the submitter’s unstated set:

| # | Artifact | SHA256 | Byte-identical? |
|---:|---|---|---|
{core25_md}

Byte replay is therefore **ACCEPT WITH CONDITIONS**. Scientific standalone status remains **NOT_ESTABLISHED** because the replay consumes five precomputed inventory inputs rather than rebuilding them from raw sources, the registry/verifier semantics fail, and the claimed core-25 scope is unstated.

## 11. Route 2 adjudication

1. 52-way exposure provenance sufficient for Design A? **NO**.
2. Registry upgradeable to COMPLETE? **NO**.
3. V2.3/V2.4 can PASS? **NO**.
4. V2.8 can PASS? **NO**.
5. Gate V2 can authorize \(T\)? **NO**.

Required route decision for this submission:

```text
REJECT_BUNDLE
```

No specific, unchecked, high-probability 52-way command/manifest/ledger artifact is identified. Accordingly, after software/artifact defects are repaired, further open-ended historical recovery should be closed as `CLOSE_GATE_V2_ROUTE_2`, not continued speculatively.

## 12. Gate V3 recommendation

Do not implement Gate V3 from this submission. Under strict non-reuse, no sealed region can currently be proved disjoint from the unknown 52-way input universe; changing activation cells alone does not prove disjointness. A genuine cell change would require a fresh active-pair/\(H_8\) analysis unless domain invariance is separately proved. Because \(H_8:199\to201\) adds only two live pairs, the marginal empirical value is low. Analytic bad-prime anti-cover / second-moment work has higher expected value for the universal problem; Gate V3 should be secondary and cost-capped.

## Final authorization and verdict

```text
New T(n): NOT AUTHORIZED
Route decision: REJECT_BUNDLE
Overall verdict: REJECT / FIX REQUIRED
```

\[
\boxed{{\text{{OEIS A303656: UNRESOLVED}}}}
\]
'''
(PKG / 'REPORT.md').write_text(report, encoding='utf-8')

print(json.dumps({
    'status': 'finalized',
    'report': str(PKG / 'REPORT.md'),
    'verdict': verdict['overall_verdict'],
    'route': verdict['route_decision'],
    'new_T': verdict['new_T_authorization'],
    'core25_identical': all(r['byte_identical'] for r in core25_rows),
}, ensure_ascii=False))
