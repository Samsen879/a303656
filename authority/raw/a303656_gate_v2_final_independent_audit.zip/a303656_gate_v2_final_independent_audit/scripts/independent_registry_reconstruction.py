#!/usr/bin/env python3
"""Run the independent registry semantic reconstruction from bundled sources.

No new T(n), oracle, factorization, or search is performed.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from independent_audit_core import recompute_registry


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--repository', type=Path, required=True)
    ap.add_argument('--output-dir', type=Path, required=True)
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    result = recompute_registry(args.repository.resolve(), args.output_dir.resolve())
    (args.output_dir / 'registry_v2_recomputed.json').write_text(
        json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + '\n'
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
