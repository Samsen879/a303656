#!/usr/bin/env python3
"""Independent closed-integer interval normalization and union-length checker.

This script performs no evaluator, oracle, factorization, or T(n) computation.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path


def normalize(intervals: list[tuple[int, int]]) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    for lo, hi in sorted(intervals):
        if lo > hi:
            raise ValueError(f'invalid closed interval: {(lo, hi)}')
        if out and lo <= out[-1][1] + 1:
            out[-1] = (out[-1][0], max(out[-1][1], hi))
        else:
            out.append((lo, hi))
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--repository', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    source = args.repository / 'analysis/p5_sparse_panel_feasibility/results/prior_evaluation_registry.json'
    data = json.loads(source.read_text())
    raw = [(int(a), int(b)) for a, b in data['interval_union']]
    norm = normalize(raw)
    result = {
        'boundary': 'closed',
        'input_record_count': len(raw),
        'normalized_record_count': len(norm),
        'normalized_intervals': norm,
        'inclusive_union_length': sum(b - a + 1 for a, b in norm),
    }
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
