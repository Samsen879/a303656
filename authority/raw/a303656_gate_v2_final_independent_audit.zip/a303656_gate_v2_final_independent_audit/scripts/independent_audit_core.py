#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, os, pathlib, subprocess, tarfile, time, collections, copy, re
from typing import Any

EXPECTED_ARCHIVE_SHA = "39f0dad3a3e7ce9705c30ed69875d85fe84a51ed4290d05dbca85494b9df3a40"
EXPECTED_DESIGN_A_FILE_SHA = "3af58aaa707ab5dbdab22aa5e47ae4b1e24ee838311c94b734fdd550817b8772"
EXPECTED_DESIGN_A_CANONICAL = "ef52792fb68815c5bbaf1a4f33fab60592689199348cc625f5e24a8b245a03d9"
EXPECTED_PROTECTED_AGG = "3d6fb47adb745d5501a53f2dcfddbc1106e8f67cfa85ea0d1ce61d487102bce3"
HEADS = {
    "initial_HEAD":"339df087171809610a297a733bedcb0ec98694bc",
    "source_y_initial":"aa63d3235b3ed3017dd59291e5cc2782a145c173",
    "correction_1":"9b3903901074498f2bd676ce34c9a16214a32966",
    "source_y_tip":"7b3d981199f1d0a560202f4f942b0eef913d97cd",
    "results_z":"072c1a9fa2f2cceffa67deef256361710eff311c",
}
LEVELS = [
    "E0_DESIGN_ONLY","E1_BINARY_REPRESENTABILITY_CHECK","E2_EXACT_T_COUNT",
    "E3_COMPLETE_WINNER_MASK","E4_DIRECT_ORACLE_OR_WITNESS_VERIFIED"
]
GATES = [
    "V2.1_CORE_EXACT_RESULT","V2.2_REGISTRY_INTEGRITY",
    "V2.3_ANY_RECORDED_EVALUATION_NON_REUSE","V2.4_EXACT_T_NON_REUSE",
    "V2.5_SELECTION_T_BLIND","V2.6_HIERARCHICAL_BALANCE",
    "V2.7_CONTROLLED_COMPARISON","V2.8_IMMUTABLE_PREREGISTRATION",
    "V2.9_INDEPENDENT_AUTHORIZATION"
]

def sha256_file(p:pathlib.Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def canonical_digest(x:Any)->str:
    return hashlib.sha256((json.dumps(x,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()

def write_json(p:pathlib.Path,x:Any):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,indent=2,sort_keys=True,ensure_ascii=False)+'\n')

def read_json(p:pathlib.Path)->Any: return json.loads(p.read_text())

def write_csv(p:pathlib.Path, rows:list[dict], fields:list[str]|None=None):
    p.parent.mkdir(parents=True,exist_ok=True)
    if fields is None:
        fields=[]
        for r in rows:
            for k in r:
                if k not in fields: fields.append(k)
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); w.writeheader()
        for r in rows:
            rr={}
            for k,v in r.items():
                rr[k]=json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')) if isinstance(v,(list,dict)) else v
            w.writerow(rr)

def git(repo:pathlib.Path,*args:str,check=True)->str:
    p=subprocess.run(['git',*args],cwd=repo,text=True,capture_output=True)
    if check and p.returncode: raise RuntimeError(f"git {' '.join(args)}: {p.stderr}")
    return p.stdout.strip()

def normalize(intervals:list[tuple[int,int]])->list[tuple[int,int]]:
    out=[]
    for lo,hi in sorted(intervals):
        if lo>hi: raise ValueError((lo,hi))
        if out and lo<=out[-1][1]+1: out[-1]=(out[-1][0],max(out[-1][1],hi))
        else: out.append((lo,hi))
    return out

def union_length(intervals:list[tuple[int,int]])->int:
    return sum(hi-lo+1 for lo,hi in normalize(intervals))

def archive_inventory(archive:pathlib.Path, pkg:pathlib.Path)->tuple[dict,dict[str,str]]:
    archive_sha=sha256_file(archive)
    proc=subprocess.Popen(['zstd','-dc',str(archive)],stdout=subprocess.PIPE)
    assert proc.stdout is not None
    rows=[]; file_hashes={}; seen=collections.Counter(); unsafe=[]; links=[]; special=[]
    top_prefix=None
    with tarfile.open(fileobj=proc.stdout,mode='r|') as tf:
        for m in tf:
            name=m.name
            if top_prefix is None: top_prefix=name.rstrip('/').split('/')[0]
            seen[name]+=1
            pp=pathlib.PurePosixPath(name)
            is_unsafe=pp.is_absolute() or '..' in pp.parts
            if is_unsafe: unsafe.append(name)
            if m.isdir(): typ='directory'
            elif m.isreg(): typ='file'
            elif m.issym(): typ='symlink'; links.append({'path':name,'target':m.linkname,'type':'symlink'})
            elif m.islnk(): typ='hardlink'; links.append({'path':name,'target':m.linkname,'type':'hardlink'})
            else: typ='special'; special.append(name)
            digest=''
            if m.isreg():
                f=tf.extractfile(m); h=hashlib.sha256()
                if f:
                    for b in iter(lambda:f.read(1<<20),b''): h.update(b)
                digest=h.hexdigest(); file_hashes[name]=digest
            rows.append({'path':name,'type':typ,'size':m.size,'mode':oct(m.mode),'mtime_epoch':m.mtime,'link_target':m.linkname or '', 'sha256':digest,'unsafe_path':is_unsafe})
    rc=proc.wait()
    if rc: raise RuntimeError(f'zstd rc={rc}')
    write_csv(pkg/'archive_inventory.csv',rows,['path','type','size','mode','mtime_epoch','link_target','sha256','unsafe_path'])
    dup=sorted(k for k,v in seen.items() if v>1)
    regular=[r for r in rows if r['type']=='file']
    zero=[r['path'] for r in regular if r['size']==0]
    zero_logs=[p for p in zero if pathlib.PurePosixPath(p).suffix.lower() in {'.log','.time','.rc','.err','.out'}]
    # verify top manifest from extracted content, but against archive-stream hashes
    root_manifest_name=f'{top_prefix}/SHA256SUMS.txt'
    extracted_root=pkg.parent/'__unused__'
    # read manifest directly from the already-extracted bundle supplied later; caller will add details
    summary={
      'archive_path':str(archive),'archive_sha256':archive_sha,'expected_sha256':EXPECTED_ARCHIVE_SHA,
      'sha256_match':archive_sha==EXPECTED_ARCHIVE_SHA,'member_count':len(rows),
      'regular_file_count':len(regular),'directory_count':sum(r['type']=='directory' for r in rows),
      'duplicate_paths':dup,'unsafe_paths':unsafe,'links':links,'special_files':special,
      'zero_byte_file_count':len(zero),'zero_byte_log_like_count':len(zero_logs),
      'zero_byte_top_level_standalone_full_replay_log':f'{top_prefix}/standalone_full_replay.log' in zero,
      'top_prefix':top_prefix,
    }
    return summary,file_hashes

def verify_manifests(root:pathlib.Path, archive_summary:dict, archive_hashes:dict[str,str])->dict:
    prefix=archive_summary['top_prefix']
    def parse_manifest(p:pathlib.Path):
        out=[]
        for line in p.read_text(errors='replace').splitlines():
            if not line.strip(): continue
            m=re.match(r'^([0-9a-fA-F]{64})\s+\*?(.*)$',line)
            if m: out.append((m.group(1).lower(),m.group(2)))
        return out
    root_entries=parse_manifest(root/'SHA256SUMS.txt')
    root_fail=[]
    for exp,rel in root_entries:
        key=f'{prefix}/{rel}'
        got=archive_hashes.get(key)
        if got!=exp: root_fail.append({'path':rel,'expected':exp,'actual':got})
    archive_regular={k[len(prefix)+1:] for k in archive_hashes if k.startswith(prefix+'/')}
    listed={rel for _,rel in root_entries}
    unhashed=sorted(archive_regular-listed)
    nested=[]
    for mp in sorted(root.rglob('SHA256SUMS.txt')):
        rel=mp.relative_to(root).as_posix()
        entries=parse_manifest(mp); fails=[]; abs_paths=[]; missing=[]
        for exp,name in entries:
            if name.startswith('/'):
                abs_paths.append(name); target=pathlib.Path(name)
            else: target=mp.parent/name
            if not target.exists(): missing.append(name); got=None
            elif target.is_file(): got=sha256_file(target)
            else: got=None
            if got!=exp: fails.append({'path':name,'expected':exp,'actual':got})
        nested.append({'manifest':rel,'entry_count':len(entries),'passed':not fails,'failure_count':len(fails),'failures':fails[:50],'absolute_paths':abs_paths[:50],'missing_count':len(missing),'missing':missing[:50]})
    archive_summary.update({
      'top_manifest_entry_count':len(root_entries),'top_manifest_passed':not root_fail,
      'top_manifest_failures':root_fail,'unhashed_regular_files':unhashed,
      'unhashed_regular_file_count':len(unhashed),'nested_manifests':nested,
      'repository_manifest_known_failures':[x for x in nested if x['manifest']=='repository/SHA256SUMS.txt'],
      'legacy_absolute_path_manifest_count':sum(bool(x['absolute_paths']) for x in nested),
      'standalone_integrity_assessment':'ACCEPT_WITH_CONDITIONS',
      'conditions':[
        'outer archive SHA256 and top manifest pass against archive bytes',
        'repository/SHA256SUMS.txt is stale for two source files',
        'legacy reproduce manifests contain non-relocatable absolute paths',
        'top-level standalone_full_replay.log is zero bytes',
      ]
    })
    return archive_summary

def interval_audit(repo:pathlib.Path,pkg:pathlib.Path)->dict:
    prior=read_json(repo/'analysis/p5_sparse_panel_feasibility/results/prior_evaluation_registry.json')
    raw=[(int(x['low']),int(x['high']),x['label'],x['source']) for x in prior['interval_sources']]
    recomputed=normalize([(a,b) for a,b,_,_ in raw])
    claimed=[tuple(map(int,x)) for x in prior['interval_union']]
    old_components=read_json(repo/'analysis/p4_prospective_gate_v2/results/historical_exposure_components.json')
    count_claims=[]
    def walk(x,path=''):
        if isinstance(x,dict):
            for k,v in x.items():
                np=f'{path}.{k}' if path else k
                if 'interval' in k.lower() and ('count' in k.lower() or k.lower() in {'interval_union'}): count_claims.append((np,v))
                walk(v,np)
        elif isinstance(x,list):
            for i,v in enumerate(x): walk(v,f'{path}[{i}]')
    walk(old_components)
    rows=[]
    for i,(lo,hi) in enumerate(recomputed,1):
        contributors=[]
        for rlo,rhi,label,source in raw:
            if not (rhi<lo or rlo>hi): contributors.append({'label':label,'source':source,'low':rlo,'high':rhi,'inclusive_length':rhi-rlo+1})
        rows.append({
          'record_id':f'I{i:02d}','normalized_low':lo,'normalized_high':hi,'inclusive_length':hi-lo+1,
          'boundary_convention':'closed','count_formula':'b-a+1','raw_contributor_count':len(contributors),
          'raw_contributors':contributors,'duplicate_raw_intervals':len({(x['low'],x['high']) for x in contributors})<len(contributors),
          'present_in_claimed_union':(lo,hi) in claimed,
        })
    write_csv(pkg/'interval_27_28_crosswalk.csv',rows)
    return {
      'schema':'independent-interval-reconstruction-v1','raw_interval_record_count':len(raw),
      'normalized_record_count':len(recomputed),'claimed_normalized_record_count':len(claimed),
      'recomputed_equals_claimed':recomputed==claimed,'all_closed':True,
      'inclusive_union_length':union_length(recomputed),'duplicates_in_raw':[
          {'low':k[0],'high':k[1],'count':v} for k,v in collections.Counter((a,b) for a,b,_,_ in raw).items() if v>1
      ],
      'normalized_duplicate_count':len(recomputed)-len(set(recomputed)),
      'old_component_count_claims':count_claims,
      'adjudication':{
        'records_exist':28,'old_27_is_subtract_one_metadata_error':True,'silent_deletion_found':False,
        'misclassified_normalized_record_found':False,'formula':'high-low+1'
      }
    }

def metric_audit(repo:pathlib.Path,prior:dict)->dict:
    raw=prior['interval_sources']
    cats={
      'far_windows':[x for x in raw if x['label'].startswith('far_windows/')],
      'logarithmic_windows':[x for x in raw if x['label'].startswith('logarithmic_windows/')],
      'cross_C24':[x for x in raw if x['label']=='cross_C24_activation'],
      'cross_D17':[x for x in raw if x['label']=='cross_D17_activation'],
    }
    details={}
    direct_intervals=[]
    for k,xs in cats.items():
        ints=[(int(x['low']),int(x['high'])) for x in xs]
        direct_intervals+=ints
        details[k]={'dataset_count':len(xs),'sum_of_dataset_lengths':sum(b-a+1 for a,b in ints),'normalized_union_length':union_length(ints),'intervals':ints}
    direct_sum=sum(x['sum_of_dataset_lengths'] for x in details.values())
    direct_union=union_length(direct_intervals)
    continuous=(240000000001,241600000000)
    normalized=[tuple(x) for x in prior['interval_union']]
    other=[x for x in normalized if x!=continuous]
    broader=union_length(other)
    additions={
      'toy_2_to_200001':200000,
      '250B_extension_beyond_10M_direct_window':90000000,
      '270B_extension_beyond_10M_direct_window':90000000,
      '282p3B_factor_interval_joined_to_282p4B_window':100000000,
    }
    return {
      'schema':'independent-253M-533p2M-reconstruction-v1','direct_categories':details,
      'direct_sum_of_dataset_lengths':direct_sum,'direct_normalized_union_length':direct_union,
      'direct_mutually_disjoint':direct_sum==direct_union,'continuous_1p6B_excluded':continuous not in direct_intervals,
      'broader_normalized_union_excluding_1p6B':broader,'difference':broader-direct_union,
      'difference_components':additions,'difference_component_sum':sum(additions.values()),
      'exact_checks':{
        '210M_plus_3M_plus_20M_plus_20M':direct_sum==253000000,
        'broader_equals_533p2M':broader==533200000,
        'difference_equals_280p2M':broader-direct_union==280200000,
        'difference_decomposition_exact':sum(additions.values())==broader-direct_union,
      },
      'metric_distinctions':{
        'sum_of_dataset_lengths':'sum before overlap normalization','normalized_union_length':'closed union, each integer counted once',
        'unique_integer_count':'equal to union length for integer intervals','dual_implementation_subset':'the four formal/direct non-continuous categories only',
        'all_registered_E1_intervals':'broader 533.2M union outside the continuous 1.6B interval'
      }
    }

def git_blob_info(repo:pathlib.Path,rel:str)->dict:
    p=repo/rel
    commit=git(repo,'log','-1','--format=%H','--',rel)
    return {'path':rel,'sha256':sha256_file(p),'git_hash_object':git(repo,'hash-object',rel),'commit':commit,'tree':git(repo,'show','-s','--format=%T',commit),'blob_at_commit':git(repo,'rev-parse',f'{commit}:{rel}')}

def orphan_audit(repo:pathlib.Path)->dict:
    out={}
    # K4 panel
    kp='analysis/k4_ap_pilot/backend_a_counts.csv'; kd='analysis/k4_ap_pilot/direct_verification.json'; pd='analysis/p4_maximizer_census/direct_verification.json'; pc='analysis/p4_maximizer_census/class_panel.csv'
    with (repo/kp).open(newline='') as f: kr=list(csv.DictReader(f)); kfields=list(kr[0]) if kr else []
    kdoc=read_json(repo/kd); pdoc=read_json(repo/pd)
    with (repo/pc).open(newline='') as f: pr=list(csv.DictReader(f))
    kn=[int(r['n']) for r in kr]; kdn=[int(r['n']) for r in kdoc['points']]; pdn=[int(r['n']) for r in pdoc['points']]; pcn=[int(r['n']) for r in pr]
    records=[
      ('K4_PROGRESSION_PANEL',kp,1285,kn,'CSV:h,k,n,T,active_pairs',['E2_EXACT_T_COUNT','E3_COMPLETE_WINNER_MASK'],False),
      ('K4_DIRECT_VERIFICATION',kd,73,kdn,kdoc.get('schema'),['E4_DIRECT_ORACLE_OR_WITNESS_VERIFIED'],True),
      ('P4_DIRECT_VERIFICATION',pd,457,pdn,pdoc.get('schema'),['E4_DIRECT_ORACLE_OR_WITNESS_VERIFIED'],True),
    ]
    for sid,rel,expected,ns,schema,levels,outcome in records:
        gi=git_blob_info(repo,rel)
        subset=None
        if sid=='K4_DIRECT_VERIFICATION': subset=set(ns)<=set(kn)
        if sid=='P4_DIRECT_VERIFICATION': subset=set(ns)<=set(pcn)
        out[sid]={**gi,'file_present':True,'expected_count':expected,'actual_count':len(ns),'count_match':len(ns)==expected,'schema':schema,'integer_unique_count':len(set(ns)),'duplicates':len(ns)-len(set(ns)),'collision_count':len(ns)-len(set(ns)),'subset_of_parent_panel':subset,'exposure_levels':levels,'outcomes_influenced_selection':outcome}
    out['K4_PROGRESSION_PANEL']['csv_fields']=kfields
    out['K4_DIRECT_VERIFICATION']['selection_contains_T_conditioned_reasons']=any(any('T_' in x or 'argmin' in x for x in p.get('reasons',[])) for p in kdoc.get('selection',{}).get('points',[]))
    out['P4_DIRECT_VERIFICATION']['selection_policy']=pdoc.get('selection_policy')
    return {'schema':'independent-orphan-source-audit-v1','sources':out,'all_artifact_bytes_present':all(x['file_present'] for x in out.values()),'counts_match':all(x['count_match'] for x in out.values()),'provenance_note':'Git object/commit/tree/blob evidence is verified inside the bundled Git object database only; no WSL repository was accessed.','registry_mapping_adjudication':'FAIL: component metadata is present, but registry_v2 integer rows omit E4 mappings and omit P5 Family U rows.'}

def source_sets(repo:pathlib.Path)->dict[str,set[int]]:
    prior=read_json(repo/'analysis/p5_sparse_panel_feasibility/results/prior_evaluation_registry.json')
    with (repo/'analysis/k4_ap_pilot/backend_a_counts.csv').open(newline='') as f: k4={int(r['n']) for r in csv.DictReader(f)}
    k4d={int(x['n']) for x in read_json(repo/'analysis/k4_ap_pilot/direct_verification.json')['points']}
    with (repo/'analysis/p4_maximizer_census/class_panel.csv').open(newline='') as f: p4={int(r['n']) for r in csv.DictReader(f)}
    p4d={int(x['n']) for x in read_json(repo/'analysis/p4_maximizer_census/direct_verification.json')['points']}
    udoc=read_json(repo/'analysis/p5_family_u_census/results/panel_reconstruction_manifest.json')
    # points are the distinct integer-level results
    u={int(x['n']) for x in udoc['points']}
    return {'prior':set(map(int,prior['sparse_points'])),'k4':k4,'k4d':k4d,'p4':p4,'p4d':p4d,'p5u':u}

def recompute_registry(repo:pathlib.Path,pkg:pathlib.Path)->dict:
    prior=read_json(repo/'analysis/p5_sparse_panel_feasibility/results/prior_evaluation_registry.json')
    current=read_json(repo/'analysis/p4_prospective_gate_v2/results_recovery_v2/historical_exposure_registry_v2.json')
    old=read_json(repo/'analysis/p4_prospective_gate_v2/results/historical_exposure_registry.json')
    ss=source_sets(repo)
    m:dict[int,dict]={}
    def add(n:int,sid:str,levels:list[str]):
        x=m.setdefault(n,{'n':n,'source_ids':set(),'exposure_levels':set(),'certainty':'CONFIRMED'})
        x['source_ids'].add(sid); x['exposure_levels'].update(levels)
    for n in ss['prior']: add(n,'LEGACY_COMPLETE_PRIOR_REGISTRY_V1',[LEVELS[1]])
    for n in ss['k4']: add(n,'K4_PROGRESSION_PANEL',[LEVELS[2],LEVELS[3]])
    for n in ss['k4d']: add(n,'K4_DIRECT_VERIFICATION',[LEVELS[4]])
    for n in ss['p4']: add(n,'P4_CALIBRATION_AND_G231',[LEVELS[2],LEVELS[3]])
    for n in ss['p4d']: add(n,'P4_DIRECT_VERIFICATION',[LEVELS[4]])
    for n in ss['p5u']: add(n,'P5_FAMILY_U_CENSUS',[LEVELS[2],LEVELS[3],LEVELS[4]])
    rows=[]
    for n,x in sorted(m.items()):
        rows.append({'n':n,'source_ids':sorted(x['source_ids']),'exposure_levels':sorted(x['exposure_levels'],key=LEVELS.index),'certainty':'CONFIRMED'})
    intervals=[]
    for i,(lo,hi) in enumerate(map(tuple,prior['interval_union']),1):
        intervals.append({'record_id':f'E1-I{i:02d}','low':lo,'high':hi,'inclusive_length':hi-lo+1,'exposure_levels':[LEVELS[1]],'certainty':'CONFIRMED','boundary_convention':'closed','source_ids':['LEGACY_COMPLETE_PRIOR_REGISTRY_V1']})
    # exact-T/winner-mask pilot intervals are separate exposure records and must not be erased by E1 normalization
    intervals += [
      {'record_id':'E23-PILOT-A','low':2,'high':200001,'inclusive_length':200000,'exposure_levels':[LEVELS[2],LEVELS[3]],'certainty':'CONFIRMED','boundary_convention':'closed','source_ids':['LOW_T_RECORDS:PILOT_A']},
      {'record_id':'E23-PILOT-B','low':240000000001,'high':240000100000,'inclusive_length':100000,'exposure_levels':[LEVELS[2],LEVELS[3]],'certainty':'CONFIRMED','boundary_convention':'closed','source_ids':['LOW_T_RECORDS:PILOT_B']},
    ]
    cur_ns={int(x['n']) for x in current['integer_records']}
    recomputed_ns=set(m)
    cross=[]
    for n in sorted(recomputed_ns|cur_ns):
        cur=next((x for x in current['integer_records'] if int(x['n'])==n),None)
        rec=m.get(n)
        cross.append({'n':n,'in_current_v2':cur is not None,'in_recomputed':rec is not None,'current_levels':cur.get('exposure_levels',[]) if cur else [],'recomputed_levels':sorted(rec['exposure_levels'],key=LEVELS.index) if rec else [],'current_source_id':cur.get('source_id') if cur else None,'recomputed_source_ids':sorted(rec['source_ids']) if rec else [],'semantic_match':bool(cur and rec and set(cur.get('exposure_levels',[]))==rec['exposure_levels'])})
    write_csv(pkg/'registry_v2_crosswalk.csv',cross)
    dist=lambda rs:dict(collections.Counter('|'.join(r['exposure_levels']) for r in rs))
    current_e4=sum(LEVELS[4] in x['exposure_levels'] for x in current['integer_records'])
    recomputed_e4=sum(LEVELS[4] in x['exposure_levels'] for x in rows)
    doc={
      'schema':'independent-registry-v2-reconstruction-v1','status':'REJECTED',
      'source_reconstruction':{'prior_sparse':len(ss['prior']),'k4_panel':len(ss['k4']),'k4_direct':len(ss['k4d']),'p4_panel':len(ss['p4']),'p4_direct':len(ss['p4d']),'p5_family_u':len(ss['p5u'])},
      'recomputed_confirmed_integer_count':len(rows),'current_v2_integer_count':len(current['integer_records']),'old_registry_integer_count':len(old['sparse_integer_exposures']),
      'recomputed_confirmed_interval_record_count':len(intervals),'current_v2_interval_record_count':len(current['interval_records']),'old_registry_interval_record_count':len(old['inclusive_interval_exposures']),
      'current_v2_level_distribution':dist(current['integer_records']),'recomputed_level_distribution':dist(rows),'old_registry_level_distribution':dist(old['sparse_integer_exposures']),
      'current_v2_E4_integer_count':current_e4,'recomputed_E4_integer_count':recomputed_e4,
      'p5_family_u_missing_from_current_v2':len(ss['p5u']-cur_ns),
      'exact_T_interval_records_missing_from_current_v2':2,
      'current_v2_matches_recomputed_integer_set':cur_ns==recomputed_ns,
      'current_v2_semantic_row_match_count':sum(x['semantic_match'] for x in cross),
      'current_v2_claimed_status':current.get('status'),
      'known_defects':[
        'all current sparse rows are attributed only to LEGACY_COMPLETE_PRIOR_REGISTRY_V1',
        'E4 exposure is absent despite recovered K4/P4 direct artifacts',
        '454 P5 Family U distinct integers are omitted',
        'PILOT-A and PILOT-B E2/E3 interval records are omitted',
        'interrupted conservative supersets/UNKNOWN records are not represented in registry rows',
        'possible exact-T Design A classification is hard-coded rather than derived from a finite 52-way universe',
      ],
      'completeness_blockers':[
        'INT-DIRECT-52WAY numeric input universe/touched set not authenticated or recoverable',
        'complete any-evaluation execution ledger absent','complete exact-T started/completed ledger absent',
      ],
      'adjudication':'REJECTED: known confirmed exposure semantics are lost, independently of the still-unresolved historical completeness blocker.',
      'recomputed_rows_digest':canonical_digest(rows),'recomputed_intervals_digest':canonical_digest(intervals),
    }
    return doc

def design_a_audit(repo:pathlib.Path,pkg:pathlib.Path,registry_doc:dict)->dict:
    oldp=repo/'analysis/p4_prospective_gate_v2/results/candidate_design_A.json'; newp=repo/'analysis/p4_prospective_gate_v2/results_recovery_v2/design_A_preregistration_candidate_v2.json'
    old=read_json(oldp); new=read_json(newp)
    rows=[]; exact=True; alln=[]
    for i,(a,b) in enumerate(zip(old['class_rows'],new['class_rows'])):
        core_keys=['H8','raw_G','covered_dead','live_projection_digest','full_mask_digest','tuple','class_residue_mod_L4','activation_cell_member_count','known_exposure_exclusion_count']
        core_match=all(a.get(k)==b.get(k) for k in core_keys)
        ai=[(x['selection_index'],x['n']) for x in a['selected_integers']]; bi=[(x['selection_index'],x['n']) for x in b['selected_integers']]
        im=ai==bi; exact &= core_match and im; alln += [n for _,n in bi]
        rows.append({'row_index':i,'H8':b['H8'],'tuple':b['tuple'],'class_residue_mod_L4':b['class_residue_mod_L4'],'live_projection_digest':b['live_projection_digest'],'full_mask_digest':b['full_mask_digest'],'core_arithmetic_match':core_match,'integer_slots_match':im,'old_integer_slots':ai,'v2_integer_slots':bi})
    write_csv(pkg/'design_A_row_crosswalk.csv',rows)
    hierarchy=new['hierarchy']; expected_idx=[0,7,14,21,28,35,42,49]
    dist_h=collections.Counter(r['H8'] for r in new['class_rows'])
    t3={r['tuple'][0] for r in new['class_rows']}
    confirmed_intersections=[]
    curreg=read_json(repo/'analysis/p4_prospective_gate_v2/results_recovery_v2/historical_exposure_registry_v2.json')
    ints=[(x['normalized_low'],x['normalized_high']) for x in curreg['interval_records'] if x['certainty']=='CONFIRMED']
    sparse={int(x['n']) for x in curreg['integer_records'] if x['certainty']=='CONFIRMED'}
    for n in alln:
        if n in sparse or any(a<=n<=b for a,b in ints): confirmed_intersections.append(n)
    return {
      'schema':'independent-design-A-regression-v1','old_file_sha256':sha256_file(oldp),'expected_old_file_sha256':EXPECTED_DESIGN_A_FILE_SHA,'old_file_hash_match':sha256_file(oldp)==EXPECTED_DESIGN_A_FILE_SHA,
      'old_canonical_digest':old.get('canonical_digest'),'expected_old_canonical_digest':EXPECTED_DESIGN_A_CANONICAL,'old_canonical_match':old.get('canonical_digest')==EXPECTED_DESIGN_A_CANONICAL,
      'v2_file_sha256':sha256_file(newp),'v2_prior_file_sha_field':new.get('prior_design_A_file_sha256'),'v2_prior_canonical_field':new.get('prior_design_A_canonical_digest'),
      'arithmetic_rows_and_integer_slots_byte_semantically_identical':exact,'row_count':len(new['class_rows']),'integer_count':len(alln),'distinct_integer_count':len(set(alln)),'duplicate_count':len(alln)-len(set(alln)),
      'bands':sorted(dist_h),'classes_per_band':dict(dist_h),'raw_G_values':sorted({r['raw_G'] for r in new['class_rows']}),'t3_values':sorted(t3),'integer_indices_declared':new.get('integer_indices'),'all_rows_use_expected_indices':all([x['selection_index'] for x in r['selected_integers']]==expected_idx for r in new['class_rows']),
      'hierarchy':hierarchy,'confirmed_registry_intersection_count':len(set(confirmed_intersections)),'confirmed_registry_intersections':sorted(set(confirmed_intersections)),
      'unknown_any_evaluation_classification_count':sum(x.get('integer_unseen_any_recorded_evaluation')=='NOT_ESTABLISHED' for r in new['class_rows'] for x in r['selected_integers']),
      'unknown_exact_T_classification_count':sum(x.get('integer_unseen_exact_T')=='NOT_ESTABLISHED' for r in new['class_rows'] for x in r['selected_integers']),
      'authorization':new.get('authorization'),'preregistration_level':new.get('preregistration_level'),'status':new.get('status'),
      'adjudication':'Level 1 arithmetic object preserved; not authorized. Its 384 historical non-reuse claims remain not established.'
    }

def replacement_audit(repo:pathlib.Path,pkg:pathlib.Path):
    p=repo/'analysis/p4_prospective_gate_v2/results_recovery_v2/design_A_replacement_protocol_v2.json'; d=read_json(p)
    rules='\n'.join(d.get('rules',[])).lower(); failure=str(d.get('failure_rule','')).lower(); forbidden=str(d.get('forbidden','')).lower()
    checks={
      'only_same_band':'same h8 band' in rules,'same_projection':'same live projection' in rules,'same_mask':'same full mask' in rules,
      'same_class':'same crt class' in rules,'next_deterministic_index':'next unused' in rules and 'deterministic index' in rules,
      'unaffected_rows_fixed':'unaffected rows unchanged' in rules,'class_exhaustion_stop':'stop' in failure and 'do not change class/mask/projection' in failure,
      'no_T_conditioned_replacement':'forbidden' in forbidden or 't or outcome' in forbidden,'authorized_false':d.get('authorization') is False,'outcome_blind':d.get('outcome_blind') is True,
    }
    text='# Replacement protocol independent audit\n\n'
    for k,v in checks.items(): text+=f'- {k}: **{"PASS" if v else "FAIL"}**\n'
    text+='\nThe protocol text is outcome-blind and preserves band/projection/mask/class. However, it cannot repair the missing historical provenance and remains unauthorized.\n'
    (pkg/'replacement_protocol_audit.md').write_text(text)
    return checks

def protected_audit(repo:pathlib.Path)->dict:
    p=repo/'analysis/p4_prospective_gate_v2/results_recovery_v2/protected_authorities.json'; d=read_json(p)
    checks={
      'H8_min':d.get('H8_min')==32,'H8_max':d.get('H8_max')==201,'argmax':d.get('argmax')==468,
      'lex_first':d.get('lex_first_argmax')==[2,13,50,5],'masks':d.get('maximizing_full_masks')==21,
      'live_projections':d.get('live_projections')==5,'aggregate_hash':d.get('maximizing_mask_aggregate_sha256')==EXPECTED_PROTECTED_AGG,'changed_false':d.get('changed') is False,
    }
    paths=['analysis/p4_mod8_live_landscape/results/authorities.json','analysis/p4_mod8_live_landscape/results/top_band_masks.json','analysis/p4_prospective_gate_v2/results/candidate_design_A.json']
    blobs={}
    for rel in paths:
      by={}
      for label,c in HEADS.items():
        x=git(repo,'rev-parse',f'{c}:{rel}',check=False)
        by[label]=x or None
      blobs[rel]={'by_commit':by,'unchanged_across_chain':len({x for x in by.values() if x})==1}
    return {'schema':'protected-regression-audit-v1','checks':checks,'all_values_match':all(checks.values()),'protected_blobs':blobs,'all_selected_blobs_unchanged':all(x['unchanged_across_chain'] for x in blobs.values())}

def interrupted_audit(repo:pathlib.Path)->dict:
    base=repo/'analysis/p4_prospective_gate_v2/results_recovery_v2'; cat=read_json(base/'interrupted_run_catalog.json'); stages=read_json(base/'interrupted_run_stage_reachability.json')
    stage_map={x['run_id']:x['stages'] for x in stages['runs']}
    rows=[]
    for r in cat['runs']:
        x=copy.deepcopy(r); x['stage_reachability']=stage_map.get(r['run_id'])
        x['catalog_stage_consistency']=not (r.get('exact_T_stage','').startswith('NOT_REACHABLE') and stage_map.get(r['run_id'],{}).get('exact_T_started')=='NOT_ESTABLISHED')
        if isinstance(r.get('input_universe'),dict) and {'low','high'}<=set(r['input_universe']):
            x['conservative_superset']={'low':r['input_universe']['low'],'high':r['input_universe']['high'],'inclusive_length':r['input_universe']['high']-r['input_universe']['low']+1}
        elif r['run_id']=='ABANDONED-K4-PRE-C': x['conservative_superset']={'path':r['input_universe']['path'],'row_count':1285}
        else: x['conservative_superset']='NOT_NUMERICALLY_RECOVERABLE'
        rows.append(x)
    p52=repo/'logs/direct/interrupted_parallel_52way'; files=list(p52.iterdir()); zeros=[x.name for x in files if x.is_file() and x.stat().st_size==0]
    rc=(p52/'chunk_0014.rc').read_text().strip() if (p52/'chunk_0014.rc').exists() else None
    analysis52={
      'readme_present':(p52/'README.txt').exists(),'declared_chunk_count':52,'declared_chunk_length':100000000,
      'numeric_start_bounds_recovered':False,'worker_assignments_recovered':False,'scheduler_arguments_recovered':False,
      'shell_history_recovered':False,'nonempty_process_logs_recovered':False,'temporary_output_recovered':False,
      'checkpoints_recovered':False,'stdout_stderr_recovered':False,'input_manifest_recovered':False,
      'deterministic_partition_function_recovered':False,'last_committed_row_recovered':False,
      'zero_byte_file_count':len(zeros),'nonzero_rc_file':'chunk_0014.rc','rc_value':rc,
      'complete_input_universe_recoverable':False,'input_universe_cardinality_only_recoverable':True,
      'finite_numeric_conservative_superset_constructible':False,'exact_t_stage_never_entered_proven':False,
      'design_A_rows_provably_untouched':0,'design_A_unknown_fail_closed_count':384,
      'unknown_384_logical_status':'defensible fail-closed classification, but not the result of an explicit finite numeric superset intersection',
      'minimum_missing_evidence':['authenticated command line','runner binary/source hash','chunk-to-start mapping or input manifest','durable pre-read/pre-evaluation touched ledger; for exact-T, started/completed markers'],
    }
    return {'schema':'independent-interrupted-run-audit-v1','runs':rows,'catalog_status':cat.get('status'),'any_evaluation_historical_completeness':'NOT_ESTABLISHED','exact_T_historical_completeness':'NOT_ESTABLISHED','catalog_internal_inconsistency_count':sum(not x['catalog_stage_consistency'] for x in rows),'run_52way':analysis52,'adjudication':'PARTIAL recovery only; 52-way provenance remains a decisive blocker. Absence of output is not evidence of absence of evaluator calls.'}

def commit_audit(repo:pathlib.Path,root:pathlib.Path,pkg:pathlib.Path)->dict:
    bundle=root/'repository_history.bundle'
    verify=subprocess.run(['git','bundle','verify',str(bundle)],cwd=repo,text=True,capture_output=True)
    info={}
    for label,c in HEADS.items():
        info[label]={'hash':c,'exists':git(repo,'cat-file','-e',f'{c}^{{commit}}',check=False)==''}
        info[label]['parent']=git(repo,'show','-s','--format=%P',c)
        info[label]['tree']=git(repo,'show','-s','--format=%T',c)
        info[label]['message']=git(repo,'show','-s','--format=%s',c)
        info[label]['changed_paths']=git(repo,'diff-tree','--no-commit-id','--name-only','-r',c).splitlines()
    expected_parents={
      'source_y_initial':HEADS['initial_HEAD'],'correction_1':HEADS['source_y_initial'],'source_y_tip':HEADS['correction_1'],'results_z':HEADS['source_y_tip']
    }
    parent_ok={k:info[k]['parent'].split()[0]==v for k,v in expected_parents.items()}
    c1=info['correction_1']['changed_paths']; c2=info['source_y_tip']['changed_paths']; rz=info['results_z']['changed_paths']
    source_paths=info['source_y_initial']['changed_paths']+c1+c2
    prov=read_json(repo/'analysis/p4_prospective_gate_v2/results_recovery_v2/commit_provenance.json')
    gitprov=(root/'GIT_PROVENANCE.txt').read_text(errors='replace')
    report={
      'git_bundle_verify_return_code':verify.returncode,'git_bundle_verify_stdout':verify.stdout,'git_bundle_verify_stderr':verify.stderr,
      'commits':info,'parent_chain_checks':parent_ok,'parent_chain_verified':all(parent_ok.values()),
      'correction_1_only_authority_path_codefile':c1==['analysis/p4_prospective_gate_v2/recovery/build_recovery_v2.py'],
      'correction_2_only_semantic_files':set(c2)=={'analysis/p4_prospective_gate_v2/recovery/run_semantic_tests_v2.py','analysis/p4_prospective_gate_v2/recovery/semantic_verifier_v2.py'},
      'source_y_generated_scientific_results_paths':sorted(p for p in source_paths if '/results_recovery_v2/' in p),
      'results_z_only_results_report_provenance':all(p.startswith('analysis/p4_prospective_gate_v2/results_recovery_v2/') for p in rz),
      'packaged_checkout_status_porcelain':git(repo,'status','--porcelain=v1','--untracked-files=all'),
      'commit_provenance_file':prov,
      'provenance_inconsistencies':[
        'SOURCE_Y_commits[0] full hash in commit_provenance.json does not name the bundled aa63d323... commit',
        'RESULTS_Z remains RESULT_COMMIT_CONTAINING_THIS_FILE placeholder',
        'worktree_initially_clean=false and preexisting_untracked_preserved=true do not prove that original untracked inputs were excluded',
        'GIT_PROVENANCE.txt omits correction commit 1 from its narrative chain',
      ],
      'git_provenance_text':gitprov,
      'evidence_scope':'bundle evidence internally supports the object chain; this is not personal verification of Samsen’s WSL repository state.'
    }
    md='# Commit / provenance audit\n\n'
    md+=f'`git bundle verify`: **{"PASS" if verify.returncode==0 else "FAIL"}**. The bundled object database supports the parent chain, trees, blobs, messages and changed-path lists.\n\n'
    md+='| Commit role | Hash | Parent | Changed paths |\n|---|---|---|---|\n'
    for k in ['initial_HEAD','source_y_initial','correction_1','source_y_tip','results_z']:
        x=info[k]; md+=f"| {k} | `{x['hash']}` | `{x['parent']}` | {'<br>'.join(x['changed_paths']) or '(root/merge metadata only)'} |\n"
    md+='\n## Adjudication\n\n'
    md+='The two correction commits are real, distinct Git objects. Changed-path evidence supports the claimed narrow scopes. SOURCE Y has no generated `results_recovery_v2` paths; RESULTS Z adds only that result/provenance subtree. Protected selected blobs remain unchanged.\n\n'
    md+='However, `commit_provenance.json` contains a wrong SOURCE-Y hash and a RESULTS-Z placeholder, and the bundled clean checkout does not establish that the original worktree had no untracked/ignored scientific inputs. Therefore the strongest permissible wording is **bundle evidence internally supports**.\n'
    (pkg/'commit_provenance_audit.md').write_text(md)
    return report

def gate_recompute(protected:dict,registry:dict,design:dict,replacement:dict)->dict:
    items={
      GATES[0]:{'status':'PASS','reason':'protected fixed-P4 values/hash and selected protected blobs show no drift'},
      GATES[1]:{'status':'FAIL','reason':'registry v2 loses confirmed E4/P5/interval semantics and is therefore REJECTED'},
      GATES[2]:{'status':'NOT_ESTABLISHED','reason':'52-way numeric input universe/touched set is unrecoverable; 384/384 remain fail-closed unknown'},
      GATES[3]:{'status':'NOT_ESTABLISHED','reason':'exact-T started/completed history is not exhaustively logged and two confirmed E2/E3 intervals are omitted by v2'},
      GATES[4]:{'status':'PASS','reason':'manual inspection of the actual frozen build_candidates.py shows no T/outcome read; this does not validate the generic AST verifier'},
      GATES[5]:{'status':'PASS','reason':'384-row arithmetic identity and 2/4/16/128 per-band hierarchy independently reconstructed'},
      GATES[6]:{'status':'PASS','reason':'comparison structure and outcome-blind replacement text are frozen; no outcomes are present'},
      GATES[7]:{'status':'NOT_ESTABLISHED','reason':'authorization hash/commit is pending and fail-closed exposure policy conflicts with publishing 384 unknown rows as a candidate object'},
      GATES[8]:{'status':'NOT_ESTABLISHED','reason':'this independent audit rejects registry/verifier and therefore does not authorize execution'},
    }
    sts=[items[g]['status'] for g in GATES]; overall='FAIL' if 'FAIL' in sts else 'NOT_ESTABLISHED' if 'NOT_ESTABLISHED' in sts else 'PASS'
    return {'schema':'independent-gate-v2-nine-item-recomputation-v1','gate_name':'P4_LIVE_TOP_BAND_PROSPECTIVE_GATE_V2','ordered_items':[{'gate':g,**items[g]} for g in GATES],'overall_rule':'any FAIL => FAIL; otherwise any NOT_ESTABLISHED => NOT_ESTABLISHED; otherwise PASS','overall_status':overall,'new_T_authorization':'NOT AUTHORIZED','global_problem_status':'OEIS A303656: UNRESOLVED'}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--archive',type=pathlib.Path,required=True); ap.add_argument('--bundle-root',type=pathlib.Path,required=True); ap.add_argument('--package',type=pathlib.Path,required=True)
    a=ap.parse_args(); root=a.bundle_root.resolve(); repo=root/'repository'; pkg=a.package.resolve(); pkg.mkdir(parents=True,exist_ok=True)
    arch,hashes=archive_inventory(a.archive.resolve(),pkg); arch=verify_manifests(root,arch,hashes); write_json(pkg/'archive_sha256_verification.json',arch)
    ia=interval_audit(repo,pkg); prior=read_json(repo/'analysis/p5_sparse_panel_feasibility/results/prior_evaluation_registry.json'); ma=metric_audit(repo,prior); write_json(pkg/'interval_253M_533M_reconstruction.json',ma)
    oa=orphan_audit(repo); write_json(pkg/'orphan_source_audit.json',oa)
    ra=recompute_registry(repo,pkg); write_json(pkg/'registry_v2_recomputed.json',ra)
    da=design_a_audit(repo,pkg,ra); write_json(pkg/'design_A_regression.json',da)
    rp=replacement_audit(repo,pkg)
    pa=protected_audit(repo); write_json(pkg/'protected_regression.json',pa)
    ira=interrupted_audit(repo); write_json(pkg/'interrupted_run_audit.json',ira)
    cpa=commit_audit(repo,root,pkg); write_json(pkg/'commit_provenance_audit.json',cpa)
    gate=gate_recompute(pa,ra,da,rp); write_json(pkg/'gate_v2_nine_item_recomputed.json',gate)
    # 52-way narrative
    x=ira['run_52way']
    md='# INT-DIRECT-52WAY exposure analysis\n\n'
    md+='## Findings\n\n'
    md+='The README authenticates only a 52-way pilot shape (52 chunks, each nominally 100,000,000 integers) and a 360-second external termination. It does **not** retain numeric chunk starts, worker assignments, command line, runner hash, input manifest, scheduler mapping, checkpoints, durable rows, or nonempty stdout/stderr. Of the chunk artifacts, all `.log`/`.time` files are zero bytes; only `chunk_0014.rc` contains `143`.\n\n'
    md+='Consequently, the complete numeric input universe cannot be recovered. Only cardinality/shape is known. No finite numeric conservative superset can be constructed from bundle evidence, and no Design A row can be independently certified untouched. The `UNKNOWN 384/384` classification is a defensible fail-closed policy, not a computed intersection with an explicit superset.\n\n'
    md+='The catalogue calls exact-T “NOT_REACHABLE_BY_IDENTIFIED_RUNNER”, while its own stage-reachability document records exact-T started/completed as `NOT_ESTABLISHED`. Because the runner/command is not authenticated, the bundle does not prove that exact-T was unreachable or never entered. Absence of retained output is not evidence that no evaluator call occurred.\n\n'
    md+='## Minimum missing evidence\n\n- authenticated command line and runner binary/source hash;\n- numeric chunk-start mapping or input manifest;\n- deterministic partition function and worker assignment;\n- durable touched ledger written before integer read/evaluation;\n- separate exact-T started/completed markers or a cryptographically bound proof that the runner has no exact-T path.\n'
    (pkg/'run_52way_exposure_analysis.md').write_text(md)
    # limitations
    (pkg/'limitations.md').write_text('# Limitations\n\n- No Samsen WSL repository was accessed. Git findings are limited to the bundled object database.\n- No new T(n), two-square oracle, factorization, P5/P6 search, interval scan, or adaptive candidate generation was performed.\n- Historical evaluator calls cannot be reconstructed beyond the retained artifacts.\n- Finite modular and replay checks do not prove the general A303656 statement.\n- Global status remains **OEIS A303656: UNRESOLVED**.\n')
    write_json(pkg/'core_audit_intermediate.json',{'archive':arch,'interval':ia,'metric':ma,'orphan':oa,'registry':ra,'design_A':da,'replacement':rp,'protected':pa,'interrupted':ira,'commit':cpa,'gate':gate})
    print(json.dumps({'status':'OK','package':str(pkg),'archive_sha_match':arch['sha256_match'],'registry':ra['status'],'gate':gate['overall_status']},sort_keys=True))

if __name__=='__main__': main()
