# INT-DIRECT-52WAY exposure analysis

## Findings

The README authenticates only a 52-way pilot shape (52 chunks, each nominally 100,000,000 integers) and a 360-second external termination. It does **not** retain numeric chunk starts, worker assignments, command line, runner hash, input manifest, scheduler mapping, checkpoints, durable rows, or nonempty stdout/stderr. Of the chunk artifacts, all `.log`/`.time` files are zero bytes; only `chunk_0014.rc` contains `143`.

Consequently, the complete numeric input universe cannot be recovered. Only cardinality/shape is known. No finite numeric conservative superset can be constructed from bundle evidence, and no Design A row can be independently certified untouched. The `UNKNOWN 384/384` classification is a defensible fail-closed policy, not a computed intersection with an explicit superset.

The catalogue calls exact-T “NOT_REACHABLE_BY_IDENTIFIED_RUNNER”, while its own stage-reachability document records exact-T started/completed as `NOT_ESTABLISHED`. Because the runner/command is not authenticated, the bundle does not prove that exact-T was unreachable or never entered. Absence of retained output is not evidence that no evaluator call occurred.

## Minimum missing evidence

- authenticated command line and runner binary/source hash;
- numeric chunk-start mapping or input manifest;
- deterministic partition function and worker assignment;
- durable touched ledger written before integer read/evaluation;
- separate exact-T started/completed markers or a cryptographically bound proof that the runner has no exact-T path.
