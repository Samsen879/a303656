# Audit package guide

Primary entry points:

- `REPORT.md` — human-readable final independent audit.
- `AUDIT_VERDICT.json` — machine-readable layered verdict.
- `SHA256SUMS.txt` — package manifest, generated after all audit files.
- `registry_v2_recomputed.json` / `registry_v2_crosswalk.csv` — independent registry reconstruction and row-level comparison.
- `semantic_test_matrix_recomputed.json`, `bypass_regression_audit.json`, `new_adversarial_probes.json` — specified-suite replay and adversarial soundness evidence.
- `standalone_replay_audit.json`, `standalone_core25_hashes.csv` — detached replay and explicit 25-file comparison.
- `route_2_adjudication.json`, `gate_v3_route_recommendation.md` — route decisions.

The scripts under `scripts/` use only bundled historical artifacts and do not compute new `T(n)`, invoke a two-square oracle, factor integers, or generate new candidate integers.

Global status: **OEIS A303656: UNRESOLVED**.
