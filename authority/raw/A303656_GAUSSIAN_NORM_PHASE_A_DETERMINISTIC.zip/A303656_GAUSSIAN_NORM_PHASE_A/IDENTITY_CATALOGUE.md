# IDENTITY CATALOGUE

## 0. Audit convention

Every entry is classified against the requested gates:

- **domain:** all parameters or a proper subfamily;
- **integrality/nonnegativity:** whether output coordinates and exponents are
  valid;
- **counterexample transfer:** whether the identity proves a map on integers,
  rather than merely on a tagged representation;
- **active-domain completeness:** whether every possible source exponent pair
  is handled;
- **payoff:** original A303656 shape, a weaker enlarged class, or an isolated
  representation identity.

Write `z=a+bi`, `pi=2+i`, and `N(z)=a^2+b^2`.

## 1. Universal algebraic identities

### ID-BF — Brahmagupta–Fibonacci

\[
N(zw)=N(z)N(w),
\]

\[
(a^2+b^2)(x^2+y^2)=(ax-by)^2+(ay+bx)^2.
\]

- **Domain:** all Gaussian integers `z,w`.
- **Coordinates:** integral; absolute values make them nonnegative.
- **Use:** exact norm multiplication.
- **Limitation:** it composes products, not sums of norms.

### ID-G9A — universal `9`-scale, `d -> d+1`, two norm terms

For all `z,c,d`,

\[
\boxed{
9\bigl(N(z)+3^c+5^d\bigr)
=N(3z)+N(2\pi^d)+3^{c+2}+5^{d+1}.}
\tag{G9A}
\]

Indeed, `N(2 pi^d)=4*5^d`.

- **Domain:** all `z,c,d>=0`.
- **Exponents:** remain nonnegative.
- **Output class:** `S_2+S_2+3^C+5^D`, not A303656's one-norm class.
- **Counterexample transfer:** none for A303656; two norms need not add to one
  norm.
- **Intermediate theorem:** a universal closure identity for the strictly
  weaker enlarged problem with two independent norm summands.

### ID-G9B — universal `9`-scale, fixed `d`, two norm terms

For all `z,c,d`,

\[
\boxed{
9\bigl(N(z)+3^c+5^d\bigr)
=N(3z)+N(2(1+i)\pi^d)+3^{c+2}+5^d.}
\tag{G9B}
\]

Here `N(2(1+i) pi^d)=8*5^d`.

The audit is the same as for `(G9A)`.  These are the two nonnegative natural
choices `5^{d+s}` with `s=0,1` under scale `9`.

### ID-G5 — universal even-`c` `5`-scale, two norm terms

For `c=2k`,

\[
\boxed{
5\bigl(N(z)+3^{2k}+5^d\bigr)
=N(\pi z)+N((1+i)3^k)+3^{2k+1}+5^{d+1}.}
\tag{G5}
\]

- **Domain:** all `z,d,k>=0`, but only even `c`.
- **Reason for parity:** `2*3^c` is a Gaussian norm exactly when `c` is even.
- **Output class:** two norms plus the two powers.
- **Active-domain completeness:** fails because odd `c` is omitted.
- **Counterexample transfer:** none for the original one-norm problem.

### ID-G25E — universal even-`c` `25`-scale, two norm terms

For `c=2k`,

\[
\boxed{
25\bigl(N(z)+3^{2k}+5^d\bigr)
=N(\pi^2z)+N(4\cdot3^k)+3^{2k+2}+5^{d+2}.}
\tag{G25E}
\]

### ID-G25O — universal odd-`c` `25`-scale, two norm terms

For `c=2k+1`,

\[
\boxed{
25\bigl(N(z)+3^{2k+1}+5^d\bigr)
=N(\pi^2z)+N(6(1+i)3^k)+3^{2k+1}+5^{d+2}.}
\tag{G25O}
\]

Together `(G25E)` and `(G25O)` cover both parities of `c`, but still land in
the enlarged two-norm class.  The parity split is an exponent state of a
chosen representation, not a state of the integer `n` itself.

## 2. Original-shape identities on thin subfamilies

These identities genuinely return to one norm term, but only after imposing a
special shape on the old norm component.

### ID-U9 — square-times-`5^d` norm component

For all `t,c,d>=0`,

\[
\boxed{
9\bigl(t^2 5^d+3^c+5^d\bigr)
=N((3t+2i)\pi^d)+3^{c+2}+5^{d+1}.}
\tag{U9}
\]

- **Domain:** norm component `S=t^2 5^d` only.
- **Coordinates:** expansion of `(3t+2i)pi^d` is integral; take absolute
  values.
- **Counterexample property:** does not transfer, because an arbitrary
  represented integer need not possess a representation with this norm
  shape.
- **Size of subfamily:** at most `O(sqrt(X) log X)` tagged values up to `X`,
  hence zero density.

### ID-U5 — diagonal thin family for even `c`

For all `t,k,d>=0`,

\[
\boxed{
5\bigl(10t^2+3^{2k}+5^d\bigr)
=(5t+3^k)^2+(5t-3^k)^2+3^{2k+1}+5^{d+1}.}
\tag{U5}
\]

The second coordinate can be replaced by its absolute value.

- **Domain:** `S=10t^2` and even `c`.
- **Status:** exact A303656 representation identity, but a thin subfamily.

### ID-U25E — square norm component, even `c`

For all `t,k,d>=0`,

\[
\boxed{
25\bigl(t^2+3^{2k}+5^d\bigr)
=(5t)^2+(4\cdot3^k)^2+3^{2k+2}+5^{d+2}.}
\tag{U25E}
\]

### ID-U25O — twice-a-square norm component, odd `c`

For all `t,k,d>=0`,

\[
\boxed{
25\bigl(2t^2+3^{2k+1}+5^d\bigr)
=(5t+6\cdot3^k)^2+(5t-6\cdot3^k)^2
 +3^{2k+1}+5^{d+2}.}
\tag{U25O}
\]

Both `U25` identities are exact and infinite, but neither normalizes an
arbitrary `S in S_2` to the required square shape.  No theorem was found that
every represented integer admits one of these forms.

## 3. Exact exponent-change identities

### ID-INC — tagged forward exponent recurrence

For all `r,s>=0`,

\[
N(z)+3^c+5^d
+3^c(3^r-1)+5^d(5^s-1)
=N(z)+3^{c+r}+5^{d+s}.
\tag{INC}
\]

- **Domain:** all tagged representations.
- **Coordinates/exponents:** unchanged norm; exponents remain nonnegative.
- **Counterexample transfer:** none.  The target increment depends on the
  witnessing pair `(c,d)`, and a smaller integer may be represented only by a
  different pair.
- **Payoff:** a tautological recurrence on tagged representations.

The increments themselves have exact norm criteria:

\[
3^{c+r}-3^c\in\mathcal S_2
\iff c\text{ is even and }3^r-1\in\mathcal S_2,
\tag{INC3}
\]

\[
5^{d+s}-5^d\in\mathcal S_2
\iff 5^s-1\in\mathcal S_2.
\tag{INC5}
\]

Even when an increment is a norm, adding it to an arbitrary old norm is not a
norm-preserving operation.

### ID-COLL28 — exact mixed-base shift collision

\[
3^3+5^0=27+1=28=3+25=3^1+5^2.
\tag{COLL28}
\]

Equivalently,

\[
3^1(3^2-1)=5^0(5^2-1)=24.
\]

- **Domain:** one shift value only.
- **Effect:** changes `(c,d)=(3,0)` to `(1,2)` without changing `n` or the norm
  component.
- **Descent:** none; `n` is unchanged, and the full active exponent domain is
  untouched.
- **Search note:** this was the only collision in the diagnostic box
  `0<=c,d<=30`, but that bounded absence is not used as a proof of global
  uniqueness.

## 4. Exact scalar coincidences on isolated shift fibers

If `K h(c,d)=h(C,D)` and `K in S_2`, then every tagged representation
`n=S+h(c,d)` gives

\[
Kn=KS+h(C,D),
\]

with `KS in S_2`.  The following individual identities are exact:

| scale `K` | source shift | target shift | exact equation |
|---:|---|---|---|
| 2 | `(0,0)` | `(1,0)` | `2(1+1)=3+1` |
| 2 | `(1,0)` | `(1,1)` | `2(3+1)=3+5` |
| 2 | `(2,1)` | `(1,2)` or `(3,0)` | `2(9+5)=28` |
| 4 | `(0,0)` | `(1,1)` | `4(1+1)=3+5` |
| 4 | `(1,1)` | `(3,1)` | `4(3+5)=27+5` |
| 4 | `(3,1)` | `(1,3)` | `4(27+5)=3+125` |
| 5 | `(0,0)` | `(2,0)` | `5(1+1)=9+1` |
| 8 | `(1,0)` | `(3,1)` | `8(3+1)=27+5` |
| 9 | `(2,1)` | `(0,3)` | `9(9+5)=1+125` |

The table is not claimed complete.  These are isolated fibers, not maps of
the entire shift set.  They therefore do not prove `R(n) => R(Kn)`.

## 5. Shift parity identity

For even `c`,

\[
3^c+5^d\in\mathcal S_2\iff d\text{ is even}.
\]

If both are even, the shift is visibly

\[
(3^{c/2})^2+(5^{d/2})^2.
\]

If `c` is even and `d` odd, the shift is `6 mod 8`, impossible for a sum of
two squares.  This is a genuine algebraic asymmetry, but replacing one shift
by a norm creates a sum of two norms and does not close A303656.

## 6. Nonlinear square completion

For any fixed target shift `h' in H` and any `K>=1`,

\[
G(n)=(Kn-h')^2+h'
\]

is automatically representable for every integer `n`, using norm component
`(Kn-h')^2`.  This is a nonlinear original-shape identity, but it is
strategically empty:

- its image is a sparse quadratic sequence;
- it maps every input, represented or not, to a represented output;
- no counterexample lies in its image;
- it supplies no inverse map from an arbitrary large counterexample.

Thus nonlinear completion alone is not a descent trigger.

## 7. Catalogue verdict

The strongest all-parameter identities are `(G9A)` and `(G9B)`, but they
land in a two-norm intermediate class.  The strongest identities retaining
the original one-norm shape are `(U9)`, `(U5)`, `(U25E)`, and `(U25O)`, but
their source norm components lie in thin algebraic subfamilies.  No identity
in the catalogue is active-domain complete or counterexample-preserving on
all represented source integers.
