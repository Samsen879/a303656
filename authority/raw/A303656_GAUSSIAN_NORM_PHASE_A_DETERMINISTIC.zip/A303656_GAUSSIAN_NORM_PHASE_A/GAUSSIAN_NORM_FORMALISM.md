# GAUSSIAN NORM FORMALISM

## 0. Scope and notation

Let

\[
\mathcal S_2=N_{\mathbf Z[i]/\mathbf Z}(\mathbf Z[i])
 =\{a^2+b^2:a,b\in\mathbf Z_{\ge 0}\},
\]

\[
h(c,d)=3^c+5^d,\qquad
\mathcal H=\{h(c,d):c,d\ge0\},
\]

and

\[
\mathcal R=\mathcal S_2+\mathcal H.
\]

Thus `n` is representable exactly when `n in R`; a counterexample is an
integer `n>1` outside `R`.  Put

\[
\pi=2+i,\qquad \bar\pi=2-i,
\qquad 5=\pi\bar\pi,
\qquad N(\pi)=5.
\]

The rational prime `3` is inert in `Z[i]`.  In particular, there is no
Gaussian integer of norm `3`, while `N(3)=9`.

All coordinate identities below are identities in `Z`.  If a displayed
coordinate is negative, replacing it by its absolute value preserves its
square, so the required `a,b>=0` convention causes no loss.

## 1. Brahmagupta–Fibonacci and the basic multipliers

For `z=a+bi` and `w=x+yi`,

\[
N(zw)=N(z)N(w),
\]

or in coordinates,

\[
(a^2+b^2)(x^2+y^2)
=(ax-by)^2+(ay+bx)^2.
\tag{BF}
\]

The multipliers relevant to this phase are

\[
\begin{aligned}
\pi(a+bi)&=(2a-b)+(a+2b)i,\\
\pi^2(a+bi)&=(3a-4b)+(4a+3b)i,\\
3(a+bi)&=3a+3bi,
\end{aligned}
\]

with norm scales `5`, `25`, and `9`, respectively.

The exact inverse divisibility conditions are

\[
\pi\mid a+bi\iff a\equiv2b\pmod5,
\]

\[
\bar\pi\mid a+bi\iff a\equiv-2b\pmod5,
\]

and, because `3` is inert,

\[
3\mid a+bi\iff a\equiv b\equiv0\pmod3.
\]

These conditions give finite local orientation states.  They do not by
themselves give a global counterexample state, because non-representability
as a norm is witnessed by an unbounded set of inert primes.

## 2. Fermat criterion and norm-scale invariance

For `m>0`, Fermat's two-square theorem gives

\[
m\in\mathcal S_2
\iff
v_q(m)\equiv0\pmod2
\quad\hbox{for every prime }q\equiv3\pmod4.
\tag{2SQ}
\]

### Lemma 2.1 — norm-scale invariance

If `K in S_2` and `K>0`, then for every `m>=0`,

\[
m\in\mathcal S_2\iff Km\in\mathcal S_2.
\tag{NSI}
\]

#### Proof

Every prime `q=3 mod 4` occurs in `K` to even valuation.  Multiplication by
`K` therefore leaves the parity of `v_q(m)` unchanged for every such `q`.
Apply `(2SQ)`.  The case `m=0` is immediate.  ∎

This is stronger than one-way multiplicative closure: multiplication by a
Gaussian norm preserves both norm membership and norm obstruction.

## 3. Quantifier-safe recurrence and descent

A tagged representation is a triple `(S,c,d)` satisfying

\[
n=S+h(c,d),\qquad S\in\mathcal S_2.
\]

A recurrence on integers, rather than on tagged representations, must work
for **every representation that may witness the source integer**.

### Lemma 3.1 — exact shift-embedding lift

Let `K in S_2`, `K>0`, and `C in Z`.  Suppose

\[
Kh+C\in\mathcal H\qquad\text{for every }h\in\mathcal H.
\tag{SHIFT-EMBED}
\]

Then

\[
m\in\mathcal R\Longrightarrow Km+C\in\mathcal R.
\tag{LIFT}
\]

Consequently, if `n=Km+C` is a counterexample and `m>1`, then `m` is a
counterexample.  When also `m<n`, the formula

\[
F(n)=\frac{n-C}{K}
\]

is a genuine counterexample-preserving descent on that residue class.

#### Proof

Write `m=S+h` with `S in S_2` and `h in H`.  By `(NSI)`, `KS in S_2`, and by
`(SHIFT-EMBED)`, `Kh+C in H`.  Hence

\[
Km+C=KS+(Kh+C)\in\mathcal R.
\]

The descent assertion is the contrapositive.  ∎

The quantifiers are load-bearing.  An identity valid only for one source
shift, one parity of `c`, or one shape of `S` proves only a tagged-subfamily
recurrence.  It does not prove `(LIFT)`.

## 4. Scalar residual formula

Take `K=N(alpha)` and try to send the exponents to `(C,D)`.  From

\[
K\bigl(N(z)+h(c,d)\bigr)
=N(\alpha z)+h(C,D)+E,
\]

one obtains the exact residual

\[
E=K h(c,d)-h(C,D).
\tag{RES}
\]

For coordinatewise shifts `C=c+r`, `D=d+s`, this becomes

\[
E_{K,r,s}(c,d)
=(K-3^r)3^c+(K-5^s)5^d.
\tag{RES-SHIFT}
\]

If `E=0`, norm multiplicativity gives an exact lift.  If `E!=0`, one must
prove

\[
K N(z)+E\in\mathcal S_2
\]

for every norm component allowed by the source representation.  The fact
that `E` may itself be a norm is insufficient, because `S_2` is not closed
under addition.

## 5. Finite scalar-repair obstruction

The following is the inherited finite-affine anti-lifting theorem specialized
to Gaussian norm scaling.

### Theorem 5.1 — finite target-menu obstruction

Fix `K>0`, a source shift `h in H`, an integer `C`, and finitely many target
shifts `h_1,...,h_t in H`.  Put

\[
e_j=Kh+C-h_j.
\]

If every `e_j` is nonzero, then there are arbitrarily large `S in S_2` such
that all integers

\[
KS+e_j
\]

are positive and outside `S_2`.

#### Proof

Apply the finite affine anti-lifting theorem to the maps

\[
S\longmapsto KS+e_j.
\]

For each nonzero offset, one chooses a private prime `q_j=3 mod 4` and uses
CRT to force exact valuation one, while simultaneously choosing `S` as a
sum of two squares.  ∎

### Exact scope

This theorem refutes a proposed **finite algebraic identity menu** whenever
none of its shift corrections is exact.  It does not prove that the target
integer has no unrelated representation using a shift outside the menu, and
therefore it is not a counterexample to A303656.

## 6. Gaussian affine rigidity

One might try to absorb `E` by replacing `alpha z` with an affine Gaussian
expression.  On any full-rank congruence state, this gives no extra freedom.

### Theorem 6.1 — Gaussian affine rigidity

Let `L` be a `2 x 2` integer matrix, `t in Z^2`, `K>0`, and `B in Z`.  Suppose
that on a full-rank lattice coset in `Z^2`,

\[
\|Lv+t\|^2=K\|v\|^2+B.
\tag{AFF}
\]

Then

\[
t=0,\qquad B=0,\qquad L^{\mathsf T}L=K I_2.
\]

Consequently, `L` is multiplication by a Gaussian integer of norm `K`, or
multiplication after complex conjugation, up to the usual unit choices.

#### Proof

The difference of the two sides of `(AFF)` is a polynomial of degree at most
two.  A polynomial vanishing on a full-rank lattice coset vanishes
identically.  Comparing quadratic, linear, and constant parts gives

\[
L^{\mathsf T}L=K I_2,
\qquad L^{\mathsf T}t=0,
\qquad \|t\|^2=B.
\]

The first identity makes `L` invertible over `R`, so `t=0`, hence `B=0`.
The two columns of `L` are orthogonal integer vectors of equal squared length
`K`; in dimension two the second is a quarter-turn of the first, with either
orientation.  This is precisely complex multiplication or conjugate complex
multiplication.  ∎

### Corollary 6.2

An affine Gaussian translation cannot absorb an exponent mismatch by an
identity valid on a full-rank finite congruence state.  Any such identity
reduces to pure norm scaling plus the exact shift equation

\[
h(C,D)=K h(c,d)+C_0.
\]

## 7. Rank obstruction to collapsing two norms

Natural `5`, `9`, and `25` scalings below produce a sum of two Gaussian
norms.  A fixed linear completion cannot collapse that sum to one norm.

### Theorem 7.1 — no finite linear two-square collapse

Let `K,L>0`.  There is no polynomial identity

\[
K(x^2+y^2)+Lt^2=A(x,y,t)^2+B(x,y,t)^2
\]

with `A,B` linear forms over `R`.  More strongly, no finite list of pairs of
linear forms can make one such equality hold for every integer triple
`(x,y,t)`.

#### Proof

The quadratic form on the left has rank three.  A sum of two squares of
linear forms has rank at most two, so no member of the list is an identity.
For a finite list, multiply the corresponding nonzero quadratic difference
polynomials.  A nonzero polynomial cannot vanish on all of `Z^3`; indeed it
cannot vanish on every sufficiently large point in an orthant.  Hence some
integer triple avoids every proposed formula.  ∎

The analogous four-variable statement rules out a finite linear identity
menu collapsing `N(u)+N(v)` to one Gaussian norm.  The theorem does not rule
out nonlinear representations on special subvarieties.

## 8. Sparsity obstruction to a complete digit recurrence

The shift set satisfies

\[
\#\{h\in\mathcal H:h\le X\}
\le (1+\lfloor\log_3 X\rfloor)(1+\lfloor\log_5 X\rfloor)
=O((\log X)^2).
\tag{SPARSE}
\]

### Theorem 8.1 — at most one exact digit branch

Let `K>=2`, and let `C_1,...,C_m` be pairwise distinct modulo `K`.  If

\[
K\mathcal H+C_j\subseteq\mathcal H
\qquad (1\le j\le m),
\tag{BRANCH}
\]

then `m<=1`.

#### Proof

Fix `h_0 in H`.  Iterating `(BRANCH)` along every word
`w=(j_0,...,j_{r-1})` gives

\[
h_w=K^r h_0+\sum_{\ell=0}^{r-1}K^\ell C_{j_\ell}\in\mathcal H.
\]

Distinct words give distinct integers: compare at the first differing base-
`K` digit, using that the offsets are distinct modulo `K`.  Thus there are
`m^r` elements of `H` of size `O(K^r)`.  By `(SPARSE)` this is `O(r^2)`,
which is impossible for `m>=2` and large `r`.  ∎

### Consequence

A complete base-`K` descent/closure scheme would need at least two residue
branches, and normally all `K` branches.  Exact norm-multiplicative shift
embeddings cannot supply them.  One isolated branch is not excluded, but it
cannot cover all sufficiently large integers by itself.

## 9. Mixed-base local asymmetry

The splitting of `5` and inertness of `3` create a real algebraic asymmetry.
For example,

\[
9\cdot5^d-5^{d+1}=4\cdot5^d=N(2\pi^d)
\]

for every `d`, while

\[
5\cdot3^c-3^{c+1}=2\cdot3^c
\]

is a norm exactly when `c` is even.  The asymmetry yields valid identities
in an enlarged two-norm class and thin original-shape subfamilies.  It does
not remove the nonadditivity barrier.

A useful exact parity fact is

\[
c\text{ even}\quad\Longrightarrow\quad
h(c,d)\in\mathcal S_2\iff d\text{ even}.
\tag{SHIFT-PARITY}
\]

For even `c,d`, write the shift as

\[
3^c+5^d=(3^{c/2})^2+(5^{d/2})^2.
\]

For even `c` and odd `d`, the shift is `6 mod 8`, which is not a sum of two
squares.

## 10. Finite Gaussian states and their limit

### Lemma 10.1 — `5`-adic blindness

For every `e>=1` and every residue `r mod 5^e`, the residue class contains
arbitrarily large members of `S_2` and arbitrarily large nonmembers of
`S_2`.

#### Proof

Choose a square root `tau` of `-1 mod 5^e`, lifted from `tau=2 mod 5`.
Solve

\[
x+\tau y\equiv r,\qquad x-\tau y\equiv1\pmod{5^e}.
\]

Then

\[
x^2+y^2\equiv r\pmod{5^e}.
\]

Varying one coordinate by multiples of
`5^e` gives arbitrarily large norms in the class.

For nonnorms, choose a prime `q=3 mod 4`, `q!=5`, and impose by CRT

\[
M\equiv r\pmod{5^e},\qquad M\equiv q\pmod{q^2}.
\]

Every sufficiently large solution has `v_q(M)=1`, hence is outside `S_2`.
∎

Thus states coming only from `pi`, `bar pi`, or powers of `5` cannot certify
the two-square predicate.  Adding any fixed finite set of inert-prime states
still leaves the previously identified need for a uniform finite witness set
and a bounded odd valuation depth.

## 11. Minimal-counterexample consequences in `Z[i]`

If `n_0` is a least counterexample, then the active remainders at shifts `2`
and `4` differ by `2`.  Therefore any common Gaussian divisor of all active
remainders divides `2` in `Z[i]`.  In particular:

- neither `pi=2+i` nor `bar pi` divides every active remainder;
- `3` does not divide every active remainder;
- no common `5`- or `9`-division descent exists;
- a possible common factor `1+i` when `n_0` is even does not help, because
  halving `(3^c+5^d)` does not preserve the shift set.

This is the Gaussian-integer refinement of the earlier no-common-square
result.
