# EXECUTIVE VERDICT

## Final decision

**NO PROMOTABLE ROUTE — SPECULATIVE WATCH**

**OEIS A303656: UNRESOLVED.**

## 1. 本轮回答的核心问题

本轮测试了 Gaussian norm multiplicativity、\(5=(2+i)(2-i)\) 的 split factorization、3 在 \(\mathbf Z[i]\) 中 inert、exponent changes，以及 nonlinear identities，是否能产生：

1. representability-preserving recurrence；
2. counterexample-preserving inverse map；
3. explicit descent；
4. finite algebraic-state reduction；
5. all-sufficiently-large closure theorem。

结论是：找到了数个严格、全参数、具有解释力的 identities 和 no-go theorems，但没有任何候选同时满足原问题的一项 norm 输出、integer-level contrapositive 和 sufficiently-large coverage。

## 2. 最强 positive result

### 2.1 exact shift-embedding trigger

若 \(K\in\mathcal S_2\)、\(K\ge2\)、\(C\in\mathbf Z\)，并且

\[
K\mathcal H+C\subseteq\mathcal H,
\qquad
\mathcal H=\{3^c+5^d:c,d\ge0\},
\]

则

\[
m\in\mathcal R\Longrightarrow Km+C\in\mathcal R,
\qquad
\mathcal R=\mathcal S_2+\mathcal H.
\]

因此对 residue class \(n\equiv C\pmod K\)，

\[
F(n)=\frac{n-C}{K}
\]

是真正的 counterexample-preserving descent，只要 \(1<F(n)<n\)。这是本轮隔离出的最干净 promotion trigger。

### 2.2 mixed-base asymmetry 的 universal identities

scale 9 给出全参数恒等式

\[
9\bigl(N(z)+3^c+5^d\bigr)
=N(3z)+N(2(2+i)^d)+3^{c+2}+5^{d+1},
\]

以及固定 \(d\) 的 companion identity。scale 25 可按 \(c\) parity 覆盖全部 exponent domain。

这些 identities 真实利用了“3 inert、5 split”的 asymmetry；但它们落入

\[
\mathcal S_2+\mathcal S_2+3^C+5^D,
\]

不是 A303656 的 one-norm class。

### 2.3 original-shape thin families

U9、U5、U25E、U25O 是 exact one-norm identities，且所有 coordinates/exponents 保持 integral/nonnegative（坐标取绝对值）。但 source norm component 必须是 \(t^25^d,10t^2,t^2,2t^2\) 等特殊形状。没有 theorem 保证 minimality 给出的 predecessor representation 属于这些 thin families。

## 3. 核心 no-go theorems

1. **finite scalar-repair obstruction:** 任意固定 finite nonzero residual menu 都被任意大的 old norms 同时击败；因此“multiplication + finite exponent repair”没有 universal closure。
2. **Gaussian affine rigidity:** 在 full-rank lattice state 上，\(\|Lv+t\|^2=K\|v\|^2+B\) 强制 \(t=B=0\) 与 \(L^TL=KI\)；affine translation 无法吸收 exponent mismatch。
3. **rank obstruction:** rank-3/4 的 two-norm quadratic form 不能由 finite linear two-square formulas 普遍 collapse 为 rank-2 form。
4. **shift sparsity obstruction:** 若 fixed scale \(K\) 有多个 distinct residue branches \(K\mathcal H+C_j\subseteq\mathcal H\)，迭代产生指数多 shifts，而 \(\mathcal H\cap[0,X]\) 仅有 \(O((\log X)^2)\)；故最多一个 branch。
5. **Gaussian common-divisor failure:** active remainders at shifts 2 and 4 相差 2；因此没有共同 \((2+i)\)、\((2-i)\) 或 3 factor，也没有 common 5/9 division descent。
6. **finite-state blindness:** 每个 residue mod \(5^e\) 同时含任意大的 norms 和 nonnorms；split-prime states 不能决定 \(\mathcal S_2\)。

## 4. 为什么不 promotion

| promotion gate | result |
|---|---|
| explicit \(F(n)<n\) preserving counterexamples | **未获得**；只隔离出 conditional trigger |
| representability closure covering all sufficiently large \(n\) | **未获得**；多 residue exact closure 被 sparsity 排除 |
| explicit finite algebraic-state reduction | **未获得**；local states 缺 uniform bad-prime/valuation certificate |
| universal-leverage core identity theorem | **部分获得但不足 promotion**；strongest identities land in two-norm class |

## 5. speculative watch 的精确含义

继续关注的不是更多 isolated identities，而是以下任一新 theorem：

- 对 \(\mathcal H\) 的全域或多-scale self-embedding；
- 对本问题 exponent-correlated two-norm sum 的 nonlinear one-norm collapse；
- every sufficiently large counterexample 的 uniform finite inert-prime certificate；
- 保证 predecessor representation 落入 U9/U25 thin norm shapes 的 normalization theorem。

在此之前，不建议扩大 symbolic search，不建议 long \(T(n)\) search，也不建议 Codex/Ultra 或 repository integration。
