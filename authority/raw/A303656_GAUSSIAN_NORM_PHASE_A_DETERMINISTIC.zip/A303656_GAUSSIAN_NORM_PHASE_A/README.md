# A303656 Gaussian-Norm Phase A Package

## Verdict

**NO PROMOTABLE ROUTE — SPECULATIVE WATCH**

**OEIS A303656: UNRESOLVED.**

## Package purpose

本包补全 Gaussian norm multiplicativity / factorization / exponent-change 路线的 Phase A 交付。它包括 formalism、identity catalogue、recurrence candidates、descent audit、explicit formula counterexamples、literature audit、no-go results、综合报告、machine-readable verdict、small exact checks 以及 deterministic ZIP 构建与校验工具。

## Required deliverables

- `EXECUTIVE_VERDICT.md`
- `GAUSSIAN_NORM_FORMALISM.md`
- `IDENTITY_CATALOGUE.md`
- `RECURRENCE_CANDIDATES.md`
- `DESCENT_AUDIT.md`
- `COUNTEREXAMPLES_TO_IDENTITIES.md`
- `LITERATURE_AUDIT.md`
- `NO_GO_RESULTS.md`
- `REPORT.md`
- `PROMOTION_VERDICT.json`

## Supporting reproducibility files

- `INPUT_PROVENANCE.json`
- `REPRODUCIBILITY.md`
- `PACKAGE_MANIFEST.json`
- `SHA256SUMS.txt`
- `VALIDATION_REPORT.txt`
- `scripts/exact_checks.py`
- `scripts/build_deterministic_zip.py`
- `scripts/validate_package.py`
- `results/exact_checks.json`

## Scope boundary

`exact_checks.py` only verifies closed-form identities on finite grids, factors explicit obstruction witnesses, and records bounded diagnostic searches. It does **not** perform a long `T(n)` search. Bounded absence is never promoted to proof.

No Codex, Codex Ultra, repository integration, Git operation, or production search was used.
