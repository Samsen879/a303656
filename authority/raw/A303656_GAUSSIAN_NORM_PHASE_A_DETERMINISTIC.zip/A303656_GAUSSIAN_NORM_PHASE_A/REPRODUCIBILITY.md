# REPRODUCIBILITY

## 1. Environment

本阶段使用网页端 GPT-5.6 Pro 的 container/Python reference environment。没有使用 Codex、Ultra、WSL repository 或 Git。

`results/exact_checks.json` 记录运行时 Python、SymPy 与 platform 信息。数学结论不依赖 bounded search 的 absence；formal proofs 位于 Markdown files。

## 2. Replay exact checks

在 package root 运行：

```bash
python scripts/exact_checks.py
```

脚本将重写：

```text
results/exact_checks.json
```

它验证：

- 6561 个 Brahmagupta–Fibonacci instances；
- G5/G9/G25 universal two-norm identities；
- U5/U9/U25 thin original-shape identities；
- explicit non-`S2` witnesses 的 exact factorizations；
- exponents up to 30 的 bounded shift collisions/scalar hits。

脚本不枚举 long integer intervals，也不判定 A303656 全局真伪。

## 3. Validate package

```bash
python scripts/validate_package.py --root .
```

validator 检查 required files、JSON parsing、verdict invariants、exact-check replay、internal SHA256、control characters 与核心文本标记。

## 4. Build deterministic ZIP

```bash
python scripts/build_deterministic_zip.py \
  --root . \
  --output ../A303656_GAUSSIAN_NORM_PHASE_A_DETERMINISTIC.zip
```

determinism rules：

- lexical path order；
- fixed timestamp `2000-01-01 00:00:00`；
- fixed Unix modes (`0644`, Python scripts `0755`)；
- empty ZIP comments/extras；
- UTF-8 names；
- DEFLATE level 9。

对同一 package byte tree 重复构建应得到相同 SHA256。

## 5. Integrity boundary

`SHA256SUMS.txt` 覆盖 package 内除其自身外的所有 files。外部 `.zip.sha256` 文件记录最终 archive digest，避免 circular self-hash。
