# DESCENT AUDIT

## 0. Descent standard

Assume, for audit purposes, that `n_0` is a least counterexample.  A promoted
map must be an explicit function `F` satisfying

\[
1<F(n)<n
\]

and

\[
T(n)=0\Longrightarrow T(F(n))=0
\tag{D}
\]

on every counterexample in its stated domain.  To reduce all counterexamples
to a finite range, the domains of finitely many such maps must cover every
sufficiently large counterexample.

The following do **not** establish `(D)`:

- transforming one selected representation of `F(n)` when another
  representation may use different exponents;
- proving an identity only on a proper norm subfamily;
- mapping into a problem with two norm summands;
- finding a recurrence on tagged tuples rather than on integers;
- checking that a proposed map works on a finite sample.

## 1. The exact norm-multiplicative descent trigger

Let `K in S_2`, `K>=2`, and `C in Z`.  If

\[
K\mathcal H+C\subseteq\mathcal H,
\tag{T1}
\]

then every representation of `m` lifts to one of `Km+C`, and therefore

\[
F(n)=\frac{n-C}{K}
\tag{F1}
\]

preserves counterexamples whenever `n=C mod K`, `F(n)>1`, and `F(n)<n`.

This is a valid explicit descent theorem **conditional on `(T1)`**.  It is the
cleanest Gaussian trigger because norm-scale invariance is exact in both
directions.

### Why the trigger did not fire

No global affine self-embedding `(T1)` of the mixed shift set was obtained.
The exact equalities found in the small identity search act on isolated shift
fibers.  They do not handle all possible exponent pairs in a representation
of `F(n)`.

## 2. Complete residue closure is impossible for exact branches at one scale

Suppose offsets `C_1,...,C_m` are distinct modulo `K` and every branch
satisfies

\[
K\mathcal H+C_j\subseteq\mathcal H.
\]

Iteration from one shift creates `m^r` distinct shifts of size `O(K^r)`, while
`H` has only `O(r^2)` elements up to that size.  Hence `m<=1`.

A base-`K` descent covering every sufficiently large integer would need at
least two residue branches, normally `K` of them.  Therefore exact
norm-multiplicative digit descent at a fixed scale is ruled out.

This theorem leaves open a single isolated branch, branches with different
scales, or a genuinely nonlinear map.  None of those produced complete
coverage.

## 3. Scale `5`: multiplication by `pi=2+i`

From a tagged representation,

\[
5n=N(\pi z)+5\cdot3^c+5^{d+1}.
\]

The nonnegative coordinatewise choices for the `3` exponent are `c` and
`c+1`, with residuals

\[
4\cdot3^c,
\qquad
2\cdot3^c.
\]

### Audit by `c` parity

- If `c` is odd, both residuals have `3` to odd valuation and are not norms.
- If `c` is even, both residuals are norms, but adding either to
  `N(pi z)` need not yield one norm.
- The pair `S=2,c=0` defeats both one-norm repairs:

\[
5S+4=14\notin\mathcal S_2,
\qquad
5S+2=12\notin\mathcal S_2.
\]

### Exact isolated branch

The shift `2` satisfies

\[
5\cdot2=10=3^2+5^0.
\]

Thus every representation using `(c,d)=(0,0)` lifts under `n->5n`.
Minimality cannot force a predecessor representation to use that shift.

### Verdict

No map `F(n)=n/5` or `(n-C)/5` was proved on a complete counterexample domain.

## 4. Scale `9`: multiplication by inert `3`

The exact universal identity is

\[
9n=N(3z)+N(2\pi^d)+3^{c+2}+5^{d+1}.
\]

A second choice keeps `d` fixed and uses a norm of size `8*5^d`.

### Strength

- Works for every `z,c,d`.
- Handles the full active exponent domain.
- Exhibits the strongest mixed-base asymmetry: the inert scale `9` shifts
  `3^c` exactly, while the split base `5` leaves a norm residual.

### Fatal defect

The target has two norm terms.  They cannot be collapsed by additivity, and
no finite linear Gaussian formula can collapse them universally.  The
complete natural residual menu fails already at `S=20,d=0`:

\[
9S+4=184\notin\mathcal S_2,
\qquad
9S+8=188\notin\mathcal S_2.
\]

The finite scalar-repair theorem supplies arbitrarily large failures for any
fixed nonzero finite menu.

### Exact isolated branch

\[
9(3^2+5^1)=9\cdot14=126=3^0+5^3.
\]

This lifts representations using shift `14`, not every representation.

### Verdict

No counterexample-preserving map `F(n)=n/9` was obtained.

## 5. Scale `25`: parity-complete residual norms

Multiplication by `pi^2=3+4i` gives norm scale `25` and shifts `d` by `2`.

- For even `c`, move `c` to `c+2`; the residual is `16*3^c`, a norm.
- For odd `c`, keep `c`; the residual is `24*3^c`, a norm.

This is a finite two-state identity on tagged representations.

### Why it still fails

The residual norm must be added to `N(pi^2 z)`.  For `c=0,S=8`, all three
nonnegative coordinatewise choices `r=0,1,2` fail:

\[
224,\ 222,\ 216\notin\mathcal S_2.
\]

Parity of `c` is also not determined by `n`; `n=8` has valid
representations of both parities.

### Verdict

A parity-complete algebraic state was found, but it is a state of the chosen
representation and lands in the wrong two-norm class.  It is not a finite
counterexample state reduction.

## 6. Division by Gaussian factors

### Division by `pi`

If `z=a+bi` and `a=2b mod 5`, then

\[
N(z/\pi)=N(z)/5.
\]

If `a=-2b mod 5`, division by `bar pi` works instead.  Thus every norm
divisible by `5` can be divided by one of the two conjugate factors.

### Division by `3`

Since `3` is inert, a norm divisible by `3` is divisible by `9`, and its
Gaussian representative is divisible by `3`.

### Minimal-counterexample audit

A counterexample has no Gaussian representative of its active remainders to
divide.  Representations of smaller integers supplied by minimality may have
divisible norm components, but converting their quotients back to `n_0`
again requires a shift embedding.

Moreover,

\[
(n_0-2)-(n_0-4)=2.
\]

Any common Gaussian divisor of all active remainders divides `2`.  Hence
neither `pi`, `bar pi`, nor `3` divides all active remainders.  There is no
common `5`- or `9`-division descent.

## 7. The ramified factor `1+i` and parity

All shifts are even.  If a represented integer `m` is even, its norm
component is even and any representing Gaussian integer is divisible by
`1+i`, so the norm can be halved.

The resulting equation contains

\[
\frac{3^c+5^d}{2},
\]

which is generally not another shift.  Exact examples such as

\[
\frac{3+1}{2}=2=3^0+5^0
\]

occur only on isolated fibers.  The prior finite affine-repair obstruction
and the sparse shift count prevent this observation from becoming a complete
binary digit recurrence.

## 8. Minimality plus exponent increments

For a fixed decrement `Delta`, minimality represents `n_0-Delta` but does not
control the witnessing `(c,d)`.  The exact exponent increment

\[
3^c(3^r-1)+5^d(5^s-1)
\]

therefore cannot be chosen in advance to equal `Delta` for whatever
representation minimality supplies.

The collision

\[
3^3+5^0=3^1+5^2
\]

only changes the tag of one shift and leaves the integer unchanged.  It does
not produce `F(n)<n`.

## 9. Thin one-norm recurrences

The identities `U9`, `U5`, `U25E`, and `U25O` yield exact original-shape
representations after scaling.  Their source norm components must be,
respectively,

\[
t^2 5^d,\quad 10t^2,\quad t^2,\quad 2t^2.
\]

For descent, one would need a theorem that every representation of every
predecessor, or at least one guaranteed representation of every predecessor,
has one of these shapes.  No such theorem was proved or located.  Minimality
alone gives no norm-shape control.

## 10. Affine and nonlinear completion

### Affine Gaussian completion

If `z -> Lz+t` is required to turn the scaled norm and exponent residual into
one norm on a full-rank congruence state, Gaussian affine rigidity forces
`t=0` and `L^T L=K I`.  The proposal reduces to exact shift scaling.

### Nonlinear square completion

Maps such as

\[
n\mapsto(Kn-h')^2+h'
\]

are represented for every input.  Their images are sparse and contain no
counterexamples, so they cannot take an arbitrary counterexample to a
smaller one.  More elaborate representation-dependent nonlinear formulas
have the same quantifier problem unless they become functions of `n` alone
and cover all large `n`.

## 11. Finite algebraic states

Fixed powers of `pi`, `bar pi`, `3`, and finitely many inert primes give a
finite exponent-state system.  This is exact local algebra, but it is not a
finite global obstruction system:

- `5`-adic states contain infinitely many norms and nonnorms in every residue
  class;
- a fixed finite inert-prime set misses possible odd-valuation witnesses;
- valuation depth must be bounded to transfer exact odd parity;
- the resulting missing statement is the already identified uniform
  certificate trigger `CRW(Q,E)`.

Gaussian factorization refines the local states but does not supply the
uniform prime/valuation bound.

## 12. Final descent decision

No unconditional map `F(n)<n` preserving the counterexample property was
obtained.  The precise positive trigger `(T1)` was isolated, and the natural
way to turn it into an all-residue finite recurrence was ruled out by shift
sparsity.  Every surviving identity is either:

- confined to a thin tagged subfamily;
- valued in an enlarged two-norm class;
- dependent on a representation state not determined by `n`;
- or too sparse to cover all sufficiently large integers.

Therefore the explicit-descent promotion gate is not met.
