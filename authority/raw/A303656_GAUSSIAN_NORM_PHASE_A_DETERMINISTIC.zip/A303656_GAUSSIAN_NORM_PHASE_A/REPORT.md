# A303656 GAUSSIAN-NORM ALGEBRAIC RECURRENCE AND DESCENT TRIGGER HUNT — PHASE A

## 0. 结论

**NO PROMOTABLE ROUTE — SPECULATIVE WATCH**

**OEIS A303656: UNRESOLVED.**

本轮得到了一组可复用的 exact lemmas、universal identities、thin-family recurrences 与 route-specific no-go theorems。它们澄清了 Gaussian route 的真实能力边界，但没有产生：

- explicit counterexample-preserving map \(F(n)<n\)；
- 覆盖所有 sufficiently large integers 的 representability closure；
- explicit finite algebraic-state reduction；
- 保持 A303656 one-norm output shape 的全域 recurrence。

## 1. 问题与 formal setup

定义

\[
\mathcal S_2=N_{\mathbf Z[i]/\mathbf Z}(\mathbf Z[i])
=\{a^2+b^2:a,b\in\mathbf Z_{\ge0}\},
\]

\[
h(c,d)=3^c+5^d,
\qquad
\mathcal H=\{h(c,d):c,d\ge0\},
\]

\[
\mathcal R=\mathcal S_2+\mathcal H.
\]

A303656 conjecture 等价于每个 \(n>1\) 都属于 \(\mathcal R\)。

在 \(\mathbf Z[i]\) 中

\[
5=(2+i)(2-i),
\qquad
N(2+i)=5,
\]

而 3 inert，故不存在 norm 3，且 \(N(3)=9\)。这构成 mixed-base asymmetry：base 5 可通过 Gaussian factor 线性放大，base 3 只能通过 rational Gaussian integer 3 以 norm scale 9 放大。

## 2. 研究边界与方法

本轮严格遵守已冻结 no-go：

- generic finite affine repair 不足；
- simple common-square descent 不足；
- uniform termwise mixed-base scaling 只有 trivial scale；
- minimality transfer 不能自动成立。

执行内容仅包括：

- symbolic derivation；
- Fermat two-square criterion；
- Gaussian divisibility 与 quadratic-form rank analysis；
- small deterministic exact identity checks；
- bounded diagnostic search for shift coincidences；
- primary-source literature crosswalk。

没有运行 long \(T(n)\) interval search，没有使用 Codex、Ultra 或 repository integration。

## 3. Core Lemma A：norm-scale invariance

### Lemma

若 \(K\in\mathcal S_2\)，则对每个 \(m\ge0\)，

\[
m\in\mathcal S_2
\iff
Km\in\mathcal S_2.
\]

### Proof

Fermat two-square criterion 说：\(m\in\mathcal S_2\) 当且仅当每个 \(q\equiv3\pmod4\) 在 \(m\) 中的 valuation 为偶数。因为 \(K\in\mathcal S_2\)，所有这类 \(q\) 在 \(K\) 中 valuation 也是偶数；乘以 \(K\) 不改变 valuation parity。∎

### Importance

这是 Gaussian route 的双向核心：norm scale 不仅 preserving representability，也 preserving norm obstruction。真正困难不在 norm component，而在 mixed shift set \(\mathcal H\)。

## 4. Core Lemma B：exact shift-embedding trigger

### Lemma

设 \(K\in\mathcal S_2\)、\(K>0\)、\(C\in\mathbf Z\)。若

\[
K\mathcal H+C\subseteq\mathcal H,
\tag{SE}
\]

则

\[
m\in\mathcal R
\Longrightarrow
Km+C\in\mathcal R.
\]

于是若 \(n=Km+C\) 是 counterexample，且 \(1<(n-C)/K<n\)，则

\[
F(n)=\frac{n-C}{K}
\]

也是 counterexample。

### Proof

写 \(m=S+h\)，其中 \(S\in\mathcal S_2,h\in\mathcal H\)。由 norm-scale invariance，\(KS\in\mathcal S_2\)；由 `(SE)`，\(Kh+C\in\mathcal H\)。所以 \(Km+C\in\mathcal R\)。取 contrapositive 即得 descent。∎

### Audit

该 lemma 完全满足 counterexample transfer 的量词要求，因为它作用于 predecessor 的 **每一个** possible source shift，而不是只作用于 chosen representation。

### Result

本轮没有证明任何 nontrivial global `(SE)`。bounded search 找到若干 isolated shift fibers，但它们不满足全域 inclusion。

## 5. Core Theorem C：fixed-scale multi-branch exact closure 不可能

### Theorem

设 \(K\ge2\)，\(C_1,\dots,C_m\) 模 \(K\) 两两不同，且对每个 \(j\)，

\[
K\mathcal H+C_j\subseteq\mathcal H.
\]

则 \(m\le1\)。

### Proof

固定 \(h_0\in\mathcal H\)。沿任意长度 \(r\) 的 branch word 迭代，得到

\[
h_w=K^r h_0+\sum_{\ell=0}^{r-1}K^\ell C_{j_\ell}\in\mathcal H.
\]

由于 offsets 模 \(K\) 不同，不同 words 给出不同整数。故大小 \(O(K^r)\) 内至少有 \(m^r\) 个 shifts。另一方面

\[
\#\{3^c+5^d\le X\}
\le(1+\lfloor\log_3X\rfloor)(1+\lfloor\log_5X\rfloor)
=O((\log X)^2),
\]

在 \(X=O(K^r)\) 时只有 \(O(r^2)\) 个。若 \(m\ge2\) 则矛盾。∎

### Consequence

一个 fixed scale 的 exact digit recurrence 不可能用两个或更多 residue branches 覆盖所有 sufficiently large integers。该 theorem 不排除单 branch 或 mixed scales，但本轮未找到可把它们组合成 complete cover 的机制。

## 6. Core Theorem D：Gaussian affine rigidity

### Theorem

设 \(L\in M_2(\mathbf Z)\)、\(t\in\mathbf Z^2\)、\(K>0\)、\(B\in\mathbf Z\)。若在一个 full-rank lattice coset 上

\[
\|Lv+t\|^2=K\|v\|^2+B,
\]

则

\[
t=0,
\qquad
B=0,
\qquad
L^{\mathsf T}L=KI_2.
\]

因此 \(L\) 只能是 Gaussian multiplication 或与 conjugation 组合的 multiplication。

### Proof sketch

两边之差是 degree-2 polynomial。它在 full-rank lattice coset 上恒为零，故 polynomial 恒等为零。比较 quadratic、linear、constant coefficients：

\[
L^TL=KI,
\quad
L^Tt=0,
\quad
\|t\|^2=B.
\]

第一式使 \(L\) 可逆，故 \(t=0,B=0\)。∎

### Consequence

在 full-dimensional finite congruence state 上，affine translation 不能吸收 exponent mismatch。任何这种 proposal 都退化为 pure norm scaling 加 exact shift equation。

## 7. Core Theorem E：two-norm linear collapse 的 rank obstruction

若尝试

\[
K(x^2+y^2)+Lt^2=A(x,y,t)^2+B(x,y,t)^2
\]

且 \(A,B\) 为 linear forms，则左侧 rank 3，右侧 rank 至多 2，不可能恒等。有限 formula menu 也不能覆盖所有 integer triples，因为有限个非零 polynomial differences 的乘积不能在 \(\mathbf Z^3\) 上恒为零。

四变量版本排除 finite linear menu 对 \(N(u)+N(v)\) 的 universal collapse。此 theorem 不排除 lower-dimensional thin subvarieties；本轮确实找到若干此类 exact identities。

## 8. Universal identities：真正的 mixed-base asymmetry

令 \(\pi=2+i\)、\(z=a+bi\)。

### 8.1 scale 9，全参数，two-norm output

\[
9\bigl(N(z)+3^c+5^d\bigr)
=N(3z)+N(2\pi^d)+3^{c+2}+5^{d+1}.
\tag{G9A}
\]

因为

\[
N(2\pi^d)=4\cdot5^d,
\qquad
9\cdot5^d=4\cdot5^d+5^{d+1}.
\]

另有

\[
9\bigl(N(z)+3^c+5^d\bigr)
=N(3z)+N(2(1+i)\pi^d)+3^{c+2}+5^d.
\tag{G9B}
\]

两式对所有 \(z,c,d\) 成立，active exponent domain 完整。但 target 含两个 independent norms。

### 8.2 scale 5，even-\(c\) two-norm identity

对 \(c=2k\)，

\[
5\bigl(N(z)+3^{2k}+5^d\bigr)
=N(\pi z)+N((1+i)3^k)+3^{2k+1}+5^{d+1}.
\tag{G5}
\]

odd \(c\) 时 residual \(2\cdot3^c\) 含 inert prime 3 的奇 valuation，故不为 norm。

### 8.3 scale 25，parity-complete two-state identities

若 \(c=2k\)，

\[
25\bigl(N(z)+3^{2k}+5^d\bigr)
=N(\pi^2z)+N(4\cdot3^k)+3^{2k+2}+5^{d+2}.
\tag{G25E}
\]

若 \(c=2k+1\)，

\[
25\bigl(N(z)+3^{2k+1}+5^d\bigr)
=N(\pi^2z)+N(6(1+i)3^k)+3^{2k+1}+5^{d+2}.
\tag{G25O}
\]

它们覆盖全部 \(c\)-parity，但 state 属于 chosen representation；例如 \(n=8\) 同时有 even-\(c\) 与 odd-\(c\) representations。

## 9. Exact original-shape identities on thin subfamilies

### U9

\[
9\bigl(t^25^d+3^c+5^d\bigr)
=N((3t+2i)\pi^d)+3^{c+2}+5^{d+1}.
\]

### U5

\[
5\bigl(10t^2+3^{2k}+5^d\bigr)
=(5t+3^k)^2+(5t-3^k)^2+3^{2k+1}+5^{d+1}.
\]

### U25-even

\[
25\bigl(t^2+3^{2k}+5^d\bigr)
=(5t)^2+(4\cdot3^k)^2+3^{2k+2}+5^{d+2}.
\]

### U25-odd

\[
25\bigl(2t^2+3^{2k+1}+5^d\bigr)
=(5t+6\cdot3^k)^2+(5t-6\cdot3^k)^2
+3^{2k+1}+5^{d+2}.
\]

所有 identities 对标示参数全域成立；coordinates 可取绝对值，故保持 nonnegative；exponents 也保持 nonnegative。

### Fatal limitation

source norm component 被限制为特殊 shapes。相关 tagged values up to \(X\) 至多 \(O(\sqrt X(\log X)^2)\)，为 zero density。minimality 只保证 predecessor 有某个 representation，不保证其 norm shape 属于这些 families。

## 10. Exponent changes

对任意 \(r,s\ge0\)，

\[
N(z)+3^c+5^d
+3^c(3^r-1)+5^d(5^s-1)
=N(z)+3^{c+r}+5^{d+s}.
\]

这是 tagged tautology，不是 integer-level recurrence。increments 的精确 norm criteria 为

\[
3^{c+r}-3^c\in\mathcal S_2
\iff c\text{ even and }3^r-1\in\mathcal S_2,
\]

\[
5^{d+s}-5^d\in\mathcal S_2
\iff5^s-1\in\mathcal S_2.
\]

即使 increment 是 norm，也不能与 arbitrary old norm 相加后仍为 norm。

唯一在 diagnostic box \(0\le c,d\le30\) 找到的 shift collision 是

\[
3^3+5^0=3^1+5^2=28.
\]

这只在固定 \(n\) 上换 tag，不产生 descent；bounded uniqueness 未被当作 theorem。

## 11. Gaussian divisibility audit

### 11.1 split prime 5

\[
\pi\mid a+bi
\iff a\equiv2b\pmod5,
\]

\[
\bar\pi\mid a+bi
\iff a\equiv-2b\pmod5.
\]

若 \(5\mid N(z)\)，至少一种 orientation 可除以 \(\pi\) 或 \(\bar\pi\)。

### 11.2 inert prime 3

\[
3\mid a+bi
\iff a\equiv b\equiv0\pmod3.
\]

若 \(3\mid N(z)\)，则实际上 \(9\mid N(z)\)，且 Gaussian representative 可除以 3。

### 11.3 为什么 division 不给 descent

counterexample 本身没有 active Gaussian representative 可除。minimality 给出的 smaller integer representation 可以有可除 norm component，但 lift 回 target 仍需要全域 shift embedding。

此外 active shifts 2 与 4 的 remainders 相差 2，故不存在共同 \(\pi,\bar\pi,3\) divisor。common 5/9 descent 被排除。

## 12. Finite-state audit

### 12.1 5-adic blindness

对每个 \(e\ge1\) 和每个 \(r\pmod{5^e}\)，该 residue class 同时含任意大的 \(\mathcal S_2\) members 与任意大的 nonmembers。

因此 split-prime states 不能决定 norm membership。

### 12.2 finite inert-prime sets

固定有限 inert-prime set 与 bounded valuations 后，当然可构造 finite state machine；但未证明 every counterexample remainder 的 odd witness 都落在该 fixed set 内。missing theorem 正是 uniform certificate trigger `CRW(Q,E)`，而不是 state enumeration 本身。

## 13. Explicit failures

以下数字不在 \(\mathcal S_2\)，并分别击败自然 repair menus：

- \(1+2=3\)：\(\mathcal S_2\) 不 additive；
- scale 5: \(14=2\cdot7\)、\(12=2^2\cdot3\)；
- scale 9: \(184=2^3\cdot23\)、\(188=2^2\cdot47\)；
- scale 25: \(224=2^5\cdot7\)、\(222=2\cdot3\cdot37\)、\(216=2^3\cdot3^3\)。

这些是 proposed identities 的 counterexamples，不是 A303656 的 counterexamples。

finite scalar-repair theorem 把这种 failure 从小例升级为：对任意 fixed finite nonzero menu，存在任意大的 old norm component 同时击败全部 candidates。

## 14. Literature audit synthesis

最接近的 descent precedent 是 Crocker 2008 的 same-base two-power setting；其 homogeneous scaling 依赖两个 power terms 共享 base。ESS/Bugeaud–Győry 的 multiplicative-group/S-unit theorems要求 fixed finite-rank group 或 fixed \(S\)；它们不能从 moving A303656 remainders 中自动产生 uniform prime support。Bajpai 的 effective norm-form theory解决 fixed norm-form equation classes，不给 additive universal coverage。Primitive-divisor theorems不保证 prime \(3\bmod4\)、odd valuation 或 simultaneous active-pair coverage。Presburger-with-powers decidability不含 quadratic norm predicate；two-square characteristic sequence 的 non-morphicity则否定最简单的 fixed automaton route。

没有审计 source 提供 exact shift embedding、one-norm collapse、counterexample descent 或 finite Gaussian-state reduction。

## 15. Promotion matrix

| candidate | all parameters? | original one-norm shape? | integer-level counterexample transfer? | sufficiently-large coverage? | result |
|---|---:|---:|---:|---:|---|
| exact shift embedding | conditional YES | YES | YES | not proved | trigger only |
| G9A/G9B | YES | NO | NO | universal only in enlarged class | intermediate identity |
| G5 | even \(c\) | NO | NO | incomplete | reject |
| G25E/G25O | parity-complete | NO | NO | representation-state only | reject |
| U9/U5/U25 | thin subfamilies | YES | NO | zero-density tagged families | watch only |
| Gaussian division | local | potentially | NO | no common divisor | reject |
| finite Gaussian states | fixed local data | N/A | conditional | no uniform witness bound | inherited trigger only |
| nonlinear square completion | all inputs | YES | NO | sparse image, no counterexamples | strategically empty |

## 16. Final referee decision

Promotion requires至少满足以下之一：

1. explicit \(F(n)<n\) preserving counterexamples；
2. representability closure covering all sufficiently large \(n\)；
3. explicit finite algebraic-state reduction；
4. 一个明显具有 universal leverage 的核心 identity theorem。

本轮 core lemmas 具有 universal no-go leverage，但没有把 original problem 降为 finite verification，也没有给出 all-large closure。strongest positive identities 均有 one-norm/additivity 或 thin-domain defect。

因此最终判定为：

**NO PROMOTABLE ROUTE — SPECULATIVE WATCH**

**OEIS A303656: UNRESOLVED.**
