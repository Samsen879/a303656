# RECURRENCE CANDIDATES

## 0. Required logical form

Let `R(n)` denote A303656 representability.  A recurrence useful for descent
must have the integer-level form

\[
R(m)\Longrightarrow R(G(m))
\tag{QSAFE}
\]

for **every** representation of `m`, or by another argument independent of a
chosen representation.  Then

\[
\neg R(G(m))\Longrightarrow\neg R(m)
\]

is valid.  To obtain an explicit descent for every sufficiently large
counterexample, the images of the allowed `G` must cover every sufficiently
large integer, with a computable predecessor `m<G(m)`.

An identity that starts with a selected tuple `(a,b,c,d)` but changes the
target integer when a different tuple is selected is not `(QSAFE)`.

## 1. Candidate scorecard

| ID | candidate | exact domain | integer-level recurrence? | counterexample inverse? | all-large coverage? | verdict |
|---|---|---|---|---|---|---|
| RC-1 | exact norm-scale shift embedding `h -> Kh+C` | would need all `h in H` | YES if embedding proved | YES on `n=C mod K` | needs several branches; sparsity forbids two exact branches at one scale | trigger theorem only; not found |
| RC-2 | scale `9`, move `c->c+2`, `d->d` or `d+1` | all tagged representations | only into two-norm class | NO for A303656 | NO | valid weaker recurrence |
| RC-3 | scale `5`, parity of `c` | even `c` for natural residual norms | NO | NO | NO | incomplete state and nonadditivity |
| RC-4 | scale `25`, two parity states | all `c` as tagged states | still two norms | NO | NO | complete parity split, wrong target class |
| RC-5 | `U9/U5/U25` one-norm identities | thin norm shapes | only for tagged subfamilies | NO | zero-density source families | watch only |
| RC-6 | affine Gaussian completion `Lz+t` | proposed finite congruence states | rigidity reduces to exact scaling | only if RC-1 holds | NO evidence | formally closed |
| RC-7 | divide by `pi`, `bar pi`, or `3` | representations with corresponding divisibility | representation-specific | NO | NO | no common divisor of active remainders |
| RC-8 | exponent increment recurrence | all tagged tuples | target depends on `(c,d)` | NO | sparse rays/grid only | identity, no descent |
| RC-9 | nonlinear square completion | all integers | trivially maps all inputs to represented outputs | no arbitrary target inverse | sparse quadratic image | strategically empty |
| RC-10 | finite Gaussian residue automaton | fixed modulus/prime set only | pointwise after certificate | conditional only | no uniform certificate | folds back to prior `CRW(Q,E)` gap |

## 2. RC-1 — exact norm-scale shift embedding

### Proposed mechanism

Take `K in S_2`, `K>=2`, and an offset `C`.  If

\[
K\mathcal H+C\subseteq\mathcal H,
\tag{E1}
\]

then

\[
R(m)\Longrightarrow R(Km+C).
\]

For a counterexample `n=Km+C`, this gives

\[
F(n)=\frac{n-C}{K}<n
\]

provided `F(n)>1`.

### Audit

- **All parameters:** `(E1)` must hold for every source shift because
  minimality does not select the shift used to represent `m`.
- **Integrality:** automatic on `n=C mod K`.
- **Norm:** `K S` is a norm and preserves nonnorm status in both directions.
- **Active exponents:** complete only if `(E1)` is global.
- **Coverage:** one branch covers one residue class.  A complete base-`K`
  descent needs at least two residue branches.

### Formal obstruction

If two offsets are distinct modulo `K` and both satisfy `(E1)`, iteration
would place exponentially many integers of size `O(K^r)` in the shift set,
contradicting its `O(r^2)` counting function.  Thus an exact digit closure is
impossible at a fixed scale.

### Status

No global embedding `(E1)` was found.  Small exact equalities such as

\[
5(3^0+5^0)=3^2+5^0
\]

and

\[
9(3^2+5^1)=3^0+5^3
\]

hold on one shift fiber only.

## 3. RC-2 — the universal `9` recurrence

Multiplying by `3` in `Z[i]` gives norm scale `9` and changes `3^c` exactly to
`3^{c+2}`.  The remaining `5` term has two nonnegative natural choices:

\[
9\cdot5^d-5^{d+1}=4\cdot5^d\in\mathcal S_2,
\]

\[
9\cdot5^d-5^d=8\cdot5^d\in\mathcal S_2.
\]

Hence every tagged representation satisfies the two-norm identities `G9A`
and `G9B`.

### Why it does not close to one norm

`S_2` is not additive.  Explicitly,

\[
9\cdot2+4=22=2\cdot11\notin\mathcal S_2.
\]

Even allowing both natural exponent choices fails on one norm component:

\[
S=20\in\mathcal S_2,
\]

\[
9S+4=184=2^3\cdot23\notin\mathcal S_2,
\]

\[
9S+8=188=2^2\cdot47\notin\mathcal S_2.
\]

The finite scalar-repair theorem upgrades this from an isolated diagnostic:
for any fixed finite nonzero residual menu, arbitrarily large norm components
can be forced to defeat the whole menu.

### Exact scope

This refutes the proposed formula family, not semantic closure
`R(n)=>R(9n)` by some unrelated representation.  No proof of that semantic
closure was obtained.

## 4. RC-3 — `5` scaling and parity of `c`

The exact residuals with nonnegative coordinatewise choices are

\[
5\cdot3^c-3^c=4\cdot3^c,
\]

\[
5\cdot3^c-3^{c+1}=2\cdot3^c.
\]

Both are norms exactly when `c` is even.  This gives the universal even-`c`
two-norm identity `G5`.

### Complete natural menu failure

For `c=0` and `S=2`, the two one-norm residual candidates are

\[
5S+4=14=2\cdot7\notin\mathcal S_2,
\]

\[
5S+2=12=2^2\cdot3\notin\mathcal S_2.
\]

For odd `c`, the residual itself already carries `3` to odd valuation.  Thus
parity creates a real asymmetry but not a recurrence.

### State defect

Parity of `c` belongs to a representation, not to `n`.  For example,

\[
8=1^2+1^2+3^0+5^1
  =2^2+0^2+3^1+5^0.
\]

The same integer has representations of both `c` parities.

## 5. RC-4 — `25` scaling and a two-state parity split

The scale `25=N(pi^2)` shifts `d` to `d+2`.  For `c=2k`, use

\[
25\cdot3^c-3^{c+2}=16\cdot3^c\in\mathcal S_2.
\]

For `c=2k+1`, keep `c` fixed and use

\[
25\cdot3^c-3^c=24\cdot3^c\in\mathcal S_2.
\]

This covers both parity states in the enlarged two-norm class.

### One-norm menu failure

For `c=0`, `S=8`, and the complete nonnegative coordinatewise choices
`r=0,1,2`, one gets

\[
25S+24=224=2^5\cdot7,
\]

\[
25S+22=222=2\cdot3\cdot37,
\]

\[
25S+16=216=2^3\cdot3^3.
\]

All three are outside `S_2`.

The parity split is therefore not a finite-state closure theorem.

## 6. RC-5 — thin original-shape recurrences

The exact identities `U9`, `U5`, `U25E`, and `U25O` have the desired output
shape.  Their source norm components are respectively

\[
t^2 5^d,\qquad 10t^2,\qquad t^2,\qquad 2t^2.
\]

### Audit

- **All parameters within subfamily:** YES.
- **Coordinates:** integral; absolute values restore nonnegativity.
- **Exponents:** all nonnegative.
- **Counterexample inverse:** NO.  A smaller represented predecessor may have
  no representation in the required norm subfamily.
- **Coverage:** the tagged families have at most `O(sqrt(X) log^2 X)` values
  up to `X`, hence zero density.
- **Intermediate theorem:** exact closure on explicit thin families only.

### Watch trigger

This route would become promotable only after a new normalization theorem
showing that every sufficiently large represented integer, or every
predecessor in a complete descent cover, has one of these norm shapes.  No
such theorem or evidence was found.

## 7. RC-6 — affine Gaussian completion

A proposed map

\[
z\longmapsto Lz+t(c,d)
\]

would have to make its norm depend only on `N(z)` and the exponent state, not
on the orientation of `z`.  Gaussian affine rigidity forces

\[
t=0,\qquad L^T L=K I.
\]

Thus every full-rank affine-state identity reduces to pure norm
multiplication and an exact shift equation.  It gives no repair beyond RC-1.

Finite menus of linear two-square completions are also blocked by the rank
three/four obstruction.

## 8. RC-7 — Gaussian division

### Split factor `pi=2+i`

If `z=a+bi` and `a=2b mod 5`, then `z/pi` is Gaussian integral and

\[
N(z/\pi)=N(z)/5.
\]

### Inert factor `3`

If `3|N(z)`, then `3|a,b`, so `N(z)/9` is again a norm.

### Descent defect

A counterexample contains no representing `z` to divide.  In a minimality
argument one can divide the norm component of a chosen representation of a
smaller integer, but lifting it back to the target again requires a global
shift relation.  Moreover, the active remainders at shifts `2` and `4`
differ by `2`, so neither `pi` nor `3` can divide all of them.  There is no
common Gaussian divisor state supporting a universal division descent.

## 9. RC-8 — exponent-change recurrences

The exact tagged identity

\[
n\mapsto n+3^c(3^r-1)+5^d(5^s-1)
\]

moves `(c,d)` to `(c+r,d+s)` and keeps the norm component fixed.

It is not an integer-level recurrence because its target depends on the
chosen representation.  It also generates sparse exponent rays rather than
a complete residue closure.  The collision

\[
3^3+5^0=3^1+5^2
\]

changes tags at fixed `n` but produces no descent.

## 10. RC-9 — nonlinear square completion

The map

\[
G(n)=(Kn-h')^2+h'
\]

is represented for every `n` and every fixed `h' in H`.  It is nonlinear and
avoids affine no-go theorems, but its image is sparse and contains no
counterexamples.  It cannot express an arbitrary large `n` as `G(m)` with a
smaller counterexample predecessor.  This is an identity generator, not a
counterexample mechanism.

## 11. RC-10 — finite Gaussian states

For fixed ideals generated by powers of `pi`, `bar pi`, `3`, and finitely many
other inert primes, exponent orbits are finite/eventually periodic.  A full
state certificate can therefore be built after fixing the prime set and
valuation depth.

This is not a new finite reduction.  `5`-adic states are blind to the
sum-of-two-squares predicate, and any fixed inert-prime state system misses
possible witnesses outside the set.  The missing theorem remains a uniform
finite witness and valuation-depth bound, equivalent in force to the prior
`CRW(Q,E)` trigger.

## 12. Recurrence conclusion

No candidate supplies all three of the following:

1. original one-norm output shape for every representation;
2. an integer-level contrapositive yielding a smaller counterexample;
3. a finite image family covering every sufficiently large integer.

The `9`-scale asymmetry is the cleanest algebraic identity, and the thin
`U9/U25` families are the cleanest original-shape recurrences.  Neither
crosses the promotion gate.
