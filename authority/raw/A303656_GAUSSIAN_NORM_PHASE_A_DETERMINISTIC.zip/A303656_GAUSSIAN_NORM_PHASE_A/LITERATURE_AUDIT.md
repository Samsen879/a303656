# LITERATURE AUDIT

检索与复核日期：`2026-07-18`。

## 0. 审计问题

本轮不是泛查 “sum of two squares” 文献，而是逐项寻找能否提供下列任一 missing bridge：

1. 对混合 shift set
   \[
   \mathcal H=\{3^c+5^d:c,d\ge0\}
   \]
   的 exact affine/nonlinear self-embedding；
2. 把一项 Gaussian norm 加上一项 exponent residual 后，统一压回一项 norm 的 theorem；
3. 从 Gaussian divisibility 导出的 counterexample-preserving inverse map；
4. 对所有 sufficiently large integers 完整覆盖的 finite algebraic-state theorem；
5. 对 moving remainders 的 explicit finite bad-prime/valuation certificate。

“未找到”不是不存在性证明；本文件只记录截至检索日已审计 source 与精确 mismatch。

## 1. 当前问题状态

### OEIS A303656

- **source:** OEIS A303656，`https://oeis.org/A303656`；访问日 2026-07-18。
- **recorded conjecture:** 每个 \(n>1\) 都可写成
  \[
  a^2+b^2+3^c+5^d.
  \]
- **recorded computation:** entry 记载已验证至 \(2.4\times10^{11}\)。
- **本轮用途:** 仅确认 public problem statement 和 unresolved status。
- **mismatch:** finite verification 不是 recurrence、descent 或 all-sufficiently-large theorem。

## 2. 最接近的同型 descent comparator

### Roger Clement Crocker, *On the Sum of Two Squares and Two Powers of k*

- **bibliography:** *Colloquium Mathematicum* 112 (2008), no. 2, 235–267；DOI `10.4064/cm112-2-3`。
- **audited point:** 论文证明对任意固定同一 base \(k\ge2\)，存在无穷多个整数不能表示为 two squares 加至多两个 \(k\)-powers。其 powers-of-two argument 中出现 homogeneous scaling/descent：同一 base 的两个 power terms 可同时按 \(2^\alpha\) 移动。
- **relevance:** 这是本轮最接近的 algebraic descent precedent。
- **exact mismatch:** A303656 同时含 bases 3 与 5。若要求逐项统一 scale，
  \[
  K3^c=3^{c+r},\qquad K5^d=5^{d+s}
  \]
  则 \(K=3^r=5^s\)，只能是 \(K=1\)。Crocker 的 common-base homogeneous mechanism 不能直接迁移。
- **consequence:** 文献提供 comparator，不提供 mixed-base descent。

## 3. multiplicative-group / S-unit finiteness

### J.-H. Evertse, H. P. Schlickewei, W. M. Schmidt

- **source:** *Linear equations in variables which lie in a multiplicative group*, *Annals of Mathematics* 155 (2002), 807–836；arXiv `math/0409604`。
- **theorem audited:** 固定 characteristic-zero field、固定 linear equation 与 finite-rank multiplicative group 时，nondegenerate solutions 数量有只依赖 dimension 与 rank 的显式上界。
- **possible use:** 控制固定 S-unit equation 或固定 exponential relation 的 solution count。
- **mismatch:** A303656 counterexample 条件涉及随 \(n,c,d\) 变化的 remainders
  \[
  n-3^c-5^d,
  \]
  且其 Gaussian/non-Gaussian prime support 不在一个预先固定的 finite-rank group 中。该 theorem 不产生 least-counterexample bound，也不产生 \(K\mathcal H+C\subseteq\mathcal H\)。

### Yann Bugeaud, Kálmán Győry

- **source:** *Bounds for the solutions of unit equations*, *Acta Arithmetica* 74 (1996), 67–80；`https://matwbn.icm.edu.pl/ksiazki/aa/aa74/aa7416.pdf`。
- **theorem audited:** 对固定 number field、固定 finite set of places \(S\) 与固定 coefficients 的 S-unit equation 给出 effective height bounds。
- **mismatch:** 对每个非-norm remainder，Fermat criterion 只保证“存在某个” \(q\equiv3\pmod4\) 以奇数 valuation 出现；这个 \(q\) 随 active pair 变化。文献 theorem 不能先验地产生统一有限 \(S\)。

### literature conclusion for S-unit route

S-unit results可在 **fixed support 已给定** 后做有效计算；它们没有完成本项目最关键的 quantifier compression：从所有 moving remainders 中先导出统一 finite support 与 valuation depth。

## 4. norm-form equation literature

### Prajeet Bajpai, *Effective Methods for Norm-Form Equations*

- **source:** arXiv `2112.13441`。
- **scope:** 对若干固定 number fields 与固定 norm-form equations 建立 effective resolution，尤其处理若干高维 norm forms。
- **relevance:** 表明在 coefficients、field 和 right-hand side structure 被固定时，norm-form equations 可有强 effectivity。
- **mismatch:** A303656 不是求解一个固定 equation
  \[
  N_{K/\mathbf Q}(x)=m
  \]
  的全部解，而是要求每个移动 \(n\) 在 \(O(\log^2 n)\) 个 mixed exponential shifts 中至少有一个 remainder 属于 \(N_{\mathbf Z[i]/\mathbf Z}(\mathbf Z[i])\)。固定 norm-form equation theory 不提供 simultaneous additive coverage。

### 本轮判断

Gaussian factorization 对单个 remainder 完全有效，但 classical/effective norm-form machinery 未给出“所有 active remainders 同时失败 \(\Rightarrow\) 更小 counterexample”的 map。

## 5. primitive divisor literature

### Yuri Bilu, Guillaume Hanrot, Paul M. Voutier

- **source:** *Existence of Primitive Divisors of Lucas and Lehmer Numbers*, *J. reine angew. Math.* 539 (2001), 75–122。
- **core result:** 对 sufficiently large index 的 Lucas/Lehmer terms 存在 primitive divisor（经典阈值为 index \(>30\)，并分类小指数例外）。

### Paul M. Voutier

- **source:** *Primitive divisors of Lucas and Lehmer sequences, II*, *J. Théorie des Nombres de Bordeaux* 8 (1996), 251–274。

### mismatch

即使 exponent difference sequence 获得 primitive prime，也仍缺三件事：

1. prime 必须满足 \(q\equiv3\pmod4\)；
2. valuation 必须为奇数；
3. 必须同步覆盖所有 moving pairs \((c,d)\)，而不是一个 fixed one-dimensional recurrence term。

因此 primitive-divisor theorem 对

\[
3^{c+r}-3^c,
\qquad
5^{d+s}-5^d
\]

可提供 factorization 信息，却不自动产生 two-square obstruction 或 finite state cover。

## 6. Presburger / finite-state literature

### Seymour Ginsburg, Edwin H. Spanier

- **source:** *Semigroups, Presburger formulas, and languages*, *Pacific Journal of Mathematics* 16 (1966), 285–296。
- **theorem audited:** Presburger-definable subsets of \(\mathbf N^d\) 与 semilinear sets 等价，并可有效转换。
- **negative relevance:** \(\mathcal H\cap[0,X]\) 只有 \(O((\log X)^2)\) 个元素；它不是一个能靠普通 semilinear periodicity 提供多分支 exact digit closure 的 dense periodic set。
- **mismatch:** 该 theorem 不含 powers predicates 或 quadratic norm predicate。

### Toghrul Karimov, Florian Luca, Joris Nieuwveld, Joël Ouaknine, James Worrell

- **source:** *On the Decidability of Presburger Arithmetic Expanded with Powers*, arXiv `2407.05191v2` (20 Jul 2025), SODA 2025。
- **theorem audited:** 对任意固定 \(\alpha,\beta>1\)，结构
  \[
  \langle\mathbf Z;0,1,<,+,\alpha^{\mathbf N},\beta^{\mathbf N}\rangle
  \]
  的 existential fragment 可判定；把 predicates 换成 exponentiation functions 则与困难 digit-pattern 问题相连。
- **relevance:** bases 3 与 5 的 linear additive-exponential fragment 有强 algorithmic structure。
- **mismatch:** language 不含
  \[
  x=a^2+b^2
  \]
  这一 quadratic/global-prime-valuation predicate；也不直接表达“对所有 active exponent pairs remainder 都不是 norm”的 universal condition。

### Shuo Li

- **source:** *The characteristic sequence of the integers that are the sum of two squares is not morphic*, arXiv `2404.08822v1` (12 Apr 2024)，后发表于 *Discrete Mathematics*。
- **result:** two-square characteristic sequence 不是 morphic；此前亦知其不是 \(k\)-automatic。
- **relevance:** 反对“一个简单固定 automaton 精确编码 \(\mathcal S_2\)”的想法。
- **mismatch:** 不排除在先给定 finite prime set 和 bounded valuation depth 后建立 certificate-dependent automaton；真正缺失的仍是 uniform bound。

## 7. Gaussian arithmetic 的 classical input

本轮使用的 classical facts 为：

- \(\mathbf Z[i]\) 是 unique factorization domain；
- \(5=(2+i)(2-i)\) split，\(3\) inert；
- Brahmagupta–Fibonacci identity / norm multiplicativity；
- Fermat two-square criterion。

这些 facts 足以证明本包中的 norm-scale invariance、Gaussian affine rigidity、divisibility tests 和 explicit identities。它们本身不包含 additive closure：\(\mathcal S_2+\mathcal S_2\not\subseteq\mathcal S_2\)。

## 8. 文献与本轮 theorem 的交叉结论

| 所需 bridge | 文献是否提供 | 本轮结论 |
|---|---:|---|
| exact mixed-base common scaling | NO | termwise scaling 只有 trivial scale |
| \(K\mathcal H+C\subseteq\mathcal H\) 的全域 theorem | NO | 仅找到 isolated fibers；多 residue branch 被 sparsity theorem 排除 |
| two norms 统一 collapse 成 one norm | NO | linear/affine universal collapse 被 rank 与 rigidity 排除 |
| Gaussian divisor 给出 least-counterexample descent | NO | active remainders 无共同 \(5\) 或 \(9\) divisor |
| finite algebraic-state reduction | NO | local states exact，但缺 uniform bad-prime/valuation bound |
| all-sufficiently-large closure | NO | strongest universal identities 落入 two-norm enlarged class |

## 9. literature watch triggers

仅在出现下列任一外部 theorem 时重新 promotion audit：

1. 对 mixed exponential set \(\{3^c+5^d\}\) 的 explicit affine/nonlinear self-embedding，且覆盖至少两个 residue branches；
2. 对 \(N(z)+N(w)\) 在本问题特定 exponent-correlated subvariety 上的 universal one-norm collapse theorem；
3. 对每个 sufficiently large A303656 counterexample 的 uniform finite bad-prime set 与 odd valuation-depth bound；
4. 对 moving Gaussian norm remainders 的 effective minimal-counterexample descent theorem。

截至 2026-07-18，审计未发现满足上述条件的 source。
