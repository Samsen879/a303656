#!/usr/bin/env python3
"""Validate the A303656 Gaussian-norm Phase-A package."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

REQUIRED = {
    "README.md",
    "EXECUTIVE_VERDICT.md",
    "GAUSSIAN_NORM_FORMALISM.md",
    "IDENTITY_CATALOGUE.md",
    "RECURRENCE_CANDIDATES.md",
    "DESCENT_AUDIT.md",
    "COUNTEREXAMPLES_TO_IDENTITIES.md",
    "LITERATURE_AUDIT.md",
    "NO_GO_RESULTS.md",
    "REPORT.md",
    "PROMOTION_VERDICT.json",
    "INPUT_PROVENANCE.json",
    "REPRODUCIBILITY.md",
    "PACKAGE_MANIFEST.json",
    "SHA256SUMS.txt",
    "VALIDATION_REPORT.txt",
    "scripts/exact_checks.py",
    "scripts/build_deterministic_zip.py",
    "scripts/validate_package.py",
    "results/exact_checks.json",
}

EXPECTED_COUNTS = {
    "Brahmagupta_Fibonacci": 6561,
    "G25_even": 5929,
    "G25_odd": 5929,
    "G5_even": 5929,
    "G9_dplus1": 6776,
    "G9_dsame": 6776,
    "U25_even": 1984,
    "U25_odd": 1984,
    "U5_even": 1984,
    "U9": 2232,
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def validate(root: Path, check_checksums: bool = True) -> list[str]:
    root = root.resolve()
    log: list[str] = []
    present = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    missing = sorted(REQUIRED - present)
    if missing:
        raise RuntimeError(f"missing required files: {missing}")
    log.append(f"required_files=PASS ({len(REQUIRED)})")

    verdict = json.loads((root / "PROMOTION_VERDICT.json").read_text(encoding="utf-8"))
    if verdict.get("final_verdict") != "NO PROMOTABLE ROUTE — SPECULATIVE WATCH":
        raise RuntimeError("wrong final verdict")
    if verdict.get("promotion") is not False or verdict.get("oeis_status") != "UNRESOLVED":
        raise RuntimeError("promotion/status invariant failed")
    if any(verdict.get(k) for k in ("codex_used", "ultra_used", "repository_integration_used", "long_Tn_search_used")):
        raise RuntimeError("forbidden execution flag is true")
    log.append("promotion_verdict=PASS")

    for path in sorted(root.rglob("*.json")):
        json.loads(path.read_text(encoding="utf-8"))
    log.append("json_parse=PASS")

    result = json.loads((root / "results/exact_checks.json").read_text(encoding="utf-8"))
    if result.get("verified_identity_instances") != EXPECTED_COUNTS:
        raise RuntimeError("exact identity counts mismatch")
    if not all(row.get("is_S2") is False for row in result.get("explicit_non_S2_witnesses", [])):
        raise RuntimeError("explicit obstruction witness classified as S2")
    collisions = result["bounded_diagnostics"]["shift_collision_exponents_0_to_30"]
    if collisions != [{"pairs": [[1, 2], [3, 0]], "value": 28}]:
        raise RuntimeError("bounded collision diagnostic mismatch")
    log.append("exact_result_schema=PASS")

    expected_bytes = (root / "results/exact_checks.json").read_bytes()
    with tempfile.TemporaryDirectory(prefix="a303656-gaussian-replay-") as td:
        replay_root = Path(td) / root.name
        shutil.copytree(root, replay_root)
        proc = subprocess.run(
            [sys.executable, str(replay_root / "scripts/exact_checks.py")],
            cwd=replay_root,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"exact-check replay failed: {proc.stderr}")
        actual_bytes = (replay_root / "results/exact_checks.json").read_bytes()
    if actual_bytes != expected_bytes:
        raise RuntimeError("exact-check replay is not byte-identical in this environment")
    log.append(f"exact_check_replay=PASS (sha256={hashlib.sha256(expected_bytes).hexdigest()})")

    for name in ("README.md", "EXECUTIVE_VERDICT.md", "REPORT.md"):
        text = (root / name).read_text(encoding="utf-8")
        if "OEIS A303656: UNRESOLVED." not in text:
            raise RuntimeError(f"missing unresolved statement in {name}")
    log.append("status_markers=PASS")

    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        if path.suffix.lower() not in {".md", ".json", ".txt", ".py"}:
            continue
        data = path.read_bytes()
        bad = [b for b in data if b < 32 and b not in (9, 10, 13)]
        if bad:
            raise RuntimeError(f"control character found in {path.relative_to(root)}")
    log.append("control_character_scan=PASS")

    manifest = json.loads((root / "PACKAGE_MANIFEST.json").read_text(encoding="utf-8"))
    for row in manifest.get("files", []):
        rel = row["path"]
        path = root / rel
        if not path.is_file() or path.stat().st_size != row["size_bytes"] or sha256(path) != row["sha256"]:
            raise RuntimeError(f"manifest mismatch: {rel}")
    log.append(f"package_manifest=PASS ({len(manifest.get('files', []))} files)")

    if check_checksums:
        rows = []
        for line in (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
            if line.strip():
                digest, rel = line.split("  ", 1)
                rows.append((digest, rel))
        expected_paths = sorted(p for p in present if p != "SHA256SUMS.txt")
        if [rel for _, rel in rows] != expected_paths:
            raise RuntimeError("SHA256SUMS path set/order mismatch")
        for digest, rel in rows:
            if sha256(root / rel) != digest:
                raise RuntimeError(f"checksum mismatch: {rel}")
        log.append(f"internal_checksums=PASS ({len(rows)} files)")
    else:
        log.append("internal_checksums=SKIPPED")

    return log


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--bootstrap", action="store_true")
    args = parser.parse_args()
    try:
        log = validate(args.root, check_checksums=not args.bootstrap)
    except Exception as exc:  # noqa: BLE001
        print("VALIDATION=FAIL")
        print(f"reason={exc}")
        return 1
    print("VALIDATION=PASS")
    for line in log:
        print(line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
