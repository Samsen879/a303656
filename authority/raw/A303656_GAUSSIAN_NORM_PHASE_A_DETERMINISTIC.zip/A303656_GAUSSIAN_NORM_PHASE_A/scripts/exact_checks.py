#!/usr/bin/env python3
"""Small deterministic exact checks for A303656 Gaussian-norm Phase A.

This script deliberately performs no long T(n) interval search.  It verifies
closed-form identities on finite grids, factors the explicit obstruction
witnesses used in the report, and records bounded diagnostic searches whose
absence results are never used as proofs.
"""
from __future__ import annotations

import json
import platform
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import sympy
from sympy import factorint

ROOT = Path(__file__).resolve().parents[1]
RESULT = ROOT / "results" / "exact_checks.json"


def fac(n: int) -> Dict[str, int]:
    return {str(int(p)): int(e) for p, e in sorted(factorint(n).items())}


def is_s2(n: int) -> bool:
    if n < 0:
        return False
    if n == 0:
        return True
    return all(not (int(p) % 4 == 3 and int(e) % 2 == 1)
               for p, e in factorint(n).items())


def norm(z: Tuple[int, int]) -> int:
    a, b = z
    return a * a + b * b


def mul(z: Tuple[int, int], w: Tuple[int, int]) -> Tuple[int, int]:
    a, b = z
    x, y = w
    return a * x - b * y, a * y + b * x


def cpow(z: Tuple[int, int], e: int) -> Tuple[int, int]:
    out = (1, 0)
    base = z
    while e:
        if e & 1:
            out = mul(out, base)
        base = mul(base, base)
        e >>= 1
    return out


def check_equal(label: str, lhs: int, rhs: int) -> None:
    if lhs != rhs:
        raise AssertionError(f"{label}: {lhs} != {rhs}")


def verify_brahmagupta() -> int:
    count = 0
    for a in range(-4, 5):
        for b in range(-4, 5):
            for x in range(-4, 5):
                for y in range(-4, 5):
                    check_equal("BF", norm(mul((a, b), (x, y))),
                                norm((a, b)) * norm((x, y)))
                    count += 1
    return count


def verify_universal_two_norm_identities() -> Dict[str, int]:
    counts = {"G5_even": 0, "G9_dplus1": 0, "G9_dsame": 0,
              "G25_even": 0, "G25_odd": 0}
    pi = (2, 1)
    pi2 = mul(pi, pi)
    for a in range(-5, 6):
        for b in range(-5, 6):
            s = a * a + b * b
            z = (a, b)
            for k in range(0, 7):
                for d in range(0, 7):
                    # 5-scale, c=2k
                    lhs = 5 * (s + 3 ** (2 * k) + 5 ** d)
                    rhs = (norm(mul(pi, z)) + norm(((3 ** k), (3 ** k)))
                           + 3 ** (2 * k + 1) + 5 ** (d + 1))
                    check_equal("G5_even", lhs, rhs)
                    counts["G5_even"] += 1

                    # 25-scale, c=2k
                    lhs = 25 * (s + 3 ** (2 * k) + 5 ** d)
                    rhs = (norm(mul(pi2, z)) + (4 * 3 ** k) ** 2
                           + 3 ** (2 * k + 2) + 5 ** (d + 2))
                    check_equal("G25_even", lhs, rhs)
                    counts["G25_even"] += 1

                    # 25-scale, c=2k+1
                    lhs = 25 * (s + 3 ** (2 * k + 1) + 5 ** d)
                    rhs = (norm(mul(pi2, z)) + norm((6 * 3 ** k, 6 * 3 ** k))
                           + 3 ** (2 * k + 1) + 5 ** (d + 2))
                    check_equal("G25_odd", lhs, rhs)
                    counts["G25_odd"] += 1

            for c in range(0, 8):
                for d in range(0, 7):
                    pid = cpow(pi, d)
                    lhs = 9 * (s + 3 ** c + 5 ** d)
                    rhs = (norm((3 * a, 3 * b)) + norm(mul((2, 0), pid))
                           + 3 ** (c + 2) + 5 ** (d + 1))
                    check_equal("G9_dplus1", lhs, rhs)
                    counts["G9_dplus1"] += 1

                    rhs2 = (norm((3 * a, 3 * b))
                            + norm(mul((2, 2), pid))
                            + 3 ** (c + 2) + 5 ** d)
                    check_equal("G9_dsame", lhs, rhs2)
                    counts["G9_dsame"] += 1
    return counts


def verify_thin_subfamily_identities() -> Dict[str, int]:
    counts = {"U5_even": 0, "U9": 0, "U25_even": 0, "U25_odd": 0}
    pi = (2, 1)
    for t in range(0, 31):
        for k in range(0, 8):
            for d in range(0, 8):
                # U5-even: norm component 10 t^2
                n = 10 * t * t + 3 ** (2 * k) + 5 ** d
                rhs = ((5 * t + 3 ** k) ** 2 + (5 * t - 3 ** k) ** 2
                       + 3 ** (2 * k + 1) + 5 ** (d + 1))
                check_equal("U5_even", 5 * n, rhs)
                counts["U5_even"] += 1

                # U25-even: norm component t^2
                n = t * t + 3 ** (2 * k) + 5 ** d
                rhs = ((5 * t) ** 2 + (4 * 3 ** k) ** 2
                       + 3 ** (2 * k + 2) + 5 ** (d + 2))
                check_equal("U25_even", 25 * n, rhs)
                counts["U25_even"] += 1

                # U25-odd: norm component 2 t^2
                n = 2 * t * t + 3 ** (2 * k + 1) + 5 ** d
                rhs = ((5 * t + 6 * 3 ** k) ** 2
                       + (5 * t - 6 * 3 ** k) ** 2
                       + 3 ** (2 * k + 1) + 5 ** (d + 2))
                check_equal("U25_odd", 25 * n, rhs)
                counts["U25_odd"] += 1

        for c in range(0, 9):
            for d in range(0, 8):
                pid = cpow(pi, d)
                n = t * t * 5 ** d + 3 ** c + 5 ** d
                w = mul((3 * t, 2), pid)
                rhs = norm(w) + 3 ** (c + 2) + 5 ** (d + 1)
                check_equal("U9", 9 * n, rhs)
                counts["U9"] += 1
    return counts


def scalar_shift_hits(exp_bound: int, scales: Iterable[int]) -> Dict[str, List[dict]]:
    values: Dict[int, List[Tuple[int, int]]] = defaultdict(list)
    for c in range(exp_bound + 1):
        for d in range(exp_bound + 1):
            values[3 ** c + 5 ** d].append((c, d))
    out: Dict[str, List[dict]] = {}
    for K in scales:
        hits: List[dict] = []
        for h in sorted(values):
            if K * h not in values:
                continue
            for src in values[h]:
                for dst in values[K * h]:
                    hits.append({"source": list(src), "target": list(dst),
                                 "h": h, "K_h": K * h})
        out[str(K)] = hits
    return out


def shift_collisions(exp_bound: int) -> List[dict]:
    values: Dict[int, List[Tuple[int, int]]] = defaultdict(list)
    for c in range(exp_bound + 1):
        for d in range(exp_bound + 1):
            values[3 ** c + 5 ** d].append((c, d))
    return [{"value": h, "pairs": [list(p) for p in pairs]}
            for h, pairs in sorted(values.items()) if len(pairs) > 1]


def increment_equalities(bound: int) -> List[dict]:
    out: List[dict] = []
    for c in range(bound + 1):
        for d in range(bound + 1):
            for r in range(1, bound + 1):
                left = 3 ** c * (3 ** r - 1)
                for s in range(1, bound + 1):
                    right = 5 ** d * (5 ** s - 1)
                    if left == right:
                        out.append({"c": c, "d": d, "r": r, "s": s,
                                    "increment": left})
    return out


def counterexample_table() -> List[dict]:
    rows = [
        ("S2_not_additive", 3),
        ("5_scale_r1", 7),
        ("5_scale_menu_r0", 14),
        ("5_scale_menu_r1", 12),
        ("9_scale_dplus1", 22),
        ("9_scale_menu_dsame", 188),
        ("9_scale_menu_dplus1", 184),
        ("25_scale_r0", 224),
        ("25_scale_r1", 222),
        ("25_scale_r2", 216),
        ("9_scale_dsame_simple", 44),
        ("shift_even_c_odd_d", 6),
    ]
    return [{"id": label, "n": n, "factorization": fac(n), "is_S2": is_s2(n)}
            for label, n in rows]


def residual_tables() -> dict:
    return {
        "3_power_increments": [
            {"r": r, "3^r-1": 3 ** r - 1,
             "is_S2": is_s2(3 ** r - 1), "factorization": fac(3 ** r - 1)}
            for r in range(1, 21)
        ],
        "5_power_increments": [
            {"s": s, "5^s-1": 5 ** s - 1,
             "is_S2": is_s2(5 ** s - 1), "factorization": fac(5 ** s - 1)}
            for s in range(1, 16)
        ],
    }


def main() -> None:
    scales = [2, 4, 5, 8, 9, 10, 13, 16, 17, 18, 20, 25, 29, 32,
              36, 41, 45, 49, 50, 64, 65, 81, 100, 125]
    data = {
        "schema": "a303656-gaussian-norm-exact-checks-v1",
        "fixed_date": "2026-07-18",
        "scope": "symbolic identities and small exact diagnostic searches only; no T(n) interval search",
        "environment": {
            "python": platform.python_version(),
            "sympy": sympy.__version__,
            "platform": platform.platform(),
        },
        "verified_identity_instances": {
            "Brahmagupta_Fibonacci": verify_brahmagupta(),
            **verify_universal_two_norm_identities(),
            **verify_thin_subfamily_identities(),
        },
        "explicit_non_S2_witnesses": counterexample_table(),
        "bounded_diagnostics": {
            "warning": "Absence outside/inside these boxes is not used as proof.",
            "shift_collision_exponents_0_to_30": shift_collisions(30),
            "equal_increment_search_c_d_0_to_10_r_s_1_to_10": increment_equalities(10),
            "scalar_shift_hits_exponents_0_to_30": scalar_shift_hits(30, scales),
        },
        "residual_tables": residual_tables(),
        "representation_state_ambiguity": {
            "n": 8,
            "representations": [
                {"norm": 2, "c": 0, "d": 1, "identity": "8=1^2+1^2+1+5"},
                {"norm": 4, "c": 1, "d": 0, "identity": "8=2^2+0^2+3+1"},
            ],
            "conclusion": "parity of c is not a state of n",
        },
    }
    RESULT.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
                      encoding="utf-8")
    print(RESULT)


if __name__ == "__main__":
    main()
