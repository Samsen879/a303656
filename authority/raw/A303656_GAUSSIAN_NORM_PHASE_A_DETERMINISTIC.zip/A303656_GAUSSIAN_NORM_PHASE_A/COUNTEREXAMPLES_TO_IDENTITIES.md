# COUNTEREXAMPLES TO PROPOSED IDENTITIES

## 0. 逻辑边界

本文件中的“counterexample”只反驳某个 **proposed identity、finite repair menu、state interpretation 或 descent inference**。它们都不是 OEIS A303656 的 counterexample，也不证明相应目标整数不具有其他表示。

判定工具是 Fermat two-square criterion：正整数属于

\[
\mathcal S_2=\{a^2+b^2:a,b\in\mathbf Z\}
\]

当且仅当每个素数 \(q\equiv3\pmod4\) 的指数均为偶数。

## 1. “两个 norm 可相加成一个 norm”是错误的

最小反例为

\[
1+2=3,
\]

其中 \(1=N(1)\)、\(2=N(1+i)\)，但 \(3\notin\mathcal S_2\)。

因此，从

\[
KN(z)+E=N(\alpha z)+N(w)
\]

不能推得右侧是一个 Gaussian norm。Brahmagupta–Fibonacci identity 处理的是乘法，不是加法。

## 2. scale 5 的 one-norm repair 失败

考虑

\[
5\bigl(N(z)+3^c+5^d\bigr)
=N(\pi z)+5\cdot3^c+5^{d+1},\qquad \pi=2+i.
\]

对 \(3^c\) 的自然非负 exponent choices 为保持 \(c\) 或改成 \(c+1\)，对应 residuals

\[
4\cdot3^c,
\qquad 2\cdot3^c.
\]

### 2.1 单一 residual 已失败

取 \(N(z)=1,c=0\)，则

\[
5N(z)+2=7\notin\mathcal S_2
\]

因为 \(7\equiv3\pmod4\) 且指数为 1。

### 2.2 完整自然二选一 menu 同时失败

取 \(N(z)=2,c=0\)，则

\[
5N(z)+4=14=2\cdot7\notin\mathcal S_2,
\]

\[
5N(z)+2=12=2^2\cdot3\notin\mathcal S_2.
\]

所以即使 \(c\) 为偶数、两个 residual 本身都是 norms，也不能把它们逐项吸收到任意旧 norm 中。

## 3. scale 9 的 one-norm repair 失败

scale 9 精确移动 \(3^c\mapsto3^{c+2}\)，对 \(5^d\) 的两个自然 choices 给出 residuals

\[
9\cdot5^d-5^{d+1}=4\cdot5^d,
\]

\[
9\cdot5^d-5^d=8\cdot5^d.
\]

两者均为 Gaussian norms，但 one-norm closure 仍失败。

### 3.1 单一 residual

取 \(N(z)=2,d=0\)，则

\[
9N(z)+4=22=2\cdot11\notin\mathcal S_2.
\]

### 3.2 完整自然二选一 menu

取 \(N(z)=20=2^2+4^2,d=0\)，则

\[
9N(z)+4=184=2^3\cdot23\notin\mathcal S_2,
\]

\[
9N(z)+8=188=2^2\cdot47\notin\mathcal S_2.
\]

这里 \(23,47\equiv3\pmod4\) 均出现奇数次。

### 3.3 G9B 不能被误读成 one-norm identity

取 \(N(z)=4,d=0\)，候选 collapse 的数为

\[
9N(z)+8=44=2^2\cdot11\notin\mathcal S_2.
\]

因此 G9A/G9B 是有效的 **two-norm identities**，但不是 A303656 原形的 recurrence。

## 4. scale 25 的 parity-complete menu 仍失败

对 \(c=0\)、\(N(z)=8=2^2+2^2\)，coordinatewise nonnegative choices \(c\mapsto c+r\) 中 \(r=0,1,2\) 给出

\[
25N(z)+24=224=2^5\cdot7\notin\mathcal S_2,
\]

\[
25N(z)+22=222=2\cdot3\cdot37\notin\mathcal S_2,
\]

\[
25N(z)+16=216=2^3\cdot3^3\notin\mathcal S_2.
\]

这反驳“按 \(c\) parity 选择有限 residual 后总能回到一个 norm”的自然方案。

## 5. representation-state 不是 integer-state

整数 8 有两种不同 \(c\)-parity 的表示：

\[
8=1^2+1^2+3^0+5^1,
\]

\[
8=2^2+0^2+3^1+5^0.
\]

所以“\(c\) 为偶/奇”是 chosen representation 的 state，而不是由整数 \(n\) 唯一决定的 finite algebraic state。任何 counterexample descent 若按此 state 分支，必须先证明 state 对所有 relevant representations 的量词安全性。

## 6. shift 本身为 norm 也不能自动合并

当 \(c\) 偶、\(d\) 奇时，

\[
3^c+5^d\equiv6\pmod8,
\]

故不在 \(\mathcal S_2\)。最小例为

\[
3^0+5^1=6=2\cdot3\notin\mathcal S_2.
\]

当 \(c,d\) 均偶时 shift 确实是一个 norm，

\[
3^c+5^d=(3^{c/2})^2+(5^{d/2})^2,
\]

但把它与任意另一个 norm 相加仍无 closure theorem；第 1 节已经给出最小障碍。

## 7. isolated shift coincidence 不产生 universal recurrence

例如

\[
5(3^0+5^0)=3^2+5^0,
\]

只说明使用 shift \((c,d)=(0,0)\) 的 tagged representation 可被放大。它不处理 predecessor 的其他表示，也不证明

\[
\mathcal R(m)\Longrightarrow\mathcal R(5m).
\]

同理，

\[
9(3^2+5^1)=3^0+5^3
\]

只作用于 shift 14 的单一 fiber。

## 8. bounded exact search 的正确解释

`results/exact_checks.json` 在 exponents \(0\le c,d\le30\) 的 diagnostic box 中找到 shift collision

\[
3^3+5^0=3^1+5^2=28,
\]

以及若干 scalar shift coincidences。其余 bounded absence 绝不被当作 global proof。脚本没有执行任何 long \(T(n)\) search。

## 9. 从有限例到 theorem 的升级

以上小反例用于快速淘汰具体 formula。对任意固定 source shift 和任意 finite nonzero residual menu，`GAUSSIAN_NORM_FORMALISM.md` 的 finite scalar-repair obstruction 给出 **任意大** 的 \(S\in\mathcal S_2\)，使全部候选 \(KS+e_j\) 同时不在 \(\mathcal S_2\)。

其精确边界是：它反驳 finite identity menu，不反驳 target integer 通过 menu 之外的 shift 获得 unrelated representation。
