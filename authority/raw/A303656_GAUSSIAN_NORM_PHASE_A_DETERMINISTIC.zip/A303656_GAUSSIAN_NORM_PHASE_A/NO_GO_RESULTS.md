# NO-GO RESULTS

## 0. 使用原则

本文件记录可复用的 route-termination statements。每条 no-go 都有明确 scope；没有任何一条声称“A303656 不可证明”或“Gaussian methods 永远无效”。

记

\[
\mathcal S_2=N_{\mathbf Z[i]/\mathbf Z}(\mathbf Z[i]),
\qquad
\mathcal H=\{3^c+5^d:c,d\ge0\},
\qquad
\mathcal R=\mathcal S_2+\mathcal H.
\]

## NG-1 — generic finite affine repair 不足（继承并专门化）

### Statement

固定 \(K>0\)、source shift \(h\in\mathcal H\)、constant \(C\)，以及有限 target menu \(h_1,\dots,h_t\in\mathcal H\)。令

\[
e_j=Kh+C-h_j.
\]

若每个 \(e_j\ne0\)，则存在任意大的 \(S\in\mathcal S_2\)，使

\[
KS+e_j>0,
\qquad
KS+e_j\notin\mathcal S_2
\quad(1\le j\le t).
\]

### Consequence

任何“先放大 norm，再从 finite exponent menu 选一个 residual 修补”的 universal identity，只要没有一个 residual 精确为零，就不能对所有 old norm components 成立。

### Scope limit

它只反驳指定 finite menu；不排除 target integer 通过 menu 之外的 unrelated shift 表示。

## NG-2 — common-square / common-Gaussian-divisor descent 不足

最小 counterexample \(n_0\) 的 active remainders 包含

\[
n_0-(3^0+5^0)=n_0-2,
\qquad
n_0-(3^1+5^0)=n_0-4.
\]

它们之差为 2。任何整除所有 active remainders 的 Gaussian integer 必须整除 2。因此：

- \(2+i\) 与 \(2-i\) 不可能共同整除所有 active remainders；
- inert prime 3 不可能共同整除所有 active remainders；
- 不存在由共同 factor 5 或 9 导出的 universal division descent。

可能的 ramified factor \(1+i\) 也不足，因为

\[
(3^c+5^d)/2
\]

通常不再属于 \(\mathcal H\)。

## NG-3 — uniform termwise mixed-base scaling 只有 trivial scale（继承）

若要求对所有 \(c,d\)

\[
K3^c=3^{c+r},
\qquad
K5^d=5^{d+s}
\]

且 \(r,s\ge0\) 固定，则

\[
K=3^r=5^s,
\]

从 multiplicative independence 得 \(r=s=0,K=1\)。

所以 Crocker-style same-base homogeneous scaling 不能逐项复制到 bases 3 与 5。

## NG-4 — minimality transfer 不能自动成立（继承并量词化）

由 \(n_0\) 为 least counterexample，只能推出每个 \(m<n_0\) 存在某个 representation

\[
m=S+3^c+5^d.
\]

minimality 不控制：

- witnessing \((c,d)\)；
- \(c\) 的 parity；
- Gaussian orientation of \(S=N(z)\)；
- \(z\) 是否被 \(2+i\)、3 或其他 factor 整除；
- \(S\) 是否属于 \(t^2,2t^2,10t^2,t^25^d\) 等 thin shapes。

因此任何只变换 chosen representation 的 identity，都不能自动取 contrapositive 得到 counterexample-preserving map。

## NG-5 — Gaussian affine translation 没有额外 repair freedom

若 integer matrix \(L\)、translation \(t\) 在任一 full-rank lattice coset 上满足

\[
\|Lv+t\|^2=K\|v\|^2+B,
\]

则 polynomial identity comparison 强制

\[
t=0,
\qquad B=0,
\qquad L^{\mathsf T}L=KI_2.
\]

所以这种 affine Gaussian map 只能是 pure Gaussian multiplication（或 conjugate multiplication），不能统一吸收非零 exponent residual。

### Scope limit

不排除在 lower-dimensional thin subvariety 上成立的 nonlinear identities；包中的 U9/U5/U25 正是此类。

## NG-6 — finite linear formulas 不能把 two norms 普遍压成 one norm

对 \(K,L>0\)，quadratic form

\[
K(x^2+y^2)+Lt^2
\]

rank 为 3；两个 linear forms 的 squares 之和 rank 至多为 2。故不存在 linear polynomial identity

\[
K(x^2+y^2)+Lt^2=A(x,y,t)^2+B(x,y,t)^2.
\]

有限多个这样的 linear formula 也不能覆盖所有 integer triples：各非零 difference polynomial 的乘积不能在 \(\mathbf Z^3\) 上恒为零。

四变量版本同样排除 finite linear menu 对

\[
N(u)+N(v)
\]

的 universal collapse。

## NG-7 — exact digit closure 在一个 fixed scale 至多有一个 residue branch

若 \(K\ge2\)，offsets \(C_1,\dots,C_m\) 模 \(K\) 两两不同，且

\[
K\mathcal H+C_j\subseteq\mathcal H
\quad(1\le j\le m),
\]

则 \(m\le1\)。

### Proof mechanism

迭代 \(r\) 次会产生 \(m^r\) 个不同 shifts，大小为 \(O(K^r)\)；但

\[
\#(\mathcal H\cap[0,X])=O((\log X)^2),
\]

所以该区间最多容纳 \(O(r^2)\) 个 shifts。若 \(m\ge2\) 则矛盾。

### Consequence

fixed-base exact recurrence 不可能通过多个 residue digits 覆盖所有 sufficiently large integers。

### Scope limit

不排除一个 isolated branch、不同 scales 的混合、或非-exact semantic closure；但本轮没有任何 surviving family 完成全覆盖。

## NG-8 — split-prime finite states 对 \(\mathcal S_2\) 是 blind 的

对任意 \(e\ge1\) 和任意 residue \(r\pmod{5^e}\)，该 residue class 中同时存在任意大的 norms 与任意大的 nonnorms。

- norms：用 \(-1\) 在 \(\mathbf Z/5^e\mathbf Z\) 中的 square root 解出 \(x^2+y^2\equiv r\pmod{5^e}\)；
- nonnorms：另选 \(q\equiv3\pmod4\)，用 CRT 强制 \(v_q(M)=1\)。

因此只记录 \((2+i)\)-adic、\((2-i)\)-adic 或 \(5\)-adic state，不能决定 two-square predicate。

## NG-9 — 任意固定有限 inert-prime state 仍不是 global certificate

固定有限 prime set \(Q\) 后，可以准确记录 \(v_q\bmod2\) 或 bounded valuation states；但一个 nonnorm remainder 的 odd-valuation witness 可出现在 \(Q\) 外。要把局部 states 升级成 finite reduction，仍需证明：

1. 所有 sufficiently large counterexamples 的每个 active remainder 都有 witness in \(Q\)；
2. odd valuation depth 有统一 bound。

这正是上一阶段的 `CRW(Q,E)`/uniform certificate trigger；Gaussian factorization 没有自动证明它。

## NG-10 — parity of \(c\) 不是 \(n\) 的 algebraic state

\[
8=1^2+1^2+3^0+5^1
 =2^2+0^2+3^1+5^0.
\]

同一整数同时有 even-\(c\) 与 odd-\(c\) representation。故 scale-25 的 parity split 虽覆盖所有 tagged representations，却不是由 \(n\) 唯一决定的 finite state，也不能直接用于 deterministic descent。

## NG-11 — exponent increment 为 norm 不等于可吸收

即使

\[
3^{c+r}-3^c\in\mathcal S_2
\quad\text{或}\quad
5^{d+s}-5^d\in\mathcal S_2,
\]

也只能得到“旧 norm + 新 norm”。由于 \(\mathcal S_2\) 不封闭于 addition，这不推出 one-norm representation。

精确 criteria 为

\[
3^{c+r}-3^c\in\mathcal S_2
\iff c\text{ even and }3^r-1\in\mathcal S_2,
\]

\[
5^{d+s}-5^d\in\mathcal S_2
\iff5^s-1\in\mathcal S_2.
\]

## NG-12 — isolated exact shift fibers 不等于 semantic recurrence

等式如

\[
5(3^0+5^0)=3^2+5^0,
\qquad
9(3^2+5^1)=3^0+5^3
\]

只 lifting 使用特定 shift 的 tagged representations。它们不证明

\[
\mathcal R(m)\Longrightarrow\mathcal R(Km)
\]

因为 \(m\) 的 available representation 可能不使用该 fiber。

## NG-13 — thin original-shape identities 不能承接 universal descent

U9/U5/U25E/U25O 分别要求 old norm component 属于

\[
t^25^d,
\quad10t^2,
\quad t^2,
\quad2t^2.
\]

这些 tagged families 至多有 \(O(\sqrt X(\log X)^2)\) 个参数值落在 \([1,X]\)，为 zero density。没有 normalization theorem 保证 every predecessor 具有其中一种表示形状。

## NG-14 — nonlinear square completion 是 tautological sparse image

\[
G(n)=(Kn-h')^2+h'
\]

对每个 \(n\) 都可表示，但正因如此其 image 不含 counterexamples；而且 image 为 sparse quadratic set。它既不能覆盖 arbitrary large counterexample，也不给出 \(F(n)<n\)。

## 15. no-go synthesis

本轮同时排除了以下自然组合：

- pure Gaussian multiplication + finite residual repair；
- affine translation repair；
- finite linear collapse of two norms；
- fixed-scale multi-residue exact recurrence；
- common \(5/9\) Gaussian division；
- representation-parity finite state；
- thin-family recurrence 直接转 minimal descent。

仍未排除的逻辑空间仅包括：

- 单一 exact shift branch 与其他完全不同机制的组合；
- genuinely nonlinear、integer-level、全覆盖 map；
- 新的 uniform finite bad-prime certificate theorem；
- 特定 exponent-correlated subvariety 上的非线性 one-norm collapse。

本轮未发现这些方向的 promotable first lemma。
