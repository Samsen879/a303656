# SHIFT LANGUAGE DEFINITIONS

## 1. Exponent presentation

For \(L\subseteq\mathbf N^2\), define

\[
\mathcal H(L)=\{3^c+5^d:(c,d)\in L\}.
\]

Different exponent pairs can occasionally produce the same value; all statements are made at the value-set level, while S-unit classification is applied to every exponent quadruple witnessing an inclusion.

## 2. Axis fibers

A vertical fiber is

\[
V_{c_0}=\{(c_0,d):d\ge0\},
\]

and a horizontal fiber is

\[
H_{d_0}=\{(c,d_0):c\ge0\}.
\]

Their shift languages are

\[
\mathcal H(V_{c_0})=\{3^{c_0}+5^d:d\ge0\},
\]

\[
\mathcal H(H_{d_0})=\{3^c+5^{d_0}:c\ge0\}.
\]

The S-unit classification proves that these are the only possible infinite affine fibers for \(K\ge2\), up to finitely many accidental points.

## 3. Linear and semilinear exponent sets

A linear set has the form

\[
b+\mathbf Np_1+\cdots+\mathbf Np_t\subseteq\mathbf N^2.
\]

A semilinear set is a finite union of linear sets. Ginsburg–Spanier identify semilinear subsets of \(\mathbf N^k\) with Presburger-definable sets and give effective conversion between the descriptions.

For this project:

- rank-zero components are finite;
- an infinite component with all periods parallel to \((0,1)\) is a finite union of vertical rays after adjusting finite prefixes;
- an infinite component with all periods parallel to \((1,0)\) is horizontal;
- a component containing a period \((p,q)\) with \(p,q>0\) contains a genuinely two-coordinate ray;
- a component with independent horizontal and vertical periods contains a rank-two grid.

The affine S-unit theorem eliminates the latter two possibilities for \(K\ge2\).

## 4. Exponent congruence states

A typical state has

\[
L_{r,s}^{u,v}=\{(c,d):c\equiv r\pmod u,\ d\equiv s\pmod v\}.
\]

This is rank two and contains non-axis rays. Therefore no fixed affine map \(K(3^c+5^d)+C\) with \(K\ge2\) can carry the whole state into \(\mathcal H\).

The failure is theorem-level, not merely a bounded search observation.

## 5. Automatic/recognisable states

Automatic exponent languages can be more general than semilinear languages. Cobham-type theorems apply when the same set is recognisable in two multiplicatively independent bases; a single arbitrary automaton is not automatically semilinear.

Nevertheless, the affine fiber classification does not require semilinearity: for fixed \(K,C\), every infinite solution set is contained, up to a finite set, in finitely many horizontal or vertical fibers. Hence any automatic state that participates in an exact affine inclusion must collapse to this axis-fiber geometry.

## 6. Finite exceptions

A state may add or delete a fixed finite set of shifts. Such modifications do not alter:

- the S-unit classification of infinite components;
- the entropy lower bound for complete path coverage;
- the polylogarithmic counting bound for \(\mathcal H\).

Finite exceptions can change finitely many low inputs only and must be handled explicitly by terminal verification.

## 7. Gaussian algebraic states

A state may record a fixed Gaussian unit, conjugation choice, parity, or bounded residue information. Such a state is valid only if it is determined without selecting an unknown representation.

In particular, the parity of the exponent \(c\) in one representation is not a state of the integer: the same integer can possess representations with different \(c\)-parity. Representation tags may be useful for identities, but not for deterministic minimal-counterexample descent unless every possible representation is handled.
