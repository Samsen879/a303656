# CANDIDATE DESCENT SYSTEMS

## Candidate 1 — vertical fiber automaton

Use states indexed by finitely many fixed \(c_0\) and transitions

\[
5^s(3^{c_0}+5^d)+C=3^{u_0}+5^{d+s}.
\]

**Strength:** exact, infinite, representation-independent within the state.

**Failure:** every domain has \(C\not\equiv0\pmod5\); multiples of 5 are not covered by vertical branches. A finite state graph cannot repair this with complete coverage, by the entropy theorem.

Classification: `PROVED PARTIAL IDENTITY / NO DESCENT SYSTEM`.

## Candidate 2 — horizontal fiber automaton

Use states indexed by fixed \(d_0\) and norm scales \(K=3^{2t}\).

**Strength:** exact axis identities.

**Failure:** every domain has \(C\not\equiv0\pmod3\). Multiples of 3 are uncovered; mixed vertical/horizontal branches still leave multiples of 15 uncovered in the infinite-semilinear class.

Classification: `PROVED PARTIAL IDENTITY / NO DESCENT SYSTEM`.

## Candidate 3 — mixed axis graph

Combine vertical and horizontal states, possibly at different scales.

**Failure:** direct residue obstruction leaves multiples of 15 when all child languages are infinite semilinear. Allowing finite or arbitrary states does not help: the entropy–sparsity theorem rules out complete tail coverage for every finite nonvacuous exact affine graph.

Classification: `FALSE AS COMPLETE SYSTEM`.

## Candidate 4 — exponent congruence automaton

States remember \(c\bmod u\) and \(d\bmod v\).

**Failure:** each such infinite state contains rank-two semilinear components and genuinely two-coordinate rays. S-unit classification proves no \(K\ge2\) affine inclusion can hold on the entire state.

Classification: `THEOREM-LEVEL NO-GO`.

## Candidate 5 — parity/Gaussian orientation states

States remember parity of \(c\), a Gaussian factor, or a chosen orientation of a norm representation.

**Failure:** these tags are generally properties of a chosen representation, not of the integer. Minimality does not allow selecting the favorable witness. Full-rank affine Gaussian translations reduce to pure norm scaling and the already classified shift equation.

Classification: `QUANTIFIER-INVALID OR REDUCED TO CLOSED CLASS`.

## Candidate 6 — finite accidental-shift states

Use finitely many isolated identities discovered by search.

**Failure:** finite source languages lead to singleton/finite states; they cannot cover tails without vacuous empty branches, and complete finite-state iteration is forbidden by entropy–sparsity.

Classification: `FINITE ACCIDENTS / NO GLOBAL PAYOFF`.

## Candidate 7 — nonlinear one-norm Gaussian map

Seek a nonlinear coordinate identity that maps every representation in a state to one norm plus one new shift.

**Status:** no formal candidate. Existing identities work only on thin norm shapes or output two norms. A general nonlinear rigidity theorem was not proved, so this remains the only logically open subdirection within the broad Gaussian theme.

Classification: `SPECULATIVE; NO PHASE-B SPECIFICATION`.

## Scorecard

| Candidate | Exact closure | Representation-independent | Complete coverage | Terminal soundness | Verdict |
|---|---:|---:|---:|---:|---|
| Vertical fibers | yes | yes within state | no | not reached | stop |
| Horizontal fibers | yes | yes within state | no | not reached | stop |
| Mixed axis graph | yes locally | yes | theorem says impossible | not reached | stop |
| Exponent congruence states | no | yes | no | no | stop |
| Gaussian parity/orientation | tagged only | no | no | no | stop |
| Finite accidents | finite only | yes | no | no | stop |
| Nonlinear one-norm map | not found | unknown | unknown | unknown | speculative watch only |
