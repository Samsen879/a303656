# REPRODUCE

## Requirements

- CPython 3.11 or newer;
- no third-party packages;
- Linux/macOS/Windows with a UTF-8 filesystem;
- no network required for replay or validation.

## 1. Replay exact experiments

From the package root:

```bash
python3 scripts/replay.py --root .
```

The script regenerates `results/experiments.json` in a temporary directory and compares bytes and SHA256.

## 2. Validate package

```bash
python3 scripts/validate_package.py --root .
```

Checks include:

- required paths;
- JSON parsing and verdict invariants;
- UTF-8 decoding;
- LF normalization;
- C0/DEL control-character scan;
- internal `MANIFEST.sha256`;
- experiment replay;
- POSIX rwx permission bits when supported (inherited setgid/sticky bits on extraction parents are ignored).

## 3. Build deterministic ZIP

```bash
python3 scripts/build_deterministic_zip.py \
  --root . \
  --output ../A303656_FINITE_STATE_MULTIBRANCH_DESCENT_PHASE_A_REBUILD.zip
```

ZIP policy:

- fixed timestamp `2000-01-01 00:00:00`;
- sorted entries;
- root directory included;
- directories mode `0755`;
- scripts mode `0755`;
- other files mode `0644`;
- `ZIP_STORED` to avoid compressor-version variance;
- UTF-8 names.

## 4. Byte-identical two-build test

```bash
python3 scripts/release.py \
  --root . \
  --output-a ../rebuild-a.zip \
  --output-b ../rebuild-b.zip \
  --report ../release-report.json
```

The release script rewrites the manifest deterministically, validates, builds twice, and requires identical bytes.

## 5. Trust boundary

Replay validates the package's deterministic computations and artifact integrity. It does not turn bounded experiments into proofs. The proofs are in `PROVED_LEMMAS.md`, `S_UNIT_CLASSIFICATION.md`, and `MULTIBRANCH_COVERAGE.md`.
