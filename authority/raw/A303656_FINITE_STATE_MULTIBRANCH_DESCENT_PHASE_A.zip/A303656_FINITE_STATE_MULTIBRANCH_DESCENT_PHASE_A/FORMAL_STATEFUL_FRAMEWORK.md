# FORMAL STATEFUL FRAMEWORK

## 1. Base objects

\[
\mathcal S_2=\{a^2+b^2:a,b\in\mathbf Z_{\ge0}\},
\qquad
\mathcal H=\{3^c+5^d:c,d\in\mathbf Z_{\ge0}\}.
\]

A finite state system consists of a finite set \(\Sigma\), an initial state \(\sigma_0\), and shift languages

\[
\mathcal H_\sigma\subseteq\mathcal H,
\qquad
\mathcal H_{\sigma_0}=\mathcal H.
\]

Define

\[
R_\sigma(n)\iff n\in\mathcal S_2+\mathcal H_\sigma,
\qquad
P_\sigma(n)\iff\neg R_\sigma(n).
\]

## 2. Exact affine transition

An edge \(e:\sigma\to\tau\) has integers

\[
K_e\in\mathcal S_2,\quad K_e\ge2,\quad C_e\in\mathbf Z,
\]

and forward map

\[
\phi_e(m)=K_em+C_e.
\]

The natural exact closure is

\[
K_e\mathcal H_\tau+C_e\subseteq\mathcal H_\sigma.
\tag{SC-e}
\]

Because multiplication by \(K_e\in\mathcal S_2\) preserves \(\mathcal S_2\), `(SC-e)` implies

\[
R_\tau(m)\Longrightarrow R_\sigma(\phi_e(m)).
\tag{FC-e}
\]

On the congruence domain

\[
D_e\subseteq\{n:n\equiv C_e\pmod{K_e}\},
\]

define

\[
F_e(n)=\frac{n-C_e}{K_e}.
\]

Contraposition gives

\[
P_\sigma(n)\Longrightarrow P_\tau(F_e(n))
\qquad(n\in D_e).
\tag{BAD-e}
\]

No representation witness is selected: `(SC-e)` quantifies over the entire child shift language.

## 3. Composed paths

For a path \(p=e_1\cdots e_r\), write

\[
\phi_p=\phi_{e_1}\circ\cdots\circ\phi_{e_r}
       =K_px+C_p,
\]

where

\[
K_p=\prod_{j=1}^r K_{e_j}\ge2^r.
\]

The corresponding sequential congruences reduce to one cylinder

\[
n\equiv C_p\pmod{K_p}.
\]

Exact closure composes:

\[
\phi_p(\mathcal H_{\operatorname{end}(p)})
\subseteq\mathcal H_{\operatorname{start}(p)}.
\]

## 4. Complete coverage

The **strong complete-tail target specified for this Phase-A route** demands, for every reachable state \(\sigma\), an \(N_\sigma\) such that

\[
(n>N_\sigma)\Longrightarrow
n\in\bigcup_{e\in\operatorname{Out}(\sigma)}D_e,
\tag{COV-}\sigma
\]

and each selected inverse is integral, positive, and strictly smaller than \(n\).

For any fixed path depth \(r\), sufficiently large initial \(n\) remains above all intermediate state thresholds. Hence length-\(r\) path cylinders must cover a tail of the integers.

## 5. Terminal soundness: missing from the naive framework

The inclusion \(\mathcal H_\sigma\subseteq\mathcal H\) gives

\[
R_\sigma(n)\Longrightarrow R_{\sigma_0}(n),
\qquad
P_{\sigma_0}(n)\Longrightarrow P_\sigma(n),
\]

but **not** the reverse implication \(P_\sigma(n)\Rightarrow P_{\sigma_0}(n)\).

Therefore repeated descent only proves that an original counterexample produces a bounded **state-bad pair** \((\sigma,m)\). To conclude A303656, one must additionally provide one of:

- state-specific finite verification of \(R_\sigma(m)\) for every reachable terminal pair;
- an explicit decoder from state-badness to original badness;
- a path that returns to an equivalent copy of the initial language.

Checking only original representability below one bound is insufficient.

## 6. Empty and singleton states

If \(\mathcal H_\sigma=\varnothing\), then \(P_\sigma(n)\) is true for every integer. An edge into such a state is a vacuous implication and cannot end a contradiction proof.

If \(\mathcal H_\sigma=\{h\}\) and all successor languages are nonempty, exact closure forces each successor to be a singleton \(\{x_e\}\) and

\[
C_e=h-K_ex_e.
\]

Every outgoing domain is then contained in \(n\equiv h\pmod{K_e}\). A finite union of these classes cannot cover a tail: choose a large prime \(q\) dividing none of the \(K_e\) and set \(n=h+q\). Hence a nonvacuous complete-tail system cannot have a reachable singleton state.

## 7. Sound system used in the no-go theorem

The no-go theorem assumes:

1. finite reachable \(\Sigma\);
2. finite transition set;
3. all reachable \(\mathcal H_\sigma\ne\varnothing\);
4. exact affine shift closure `(SC-e)`;
5. \(K_e\ge2\);
6. complete tail coverage `(COV-σ)`;
7. no use of empty-state badness as a terminal certificate.

These are the requirements of the proposed complete-tail multi-branch route. A weaker scheme that covers only state-bad integers by separately proving all uncovered residue classes representable is not covered by this theorem; such a scheme would need an additional semantic representability theorem and was not found.
