# S-UNIT CLASSIFICATION

## 1. Fixed affine equation

Fix \(K\ge2\) and \(C\in\mathbf Z\). We study exponent quadruples satisfying

\[
K3^c+K5^d+C-3^u-5^v=0.
\tag{E}
\]

After the fixed coefficients are separated, the variable tuples lie in a finite-rank subgroup generated coordinatewise by 3 and 5. This is exactly the setting of the finite-rank unit-equation theorem.

## 2. Finite-rank partition lemma

The Evertse–Schlickewei–Schmidt theorem bounds the number of nondegenerate solutions of a fixed linear equation in a finite-rank multiplicative group. We use the following standard corollary, with the short reduction included to make the dependency explicit.

> **Projective partition lemma.** Fix nonzero coefficients \(a_1,\ldots,a_m\) and finitely generated multiplicative subgroups from which the variables \(x_i\) are drawn. The solutions of
> \[
> \sum_{i=1}^m a_ix_i=0
> \]
> lie in finitely many projective families. In each family there is a set partition of \(\{1,\ldots,m\}\) into minimal zero-sum blocks; inside every block all ratios \((a_ix_i)/(a_jx_j)\) are fixed.

To prove it, assign to each solution a partition into inclusion-minimal zero-sum blocks. There are finitely many set partitions. In one block, divide by one chosen term. The remaining ratios lie in a finite-rank multiplicative group and satisfy a nondegenerate normalized unit equation; ESS gives only finitely many ratio tuples. Repeating over the finitely many blocks and partitions gives the claimed finite list. The common multiplier of a block may vary, which is exactly the projective freedom retained by the lemma.

## 3. Classification theorem

### Theorem — Affine S-unit Fiber Classification

For fixed \(K\ge2,C\in\mathbf Z\), the set

\[
L_{K,C}=\{(c,d)\in\mathbf N^2:
K(3^c+5^d)+C=3^u+5^v
\text{ for some }u,v\ge0\}
\]

is, up to a finite exceptional set, a finite union of exactly one of the following two types.

#### Vertical type

\[
K=5^s\quad(s\ge1),
\]

and for finitely many pairs \((c_0,u_0)\),

\[
K3^{c_0}+C=3^{u_0}.
\]

For every \(d\ge0\),

\[
K(3^{c_0}+5^d)+C=3^{u_0}+5^{d+s}.
\tag{V}
\]

#### Horizontal type

\[
K=3^r\quad(r\ge1),
\]

and for finitely many pairs \((d_0,v_0)\),

\[
K5^{d_0}+C=5^{v_0}.
\]

For every \(c\ge0\),

\[
K(3^c+5^{d_0})+C=3^{c+r}+5^{v_0}.
\tag{H}
\]

If \(K\) is neither a power of 3 nor a power of 5, then \(L_{K,C}\) is finite.

### Proof

Apply the partition lemma to the five signed terms

\[
K3^c,\quad K5^d,\quad C,\quad -3^u,\quad -5^v,
\]

omitting the constant term if \(C=0\).

In one projective family, suppose \(c\) varies. The term \(K3^c\) cannot lie in a fixed-ratio block with the constant term or with a power of 5: either would force \(c\) to be fixed, since

\[
3^{c-c'}=5^{d-d'}
\]

implies both exponent differences are zero. Therefore its zero-sum block must be the pair

\[
K3^c-3^u=0.
\]

Hence \(u-c=r\) is fixed and \(K=3^r\). Similarly, if \(d\) varies, its block must be

\[
K5^d-5^v=0,
\]

so \(K=5^s\).

Both \(c\) and \(d\) cannot vary in the same family when \(K\ge2\), because that would require

\[
K=3^r=5^s,
\]

forcing \(K=1\). Hence every positive-dimensional family is horizontal or vertical. The remaining equation gives the fixed-axis condition in `(H)` or `(V)`.

There are only finitely many axis fibers. For example, in the vertical case

\[
3^{u_0}-5^s3^{c_0}=C.
\]

If \(C=0\), unique factorization makes this impossible for \(s\ge1\). If \(C\ne0\), at least one of \(u_0,c_0\) is bounded by the 3-adic valuation of \(C\); monotonicity then leaves finitely many possibilities. The horizontal argument is symmetric. All remaining projective families are zero-dimensional and form the finite exceptional set. ∎

## 4. Norm-scale restriction

When \(K\in\mathcal S_2\):

- every \(5^s\) is allowed;
- \(3^r\in\mathcal S_2\) iff \(r\) is even, because 3 is \(3\pmod4\).

Thus horizontal exact branches have \(K=3^{2t}\).

## 5. Consequences for semilinear states

An infinite linear exponent component contained in a finite union of axis lines must have every nonzero period parallel to one axis. Hence:

- a non-axis ray \((c_0+pt,d_0+qt)\), \(p,q>0\), admits no infinite exact affine inclusion with \(K\ge2\);
- a rank-two exponent grid admits none;
- an exponent-congruence state admits none;
- under one fixed affine map, infinite vertical and horizontal components cannot coexist.

## 6. Effectivity audit

ESS supplies an explicit count of nondegenerate normalized solutions, not an exponent-height bound. The structural classification of infinite components is nevertheless exact because only fixed-ratio blocks can be infinite.

For fixed numerical \(K,C\), effective S-unit/linear-forms methods can in principle bound and enumerate the finite accidental set, although the bounds may be enormous. This does not give an a priori bound on all possible \(K,C\) or on the size of an unknown state system.
