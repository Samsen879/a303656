# MULTIBRANCH COVERAGE

## 1. Path cylinders

A length-\(r\) path has composed map

\[
\phi_p(x)=K_px+C_p,
\qquad K_p\ge2^r.
\]

Its actual sequential inverse domain is contained in one residue class modulo \(K_p\). Therefore that domain has upper asymptotic density at most

\[
\frac1{K_p}\le2^{-r}.
\]

## 2. Entropy lower bound

For fixed \(r\), complete tail coverage at every intermediate state implies that all usable length-\(r\) path domains from a starting state cover a tail of the integers. Group these path domains by their **distinct residue cylinders**, and let \(\mathcal C_r\) be the resulting finite cylinder set.

Every grouped union remains inside its cylinder, so it has upper density at most \(2^{-r}\). Since the total union contains a tail,

\[
1\le
\sum_{Q\in\mathcal C_r}\overline d(Q)
\le |\mathcal C_r|2^{-r}.
\]

Consequently

\[
|\mathcal C_r|\ge2^r.
\tag{ENT}
\]

Two distinct cylinders cannot arise from one identical composed affine map. Therefore the number of distinct composed maps is also at least \(2^r\). Grouping is essential: merely counting syntactically different paths would not exclude duplicate maps. No disjointness assumption is used; overlaps only make coverage harder.

## 3. Sparsity upper bound

For \(X\ge2\),

\[
|\mathcal H\cap[1,X]|
\le(1+\lfloor\log_3X\rfloor)
   (1+\lfloor\log_5X\rfloor)
=O((\log X)^2).
\tag{SP}
\]

A reachable nonvacuous complete state cannot be singleton; fix two distinct shifts

\[
x_\tau,y_\tau\in\mathcal H_\tau
\]

for every reachable endpoint state \(\tau\).

For a path ending at \(\tau\), exact closure gives

\[
\phi_p(x_\tau),\phi_p(y_\tau)\in\mathcal H.
\]

Let

\[
K_{\max}=\max_e K_e,
\qquad C_{\max}=\max_e|C_e|.
\]

For any fixed integer \(z\), forward composition satisfies

\[
|\phi_p(z)|
\le K_{\max}^r|z|
+C_{\max}\frac{K_{\max}^r-1}{K_{\max}-1}.
\]

Thus both positive image shifts are at most \(A_\tau K_{\max}^r\) for a state-dependent constant \(A_\tau\). By `(SP)`, each image has only \(O(r^2)\) possibilities and the ordered pair has \(O(r^4)\) possibilities.

An affine map is uniquely determined by its images at two distinct points. Hence only \(O(r^4)\) distinct maps can end at \(\tau\). Summing over the finite state set gives

\[
\#\{\text{distinct depth-}r\text{ composed maps}\}
=O_\Sigma(r^4),
\tag{PAIR}
\]

contradicting `(ENT)` for all sufficiently large \(r\).

## 4. Theorem

### Entropy–Sparsity Finite-State No-Go Theorem

No finite nonvacuous exact affine shift-language descent system with \(K_e\ge2\) can have all-integer complete sufficiently-large congruence coverage at every reachable state.

## 5. Robustness

The proof allows:

- different scales and offsets on every edge;
- overlapping congruence domains;
- arbitrary domain subsets inside the required integrality class;
- arbitrary state languages, not only semilinear or automatic;
- fixed finite additions or deletions in state languages;
- cycles in the state graph, since forward scales still grow along paths.

It uses only finite-state bounded parameters, exact shift closure, nonvacuity, and the strong all-integer tail-coverage requirement.

## 6. Scope boundary

A weaker proposal might cover only state-bad integers and separately prove that every uncovered congruence class is representable. The theorem above does not rule out that semantic hybrid, because its extra representability theorem could destroy the density lower bound. No such theorem was found in this round.

Likewise, density-one coverage is not pointwise descent for every counterexample and does not meet the specified promotion standard.
