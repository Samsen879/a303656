# LITERATURE AUDIT

## Audit rule

Primary sources were preferred. For every theorem the audit separates:

- exact qualitative statement;
- effective solution **count** versus effective exponent/height bound;
- fixed coefficients versus a transition architecture whose coefficients are unknown;
- isolated solutions versus infinite parametric families;
- whether the theorem classifies an inclusion or merely proves finiteness in one equation.

Canonical identifiers and links are recorded in `results/literature_sources.json`.

## 1. Evertse–Schlickewei–Schmidt: finite-rank unit equations

**Primary source:** J.-H. Evertse, H. P. Schlickewei, W. M. Schmidt, *Linear equations in variables which lie in a multiplicative group*, Annals of Mathematics 155 (2002), 807–836.

**Exact statement used.** For a subgroup \(\Gamma\subset(K^*)^n\) of finite rank \(r\), the number of nondegenerate solutions of

\[
a_1x_1+\cdots+a_nx_n=1,
\qquad x\in\Gamma,
\]

is at most

\[
\exp((6n)^{3n}(r+1)).
\]

**Effective status.** The number of nondegenerate solutions is explicitly bounded. The theorem does not give a usable exponent-height bound for every solution.

**Variables and coefficients.** The number of terms and coefficients are fixed; the variables range over one finite-rank multiplicative group.

**Infinite families.** Degenerate solutions may occur in infinite projective families. They must be split into minimal zero-sum blocks. This package performs that block classification and obtains the axis fibers.

**Task payoff.** This is the decisive external theorem behind `Affine S-unit Fiber Classification`. It classifies every infinite component for each fixed \((K,C)\), but does not bound all possible transition parameters of an unknown automaton.

## 2. Laurent: Mordell–Lang for algebraic tori

**Primary source:** M. Laurent, *Équations diophantiennes exponentielles*, Inventiones Mathematicae 78 (1984), 299–327, DOI 10.1007/BF01388597.

**Exact structural statement.** If \(X\) is a subvariety of an algebraic torus and \(\Gamma\) is a finitely generated subgroup (or its division group in the standard formulation), then \(X\cap\Gamma\) is contained in a finite union of torus cosets lying in \(X\).

**Effective status.** Laurent's original theorem is qualitative. Later quantitative work bounds the number of cosets under fixed geometric data, but does not by itself enumerate exponent tuples here.

**Infinite families.** The theorem predicts that every infinite solution component comes from an algebraic subgroup/coset identity.

**Task payoff.** It conceptually validates the ESS block approach. The specific cosets inside the five-term hyperplane still have to be classified; Laurent alone does not say that they are horizontal or vertical.

## 3. Effective S-unit equations

**Primary sources:** J.-H. Evertse and K. Győry, *Effective results for unit equations over finitely generated domains*; A. Bérczes, J.-H. Evertse and K. Győry, *Effective results for linear equations in two unknowns from a multiplicative division group*.

**Exact scope.** For a fixed finitely generated domain/group, fixed coefficients, and a two-variable unit equation, explicit height bounds can be obtained.

**Effective status.** Effective for the fixed numerical input. The constants can be enormous.

**Task payoff.** In principle, these results can enumerate the finite accidental solutions for one fixed \((K,C)\). They do not yield a finite range for all unknown \(K,C\), state counts, moduli, or automata. Hence “effective S-unit” does not turn the global system search into a bounded computation.

## 4. Linear forms in logarithms

**Primary source audited:** E. M. Matveev, *An explicit lower bound for a homogeneous rational linear form in the logarithms of algebraic numbers. II*, Izvestiya: Mathematics 64 (2000), 1217–1269.

**Exact scope.** A nonzero linear form in logarithms of fixed algebraic numbers with integer coefficients has an explicit lower bound in terms of degrees, heights, the number of logarithms, and coefficient size.

**Effective status.** Fully explicit for fixed input data.

**Task payoff.** Baker–Matveev methods can bound exponents in a fixed accidental exponential equation. They do not classify positive-dimensional families as cleanly as the ESS block argument, and they provide no bound on the architecture of an unknown finite-state system.

## 5. Skolem–Mahler–Lech and exponential-polynomial zero sets

**Primary/modern source:** Jason P. Bell, *A generalised Skolem–Mahler–Lech theorem for affine varieties*, Journal of the London Mathematical Society 73 (2006).

**Exact statement.** The zero set of a fixed characteristic-zero linear recurrence is a finite union of arithmetic progressions and a finite set. Bell's orbit version gives the analogous finite-union statement for intersections of an automorphism orbit with a subvariety.

**Effective status.** The classical qualitative theorem generally does not supply the explicit exceptional range needed for this project.

**Variables and coefficients.** One fixed one-dimensional recurrence/orbit is essential.

**Task payoff.** A one-parameter specialization of the affine equation may fall under recurrence methods. The full relation

\[
K3^c+K5^d+C=3^u+5^v
\]

has four exponent variables and moving specializations. SML does not classify the universal two-dimensional inclusion. Laurent/ESS are the correct multivariate tools.

## 6. Primitive divisors

**Primary source:** Y. Bilu, G. Hanrot, P. M. Voutier, *Existence of primitive divisors of Lucas and Lehmer numbers*, J. reine angew. Math. 539 (2001), 75–122, DOI 10.1515/crll.2001.080.

**Exact statement used in the audit.** Every Lucas or Lehmer term with index \(n>30\) has a primitive divisor.

**Effective status.** Explicit in the fixed-sequence setting, including finite small-index exceptions.

**Task payoff.** Differences arising in this project form a changing two-parameter family rather than one fixed Lucas/Lehmer sequence. Primitive-divisor theory can eliminate selected candidate recurrences but does not classify all affine inclusions or prove residue coverage.

## 7. Semilinear sets and Presburger arithmetic

**Primary source:** S. Ginsburg, E. H. Spanier, *Semigroups, Presburger formulas, and languages*, Pacific Journal of Mathematics 16 (1966), 285–296.

**Exact statement.** Semilinear subsets of \(\mathbf N^n\) are exactly Presburger-definable subsets, and each description can be effectively converted to the other.

**Effective status.** Effective at the language-description level.

**Task payoff.** This formalizes the permitted semilinear exponent states and their period geometry. It does not linearize the value map \((c,d)\mapsto3^c+5^d\), so it cannot prove an affine inclusion without S-unit input.

## 8. Cobham–Semenov rigidity and recognisable subsets of \(\mathbf N^2\)

**Primary sources:** A. Cobham, *On the base-dependence of sets of numbers recognizable by finite automata* (1969); A. L. Semenov, *Presburgerness of predicates regular in two number systems* (1977).

**Exact scope.** In one dimension, recognition in two multiplicatively independent bases forces ultimate periodicity. Semenov gives the multidimensional Presburger analogue.

**Effective status.** The original statements are structural; later constructive/quantitative variants exist under additional hypotheses.

**Critical hypothesis.** The same set must be recognisable in two independent systems. A language recognised by one arbitrary fixed automaton need not be semilinear.

**Task payoff.** Cobham–Semenov cannot be invoked merely because the values contain bases 3 and 5. The affine fiber theorem is stronger for this task: it constrains any source language once its values satisfy one fixed exact inclusion.

## 9. Existential Presburger arithmetic with two power predicates

**Primary source:** T. Karimov, F. Luca, J. Nieuwveld, J. Ouaknine, J. Worrell, *On the Decidability of Presburger Arithmetic Expanded with Powers*, SODA 2025; arXiv:2407.05191.

**Exact statement.** For fixed integers \(\alpha,\beta>1\), the existential fragment of

\[
\langle\mathbf Z;0,1,<,+,\alpha^{\mathbf N},\beta^{\mathbf N}\rangle
\]

is decidable.

**Effective status.** Decidable for each fixed existential formula.

**Task payoff.** A universal language inclusion is not one existential query, the unknown transition system is not fixed in advance, and the sum-of-two-squares predicate is absent. The theorem does not generate complete descent or a uniform parameter bound.

## 10. Two-base linear-exponential equations

The fixed equation in this round is a finite-rank S-unit equation, so ESS/Laurent subsume the qualitative finiteness and family structure needed here. Specialized papers on equations such as \(a3^x-b5^y=c\) may give sharper effective bounds, but their fixed coefficients and one- or two-variable form do not classify a finite graph with unknown transitions.

**Conclusion for this category:** no audited two-base theorem gives more route leverage than the proved ESS fiber classification.

## 11. Norm-form recurrences and Gaussian identities

Norm multiplicativity in \(\mathbf Z[i]\) gives exact scalar transformations. Full-rank affine Gaussian maps are classified directly in `GAUSSIAN_NORM_TRANSFORMATIONS.md`. Recurrence and primitive-divisor results apply only after a fixed one-dimensional sequence has been isolated.

No primary theorem audited here converts a general two-norm identity into a single norm or guarantees that an arbitrary representation lies in the thin norm shapes used by known nonlinear identities.

## 12. Affine self-embeddings of sparse exponential sets

No primary source located in this audit states the exact needed theorem for

\[
\mathcal H=\{3^c+5^d\}.
\]

The package therefore does not cite a generic “sparse self-embedding theorem.” Instead it proves two task-specific results:

1. ESS classifies every infinite fixed affine branch into axis fibers;
2. the internal entropy–sparsity argument rules out any finite complete-tail graph, using only \(|\mathcal H\cap[1,X]|=O((\log X)^2)\).

This distinction prevents an unsupported literature analogy from being promoted as a theorem.

## Literature conclusion

The literature is sufficient to support a strong **negative classification** of exact affine transitions. It supplies neither:

- a representation-independent nonlinear one-output-norm transformation;
- an independent theorem proving all uncovered residues representable;
- complete finite-state coverage;
- nor a terminal decoder from state-badness to original badness.

There is no literature-supported, bounded Phase B for this route.
