# PROVED LEMMAS AND THEOREMS

## P1 — Norm-scale invariance

If \(K\in\mathcal S_2\), then

\[
m\in\mathcal S_2\iff Km\in\mathcal S_2.
\]

Proof: Fermat's two-square criterion and even valuation of every prime \(3\pmod4\) in \(K\).

## P2 — Stateful contrapositive

If

\[
K\mathcal H_\tau+C\subseteq\mathcal H_\sigma,
\]

then

\[
P_\sigma(n),\quad n\equiv C\pmod K
\Longrightarrow
P_\tau\!\left(\frac{n-C}{K}\right).
\]

This implication is independent of unknown representation witnesses.

## P3 — Terminal-soundness necessity

From \(\mathcal H_\sigma\subseteq\mathcal H\) one has

\[
P_{\sigma_0}(n)\Rightarrow P_\sigma(n),
\]

but not conversely. Therefore a bounded state-bad pair is not automatically a bounded original counterexample. State-specific terminal verification or an explicit decoder is necessary.

## P4 — Empty-state vacuity

If \(\mathcal H_\sigma=\varnothing\), then \(P_\sigma(n)\) holds for every \(n\). Such a state cannot discharge a finite proof and must not be counted as a successful terminal branch.

## P5 — Singleton-state coverage obstruction

A reachable singleton state with nonempty successors cannot have finitely many outgoing exact affine domains covering a tail. Proof: all domains are contained in classes \(n\equiv h\pmod{K_e}\); choose \(n=h+q\) with a large prime \(q\) dividing no \(K_e\).

## P6 — S-unit projective partition lemma

For a fixed linear equation in a finite-rank multiplicative group, all solutions lie in finitely many families determined by partitions into zero-sum blocks with fixed term ratios inside each block.

Proof: apply the ESS finiteness theorem to nondegenerate normalized solutions and induct on proper vanishing subsums.

## P7 — Affine S-unit Fiber Classification

For fixed \(K\ge2,C\), all but finitely many source pairs satisfying

\[
K(3^c+5^d)+C\in\mathcal H
\]

lie on finitely many vertical fibers if \(K\) is a power of 5, or finitely many horizontal fibers if \(K\) is a power of 3. Otherwise there are only finitely many solutions.

Full proof: `S_UNIT_CLASSIFICATION.md`.

## P8 — No non-axis semilinear affine branch

No non-axis ray, rank-two linear component, or exponent-congruence state has an infinite exact affine inclusion with \(K\ge2\).

This follows immediately from P7.

## P9 — Axis residue obstruction

Every infinite vertical branch has a domain avoiding multiples of 5; every infinite horizontal branch has a domain avoiding multiples of 3. Therefore finite unions of infinite semilinear axis branches leave all multiples of 15 uncovered.

## P10 — Exponential cylinder/map lower bound

After grouping all usable depth-\(r\) path domains by their distinct residue cylinders, complete tail coverage requires at least \(2^r\) cylinders. Every grouped union has upper density at most \(2^{-r}\), and distinct cylinders require distinct composed affine maps.

## P11 — Polynomial image-pair upper bound

For any fixed finite exact affine state graph with all reachable states containing two shifts, the number of distinct depth-\(r\) composed maps is \(O(r^4)\). Each map is determined by two image shifts, and \(\mathcal H\) has \(O((\log X)^2)\) elements up to \(X\).

## P12 — Entropy–Sparsity Finite-State No-Go Theorem

P10 and P11 contradict one another for large \(r\). Therefore no nonvacuous finite exact affine shift-language state system with \(K_e\ge2\) can satisfy complete tail coverage at every reachable state.

## P13 — Gaussian affine rigidity

On a full-rank lattice coset,

\[
\|Lv+t\|^2=K\|v\|^2+B
\]

forces \(t=0,B=0,L^{\mathsf T}L=KI\). Hence affine Gaussian transformations reduce to multiplication/conjugation by a Gaussian integer and do not evade P7/P12.
