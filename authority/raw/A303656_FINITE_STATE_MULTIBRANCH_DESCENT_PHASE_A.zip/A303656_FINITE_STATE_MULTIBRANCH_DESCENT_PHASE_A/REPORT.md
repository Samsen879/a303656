# REPORT

## 1. Research question

Can one replace the failed single-branch Gaussian descent by a finite state graph whose branches use exact affine/norm transformations, cover every sufficiently large integer, and preserve counterexample badness without knowing a representation witness?

## 2. Answer

Within the natural exact affine shift-language framework, **no**. The route is not merely missing a clever automaton: complete coverage and shift sparsity are incompatible.

## 3. First correction: state badness is not original badness

A state language is usually a proper subset of \(\mathcal H\). Therefore an integer may fail to use that state language while still possessing a representation using another shift. The naive final step from bounded \(P_\sigma\) to bounded \(P\) is invalid.

This forces a terminal-soundness layer absent from the bare state transition definition.

## 4. S-unit rigidity

For a fixed affine map, the equation

\[
K3^c+K5^d+C=3^u+5^v
\]

is a fixed linear equation in finite-rank multiplicative variables. ESS finiteness of nondegenerate solutions, followed by degenerate-block analysis, proves that every infinite component must pair same-base terms exactly.

Thus the only infinite branches are:

\[
K=5^s,\quad c=c_0,
\]

or

\[
K=3^r,\quad d=d_0.
\]

No rank-two, congruence-grid, or genuinely diagonal state survives.

## 5. Coverage failure

Axis branches already have a visible local obstruction: vertical domains avoid multiples of 5 and horizontal domains avoid multiples of 3. In the infinite-semilinear class, multiples of 15 are never covered.

The more general theorem does not depend on this local pattern. After duplicate path domains are grouped by residue cylinder, complete depth-\(r\) coverage still requires exponentially many distinct cylinders/maps. Exact closure allows only polynomially many affine maps, because two shift images determine a map and \(\mathcal H\) has polylogarithmic growth.

## 6. Gaussian audit

Norm-scale invariance remains exact. Full-rank affine Gaussian transformations are rigid and reduce to norm multiplication. Existing nonlinear identities are thin or output two norms. None gives a state transition on arbitrary integer representations.

## 7. Computation

A deterministic exact search was used only as a diagnostic. It found no full-grid or non-axis branch and reproduced the known collision at 28. All long axis survivors match the theorem templates.

## 8. Literature conclusion

The strongest directly relevant theorem is the ESS finite-rank unit-equation bound. Laurent's torus Mordell–Lang theorem gives the same qualitative geometry at a more general level. Effective S-unit theorems can handle fixed numerical equations but do not bound an unknown automaton's transition parameters. Skolem–Mahler–Lech, primitive-divisor, Presburger, and Cobham results have narrower hypotheses and do not supply complete pointwise descent.

## 9. Exact payoff

This round proves that Candidates A–C cannot be realized in the entire finite exact affine shift-language class, even with mixed scales and arbitrary finite state languages. It also installs terminal soundness as a mandatory future gate.

The only unclosed algebraic possibility is a genuinely nonlinear, representation-independent one-output-norm transformation outside the affine shift-embedding class. No candidate or bounded Phase B exists.

## 10. Final governance

```text
FINAL VERDICT:
STOP FINITE-STATE MULTI-BRANCH DESCENT TRIGGER

PROMOTION:
NO

CODEX:
NO

ULTRA:
NO

OEIS A303656:
UNRESOLVED
```
