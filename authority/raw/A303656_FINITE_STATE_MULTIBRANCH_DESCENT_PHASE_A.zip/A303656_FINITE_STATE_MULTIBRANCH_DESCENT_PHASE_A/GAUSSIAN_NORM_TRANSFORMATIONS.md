# GAUSSIAN NORM TRANSFORMATIONS

## 1. Norm-scale invariance

For \(K\in\mathcal S_2\) and \(m\ge0\), Fermat's two-square criterion gives

\[
m\in\mathcal S_2\iff Km\in\mathcal S_2.
\]

Every prime \(q\equiv3\pmod4\) occurs in \(K\) with even valuation, so multiplication by \(K\) preserves all obstruction parities.

Thus the norm component is not the main obstacle. The obstruction is preservation of the sparse mixed-base shift set.

## 2. Integer-level exact lift

If

\[
K\mathcal H_{\tau}+C\subseteq\mathcal H_\sigma,
\]

then

\[
m\in\mathcal S_2+\mathcal H_\tau
\Longrightarrow
Km+C\in\mathcal S_2+\mathcal H_\sigma.
\]

This is quantifier-safe and representation-independent.

## 3. Gaussian affine rigidity

Let \(L\in M_2(\mathbf Z)\), \(t\in\mathbf Z^2\), \(K>0\), \(B\in\mathbf Z\). Suppose on a full-rank lattice coset

\[
\|Lv+t\|^2=K\|v\|^2+B.
\]

The difference is a degree-two polynomial vanishing on a full-rank lattice coset, hence identically zero. Comparing terms yields

\[
L^{\mathsf T}L=KI_2,\qquad L^{\mathsf T}t=0,
\qquad \|t\|^2=B.
\]

The first identity makes \(L\) invertible over \(\mathbf R\), so \(t=0\) and \(B=0\). The two columns of \(L\) have equal length and are perpendicular, therefore \(L\) is Gaussian multiplication or Gaussian multiplication after conjugation, up to a unit.

Consequently, full-rank affine Gaussian states provide no additive repair beyond pure norm scaling. They reduce to the affine shift equation classified in `S_UNIT_CLASSIFICATION.md`.

## 4. Why two norm terms do not suffice

Brahmagupta–Fibonacci identities can produce

\[
K\bigl(N(z)+3^c+5^d\bigr)
=N(z_1)+N(z_2)+3^{c'}+5^{d'}.
\]

The target problem permits only one independent norm term. Since \(\mathcal S_2\) is not closed under addition, the existence of two norms does not imply a one-norm representation.

A universal linear collapse is impossible by rank: a positive quadratic form in three independent variables has rank three, while a sum of two squares of linear forms has rank at most two.

## 5. Thin nonlinear identities

The prior Gaussian package contains exact identities on thin shapes such as square or twice-square norm components. They are valid tagged identities but do not control arbitrary representations and do not define a state of the integer.

No theorem was found that every represented predecessor admits one of those thin norm shapes. Therefore they cannot be contraposed into a counterexample-preserving descent.

## 6. Remaining unclassified possibility

This Phase A does not prove a universal rigidity theorem for every nonlinear map of Gaussian coordinates. A future candidate would need all of:

- one output norm term;
- integer coordinates;
- validity for every representation in a state;
- a state determined without hidden witnesses;
- exact shift output in \(\mathcal H\);
- complete tail coverage;
- terminal soundness.

No concrete candidate meeting even the first four requirements survived.
