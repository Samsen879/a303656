# EXECUTIVE VERDICT

## Final verdict

\[
\boxed{\textbf{STOP FINITE-STATE MULTI-BRANCH DESCENT TRIGGER}}
\]

本轮没有构造可 promotion 的 finite-state descent。相反，得到一个覆盖面显著宽于旧 fixed-scale single-branch obstruction 的 structural no-go theorem。

## Strongest proved theorem

### Entropy–Sparsity Finite-State No-Go Theorem

设 \(\Sigma\) 为 finite reachable state set，\(\mathcal H_{\sigma_0}=\mathcal H\)，每个 reachable state language 非空；每条 edge \(e:\sigma\to\tau\) 给出

\[
\phi_e(x)=K_ex+C_e,\qquad K_e\ge2,
\]

且满足 exact shift closure

\[
\phi_e(\mathcal H_\tau)\subseteq\mathcal H_\sigma.
\]

若每个 reachable state 的 finitely many outgoing congruence domains 覆盖所有 sufficiently large integers，并且系统不借助 empty-state/vacuous badness，则这样的系统不存在。

证明机制：将长度 \(r\) 的 path domains 按 distinct residue cylinders 分组后，complete coverage 仍至少需要 \(2^r\) 个 cylinders，因而需要至少 \(2^r\) 个不同 composed affine maps；但每个 reachable state 至少含两个 shifts，故每个 composed map 由两个 image shifts 唯一决定。长度 \(r\) images 的大小至多 exponential in \(r\)，而

\[
|\mathcal H\cap[1,X]|=O((\log X)^2),
\]

所以所有 endpoint 的 image pairs 总数只有 \(O(r^4)\)。指数下界与多项式上界矛盾。

该 theorem 允许 mixed scales、mixed offsets、arbitrary finite state languages、semilinear languages 以及 automatic languages；它不要求所有 edges 使用同一个 \(K\)。

## Strongest complementary classification theorem

对 fixed \(K\ge2,C\in\mathbf Z\)，令

\[
L_{K,C}=\{(c,d):K(3^c+5^d)+C\in\mathcal H\}.
\]

利用 Evertse–Schlickewei–Schmidt finite-rank unit-equation theorem，可证明 \(L_{K,C}\) 除有限 accidental points 外，只可能是 finite union of axis fibers：

- 若 \(K=5^s\)，只可能有 vertical fibers \(c=c_0\)，且
  \[
  K3^{c_0}+C=3^{u_0},\qquad
  K(3^{c_0}+5^d)+C=3^{u_0}+5^{d+s};
  \]
- 若 \(K=3^r\)，只可能有 horizontal fibers \(d=d_0\)，且
  \[
  K5^{d_0}+C=5^{v_0},\qquad
  K(3^c+5^{d_0})+C=3^{c+r}+5^{v_0};
  \]
- 若 \(K\) 既不是 pure power of 3 也不是 pure power of 5，则只有 finitely many accidental source exponent pairs。

当额外要求 \(K\in\mathcal S_2\) 时，horizontal case 中 \(r\) 必须为偶数。

## Fundamental logical correction

由于 \(\mathcal H_\sigma\subseteq\mathcal H\)，

\[
P_\sigma(n): n\notin\mathcal S_2+\mathcal H_\sigma
\]

比 original bad property \(P_{\sigma_0}(n)\) 更弱。沿 path 得到 bounded \(P_\sigma(m)\) **不能**自动推出 bounded original counterexample。一个 sound finite reduction 还必须提供：

1. 每个 terminal state 的 state-specific certified coverage；或
2. explicit decoder \(P_\sigma(m)\Rightarrow P_{\sigma_0}(g_\sigma(m))\)；或
3. return-to-initial-state mechanism。

Empty state 使 \(P_\sigma\) 恒真，属于 vacuous branch，不能用于证明 A303656。

## Computational observation

Small exact search tested：

- 78 norm scales \(2\le K\le200\)；
- \(-500\le C\le500\)；
- 78,078 affine maps on the \(9\times9\) exponent grid；
- 11,243,232 genuinely two-coordinate diagonal rays；
- deep axis checks through variable exponent 32。

结果：无 full-grid map；无 diagonal survivor；所有 deep axis survivors 均由上面的 proved axis templates 解释；\(0\le c,d\le30\) 中唯一 shift collision value 为 28，对应 \((1,2)\) 与 \((3,0)\)。这些只是 `COMPUTATIONAL OBSERVATION`，不承担 global proof。

## Promotion and execution

- Promotion recommended: **NO**
- Ordinary Codex recommended: **NO**
- Codex Ultra recommended: **NO**
- New production interval search: **NO**
- Literature watch: 仅保留针对 genuinely nonlinear, representation-independent one-norm transformation 的低成本 watch

```text
OEIS A303656:
UNRESOLVED
```
