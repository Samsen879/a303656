# NO-GO THEOREMS

## NG-1 — Naive state descent is logically incomplete

A path ending in \(P_\sigma(m)\) does not yield \(P_{\sigma_0}(m)\). Any theorem claiming a bounded original counterexample without terminal soundness has a quantifier gap.

**Scope:** all proper sublanguages \(\mathcal H_\sigma\subsetneq\mathcal H\).

## NG-2 — Empty-state branch is vacuous

An empty child language makes the bad property tautological. It can make congruence coverage look complete while proving nothing.

**Scope:** the state definition in the task; does not preclude a different formalism with extra invariant semantics.

## NG-3 — No global affine self-embedding

For \(K\ge2\), no integer \(C\) satisfies

\[
K\mathcal H+C\subseteq\mathcal H.
\]

**Reason:** the full exponent grid contradicts the affine S-unit fiber classification.

## NG-4 — Infinite affine branches are axis-only

Every fixed affine map has, outside finitely many accidents, only vertical fibers at power-of-5 scale or horizontal fibers at power-of-3 scale.

**Scope:** arbitrary exponent languages; no semilinearity assumption.

## NG-5 — Exponent congruence and rank-two states fail

Any state containing a genuine two-coordinate semilinear ray cannot be the child of a nontrivial exact affine edge.

## NG-6 — Infinite-semilinear branches cannot cover multiples of 15

Vertical domains avoid 5-divisible integers and horizontal domains avoid 3-divisible integers. Their finite union misses every multiple of 15.

## NG-7 — Complete finite mixed-scale affine state systems do not exist

The entropy–sparsity theorem rules out mixed scales, mixed offsets, cycles, finite exceptions, semilinear states, and automatic states simultaneously, provided the system is finite, nonvacuous, and requires all-integer complete tail coverage by its congruence domains.

This is the principal route-termination theorem of the round.

## NG-8 — Full-rank affine Gaussian repair gives no extra freedom

Gaussian translation cannot absorb a fixed exponent residual on a full-rank state. It reduces to pure norm multiplication and the closed affine shift class.

## NG-9 — Tagged parity/orientation cannot select a branch

A branch depending on the parity or Gaussian orientation of an unknown representation is not a deterministic state transition on the integer.

## NG-10 — Finite search cannot promote accidental identities

No finite exponent box proves a global inclusion. The exact search is diagnostic and is not used to close any infinite case; infinite cases are closed by P7/P12.

## Scope boundary

These theorems do **not** prove that all conceivable descent methods fail. Specifically unruled-out are:

- nonlinear integer maps not expressible as finite affine norm scaling;
- bad-set-only domain coverage supported by an independent theorem proving uncovered classes representable;
- semantic closure at the full representability-set level that does not induce shift inclusion;
- analytic, sieve, Fourier, or inverse-theorem routes outside this algebraic finite-state framework.
