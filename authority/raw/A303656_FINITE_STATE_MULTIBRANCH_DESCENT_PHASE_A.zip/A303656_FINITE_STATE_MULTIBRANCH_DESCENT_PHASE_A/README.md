# A303656 FINITE-STATE MULTI-BRANCH DESCENT AND S-UNIT RIGIDITY TRIGGER HUNT — PHASE A

本目录是一个 deterministic research package。研究对象为

\[
\mathcal S_2=\{a^2+b^2:a,b\ge 0\},\qquad
\mathcal H=\{3^c+5^d:c,d\ge0\},
\]

以及 universal inclusion

\[
\mathbf Z_{>1}\stackrel{?}{\subseteq}\mathcal S_2+\mathcal H.
\]

本轮只审计 finite-state、representation-independent、exact affine/Gaussian descent。未调用 Codex CLI 或 Codex Ultra，未运行大型 production interval search。

## Final verdict

```text
STOP FINITE-STATE MULTI-BRANCH DESCENT TRIGGER
```

该 verdict 的严格 scope 是：**finite nonvacuous state set + exact affine shift-language inclusions + fixed integer scales \(K\ge2\) + complete congruence-tail coverage**。本包证明这一整类系统不可能存在。它不声称排除所有 nonlinear 或非-affine 的 representation-independent transformations。

```text
OEIS A303656:
UNRESOLVED
```

## Reproduction

见 `REPRODUCE.md`。核心入口：

```bash
python3 scripts/replay.py --root .
python3 scripts/validate_package.py --root .
python3 scripts/build_deterministic_zip.py --root . --output ../rebuild.zip
```
