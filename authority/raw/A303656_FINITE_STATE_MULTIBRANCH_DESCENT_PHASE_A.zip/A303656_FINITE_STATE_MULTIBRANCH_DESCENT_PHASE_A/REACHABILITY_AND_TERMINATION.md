# REACHABILITY AND TERMINATION

## 1. Reachability

Only states reachable from \(\sigma_0\) matter. Removing unreachable states preserves every descent implication and all coverage requirements.

Because \(\Sigma\) and the edge set are finite, all scales and offsets have absolute bounds

\[
2\le K_e\le K_{\max},
\qquad |C_e|\le C_{\max}.
\]

These bounds are essential in the sparsity proof.

## 2. Strict decrease

For one edge,

\[
F_e(n)=\frac{n-C_e}{K_e}.
\]

Since \(K_e\ge2\), there is an explicit threshold after which

\[
0<F_e(n)<n.
\]

For any fixed depth \(r\), choosing the initial \(n\) sufficiently large keeps all intermediate values above their state thresholds. Therefore recursive complete coverage genuinely produces length-\(r\) paths on a tail.

## 3. Cycles

A state graph cycle is not itself a termination problem because every inverse step decreases the integer above a fixed threshold. Conversely, cycles do not evade the entropy theorem: forward composition around a cycle multiplies scale by at least 2 per edge and creates the same exponential path-cylinder demand.

## 4. Terminal range

A formal descent theorem would terminate at finitely many pairs

\[
(\sigma,m),\qquad m\le N_\sigma.
\]

The required finite certificate is state-specific:

\[
R_\sigma(m)
\quad\text{for every reachable terminal pair.}
\]

A pre-existing certificate only for \(R_{\sigma_0}(m)\) is not enough because \(R_{\sigma_0}(m)\) may use a shift excluded from \(\mathcal H_\sigma\).

## 5. Empty-state failure

An empty state has no representable integers and hence no terminal pair can be discharged. It is not a terminating success state; it is a logical sink carrying no information.

## 6. Status

No sound reachable graph survives the complete-coverage no-go theorem. There is therefore no terminal bound \(N_*\) to pass to a certified finite computation.
