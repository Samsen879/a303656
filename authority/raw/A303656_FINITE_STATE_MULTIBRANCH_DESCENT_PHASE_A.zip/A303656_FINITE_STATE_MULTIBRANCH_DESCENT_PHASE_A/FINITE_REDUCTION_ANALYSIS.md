# FINITE REDUCTION ANALYSIS

## 1. Desired implication

A genuine finite reduction would establish an explicit \(N_*\) with

\[
(\exists n>1:P_{\sigma_0}(n))
\Longrightarrow
(\exists m\le N_*:P_{\sigma_0}(m)).
\tag{FR}
\]

A stateful descent naturally yields only

\[
(\exists n:P_{\sigma_0}(n))
\Longrightarrow
(\exists \sigma,\ m\le N_\sigma:P_\sigma(m)).
\tag{SFR}
\]

`(SFR)` implies `(FR)` only with an additional terminal-soundness theorem.

## 2. State-specific finite certificate

One possible sound endpoint would be an exact table certifying

\[
R_\sigma(m)
\]

for every reachable state and every terminal \(m\) in its actual domain. This is a finite problem only after the graph, domains, and bounds are proved.

No graph survives the no-go theorem, so there is no bounded table to authorize.

## 3. Decoder alternative

An explicit map

\[
P_\sigma(m)\Longrightarrow P_{\sigma_0}(g_\sigma(m))
\]

with bounded or decreasing \(g_\sigma(m)\) could restore original badness. No such decoder was found. For sublanguages, the implication points in the opposite direction by default.

## 4. Exact affine class verdict

The entropy–sparsity theorem proves that the exact affine class cannot supply `(SFR)` with complete tail coverage, even before terminal verification is considered.

Thus Candidates A, B, and C from the task are unavailable within this class:

- no explicit finite-state descent;
- no finite graph reduction;
- no multi-branch closure approaching complete coverage.

## 5. Certified prior computation

The frozen positive-density package and prior bounded computations remain valid within their own authority. They do not provide a theorem-linked universal threshold. This round does not convert any prior interval into a final finite tail.

## 6. Status

No \(N_*\) is produced. No repository implementation or large verification run is justified.

```text
OEIS A303656:
UNRESOLVED
```
