# AFFINE INCLUSION ANALYSIS

## 1. Inclusion problem

An edge asks for

\[
K\mathcal H(L')+C\subseteq\mathcal H(L).
\]

Ignoring the target restriction only weakens the demand:

\[
K\mathcal H(L')+C\subseteq\mathcal H.
\tag{A}
\]

The S-unit classification therefore applies to every valid edge.

## 2. Full shift set

For \(L'=\mathbf N^2\), `(A)` would require a rank-two family. The classification theorem shows that no \(K\ge2\) works. Thus no nontrivial global affine self-embedding

\[
K\mathcal H+C\subseteq\mathcal H
\]

exists.

This is stronger than bounded search and removes the last possibility of a single exact global branch.

## 3. Vertical branches

A vertical source fiber \(c=c_0\) has an infinite branch exactly when

\[
K=5^s,
\qquad
K3^{c_0}+C=3^{u_0}.
\]

Example:

\[
5(3^0+5^d)-2=3^1+5^{d+1}.
\]

The congruence domain is

\[
n\equiv -2\equiv3\pmod5.
\]

More generally, since \(C\equiv3^{u_0}\pmod5\), a vertical branch never covers an integer divisible by 5.

## 4. Horizontal branches

A horizontal source fiber \(d=d_0\) has an infinite branch exactly when

\[
K=3^r,
\qquad
K5^{d_0}+C=5^{v_0}.
\]

For norm scaling, \(r\) is even. Example:

\[
9(3^c+5^0)-4=3^{c+2}+5^1.
\]

The congruence domain is

\[
n\equiv -4\equiv5\pmod9.
\]

Since \(C\equiv5^{v_0}\not\equiv0\pmod3\), a horizontal branch never covers an integer divisible by 3.

## 5. Direct semilinear coverage obstruction

If every outgoing child state has an infinite semilinear exponent language, every valid edge is vertical or horizontal. Vertical domains avoid multiples of 5; horizontal domains avoid multiples of 3. Consequently every multiple of 15 is uncovered.

This gives a simple no-go for the natural infinite-semilinear branch class. Finite child states and arbitrary automatic states require the stronger entropy–sparsity theorem.

## 6. Finite accidental fibers

A fixed map may contain finitely many accidental exponent pairs outside its axis families. They can support only finite child shift languages. Finite exceptions cannot produce tail coverage by themselves; any attempt to iterate them either reaches singleton/empty states or is absorbed by the global entropy contradiction.

## 7. Difference from old fixed-scale theorem

The earlier theorem allowed one scale \(K\) and showed that two distinct global offsets at that scale are impossible. The new analysis:

- proves that no global nontrivial branch exists at all;
- classifies every infinite partial branch;
- allows mixed \(K_e\) across transitions;
- combines with complete-coverage entropy to rule out every finite mixed-scale system in the stated class.
