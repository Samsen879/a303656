# LIMITATIONS

## 1. Scope of the main no-go theorem

The entropy–sparsity theorem assumes exact affine shift-language closure

\[
K\mathcal H_\tau+C\subseteq\mathcal H_\sigma.
\]

It also assumes the task's strong **all-integer tail coverage** of congruence domains. It does not classify a weaker bad-set-only scheme in which an independent theorem proves every uncovered class representable.

Nor does it classify every possible semantic implication

\[
K(\mathcal S_2+\mathcal H_\tau)+C
\subseteq
\mathcal S_2+\mathcal H_\sigma
\]

that might arise through a nontrivial, representation-independent norm repair not visible at the shift level.

## 2. Nonlinear Gaussian transformations

Only full-rank affine Gaussian maps are classified. Thin nonlinear identities exist, but no theorem here excludes every nonlinear map on every finite algebraic state.

## 3. Effectivity of finite accidents

ESS gives a uniform count for nondegenerate solutions, not a direct height bound. Effective S-unit methods can in principle enumerate fixed equations, but this package does not implement their enormous explicit bounds.

This limitation does not affect the classification of infinite fibers or the entropy theorem.

## 4. Automatic languages

No general minimization/classification algorithm for arbitrary automata is implemented. The theorem bypasses this need by classifying the exponent geometry of any infinite exact affine solution set.

## 5. Prior input replay anomaly

The uploaded Gaussian-norm package passed static content inspection, but its bundled exact-check validator reported that replay was not byte-identical in the present environment. This package records the failure rather than silently treating it as a pass. The descent package and frozen positive-density verifier passed.

## 6. No universal A303656 conclusion

The route-specific no-go theorem does not prove or disprove A303656. It removes one proposed theorem-discovery class and strengthens the project authority map.

```text
OEIS A303656:
UNRESOLVED
```
