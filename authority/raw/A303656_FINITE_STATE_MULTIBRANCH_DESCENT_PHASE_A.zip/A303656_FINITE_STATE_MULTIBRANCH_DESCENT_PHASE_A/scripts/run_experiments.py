#!/usr/bin/env python3
"""Deterministic small exact experiments for the A303656 finite-state Phase A round.

All arithmetic uses Python arbitrary-precision integers. The searches are diagnostic only;
no bounded absence is promoted to a global theorem.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

SCHEMA_VERSION = 1


def is_sum_two_squares_bruteforce(n: int) -> bool:
    if n < 0:
        return False
    r = math.isqrt(n)
    squares = {i * i for i in range(r + 1)}
    return any(n - a * a in squares for a in range(r + 1))


def norm_scales(limit: int) -> List[int]:
    return [k for k in range(2, limit + 1) if is_sum_two_squares_bruteforce(k)]


def exact_power(n: int, base: int) -> Optional[int]:
    if n < 1:
        return None
    e = 0
    while n % base == 0:
        n //= base
        e += 1
    return e if n == 1 else None


def powers_up_to(base: int, bound: int) -> List[int]:
    out = [1]
    while out[-1] <= bound // base:
        out.append(out[-1] * base)
    return out


def h_map_up_to(bound: int) -> Dict[int, List[Tuple[int, int]]]:
    p3 = powers_up_to(3, bound)
    p5 = powers_up_to(5, bound)
    out: Dict[int, List[Tuple[int, int]]] = defaultdict(list)
    for c, x in enumerate(p3):
        for d, y in enumerate(p5):
            s = x + y
            if s <= bound:
                out[s].append((c, d))
    return dict(out)


def mapped_value(k: int, c: int, d: int, offset: int) -> int:
    return k * (pow(3, c) + pow(5, d)) + offset


def maps_point(k: int, offset: int, c: int, d: int, hmap: Dict[int, List[Tuple[int, int]]]) -> bool:
    return mapped_value(k, c, d, offset) in hmap


def all_points_map(
    k: int,
    offset: int,
    points: Iterable[Tuple[int, int]],
    hmap: Dict[int, List[Tuple[int, int]]],
) -> bool:
    return all(maps_point(k, offset, c, d, hmap) for c, d in points)


def classify_axis_identity(k: int, offset: int, axis_limit: int) -> Tuple[List[dict], List[dict]]:
    vertical: List[dict] = []
    horizontal: List[dict] = []
    s5 = exact_power(k, 5)
    if s5 is not None and s5 >= 1:
        for c0 in range(axis_limit + 1):
            u0 = exact_power(k * pow(3, c0) + offset, 3)
            if u0 is not None:
                vertical.append(
                    {
                        "source_c": c0,
                        "target_c": u0,
                        "d_increment": s5,
                        "identity": f"{k}(3^{c0}+5^d)+({offset})=3^{u0}+5^(d+{s5})",
                    }
                )
    s3 = exact_power(k, 3)
    if s3 is not None and s3 >= 1:
        for d0 in range(axis_limit + 1):
            v0 = exact_power(k * pow(5, d0) + offset, 5)
            if v0 is not None:
                horizontal.append(
                    {
                        "source_d": d0,
                        "target_d": v0,
                        "c_increment": s3,
                        "identity": f"{k}(3^c+5^{d0})+({offset})=3^(c+{s3})+5^{v0}",
                    }
                )
    return vertical, horizontal


def canonical_json_bytes(obj: object) -> bytes:
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def run() -> dict:
    k_limit = 200
    c_abs_limit = 500
    grid_exp_limit = 8
    axis_index_limit = 8
    axis_sample_limit = 12
    axis_deep_limit = 32
    diagonal_origin_limit = 3
    diagonal_step_limit = 3
    diagonal_sample_limit = 8
    diagonal_deep_limit = 18
    collision_exp_limit = 30

    ks = norm_scales(k_limit)
    max_source = pow(3, axis_deep_limit) + pow(5, axis_deep_limit)
    max_image = max(ks) * max_source + c_abs_limit
    hmap = h_map_up_to(max_image)

    grid_points = [(c, d) for c in range(grid_exp_limit + 1) for d in range(grid_exp_limit + 1)]
    maps_tested = 0
    full_grid_maps: List[dict] = []
    score_histogram: Dict[int, int] = defaultdict(int)
    top_maps: List[Tuple[int, int, int]] = []

    predicted_vertical: List[dict] = []
    predicted_horizontal: List[dict] = []
    observed_axis_unexplained: List[dict] = []
    axis_false_positives_rejected = 0

    for k in ks:
        for offset in range(-c_abs_limit, c_abs_limit + 1):
            maps_tested += 1
            score = sum(1 for c, d in grid_points if maps_point(k, offset, c, d, hmap))
            score_histogram[score] += 1
            if score == len(grid_points):
                full_grid_maps.append({"K": k, "C": offset})
            if score >= 8:
                top_maps.append((score, k, offset))

            vertical, horizontal = classify_axis_identity(k, offset, axis_index_limit)
            for rec in vertical:
                rec2 = {"K": k, "C": offset, **rec}
                predicted_vertical.append(rec2)
                c0 = rec["source_c"]
                assert all_points_map(
                    k,
                    offset,
                    ((c0, d) for d in range(axis_deep_limit + 1)),
                    hmap,
                )
            for rec in horizontal:
                rec2 = {"K": k, "C": offset, **rec}
                predicted_horizontal.append(rec2)
                d0 = rec["source_d"]
                assert all_points_map(
                    k,
                    offset,
                    ((c, d0) for c in range(axis_deep_limit + 1)),
                    hmap,
                )

            # Search sampled axis fibres, then reject shallow accidental survivors deeply.
            for c0 in range(axis_index_limit + 1):
                pts = ((c0, d) for d in range(axis_sample_limit + 1))
                if all_points_map(k, offset, pts, hmap):
                    predicted = any(v["source_c"] == c0 for v in vertical)
                    deep = all_points_map(
                        k,
                        offset,
                        ((c0, d) for d in range(axis_deep_limit + 1)),
                        hmap,
                    )
                    if not predicted:
                        if deep:
                            observed_axis_unexplained.append(
                                {"orientation": "vertical", "K": k, "C": offset, "fixed_c": c0}
                            )
                        else:
                            axis_false_positives_rejected += 1
            for d0 in range(axis_index_limit + 1):
                pts = ((c, d0) for c in range(axis_sample_limit + 1))
                if all_points_map(k, offset, pts, hmap):
                    predicted = any(h["source_d"] == d0 for h in horizontal)
                    deep = all_points_map(
                        k,
                        offset,
                        ((c, d0) for c in range(axis_deep_limit + 1)),
                        hmap,
                    )
                    if not predicted:
                        if deep:
                            observed_axis_unexplained.append(
                                {"orientation": "horizontal", "K": k, "C": offset, "fixed_d": d0}
                            )
                        else:
                            axis_false_positives_rejected += 1

    top_maps.sort(reverse=True)
    top_maps_json = [{"grid_hits": s, "K": k, "C": c} for s, k, c in top_maps[:30]]

    # Search genuinely two-coordinate rays for a bounded long identity.
    diagonal_sample_survivors: List[dict] = []
    diagonal_deep_survivors: List[dict] = []
    diagonal_tests = 0
    for k in ks:
        for offset in range(-c_abs_limit, c_abs_limit + 1):
            for c0 in range(diagonal_origin_limit + 1):
                for d0 in range(diagonal_origin_limit + 1):
                    for p in range(1, diagonal_step_limit + 1):
                        for q in range(1, diagonal_step_limit + 1):
                            diagonal_tests += 1
                            sample_points = ((c0 + p * t, d0 + q * t) for t in range(diagonal_sample_limit + 1))
                            if all_points_map(k, offset, sample_points, hmap):
                                rec = {"K": k, "C": offset, "c0": c0, "d0": d0, "p": p, "q": q}
                                diagonal_sample_survivors.append(rec)
                                deep_points = ((c0 + p * t, d0 + q * t) for t in range(diagonal_deep_limit + 1))
                                if all_points_map(k, offset, deep_points, hmap):
                                    diagonal_deep_survivors.append(rec)

    # Collisions of exponent pairs in a fixed box.
    collision_map: Dict[int, List[Tuple[int, int]]] = defaultdict(list)
    for c in range(collision_exp_limit + 1):
        for d in range(collision_exp_limit + 1):
            collision_map[pow(3, c) + pow(5, d)].append((c, d))
    collisions = [
        {"value": value, "pairs": [list(pair) for pair in pairs]}
        for value, pairs in sorted(collision_map.items())
        if len(pairs) > 1
    ]

    # Bounded coverage observation from all predicted axis branches in the search box.
    branch_domains: List[dict] = []
    for rec in predicted_vertical:
        branch_domains.append({"K": rec["K"], "C_mod_K": rec["C"] % rec["K"], "kind": "vertical"})
    for rec in predicted_horizontal:
        branch_domains.append({"K": rec["K"], "C_mod_K": rec["C"] % rec["K"], "kind": "horizontal"})
    branch_domains = [dict(t) for t in {tuple(sorted(d.items())) for d in branch_domains}]
    branch_domains.sort(key=lambda x: (x["K"], x["C_mod_K"], x["kind"]))
    coverage_limit = 10_000
    uncovered_multiples_15 = []
    for n in range(15, coverage_limit + 1, 15):
        if not any(n % b["K"] == b["C_mod_K"] for b in branch_domains):
            uncovered_multiples_15.append(n)

    example_identities = {
        "vertical": {
            "K": 5,
            "C": -2,
            "statement": "5(3^0+5^d)-2=3^1+5^(d+1)",
            "verified_d_0_to_32": all_points_map(5, -2, ((0, d) for d in range(33)), hmap),
        },
        "horizontal": {
            "K": 9,
            "C": -4,
            "statement": "9(3^c+5^0)-4=3^(c+2)+5^1",
            "verified_c_0_to_32": all_points_map(9, -4, ((c, 0) for c in range(33)), hmap),
        },
    }

    result = {
        "schema_version": SCHEMA_VERSION,
        "classification": "COMPUTATIONAL OBSERVATION",
        "integer_arithmetic": "Python arbitrary-precision integers; no overflow",
        "parameters": {
            "K": "2<=K<=200 and K is a sum of two squares",
            "C": "-500<=C<=500",
            "grid": "0<=c,d<=8",
            "axis_fixed_index": "0..8",
            "axis_shallow_variable": "0..12",
            "axis_deep_variable": "0..32",
            "diagonal_origins": "0..3",
            "diagonal_steps": "1..3 in both coordinates",
            "diagonal_shallow_t": "0..8",
            "diagonal_deep_t": "0..18",
            "collision_box": "0<=c,d<=30",
        },
        "counts": {
            "norm_scales": len(ks),
            "affine_maps_tested": maps_tested,
            "grid_points_per_map": len(grid_points),
            "full_grid_maps": len(full_grid_maps),
            "predicted_vertical_fibres": len(predicted_vertical),
            "predicted_horizontal_fibres": len(predicted_horizontal),
            "unexplained_deep_axis_fibres": len(observed_axis_unexplained),
            "shallow_axis_false_positives_rejected": axis_false_positives_rejected,
            "diagonal_rays_tested": diagonal_tests,
            "diagonal_shallow_survivors": len(diagonal_sample_survivors),
            "diagonal_deep_survivors": len(diagonal_deep_survivors),
            "colliding_shift_values": len(collisions),
            "distinct_axis_branch_domains": len(branch_domains),
            "uncovered_multiples_of_15_below_10000": len(uncovered_multiples_15),
        },
        "full_grid_maps": full_grid_maps,
        "score_histogram": {str(k): v for k, v in sorted(score_histogram.items())},
        "top_maps_by_grid_hits": top_maps_json,
        "predicted_vertical_fibres_first_30": predicted_vertical[:30],
        "predicted_horizontal_fibres_first_30": predicted_horizontal[:30],
        "unexplained_deep_axis_fibres": observed_axis_unexplained,
        "diagonal_shallow_survivors_first_30": diagonal_sample_survivors[:30],
        "diagonal_deep_survivors": diagonal_deep_survivors,
        "collisions": collisions,
        "axis_branch_domains_first_100": branch_domains[:100],
        "uncovered_multiples_of_15_first_50": uncovered_multiples_15[:50],
        "all_tested_multiples_of_15_uncovered": len(uncovered_multiples_15) == coverage_limit // 15,
        "example_identities": example_identities,
        "interpretation": [
            "No K>=2 map in the bounded search carried the full 9x9 exponent grid into H.",
            "Every long sampled axis fibre that survived deep checking was explained by the proved axis identity templates.",
            "No genuinely two-coordinate diagonal ray survived the deep bounded test.",
            "The bounded residue-domain list left every tested multiple of 15 uncovered; the package proves the corresponding infinite obstruction theorem separately.",
            "These statements remain bounded observations unless explicitly linked to a theorem in PROVED_LEMMAS.md.",
        ],
    }
    payload = canonical_json_bytes(result)
    result["content_sha256_without_self_field"] = hashlib.sha256(payload).hexdigest()
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = run()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(canonical_json_bytes(result))
    print(f"wrote {args.output}")
    print(json.dumps(result["counts"], sort_keys=True))


if __name__ == "__main__":
    main()
