#!/usr/bin/env python3
"""Replay the exact bounded experiment and require byte-identical JSON output."""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True

import argparse
import json
import subprocess
import tempfile
from pathlib import Path

from package_lib import canonical_json_bytes, sha256_file


def replay(root: Path) -> dict:
    root = root.resolve()
    expected = root / "results/experiments.json"
    script = root / "scripts/run_experiments.py"
    if not expected.is_file() or not script.is_file():
        raise FileNotFoundError("required experiment script/result missing")

    with tempfile.TemporaryDirectory(prefix="a303656-replay-") as temp_dir:
        replayed = Path(temp_dir) / "experiments.json"
        proc = subprocess.run(
            [sys.executable, str(script), "--output", str(replayed)],
            cwd=root,
            text=True,
            capture_output=True,
            check=False,
        )
        if proc.returncode != 0:
            raise RuntimeError(
                "experiment replay failed\n"
                f"stdout:\n{proc.stdout}\n"
                f"stderr:\n{proc.stderr}\n"
            )
        expected_bytes = expected.read_bytes()
        replayed_bytes = replayed.read_bytes()
        expected_sha = sha256_file(expected)
        replayed_sha = sha256_file(replayed)
        if expected_bytes != replayed_bytes:
            raise RuntimeError(
                "experiment replay not byte-identical: "
                f"expected_sha256={expected_sha}, replayed_sha256={replayed_sha}"
            )

    obj = json.loads(expected_bytes.decode("utf-8"))
    return {
        "schema_version": 1,
        "status": "PASS",
        "byte_identical": True,
        "expected_path": "results/experiments.json",
        "expected_sha256": expected_sha,
        "replayed_sha256": replayed_sha,
        "counts": obj["counts"],
        "classification": obj["classification"],
        "network_used": False,
        "third_party_packages_used": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    report = replay(args.root)
    if args.report is not None:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_bytes(canonical_json_bytes(report))
    print("REPLAY=PASS")
    print(f"byte_identical={str(report['byte_identical']).lower()}")
    print(f"sha256={report['expected_sha256']}")
    print(json.dumps(report["counts"], sort_keys=True))


if __name__ == "__main__":
    main()
