#!/usr/bin/env python3
"""Normalize, manifest, fully validate, and perform a two-build determinism test."""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True

import argparse
import subprocess
from pathlib import Path

from build_deterministic_zip import build
from package_lib import canonical_json_bytes, normalize_permissions, sha256_file, write_manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output-a", type=Path, required=True)
    parser.add_argument("--output-b", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    root = args.root.resolve()
    output_a = args.output_a.resolve()
    output_b = args.output_b.resolve()
    report_path = args.report.resolve()

    normalize_permissions(root)
    manifest_sha = write_manifest(root)

    validator = subprocess.run(
        [sys.executable, str(root / "scripts/validate_package.py"), "--root", str(root)],
        cwd=root,
        text=True,
        capture_output=True,
        check=False,
    )
    if validator.returncode != 0:
        raise RuntimeError(
            "package validation failed\n"
            f"stdout:\n{validator.stdout}\n"
            f"stderr:\n{validator.stderr}\n"
        )

    build_a = build(root, output_a)
    build_b = build(root, output_b)
    bytes_equal = output_a.read_bytes() == output_b.read_bytes()
    if not bytes_equal:
        raise RuntimeError(
            "two deterministic builds differ: "
            f"a={sha256_file(output_a)}, b={sha256_file(output_b)}"
        )

    report = {
        "schema_version": 1,
        "status": "PASS",
        "package_name": root.name,
        "manifest_sha256": manifest_sha,
        "validation": "PASS",
        "validator_stdout": validator.stdout.splitlines(),
        "build_a": build_a,
        "build_b": build_b,
        "byte_identical_rebuild": bytes_equal,
        "outer_zip_sha256": build_a["sha256"],
        "outer_zip_bytes": build_a["bytes"],
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_bytes(canonical_json_bytes(report))

    print("RELEASE=PASS")
    print(f"manifest_sha256={manifest_sha}")
    print(f"byte_identical_rebuild={str(bytes_equal).lower()}")
    print(f"outer_zip_sha256={build_a['sha256']}")
    print(f"outer_zip_bytes={build_a['bytes']}")


if __name__ == "__main__":
    main()
