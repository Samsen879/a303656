#!/usr/bin/env python3
"""Shared deterministic package utilities for the A303656 Phase-A release."""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
from pathlib import Path
from typing import Iterable

PACKAGE_NAME = "A303656_FINITE_STATE_MULTIBRANCH_DESCENT_PHASE_A"
FIXED_ZIP_DATETIME = (2000, 1, 1, 0, 0, 0)
MANIFEST_NAME = "MANIFEST.sha256"
SCRIPT_MODE = 0o755
FILE_MODE = 0o644
DIR_MODE = 0o755

REQUIRED_PATHS = (
    "EXECUTIVE_VERDICT.md",
    "ROUTE_VERDICT.json",
    "REPORT.md",
    "FORMAL_STATEFUL_FRAMEWORK.md",
    "SHIFT_LANGUAGE_DEFINITIONS.md",
    "GAUSSIAN_NORM_TRANSFORMATIONS.md",
    "S_UNIT_CLASSIFICATION.md",
    "AFFINE_INCLUSION_ANALYSIS.md",
    "MULTIBRANCH_COVERAGE.md",
    "REACHABILITY_AND_TERMINATION.md",
    "CANDIDATE_DESCENT_SYSTEMS.md",
    "PROVED_LEMMAS.md",
    "NO_GO_THEOREMS.md",
    "FINITE_REDUCTION_ANALYSIS.md",
    "LITERATURE_AUDIT.md",
    "COMPUTATIONAL_EXPERIMENTS.md",
    "LIMITATIONS.md",
    "AUTHORITY_UPDATES.md",
    "README.md",
    "REPRODUCE.md",
    "environment.json",
    "MANIFEST.sha256",
    "scripts/run_experiments.py",
    "scripts/replay.py",
    "scripts/validate_package.py",
    "scripts/build_deterministic_zip.py",
    "scripts/release.py",
    "scripts/package_lib.py",
    "results/experiments.json",
    "results/replay_report.json",
    "results/input_audit.json",
    "results/literature_sources.json",
    "logs/experiment_stdout.txt",
    "logs/experiment_timing.txt",
    "logs/input_validator_replay.txt",
)

HASH_LINE_RE = re.compile(r"^([0-9a-f]{64})  ([^\n]+)$")


def canonical_json_bytes(obj: object) -> bytes:
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def relative_files(root: Path, *, include_manifest: bool = True) -> list[Path]:
    root = root.resolve()
    out: list[Path] = []
    for path in root.rglob("*"):
        if path.is_symlink():
            raise ValueError(f"symlink not allowed: {path}")
        if path.is_file():
            rel = path.relative_to(root)
            if not include_manifest and rel.as_posix() == MANIFEST_NAME:
                continue
            out.append(rel)
    return sorted(out, key=lambda p: p.as_posix())


def relative_dirs(root: Path) -> list[Path]:
    root = root.resolve()
    out: list[Path] = []
    for path in root.rglob("*"):
        if path.is_symlink():
            raise ValueError(f"symlink not allowed: {path}")
        if path.is_dir():
            out.append(path.relative_to(root))
    return sorted(out, key=lambda p: p.as_posix())


def expected_mode(rel: Path) -> int:
    return SCRIPT_MODE if rel.parts and rel.parts[0] == "scripts" else FILE_MODE


def normalize_permissions(root: Path) -> None:
    root = root.resolve()
    os.chmod(root, DIR_MODE)
    for rel in relative_dirs(root):
        os.chmod(root / rel, DIR_MODE)
    for rel in relative_files(root):
        os.chmod(root / rel, expected_mode(rel))


def manifest_bytes(root: Path) -> bytes:
    lines = [f"{sha256_file(root / rel)}  {rel.as_posix()}" for rel in relative_files(root, include_manifest=False)]
    return (("\n".join(lines) + "\n") if lines else "").encode("utf-8")


def write_manifest(root: Path) -> str:
    root = root.resolve()
    payload = manifest_bytes(root)
    (root / MANIFEST_NAME).write_bytes(payload)
    os.chmod(root / MANIFEST_NAME, FILE_MODE)
    return sha256_bytes(payload)


def parse_manifest(root: Path) -> dict[str, str]:
    path = root / MANIFEST_NAME
    text = path.read_text(encoding="utf-8")
    records: dict[str, str] = {}
    for number, line in enumerate(text.splitlines(), start=1):
        match = HASH_LINE_RE.fullmatch(line)
        if not match:
            raise ValueError(f"invalid manifest line {number}: {line!r}")
        digest, rel = match.groups()
        if rel == MANIFEST_NAME:
            raise ValueError("manifest must exclude itself")
        if rel in records:
            raise ValueError(f"duplicate manifest path: {rel}")
        records[rel] = digest
    return records


def validate_manifest(root: Path) -> tuple[int, str]:
    records = parse_manifest(root)
    actual_rels = [rel.as_posix() for rel in relative_files(root, include_manifest=False)]
    if sorted(records) != actual_rels:
        missing = sorted(set(actual_rels) - set(records))
        extra = sorted(set(records) - set(actual_rels))
        raise ValueError(f"manifest path mismatch: missing={missing}, extra={extra}")
    for rel, expected in records.items():
        actual = sha256_file(root / rel)
        if actual != expected:
            raise ValueError(f"manifest hash mismatch: {rel}: expected={expected}, actual={actual}")
    return len(records), sha256_file(root / MANIFEST_NAME)


def validate_text_bytes(rel: Path, data: bytes) -> None:
    try:
        data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError(f"not UTF-8: {rel}: {exc}") from exc
    if b"\r" in data:
        raise ValueError(f"CR byte found (LF normalization failure): {rel}")
    for index, value in enumerate(data):
        if value in (0x09, 0x0A):
            continue
        if value < 0x20 or value == 0x7F:
            raise ValueError(f"C0/DEL byte 0x{value:02x} at offset {index}: {rel}")


def scan_utf8_and_controls(root: Path) -> tuple[int, int]:
    file_count = 0
    byte_count = 0
    for rel in relative_files(root):
        data = (root / rel).read_bytes()
        validate_text_bytes(rel, data)
        file_count += 1
        byte_count += len(data)
    return file_count, byte_count


def validate_json_files(root: Path) -> int:
    count = 0
    for rel in relative_files(root):
        if rel.suffix.lower() == ".json":
            json.loads((root / rel).read_text(encoding="utf-8"))
            count += 1
    return count


def validate_permissions(root: Path) -> tuple[int, int]:
    dir_count = 1
    file_count = 0
    root_mode = stat.S_IMODE(root.stat().st_mode)
    if (root_mode & 0o777) != DIR_MODE:
        raise ValueError(f"root rwx mode {root_mode & 0o777:o}, expected {DIR_MODE:o}")
    for rel in relative_dirs(root):
        mode = stat.S_IMODE((root / rel).stat().st_mode)
        if (mode & 0o777) != DIR_MODE:
            raise ValueError(f"directory rwx mode {mode & 0o777:o}, expected {DIR_MODE:o}: {rel}")
        dir_count += 1
    for rel in relative_files(root):
        mode = stat.S_IMODE((root / rel).stat().st_mode)
        expected = expected_mode(rel)
        if (mode & 0o777) != expected:
            raise ValueError(f"file rwx mode {mode & 0o777:o}, expected {expected:o}: {rel}")
        file_count += 1
    return dir_count, file_count


def validate_required_paths(root: Path) -> int:
    missing = [rel for rel in REQUIRED_PATHS if not (root / rel).is_file()]
    if missing:
        raise ValueError(f"missing required paths: {missing}")
    return len(REQUIRED_PATHS)


def validate_verdict(root: Path) -> None:
    verdict = json.loads((root / "ROUTE_VERDICT.json").read_text(encoding="utf-8"))
    required = {
        "project": "A303656",
        "phase": "finite_state_multibranch_descent_phase_a",
        "final_verdict": "STOP FINITE-STATE MULTI-BRANCH DESCENT TRIGGER",
        "promotion_recommended": False,
        "codex_authorized": False,
        "ultra_authorized": False,
        "a303656_status": "UNRESOLVED",
    }
    for key, expected in required.items():
        if verdict.get(key) != expected:
            raise ValueError(f"verdict invariant {key}: expected={expected!r}, actual={verdict.get(key)!r}")
    for key in ("strongest_proved_lemma", "strongest_candidate", "core_missing_lemma"):
        if not isinstance(verdict.get(key), str) or not verdict[key].strip():
            raise ValueError(f"verdict field must be nonempty string: {key}")


def validate_experiment_self_hash(root: Path) -> str:
    path = root / "results/experiments.json"
    obj = json.loads(path.read_text(encoding="utf-8"))
    expected = obj.pop("content_sha256_without_self_field", None)
    if not isinstance(expected, str):
        raise ValueError("experiments self-hash field missing")
    actual = sha256_bytes(canonical_json_bytes(obj))
    if actual != expected:
        raise ValueError(f"experiments self-hash mismatch: expected={expected}, actual={actual}")
    return actual


def ensure_package_name(root: Path) -> None:
    if root.resolve().name != PACKAGE_NAME:
        raise ValueError(f"package root name must be {PACKAGE_NAME!r}, got {root.resolve().name!r}")
