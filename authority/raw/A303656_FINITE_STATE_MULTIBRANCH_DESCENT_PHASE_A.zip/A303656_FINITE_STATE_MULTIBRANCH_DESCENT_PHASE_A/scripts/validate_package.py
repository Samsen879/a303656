#!/usr/bin/env python3
"""Strict deterministic validator for the A303656 Phase-A package."""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True

import argparse
import subprocess
from pathlib import Path

from package_lib import (
    ensure_package_name,
    scan_utf8_and_controls,
    validate_experiment_self_hash,
    validate_json_files,
    validate_manifest,
    validate_permissions,
    validate_required_paths,
    validate_verdict,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--skip-replay", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()

    ensure_package_name(root)
    required_count = validate_required_paths(root)
    json_count = validate_json_files(root)
    validate_verdict(root)
    self_hash = validate_experiment_self_hash(root)
    text_files, text_bytes = scan_utf8_and_controls(root)
    manifest_count, manifest_sha = validate_manifest(root)
    dir_count, permission_files = validate_permissions(root)

    if not args.skip_replay:
        proc = subprocess.run(
            [sys.executable, str(root / "scripts/replay.py"), "--root", str(root)],
            cwd=root,
            text=True,
            capture_output=True,
            check=False,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"replay failed\nstdout:\n{proc.stdout}\nstderr:\n{proc.stderr}")
        replay_status = "PASS"
    else:
        replay_status = "SKIPPED"

    print("VALIDATION=PASS")
    print(f"required_paths=PASS ({required_count})")
    print(f"json_parse=PASS ({json_count})")
    print("route_verdict_invariants=PASS")
    print(f"experiment_self_hash=PASS ({self_hash})")
    print(f"utf8_lf_c0_scan=PASS (files={text_files}, bytes={text_bytes}, allowed=TAB/LF)")
    print(f"manifest=PASS (records={manifest_count}, sha256={manifest_sha})")
    print(f"permissions=PASS (directories={dir_count}, files={permission_files})")
    print(f"experiment_replay={replay_status}")


if __name__ == "__main__":
    main()
