#!/usr/bin/env python3
"""Build a deterministic ZIP with fixed metadata and sorted entries."""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True

import argparse
import stat
import zipfile
from pathlib import Path

from package_lib import (
    DIR_MODE,
    FIXED_ZIP_DATETIME,
    PACKAGE_NAME,
    ensure_package_name,
    expected_mode,
    relative_dirs,
    relative_files,
    sha256_file,
)


def directory_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, FIXED_ZIP_DATETIME)
    info.create_system = 3
    info.compress_type = zipfile.ZIP_STORED
    info.external_attr = ((stat.S_IFDIR | DIR_MODE) << 16) | 0x10
    info.extra = b""
    info.comment = b""
    return info


def file_info(name: str, mode: int) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, FIXED_ZIP_DATETIME)
    info.create_system = 3
    info.compress_type = zipfile.ZIP_STORED
    info.external_attr = (stat.S_IFREG | mode) << 16
    info.extra = b""
    info.comment = b""
    return info


def build(root: Path, output: Path) -> dict:
    root = root.resolve()
    output = output.resolve()
    ensure_package_name(root)
    if output == root or root in output.parents:
        raise ValueError("output ZIP must be outside package root")
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()

    prefix = PACKAGE_NAME + "/"
    entries: list[tuple[str, str, Path | None]] = [(prefix, "dir", None)]
    entries.extend((prefix + rel.as_posix() + "/", "dir", rel) for rel in relative_dirs(root))
    entries.extend((prefix + rel.as_posix(), "file", rel) for rel in relative_files(root))
    entries.sort(key=lambda item: item[0])

    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
        for name, kind, rel in entries:
            if kind == "dir":
                archive.writestr(directory_info(name), b"")
            else:
                assert rel is not None
                archive.writestr(file_info(name, expected_mode(rel)), (root / rel).read_bytes())
        archive.comment = b""

    return {
        "output": output.name,
        "bytes": output.stat().st_size,
        "sha256": sha256_file(output),
        "fixed_timestamp": "2000-01-01T00:00:00",
        "compression": "ZIP_STORED",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build(args.root, args.output)
    print("ZIP_BUILD=PASS")
    print(f"output={report['output']}")
    print(f"bytes={report['bytes']}")
    print(f"sha256={report['sha256']}")


if __name__ == "__main__":
    main()
