# AUTHORITY UPDATES

## Accepted new authority

### AU-1 — Terminal soundness requirement

A finite-state descent to a narrower shift language produces bounded state-badness, not automatically a bounded original counterexample. Future stateful proposals must include a terminal decoder or state-specific finite certificate.

Status: `ACCEPTED LOGICAL AUTHORITY`.

### AU-2 — Affine S-unit Fiber Classification

For fixed \(K\ge2,C\), every infinite solution component of

\[
K(3^c+5^d)+C=3^u+5^v
\]

is an axis fiber: vertical at a power-of-5 scale or horizontal at a power-of-3 scale. All other solutions are finite accidents.

Status: `ACCEPTED STRUCTURAL THEOREM`, conditional only on standard cited ESS finite-rank unit-equation theorem.

### AU-3 — Entropy–Sparsity Finite-State No-Go

No finite nonvacuous exact affine shift-language system with scales \(K_e\ge2\) can combine complete tail congruence coverage with closure into \(\mathcal H\).

Status: `ACCEPTED NEGATIVE STRUCTURAL AUTHORITY`.

### AU-4 — Gaussian affine closure remains reduced

Full-rank affine Gaussian transformations give no additive repair and remain subsumed by AU-2/AU-3.

Status: `RECONFIRMED`.

## Unchanged authority

- Frozen direct two-square result remains a positive-density theorem only.
- Prior descent finite-certificate trigger remains conditional and unproved.
- Prior exact computations remain bounded evidence without a theorem-linked universal threshold.
- Project status remains paused; no promoted active route exists.

## Route governance update

```text
FINITE-STATE MULTI-BRANCH EXACT AFFINE DESCENT:
STOP

CODEX:
NOT AUTHORIZED

CODEX ULTRA:
NOT AUTHORIZED

OEIS A303656:
UNRESOLVED
```
