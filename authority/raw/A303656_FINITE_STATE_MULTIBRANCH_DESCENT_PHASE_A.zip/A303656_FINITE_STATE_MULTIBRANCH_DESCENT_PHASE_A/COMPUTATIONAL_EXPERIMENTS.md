# COMPUTATIONAL EXPERIMENTS

## 1. Classification

Every numerical result in this section is labeled

```text
COMPUTATIONAL OBSERVATION
```

unless independently proved in `PROVED_LEMMAS.md`.

## 2. Exact arithmetic and bounds

Script: `scripts/run_experiments.py`.

- Python arbitrary-precision integers; no overflow.
- Norm scales: all \(2\le K\le200\) that are sums of two squares.
- Offsets: \(-500\le C\le500\).
- Full grid test: \(0\le c,d\le8\).
- Axis shallow/deep checks: fixed index \(0\ldots8\), variable exponent through 12 and 32.
- Diagonal rays: origins \(0\ldots3\), steps \(1\ldots3\) in both coordinates, shallow \(t\le8\), deep \(t\le18\).
- Collision box: \(0\le c,d\le30\).

The target membership table is generated exactly up to the maximum possible tested image.

## 3. Results

From `results/experiments.json`:

- 78 norm scales;
- 78,078 affine maps tested;
- zero maps carrying the full \(9\times9\) exponent grid into \(\mathcal H\);
- 11,243,232 genuinely two-coordinate rays tested;
- zero shallow or deep diagonal survivors;
- 68 predicted vertical fibers and 23 predicted horizontal fibers within the parameter box;
- zero unexplained deep axis fibers;
- every tested multiple of 15 up to 10,000 was outside every bounded axis-branch domain;
- one colliding shift value in the \(31\times31\) box:
  \[
  28=3^1+5^2=3^3+5^0.
  \]

## 4. Verified examples

Vertical:

\[
5(3^0+5^d)-2=3^1+5^{d+1}
\qquad(0\le d\le32\text{ checked}).
\]

Horizontal:

\[
9(3^c+5^0)-4=3^{c+2}+5^1
\qquad(0\le c\le32\text{ checked}).
\]

Their global validity follows symbolically, not from the checks.

## 5. Completeness boundary

The search bounds are not claimed complete over all \(K,C\), automata, or exponents. The global statements are instead proved by S-unit rigidity and entropy–sparsity. Bounded absence is used only as false-positive rejection and sanity checking.

## 6. Replay

`python3 scripts/replay.py --root .` regenerates `experiments.json` in a temporary directory and requires byte identity with the authoritative result.
