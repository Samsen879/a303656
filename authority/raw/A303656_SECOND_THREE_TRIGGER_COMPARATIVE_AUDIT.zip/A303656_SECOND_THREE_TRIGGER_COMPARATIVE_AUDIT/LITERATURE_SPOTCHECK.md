# LITERATURE SPOT-CHECK

This audit independently spot-checked the most load-bearing current bibliographic claims on 2026-07-21.

- OEIS A303656 remains explicitly conjectural and records verification through `2.4*10^11` in a 2022 comment.
- Croot--Mao--Pohoata--Sheffer--Yip, arXiv:2606.17487v2, is a combinatorial large-sieve paper for bounded algebraic multiplicities and norm-form applications; its abstract does not supply a complete-family private-witness bound.
- Fan--Lott, arXiv:2606.29185v2, proves a van der Corput/Sárközy-type difference-set theorem for sums of two squares; this has the wrong structure for fixed-translate coverage by the logarithmic shift set.
- Iudelevich, arXiv:2508.02701, concerns a different quotient observable involving the sum-of-squares representation function.
- Johnston--Trudgian, arXiv:2605.17825, uses many powers of two in the Linnik--Goldbach architecture and does not provide a two-factor mixed-base pointwise theorem.

The negative statement “no directly applicable theorem was found” is necessarily an audit conclusion, not a proof of nonexistence across all literature. No contradiction to the package crosswalk was found in the spot-check.
