# ARTIFACT AUDIT

## Outer archives

| Package | Outer SHA256 | ZIP integrity | Internal verifier | C0 scan | Deterministic rebuild |
|---|---|---:|---:|---:|---:|
| `A303656_THETA_SERIES_POINTWISE_PHASE_A_DETERMINISTIC.zip` | `15496d228ebf6a49b0cc41bb1cc4d88594362ae9b694c7fa2cec6362f7b97909` | PASS | PASS | PASS | BYTE-IDENTICAL |
| `A303656_PRIVATE_WITNESS_SUPPRESSION_PHASE_A(1).zip` | `e73359aea8c3d9c808e48861b59a748df237d672383e2904c1c1a29e79759005` | PASS | PASS | PASS | BYTE-IDENTICAL |
| `A303656_NU_TAU_PARALLEL_SHIFT_TRIGGER_PHASE_A(1).zip` | `561c4206bd5ae4019222f0ea28ff9d069680cc12162c10191d279b54174eb464` | PASS | PASS | PASS | BYTE-IDENTICAL |

Forbidden C0 bytes were defined as bytes below `0x20` other than tab, LF, and CR. No forbidden bytes were found in any of the three delivered packages.

## Reproduction commands executed

- Theta: `verify_bundle.py`, `check_candidate_formula.py`, deterministic ZIP builder.
- Private witness: `validate_package.py`, `verify_lemmas.py`, deterministic ZIP builder.
- NU-TAU: full `REPRODUCE.sh`, including formula replay, bundle verification, and deterministic ZIP builder.

## Provenance limitation

The source-lock records list primary-paper versions and PDF hashes, but the primary PDFs are not embedded in the delivered ZIPs. The mathematical core proofs are present; the literature crosswalk is therefore auditable from recorded identifiers but not fully self-contained byte-for-byte.

## Upstream defect report not yet promoted

The private-witness package reports a `0x0C` defect in an upstream `a303656_p2cover_bundle` report. That upstream archive was not one of the three mounted inputs in this comparative audit, so this additional defect report is **NOT INDEPENDENTLY RECHECKED HERE** and must not yet alter the p2-cover authority record.
