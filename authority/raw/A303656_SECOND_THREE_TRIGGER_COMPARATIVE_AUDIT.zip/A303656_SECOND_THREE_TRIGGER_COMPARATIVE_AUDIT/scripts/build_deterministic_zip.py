#!/usr/bin/env python3
from pathlib import Path
import stat, sys, zipfile
FIXED=(1980,1,1,0,0,0)
root=Path(sys.argv[1]).resolve(); out=Path(sys.argv[2]).resolve()
files=sorted(p for p in root.rglob('*') if p.is_file() and p.resolve()!=out)
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_STORED) as z:
    for p in files:
        info=zipfile.ZipInfo(f'{root.name}/{p.relative_to(root).as_posix()}',FIXED)
        info.create_system=3; info.external_attr=(stat.S_IFREG|0o644)<<16; info.compress_type=zipfile.ZIP_STORED
        z.writestr(info,p.read_bytes())
