# Authority hierarchy

1. Web-side accepted mathematical scope.
2. Exact raw source artifact hashes.
3. Independent audits.
4. Master V2 candidate ledgers.
5. Historical local reports.

Conflicts remain explicit; this candidate is not final authority.
