#!/usr/bin/env python3
"""Fail-closed verifier for the A303656 post-trigger master authority package."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import tempfile
import zipfile
from pathlib import Path


ALLOWED_THEOREM_CLASSES = {
    "PROVED",
    "PROVED_CONDITIONAL_ON_STANDARD_CITED_THEOREM",
    "CONDITIONAL",
    "CERTIFIED",
    "EXACT_FINITE_COMPUTATION",
    "OBSERVATION",
    "HEURISTIC",
    "UNKNOWN",
    "UNRESOLVED",
}

ALLOWED_ADJUDICATIONS = {
    "ACCEPTED",
    "ACCEPTED_WITH_CONDITIONS",
    "ACCEPTED_WITH_CUSTODY_EXCEPTION",
    "ACCEPTED_AS_CONDITIONAL_ONLY",
    "ACCEPTED_AS_NEGATIVE_AUTHORITY",
    "SUPERSEDED",
    "REJECTED",
    "NOT_ESTABLISHED",
}

ALLOWED_ROUTE_STATES = {
    "FREEZE_AND_STOP",
    "STOP",
    "CLOSED_FAIL",
    "NOT_AUTHORIZED",
    "SPECULATIVE_WATCH",
    "PAUSE",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def verify_directory(root: Path) -> dict:
    errors: list[str] = []
    required = {
        "README.md",
        "EXECUTIVE_VERDICT.md",
        "MASTER_AUTHORITY_REPORT.md",
        "MASTER_AUTHORITY_REPORT_zh.md",
        "AUTHORITY_HIERARCHY.md",
        "AUTHORITY_HIERARCHY.json",
        "THEOREM_LEDGER.md",
        "THEOREM_LEDGER.json",
        "FINITE_COMPUTATION_LEDGER.md",
        "FINITE_COMPUTATION_LEDGER.json",
        "ROUTE_MATRIX.md",
        "ROUTE_MATRIX.csv",
        "ROUTE_MATRIX.json",
        "ARTIFACT_DEFECT_LEDGER.md",
        "ARTIFACT_DEFECT_LEDGER.json",
        "RESTART_GATE.md",
        "RESTART_GATE.json",
        "CUSTODY_EXCEPTION.md",
        "SOURCE_ARCHIVE_INVENTORY.json",
        "SOURCE_ARCHIVE_INVENTORY.tsv",
        "REPOSITORY_AUTHORITY_SNAPSHOT.json",
        "MACHINE_VERDICT.json",
        "PACKAGE_MANIFEST.json",
        "PACKAGE_FILE_LIST.txt",
        "SHA256SUMS.txt",
        "environment.json",
        "scripts/verify_master_authority.py",
        "scripts/build_deterministic_authority_zip.py",
        "scripts/build_master_authority.py",
    }
    for relative in sorted(required):
        path = root / relative
        if not path.is_file() or path.stat().st_size == 0:
            errors.append(f"REQUIRED_FILE_MISSING_OR_EMPTY:{relative}")

    manifest_path = root / "SHA256SUMS.txt"
    manifest_records: dict[str, str] = {}
    if manifest_path.is_file():
        for line_number, line in enumerate(
            manifest_path.read_text(encoding="utf-8").splitlines(), start=1
        ):
            if not line:
                continue
            try:
                expected, relative = line.split("  ", 1)
            except ValueError:
                errors.append(f"BAD_MANIFEST_LINE:{line_number}")
                continue
            if len(expected) != 64 or relative in manifest_records:
                errors.append(f"BAD_OR_DUPLICATE_MANIFEST_RECORD:{relative}")
                continue
            manifest_records[relative] = expected

    regular_files = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path.name != "SHA256SUMS.txt"
    }
    if set(manifest_records) != regular_files:
        missing = sorted(regular_files - set(manifest_records))
        extra = sorted(set(manifest_records) - regular_files)
        if missing:
            errors.append(f"MANIFEST_MISSING:{missing}")
        if extra:
            errors.append(f"MANIFEST_EXTRA:{extra}")
    for relative, expected in manifest_records.items():
        path = root / relative
        if path.is_file() and sha256(path) != expected:
            errors.append(f"SHA256_MISMATCH:{relative}")

    file_list_path = root / "PACKAGE_FILE_LIST.txt"
    if file_list_path.is_file():
        listed = {
            line
            for line in file_list_path.read_text(encoding="utf-8").splitlines()
            if line
        }
        if listed != regular_files:
            errors.append("PACKAGE_FILE_LIST_MISMATCH")

    json_paths = sorted(root.rglob("*.json"))
    parsed = {}
    for path in json_paths:
        try:
            parsed[path.relative_to(root).as_posix()] = load_json(path)
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"JSON_PARSE_ERROR:{path.relative_to(root)}:{exc}")

    verdict = parsed.get("MACHINE_VERDICT.json", {})
    expected_verdict = {
        "a303656_status": "UNRESOLVED",
        "project_status": "PAUSED",
        "active_promoted_route": None,
        "certified_counterexample_found": False,
        "general_proof_obtained": False,
        "master_package_verdict": "PASS_WITH_DISCLOSED_CUSTODY_EXCEPTION",
    }
    for key, expected in expected_verdict.items():
        if verdict.get(key) != expected:
            errors.append(f"MACHINE_VERDICT_MISMATCH:{key}")

    theorem_ledger = parsed.get("THEOREM_LEDGER.json", {})
    theorem_rows = theorem_ledger.get("entries", [])
    theorem_ids = [row.get("id") for row in theorem_rows]
    if len(theorem_ids) != len(set(theorem_ids)):
        errors.append("DUPLICATE_THEOREM_ID")
    for row in theorem_rows:
        if row.get("classification") not in ALLOWED_THEOREM_CLASSES:
            errors.append(f"BAD_THEOREM_CLASS:{row.get('id')}")
        if row.get("adjudication") not in ALLOWED_ADJUDICATIONS:
            errors.append(f"BAD_THEOREM_ADJUDICATION:{row.get('id')}")
        if not row.get("scope_limit"):
            errors.append(f"MISSING_THEOREM_SCOPE_LIMIT:{row.get('id')}")

    finite_ledger = parsed.get("FINITE_COMPUTATION_LEDGER.json", {})
    for row in finite_ledger.get("entries", []):
        if row.get("classification") != "EXACT_FINITE_COMPUTATION":
            errors.append(f"BAD_FINITE_CLASS:{row.get('id')}")
        bounds = row.get("explicit_bounds")
        if not bounds:
            errors.append(f"MISSING_EXPLICIT_BOUNDS:{row.get('id')}")
        if row.get("global_implication") not in {
            "NONE",
            "BOUNDED_RESULT_ONLY",
            "ROUTE_SPECIFIC_OBSTRUCTION_ONLY",
        }:
            errors.append(f"BAD_FINITE_GLOBAL_IMPLICATION:{row.get('id')}")

    route_matrix = parsed.get("ROUTE_MATRIX.json", {})
    route_rows = route_matrix.get("routes", [])
    route_ids = [row.get("id") for row in route_rows]
    if len(route_ids) != len(set(route_ids)):
        errors.append("DUPLICATE_ROUTE_ID")
    for row in route_rows:
        if row.get("state") not in ALLOWED_ROUTE_STATES:
            errors.append(f"BAD_ROUTE_STATE:{row.get('id')}")
        if row.get("state") == "SPECULATIVE_WATCH" and not row.get(
            "exact_restart_trigger"
        ):
            errors.append(f"WATCH_WITHOUT_EXACT_TRIGGER:{row.get('id')}")

    csv_path = root / "ROUTE_MATRIX.csv"
    if csv_path.is_file():
        with csv_path.open(newline="", encoding="utf-8") as handle:
            csv_rows = list(csv.DictReader(handle))
        if [row["id"] for row in csv_rows] != route_ids:
            errors.append("ROUTE_CSV_JSON_ID_MISMATCH")

    defects = parsed.get("ARTIFACT_DEFECT_LEDGER.json", {})
    defect_rows = defects.get("defects", [])
    defect_ids = [row.get("id") for row in defect_rows]
    if len(defect_ids) != len(set(defect_ids)):
        errors.append("DUPLICATE_DEFECT_ID")
    missing_hash = "1d8bb9b45cb556d4693b568d42b10af386de88e734094d1af5f0396c9c243ff8"
    missing_defect = [
        row
        for row in defect_rows
        if row.get("expected_sha256") == missing_hash
        and row.get("status") == "OPEN_DISCLOSED_CUSTODY_EXCEPTION"
    ]
    if len(missing_defect) != 1:
        errors.append("MISSING_CUSTODY_EXCEPTION_NOT_EXACTLY_RECORDED")

    source_inventory = parsed.get("SOURCE_ARCHIVE_INVENTORY.json", {})
    source_rows = source_inventory.get("archives", [])
    source_hashes = [row.get("sha256") for row in source_rows]
    if len(source_hashes) != len(set(source_hashes)):
        errors.append("DUPLICATE_ACTIVE_SOURCE_ARCHIVE_HASH")
    for row in source_rows:
        relative = row.get("package_path", "")
        path = root / relative
        if not path.is_file():
            errors.append(f"SOURCE_ARCHIVE_MISSING:{relative}")
            continue
        if sha256(path) != row.get("sha256"):
            errors.append(f"SOURCE_ARCHIVE_HASH_MISMATCH:{relative}")
        try:
            with zipfile.ZipFile(path) as archive:
                bad = archive.testzip()
                if bad is not None:
                    errors.append(f"SOURCE_ARCHIVE_CRC_FAILURE:{relative}:{bad}")
                for info in archive.infolist():
                    member = Path(info.filename)
                    if member.is_absolute() or ".." in member.parts:
                        errors.append(
                            f"UNSAFE_SOURCE_ARCHIVE_MEMBER:{relative}:{info.filename}"
                        )
        except zipfile.BadZipFile:
            errors.append(f"BAD_SOURCE_ARCHIVE:{relative}")

    missing_sources = source_inventory.get("missing_historical_inputs", [])
    if not any(row.get("sha256") == missing_hash for row in missing_sources):
        errors.append("SOURCE_INVENTORY_MISSING_CUSTODY_EXCEPTION")

    repository_snapshot = parsed.get("REPOSITORY_AUTHORITY_SNAPSHOT.json", {})
    snapshot_rows = repository_snapshot.get("files", [])
    if repository_snapshot.get("repository_head") != (
        "23eecc0137cf9ddd0d0640b2ac9e1f5fa3b10c67"
    ):
        errors.append("REPOSITORY_SNAPSHOT_HEAD_MISMATCH")
    if repository_snapshot.get("file_count") != len(snapshot_rows):
        errors.append("REPOSITORY_SNAPSHOT_COUNT_MISMATCH")
    if repository_snapshot.get("total_bytes") != sum(
        row.get("size_bytes", -1) for row in snapshot_rows
    ):
        errors.append("REPOSITORY_SNAPSHOT_SIZE_MISMATCH")
    snapshot_paths = [row.get("path") for row in snapshot_rows]
    if len(snapshot_paths) != len(set(snapshot_paths)):
        errors.append("DUPLICATE_REPOSITORY_SNAPSHOT_PATH")
    for row in snapshot_rows:
        relative = row.get("path", "")
        path = root / "repository_snapshot" / relative
        if not path.is_file():
            errors.append(f"REPOSITORY_SNAPSHOT_FILE_MISSING:{relative}")
            continue
        if path.stat().st_size != row.get("size_bytes"):
            errors.append(f"REPOSITORY_SNAPSHOT_FILE_SIZE_MISMATCH:{relative}")
        if sha256(path) != row.get("sha256"):
            errors.append(f"REPOSITORY_SNAPSHOT_FILE_HASH_MISMATCH:{relative}")

    restart_gate = parsed.get("RESTART_GATE.json", {})
    if restart_gate.get("current_decision") != "PAUSE":
        errors.append("RESTART_GATE_CURRENT_DECISION_NOT_PAUSE")
    if restart_gate.get("automatic_restart_authorized") is not False:
        errors.append("AUTOMATIC_RESTART_MUST_BE_FALSE")
    if not restart_gate.get("exact_triggers"):
        errors.append("RESTART_GATE_HAS_NO_TRIGGERS")

    hierarchy = parsed.get("AUTHORITY_HIERARCHY.json", {})
    if hierarchy.get("unresolved_bridges") != [
        "indicator_level_lower_tail_or_signed_covariance",
        "effective_exceptional_set_elimination",
        "representation_independent_non_affine_unconditional_descent",
    ]:
        errors.append("UNRESOLVED_BRIDGE_SET_MISMATCH")

    baseline = parsed.get("PACKAGE_MANIFEST.json", {}).get("baseline_snapshot", {})
    for relative, expected in baseline.items():
        path = root / "baseline_snapshot" / relative
        if not path.is_file() or sha256(path) != expected:
            errors.append(f"BASELINE_SNAPSHOT_MISMATCH:{relative}")

    return {
        "schema": "a303656-master-authority-verification-v1",
        "status": "PASS" if not errors else "FAIL",
        "root": str(root.resolve()),
        "errors": errors,
        "manifest_record_count": len(manifest_records),
        "source_archive_count": len(source_rows),
        "theorem_entry_count": len(theorem_rows),
        "finite_computation_entry_count": len(finite_ledger.get("entries", [])),
        "route_count": len(route_rows),
        "defect_count": len(defect_rows),
        "json_file_count": len(json_paths),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--root", type=Path)
    group.add_argument("--zip", dest="zip_path", type=Path)
    args = parser.parse_args()

    if args.root is not None:
        result = verify_directory(args.root.resolve())
    else:
        try:
            with tempfile.TemporaryDirectory(prefix="a303656-master-verify-") as tmp:
                with zipfile.ZipFile(args.zip_path.resolve()) as archive:
                    bad = archive.testzip()
                    if bad is not None:
                        raise RuntimeError(f"ZIP_CRC_FAILURE:{bad}")
                    names = archive.namelist()
                    if not names:
                        raise RuntimeError("EMPTY_ZIP")
                    top_levels = {
                        Path(name).parts[0]
                        for name in names
                        if Path(name).parts
                    }
                    if len(top_levels) != 1:
                        raise RuntimeError("ZIP_MUST_HAVE_ONE_TOP_LEVEL_DIRECTORY")
                    for info in archive.infolist():
                        member = Path(info.filename)
                        if member.is_absolute() or ".." in member.parts:
                            raise RuntimeError(
                                f"UNSAFE_ZIP_MEMBER:{info.filename}"
                            )
                    archive.extractall(tmp)
                result = verify_directory(Path(tmp) / next(iter(top_levels)))
                result["zip"] = str(args.zip_path.resolve())
                result["zip_sha256"] = sha256(args.zip_path.resolve())
        except (OSError, RuntimeError, zipfile.BadZipFile) as exc:
            result = {
                "schema": "a303656-master-authority-verification-v1",
                "status": "FAIL",
                "errors": [str(exc)],
            }

    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
