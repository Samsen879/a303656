#!/usr/bin/env python3
"""Generate the A303656 post-trigger master authority package.

The generator is deliberately archival rather than exploratory.  It copies
authenticated source archives, snapshots the certified baseline authority
files, emits the adjudication ledgers, and creates a self-excluding SHA256
manifest.  It performs no T(n) evaluation and no mathematical search.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path


PACKAGE_NAME = "A303656_POST_TRIGGER_MASTER_AUTHORITY_AND_RESTART_GATE_REVIEW"
EXPECTED_HEAD = "23eecc0137cf9ddd0d0640b2ac9e1f5fa3b10c67"
MISSING_POSITIVE_DENSITY_SHA256 = (
    "1d8bb9b45cb556d4693b568d42b10af386de88e734094d1af5f0396c9c243ff8"
)


SOURCE_ARCHIVES = [
    {
        "id": "SRC-001",
        "canonical_name": "A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A.zip",
        "source_name": "A303656_CANONICAL_CERTIFICATE_COMPRESSION_PHASE_A.zip",
        "sha256": "51efabb8b7f6d9dad65021be11cdda4316da91f9530abb7ddef8d648b4d9fd71",
        "authority_role": "HC-A and canonical-record saturation authority",
        "adjudication": "ACCEPTED_WITH_CUSTODY_EXCEPTION",
    },
    {
        "id": "SRC-002",
        "canonical_name": "A303656_CANONICAL_MULTIBRANCH_COMPARATIVE_AUDIT.zip",
        "source_name": "A303656_CANONICAL_MULTIBRANCH_COMPARATIVE_AUDIT.zip",
        "sha256": "41172ce4e5f67424edd99844c269f6ab4f2ba4cb4a0282f0a501c449f8e8380c",
        "authority_role": "independent comparative adjudication of HC-A and affine descent",
        "adjudication": "ACCEPTED",
    },
    {
        "id": "SRC-003",
        "canonical_name": "A303656_DESCENT_FINITE_REDUCTION_PHASE_A.zip",
        "source_name": "A303656_DESCENT_FINITE_REDUCTION_PHASE_A.zip",
        "sha256": "bebf5f5735fb476bb8d1859f297203715e07bc4de94f56bbf880f6763936205d",
        "authority_role": "earlier finite-reduction candidate and no-promotion record",
        "adjudication": "SUPERSEDED",
    },
    {
        "id": "SRC-004",
        "canonical_name": "A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN.zip",
        "source_name": "A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(2).zip",
        "sha256": "aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2",
        "authority_role": "active frozen positive-density theorem authority",
        "adjudication": "ACCEPTED",
    },
    {
        "id": "SRC-005",
        "canonical_name": "A303656_EXCEPTIONAL_SET_INVERSE_PHASE_A.zip",
        "source_name": "A303656_EXCEPTIONAL_SET_INVERSE_PHASE_A.zip",
        "sha256": "7d82d189cad508f150c2379b5009290ea82bf908c6a9fe29807d1358d6711b31",
        "authority_role": "critical spectral scale and inverse-route barrier",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
    },
    {
        "id": "SRC-006",
        "canonical_name": "A303656_FINITE_STATE_MULTIBRANCH_DESCENT_PHASE_A.zip",
        "source_name": "A303656_FINITE_STATE_MULTIBRANCH_DESCENT_PHASE_A.zip",
        "sha256": "ddfeb79af1046e5f44245e192341f35a43103627a6af1ef8ba6940dc6a4be34c",
        "authority_role": "affine S-unit classification and entropy-sparsity no-go",
        "adjudication": "ACCEPTED_WITH_CUSTODY_EXCEPTION",
    },
    {
        "id": "SRC-007",
        "canonical_name": "A303656_GAUSSIAN_NORM_PHASE_A_DETERMINISTIC.zip",
        "source_name": "A303656_GAUSSIAN_NORM_PHASE_A_DETERMINISTIC.zip",
        "sha256": "2f9b1323805d03e47e6edc4a4766073ac8d610d6a555a5778d39196583fedc6a",
        "authority_role": "Gaussian rigidity and single-branch sparsity obstruction",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
    },
    {
        "id": "SRC-008",
        "canonical_name": "A303656_GLOBAL_ROUTE_RESET.zip",
        "source_name": "A303656_GLOBAL_ROUTE_RESET(1)(1).zip",
        "sha256": "b063ab790121a80fb74c124e035a50647ef2d47b0fd2fd84a67cbe595bd63e13",
        "authority_role": "pre-trigger project pause and route governance baseline",
        "adjudication": "SUPERSEDED",
    },
    {
        "id": "SRC-009",
        "canonical_name": "A303656_NU_TAU_PARALLEL_SHIFT_TRIGGER_PHASE_A.zip",
        "source_name": "A303656_NU_TAU_PARALLEL_SHIFT_TRIGGER_PHASE_A.zip",
        "sha256": "561c4206bd5ae4019222f0ea28ff9d069680cc12162c10191d279b54174eb464",
        "authority_role": "mod-6 variance obstruction and STOP decision",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
    },
    {
        "id": "SRC-010",
        "canonical_name": "A303656_P4_MOD8_LIVE_INDEPENDENT_AUDIT_20260715.zip",
        "source_name": "A303656_P4_MOD8_LIVE_INDEPENDENT_AUDIT_Samsen_20260715.zip",
        "sha256": "cc917a6f7f04f6a4f6264775d63129c4fd7f18af40116b27291b3226014c570d",
        "authority_role": "accept exact P4 core and reject freshness/promotion claims",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
    },
    {
        "id": "SRC-011",
        "canonical_name": "A303656_PRIVATE_WITNESS_SUPPRESSION_PHASE_A.zip",
        "source_name": "A303656_PRIVATE_WITNESS_SUPPRESSION_PHASE_A.zip",
        "sha256": "e73359aea8c3d9c808e48861b59a748df237d672383e2904c1c1a29e79759005",
        "authority_role": "private-witness positive-density obstruction",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
    },
    {
        "id": "SRC-012",
        "canonical_name": "A303656_SIMULTANEOUS_SELECTION_PHASE_A.zip",
        "source_name": "A303656_SIMULTANEOUS_SELECTION_PHASE_A.zip",
        "sha256": "95736761e3211a35682cc034d2d13d6f13bce6a5281e8c90bb2d56097ce631a2",
        "authority_role": "actual-mask Helly/profinite barriers and CRW watch record",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
    },
    {
        "id": "SRC-013",
        "canonical_name": "A303656_WEIGHTED_MINORANT_PHASE_A.zip",
        "source_name": "A303656_WEIGHTED_MINORANT_PHASE_A.zip",
        "sha256": "f5fc3c8a4563c2e46060244fe33567018ac367cc852b76393c61bc2b97101ce4",
        "authority_role": "nu_tau exact-support bounded minorant and correct mean scale",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
    },
    {
        "id": "SRC-014",
        "canonical_name": "a303656_gate_v2_final_independent_audit.zip",
        "source_name": "a303656_gate_v2_final_independent_audit.zip",
        "sha256": "fedbfd4d5079d1ccd23cb6fca61c23a61b7419a01bd7b278168e6bc2750cc49b",
        "authority_role": "Gate V2 rejection, registry rejection, and authorization closure",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
    },
    {
        "id": "SRC-015",
        "canonical_name": "analytic_bad_prime_phaseA.zip",
        "source_name": "analytic_bad_prime_phaseA.zip",
        "sha256": "9dd538f5d47a4d2327159b619af7db752f241421caef926207e623be6a8b1ec2",
        "authority_role": "random-CRT L2 versus adversarial L-infinity barrier",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
    },
    {
        "id": "SRC-016",
        "canonical_name": "a303656_bounded_counterexample_bundle_refreshed.zip",
        "source_name": "a303656_bounded_counterexample_bundle_refreshed.zip",
        "sha256": "f877561680531f448e90d38bb097a8d05379d3b25f993e44289ed8f82baa0316",
        "authority_role": "certified baseline exact finite computations and raw audit package",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
    },
    {
        "id": "SRC-017",
        "canonical_name": "a303656_p2cover_bundle.zip",
        "source_name": "a303656_p2cover_bundle.zip",
        "sha256": "4dadb8ce07cd0ccf56575ef0882d6bb02284a02c61e05cd1424e070d83b22ff3",
        "authority_role": "bounded-order p2-cover obstruction and lower-bound certificate",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
    },
]


THEOREMS = [
    {
        "id": "P-001",
        "group": "POSITIVE_AUTHORITY",
        "name": "Direct dyadic positive-density theorem",
        "classification": "PROVED",
        "adjudication": "ACCEPTED",
        "statement": (
            "A positive proportion of every sufficiently large dyadic interval "
            "has at least on the order of (log X)^(3/2) admissible exponent-pair "
            "representations through the sums-of-two-squares support."
        ),
        "source_ids": ["SRC-004", "SRC-008"],
        "scope_limit": (
            "Positive density only; substantially subsumed by Radomskii v6; "
            "does not imply almost-all or universal representability."
        ),
    },
    {
        "id": "P-002",
        "group": "POSITIVE_AUTHORITY",
        "name": "Distinct-shift positive-density variant",
        "classification": "PROVED",
        "adjudication": "ACCEPTED",
        "statement": (
            "The positive-density conclusion survives after equal numerical "
            "shifts are merged, with the unique nontrivial collision handled."
        ),
        "source_ids": ["SRC-004"],
        "scope_limit": "Same positive-density-only limit as P-001.",
    },
    {
        "id": "P-003",
        "group": "POSITIVE_AUTHORITY",
        "name": "Shift multiplicity, Sidon-scale energy, and singular-factor support",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
        "statement": (
            "The structured shift family has bounded multiplicity, Sidon-scale "
            "additive energy, and the frozen structured singular-factor average."
        ),
        "source_ids": ["SRC-004"],
        "scope_limit": (
            "Supporting structure only; novelty is not established and the "
            "lemmas do not supply indicator covariance cancellation."
        ),
    },
    {
        "id": "P-004",
        "group": "POSITIVE_AUTHORITY",
        "name": "nu_tau exact-support bounded minorant and correct mean scale",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
        "statement": (
            "nu_tau(n)=r_2(n)/(4 tau(n)) is nonnegative, bounded by the "
            "two-square indicator, has exactly the two-square support, and has "
            "first moment c_tau X/sqrt(log X)+O(X/(log X)^(3/2)), c_tau>0."
        ),
        "source_ids": ["SRC-013"],
        "scope_limit": (
            "No applicable growing parallel-shift covariance theorem is known; "
            "the finite sanity computation is non-evidentiary."
        ),
    },
    {
        "id": "P-005",
        "group": "POSITIVE_AUTHORITY",
        "name": "Weighted concentration-to-support implication",
        "classification": "CONDITIONAL",
        "adjudication": "ACCEPTED_AS_CONDITIONAL_ONLY",
        "statement": (
            "For a bounded exact-support weight with the correct mean, a "
            "variance little-o at scale X W_X^2/log X implies o(X) uncovered integers."
        ),
        "source_ids": ["SRC-013"],
        "scope_limit": "The required variance/covariance hypothesis is UNPROVED.",
    },
    {
        "id": "P-006",
        "group": "POSITIVE_AUTHORITY",
        "name": "HC-A aggregate high-cutoff bad-tail bound",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_WITH_CUSTODY_EXCEPTION",
        "statement": (
            "At cutoff z=X^(1-delta), the aggregate high-cutoff bad-tail "
            "incidence over the complete structured shift family has the proved "
            "sqrt(delta)-scale saving stated in HC-A."
        ),
        "source_ids": ["SRC-001", "SRC-002"],
        "scope_limit": (
            "Does not bound the exceptional set without the unproved complete-"
            "survivor lower-tail theorem HC-LT."
        ),
    },
    {
        "id": "P-007",
        "group": "POSITIVE_AUTHORITY",
        "name": "HC-A plus HC-LT almost-all implication",
        "classification": "CONDITIONAL",
        "adjudication": "ACCEPTED_AS_CONDITIONAL_ONLY",
        "statement": "HC-A together with HC-LT would imply |E_X|=o(X).",
        "source_ids": ["SRC-001", "SRC-002"],
        "scope_limit": "HC-LT is UNKNOWN and close to the indicator-covariance barrier.",
    },
    {
        "id": "N-001",
        "group": "NEGATIVE_STRUCTURAL_AUTHORITY",
        "name": "Random CRT L2 versus adversarial L-infinity barrier",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
        "statement": (
            "Exact random-CRT moments control average residue tuples, while "
            "anti-cover against an optimized tuple is an L-infinity problem; "
            "the audited second-moment and uncentered-energy methods do not bridge it."
        ),
        "source_ids": ["SRC-015"],
        "scope_limit": "Does not exclude a genuinely new generator-specific centered theorem.",
    },
    {
        "id": "N-002",
        "group": "NEGATIVE_STRUCTURAL_AUTHORITY",
        "name": "Private-witness positive-density obstruction",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
        "statement": (
            "Along infinitely many n, private exact-valuation-one witnesses at "
            "the square-root cutoff occupy a positive proportion of the complete "
            "actual survivor family, before and after equal-shift merging."
        ),
        "source_ids": ["SRC-011"],
        "scope_limit": "Stops uniform private-witness suppression, not every witness method.",
    },
    {
        "id": "N-003",
        "group": "NEGATIVE_STRUCTURAL_AUTHORITY",
        "name": "Mod-6 nu_tau between-class variance obstruction",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
        "statement": (
            "The literal globally centered nu_tau proxy has a positive normalized "
            "variance liminf at least kappa_6, with the exact formula recorded in "
            "the source authority."
        ),
        "source_ids": ["SRC-009"],
        "scope_limit": (
            "A classwise W-trick removes this local bias but leaves an unproved "
            "parallel covariance theorem."
        ),
    },
    {
        "id": "N-004",
        "group": "NEGATIVE_STRUCTURAL_AUTHORITY",
        "name": "Theta/minor-arc critical-scale and phase barrier",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
        "statement": (
            "Sparse cross-avoidance forces absolute minor-spectrum control at "
            "scale O((log X)/sqrt(X)); existing one-sided theta/minor-arc bounds "
            "have the wrong scale or phase, and Sidon energy does not bound the "
            "major spectrum."
        ),
        "source_ids": ["SRC-005"],
        "scope_limit": "A future arithmetic bipartite expansion theorem is not excluded.",
    },
    {
        "id": "N-005",
        "group": "NEGATIVE_STRUCTURAL_AUTHORITY",
        "name": "Gaussian single-branch sparsity obstruction",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
        "statement": (
            "At a fixed affine scale, multiple exact shift branches would grow "
            "exponentially under iteration, contradicting the O((log X)^2) shift "
            "count; at most one branch can persist."
        ),
        "source_ids": ["SRC-007"],
        "scope_limit": "Does not exclude genuinely nonlinear, representation-independent maps.",
    },
    {
        "id": "N-006",
        "group": "NEGATIVE_STRUCTURAL_AUTHORITY",
        "name": "Affine S-unit axis-fiber classification",
        "classification": "PROVED_CONDITIONAL_ON_STANDARD_CITED_THEOREM",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
        "statement": (
            "Infinite affine inclusions in the shift language reduce to horizontal "
            "or vertical axis fibers, with all non-axis solutions finite."
        ),
        "source_ids": ["SRC-006", "SRC-002"],
        "scope_limit": (
            "Uses the cited Evertse-Schlickewei-Schmidt finite-rank unit-equation theorem."
        ),
    },
    {
        "id": "N-007",
        "group": "NEGATIVE_STRUCTURAL_AUTHORITY",
        "name": "Entropy-sparsity finite-state affine descent no-go",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
        "statement": (
            "No finite nonvacuous exact affine shift-language system with scales "
            "K_e>=2 has both complete tail congruence coverage and closure into "
            "the A303656 shift language with terminal soundness."
        ),
        "source_ids": ["SRC-006", "SRC-002"],
        "scope_limit": "Only the stated finite exact affine state framework is ruled out.",
    },
    {
        "id": "N-008",
        "group": "NEGATIVE_STRUCTURAL_AUTHORITY",
        "name": "Canonical-record critical saturation",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
        "statement": (
            "Complete-grid private canonical square-root records have total "
            "dyadic cardinality Theta(X (log X)^(3/2)), so raw one-record "
            "incidence charging reaches only O(X)."
        ),
        "source_ids": ["SRC-001", "SRC-002"],
        "scope_limit": "A different compressed record or a proved HC-LT theorem is not excluded.",
    },
    {
        "id": "N-009",
        "group": "NEGATIVE_STRUCTURAL_AUTHORITY",
        "name": "Actual-mask Helly and profinite compactness obstruction",
        "classification": "PROVED",
        "adjudication": "ACCEPTED_AS_NEGATIVE_AUTHORITY",
        "statement": (
            "Actual valuation masks exhibit unbounded Helly obstruction, and "
            "finite local/profinite consistency does not select one ordinary "
            "exponent pair completing all prime constraints."
        ),
        "source_ids": ["SRC-012"],
        "scope_limit": "Does not exclude a theorem using the full arithmetic witness graph.",
    },
]


FINITE_COMPUTATIONS = [
    {
        "id": "F-001",
        "name": "Certified baseline direct original-representation scan",
        "classification": "EXACT_FINITE_COMPUTATION",
        "adjudication": "ACCEPTED",
        "explicit_bounds": (
            "1,853,000,000 distinct integers across the five explicitly "
            "manifested datasets; strongest continuous interval "
            "[240000000001,241600000000]."
        ),
        "result": "candidate_count=0; every tested integer was represented",
        "source_ids": ["SRC-016"],
        "global_implication": "BOUNDED_RESULT_ONLY",
        "scope_limit": "No theorem links the tested region to all integers.",
    },
    {
        "id": "F-002",
        "name": "Bounded-order p2-cover obstruction",
        "classification": "EXACT_FINITE_COMPUTATION",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
        "explicit_bounds": (
            "All 527 eligible primes under the frozen order bound B=5000; "
            "the certified cardinality lower-bound computation is 598."
        ),
        "result": (
            "527 primes cannot cover; any such finite cover needs at least 598 "
            "primes and at least 135 primes beyond the order bound."
        ),
        "source_ids": ["SRC-017", "SRC-016"],
        "global_implication": "ROUTE_SPECIFIC_OBSTRUCTION_ONLY",
        "scope_limit": "Does not prove nonexistence of a larger finite cover.",
    },
    {
        "id": "F-003",
        "name": "Validated T(n) pilot",
        "classification": "EXACT_FINITE_COMPUTATION",
        "adjudication": "ACCEPTED",
        "explicit_bounds": (
            "PILOT-A [2,200002), 200000 integers; PILOT-B "
            "[240000000001,240000100001), 100000 integers."
        ),
        "result": (
            "PILOT-A minimum T=1 at 2,3,5,25; PILOT-B minimum T=16 at "
            "240000005594; no T=0."
        ),
        "source_ids": ["REPO-SNAPSHOT"],
        "global_implication": "BOUNDED_RESULT_ONLY",
        "scope_limit": "Only 300000 predeclared integers; no broad campaign authority.",
    },
    {
        "id": "F-004",
        "name": "Fixed-P4 maximizer-class census",
        "classification": "EXACT_FINITE_COMPUTATION",
        "adjudication": "ACCEPTED",
        "explicit_bounds": (
            "87 fixed CRT classes and 4838 exact panel points in "
            "[183968950234,246731069451], with 407 exponent pairs per point."
        ),
        "result": (
            "No T=0; unique G=231 minimum T=15 at n=196653638594."
        ),
        "source_ids": ["REPO-SNAPSHOT"],
        "global_implication": "BOUNDED_RESULT_ONLY",
        "scope_limit": "Finite fixed-P4 panel only.",
    },
    {
        "id": "F-005",
        "name": "Exact fixed-P4 mod-8-live landscape core",
        "classification": "EXACT_FINITE_COMPUTATION",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
        "explicit_bounds": (
            "P4={3,7,11,23}; n congruent 34 mod 40; complete "
            "9*49*121*529=28227969 tuple enumeration; 407 exponent pairs."
        ),
        "result": (
            "H8 min/max=32/201, 468 argmax tuples, lex-first "
            "(2,13,50,5), 21 maximizing full masks."
        ),
        "source_ids": ["REPO-SNAPSHOT", "SRC-010", "SRC-014"],
        "global_implication": "BOUNDED_RESULT_ONLY",
        "scope_limit": (
            "Exact landscape accepted; original strict freshness and promotion "
            "claims are rejected."
        ),
    },
    {
        "id": "F-006",
        "name": "Weighted fixed-P4 transferability audit",
        "classification": "EXACT_FINITE_COMPUTATION",
        "adjudication": "ACCEPTED_WITH_CONDITIONS",
        "explicit_bounds": (
            "Frozen 4671-point G=231 panel and complete fixed-P4 tuple domain."
        ),
        "result": (
            "Weighted optimum G=219 at lex-first (1,9,21,21); t3=2 "
            "weighted optimum G=222 at lex-first (2,13,32,13); 12 deduplicated masks."
        ),
        "source_ids": ["REPO-SNAPSHOT"],
        "global_implication": "BOUNDED_RESULT_ONLY",
        "scope_limit": "Empirical panel weights are not theorem evidence.",
    },
    {
        "id": "F-007",
        "name": "P5 Family-U unbalanced sparse census",
        "classification": "EXACT_FINITE_COMPUTATION",
        "adjudication": "ACCEPTED",
        "explicit_bounds": (
            "457 frozen Family-U descriptions, 457 CRT classes, and 454 "
            "distinct integers in [183968950234,246731069451]."
        ),
        "result": (
            "No T=0; minimum T=16 at 187808590514; exact mean 7762/227."
        ),
        "source_ids": ["REPO-SNAPSHOT", "SRC-014"],
        "global_implication": "BOUNDED_RESULT_ONLY",
        "scope_limit": "Family U only; no Family R/Q and no adaptive continuation.",
    },
    {
        "id": "F-008",
        "name": "Analytic bad-prime finite anti-cover family",
        "classification": "EXACT_FINITE_COMPUTATION",
        "adjudication": "ACCEPTED",
        "explicit_bounds": (
            "All 23 eligible primes p<=200 and seven declared finite family instances."
        ),
        "result": (
            "Certified finite-family survivor lower density at least "
            "0.3855312313183401933866...; route does not scale under added primes."
        ),
        "source_ids": ["SRC-015"],
        "global_implication": "ROUTE_SPECIFIC_OBSTRUCTION_ONLY",
        "scope_limit": "Fixed finite prime family only.",
    },
]


ROUTES = [
    {
        "id": "R-001",
        "route": "Direct positive-density theorem",
        "state": "FREEZE_AND_STOP",
        "authority": "P-001 through P-003",
        "reason": "The theorem is accepted but stops at positive density and is substantially subsumed.",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-002",
        "route": "Indicator-level signed covariance / lower tail",
        "state": "SPECULATIVE_WATCH",
        "authority": "P-005, P-007",
        "reason": "This is the principal almost-all bridge and remains unproved.",
        "exact_restart_trigger": (
            "A primary theorem proving the required growing-shift signed covariance "
            "or HC-LT with uniform, summable errors on the exact structured family."
        ),
    },
    {
        "id": "R-003",
        "route": "Literal globally centered nu_tau covariance trigger",
        "state": "STOP",
        "authority": "N-003",
        "reason": "The mod-6 between-class variance lower bound disproves the literal trigger.",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-004",
        "route": "Classwise-centered bounded exact-support weight",
        "state": "SPECULATIVE_WATCH",
        "authority": "P-004, P-005",
        "reason": "The weight exists; the required parallel covariance theorem does not.",
        "exact_restart_trigger": (
            "A boundary-uniform classwise/W-tricked parallel-shift asymptotic "
            "with h-dependent singular series and errors summable against the "
            "true structured difference multiplicity."
        ),
    },
    {
        "id": "R-005",
        "route": "Exceptional-set Fourier / density increment",
        "state": "SPECULATIVE_WATCH",
        "authority": "N-004",
        "reason": "Current theorems miss the critical scale, phase, alignment, or hereditary closure.",
        "exact_restart_trigger": (
            "An arithmetic bipartite expansion theorem with o((log X)/sqrt(X)) "
            "absolute minor error, bounded aligned major mass, and hereditary "
            "closure under the induced affine slices."
        ),
    },
    {
        "id": "R-006",
        "route": "Random CRT / analytic bad-prime second moment",
        "state": "STOP",
        "authority": "N-001",
        "reason": "Random-tuple L2 control does not imply adversarial optimized-tuple L-infinity control.",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-007",
        "route": "Private-witness suppression",
        "state": "STOP",
        "authority": "N-002",
        "reason": "The requested uniform suppression statement is false on the complete actual survivor family.",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-008",
        "route": "Simultaneous local selection / finite Helly / profinite compactness",
        "state": "STOP",
        "authority": "N-009",
        "reason": "Local consistency and bounded Helly data do not select one ordinary exponent pair.",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-009",
        "route": "Canonical one-record certificate compression",
        "state": "STOP",
        "authority": "N-008",
        "reason": "The natural record budget is critically saturated and yields only O(X).",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-010",
        "route": "HC-LT high-cutoff complete-survivor lower tail",
        "state": "SPECULATIVE_WATCH",
        "authority": "P-006, P-007",
        "reason": "HC-A is proved and HC-LT would close the almost-all counting chain.",
        "exact_restart_trigger": (
            "A proof of HC-LT with constants kappa>0 and rho(delta)->0 for "
            "the complete fixed-core survivor count, independently audited "
            "against indicator-level parity and boundary effects."
        ),
    },
    {
        "id": "R-011",
        "route": "Gaussian fixed-affine or single-branch descent",
        "state": "STOP",
        "authority": "N-005, N-006",
        "reason": "Affine rigidity and shift sparsity eliminate the fixed-affine branch class.",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-012",
        "route": "Finite-state exact affine multibranch descent",
        "state": "STOP",
        "authority": "N-006, N-007",
        "reason": "Complete tail coverage and exact affine shift-language closure are incompatible.",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-013",
        "route": "Representation-independent non-affine unconditional descent",
        "state": "SPECULATIVE_WATCH",
        "authority": "UNRESOLVED BRIDGE",
        "reason": "The accepted affine no-go does not cover a genuinely nonlinear transformation.",
        "exact_restart_trigger": (
            "An explicit representation-independent non-affine map with exact "
            "forward closure, strict descent, complete tail coverage, and a "
            "terminal decoder or state-specific certified coverage."
        ),
    },
    {
        "id": "R-014",
        "route": "Effective exceptional-set elimination",
        "state": "SPECULATIVE_WATCH",
        "authority": "UNRESOLVED BRIDGE",
        "reason": "Even an almost-all theorem does not eliminate infinitely many exceptions.",
        "exact_restart_trigger": (
            "An effective theorem proving eventual emptiness, an explicit finite "
            "exception threshold, or a certified descent from every exception "
            "above a stated bound."
        ),
    },
    {
        "id": "R-015",
        "route": "Linear extension of bounded interval search",
        "state": "STOP",
        "authority": "F-001 through F-008",
        "reason": "Exact finite evidence has no theorem-linked universal threshold.",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-016",
        "route": "P4 prospective Gate V2 / new T(n) panel",
        "state": "CLOSED_FAIL",
        "authority": "SRC-010, SRC-014",
        "reason": "Registry completeness and semantic-verifier soundness failed; historical non-reuse is not established.",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-017",
        "route": "New T(n) execution under the closed Gate V2 design",
        "state": "NOT_AUTHORIZED",
        "authority": "SRC-014",
        "reason": "Gate V2 closed FAIL and Design A remains Level 1 conditional only.",
        "exact_restart_trigger": "",
    },
    {
        "id": "R-018",
        "route": "Project-level active research",
        "state": "PAUSE",
        "authority": "Master adjudication",
        "reason": "No active promoted route survives; only exact-trigger watches remain.",
        "exact_restart_trigger": "",
    },
]


DEFECTS = [
    {
        "id": "D-001",
        "artifact": "historical positive-density input to SRC-001 and SRC-006",
        "status": "OPEN_DISCLOSED_CUSTODY_EXCEPTION",
        "severity": "CUSTODY",
        "expected_sha256": MISSING_POSITIVE_DENSITY_SHA256,
        "details": (
            "The exact 268781-byte historical input was not found in Downloads, "
            "Desktop, Documents, the repository family, or the local archive directory."
        ),
        "disposition": (
            "Do not reconstruct or impersonate the bytes. Use SRC-004 aa0392... "
            "as active positive authority; accept SRC-001/SRC-006 with custody exception."
        ),
    },
    {
        "id": "D-002",
        "artifact": "legacy positive-density input variant 1d8bb9...",
        "status": "SUPERSEDED_FOR_ACTIVE_AUTHORITY",
        "severity": "TYPOGRAPHY_AND_GENERATOR",
        "expected_sha256": MISSING_POSITIVE_DENSITY_SHA256,
        "details": "Input audits report form-feed control bytes in two Markdown files and generator source.",
        "disposition": "SRC-004 aa0392... is the active repaired positive-density authority.",
    },
    {
        "id": "D-003",
        "artifact": "SRC-012 simultaneous-selection replay",
        "status": "ACCEPTED_WITH_REPRODUCIBILITY_DEFECT",
        "severity": "REPRODUCIBILITY",
        "details": (
            "Replay differs only in the embedded platform/Python environment field; "
            "one legacy report contains a form-feed byte."
        ),
        "disposition": "Mathematical fields retained; byte-determinism claim downgraded.",
    },
    {
        "id": "D-004",
        "artifact": "SRC-007 Gaussian exact-check replay",
        "status": "ACCEPTED_WITH_REPRODUCIBILITY_DEFECT",
        "severity": "REPRODUCIBILITY",
        "details": "Replay mathematical JSON matches after deleting environment metadata.",
        "disposition": "Keep proofs and exact identities; do not claim cross-environment byte replay.",
    },
    {
        "id": "D-005",
        "artifact": "SRC-013 weighted-minorant sanity replay",
        "status": "ACCEPTED_WITH_NON_EVIDENTIARY_NUMERIC_DRIFT",
        "severity": "REPRODUCIBILITY",
        "details": "NumPy reductions differ in floating-point trailing digits at approximately 1e-13.",
        "disposition": "Sanity output remains non-evidentiary; exact theorem statements do not depend on it.",
    },
    {
        "id": "D-006",
        "artifact": "SRC-017 p2-cover legacy report",
        "status": "ACCEPTED_WITH_TYPOGRAPHY_DEFECT",
        "severity": "TYPOGRAPHY",
        "details": "REPORT_zh.md contains an authenticated form-feed byte in place of a TeX backslash.",
        "disposition": "Certificate, rebuilt source verifier, and exact numeric conclusions remain authoritative.",
    },
    {
        "id": "D-007",
        "artifact": "Windows duplicate downloads",
        "status": "RESOLVED_BY_HASH_DEDUPLICATION",
        "severity": "CUSTODY",
        "details": (
            "Descent, exceptional-set, Gaussian, simultaneous-selection, and "
            "weighted-minorant duplicate filenames have byte-identical hashes."
        ),
        "disposition": "One canonical copy per SHA256 is included; duplicates add no proof weight.",
    },
    {
        "id": "D-008",
        "artifact": "original P4 mod-8-live freshness and promotion claims",
        "status": "SUPERSEDED_AND_REJECTED",
        "severity": "SCOPE_OVERSTATEMENT",
        "details": (
            "Strict class/mask freshness is false; 25345 is snapshot-relative "
            "only; absolute historical freshness is NOT ESTABLISHED."
        ),
        "disposition": "Retain the exact core landscape only; reject freshness/panel promotion authority.",
    },
    {
        "id": "D-009",
        "artifact": "Gate V2 registry_v2 and semantic verifier",
        "status": "REJECTED_ROUTE_CLOSED",
        "severity": "AUTHORITY_AND_SOUNDNESS",
        "details": (
            "Registry omissions include E4, P5 Family U, and exact-T intervals; "
            "the verifier passed its 32 tests but admitted 15 material bypasses."
        ),
        "disposition": "Gate V2=CLOSED/FAIL; new T(n)=NOT AUTHORIZED.",
    },
    {
        "id": "D-010",
        "artifact": "Gate V2 audit source bundle",
        "status": "ACCEPTED_WITH_CONDITIONS_AS_NEGATIVE_AUTHORITY",
        "severity": "PROVENANCE",
        "details": (
            "Stale source hashes, non-relocatable legacy paths, a placeholder "
            "RESULTS_Z field, and a zero-byte replay log are disclosed."
        ),
        "disposition": "Use the audit for its fail-closed rejection and protected exact core only.",
    },
    {
        "id": "D-011",
        "artifact": "2026-07-13 final packaging audit",
        "status": "SCOPE_SUPERSEDED_PROJECT_WIDE",
        "severity": "SCOPE",
        "details": "It predates post-trigger theorem and route packages.",
        "disposition": "Retain as authority for its exact finite computations, not current project governance.",
    },
    {
        "id": "D-012",
        "artifact": "NEXT_TASK.md near-counterexample continuation",
        "status": "SUPERSEDED_FOR_EXECUTION_AUTHORIZATION",
        "severity": "GOVERNANCE",
        "details": "The local note predates Global Route Reset and all post-trigger STOP decisions.",
        "disposition": "Do not execute unless a restart trigger in this master package is independently admitted.",
    },
    {
        "id": "D-013",
        "artifact": "SRC-017 bundled precompiled verify_pruning binary",
        "status": "PRESERVED_FOR_CUSTODY_NOT_TRUSTED",
        "severity": "EXECUTABLE_PROVENANCE",
        "details": "The source archive includes a precompiled verifier executable.",
        "disposition": "Never use the bundled binary as authority. The accepted computation relies on the recorded clean rebuild from src/verify_pruning.cpp and exact replay.",
    },
]


RESTART_TRIGGERS = [
    {
        "id": "T-001",
        "bridge": "indicator_level_lower_tail_or_signed_covariance",
        "requirement": (
            "A precise primary theorem proves the exact growing-shift signed "
            "indicator covariance, classwise exact-support weight covariance, "
            "or HC-LT with uniform summable error and dyadic-boundary control."
        ),
        "payoff": "Reopen a bounded proof audit for an almost-all theorem.",
    },
    {
        "id": "T-002",
        "bridge": "effective_exceptional_set_elimination",
        "requirement": (
            "A theorem gives eventual emptiness, an explicit finite threshold, "
            "or certified descent from every exception above an explicit bound."
        ),
        "payoff": "Reopen only the all-sufficiently-large and finite-closeout bridge.",
    },
    {
        "id": "T-003",
        "bridge": "representation_independent_non_affine_unconditional_descent",
        "requirement": (
            "An explicit non-affine representation-independent transformation "
            "has exact forward closure, strict descent, complete tail coverage, "
            "and terminal soundness via a decoder or state-specific certificate."
        ),
        "payoff": "Reopen a theorem-only descent audit outside the affine no-go scope.",
    },
    {
        "id": "T-004",
        "bridge": "finite_counterexample_reduction",
        "requirement": (
            "A proved theorem reduces existence of a counterexample to an "
            "explicit finite interval or finite certified state space."
        ),
        "payoff": "Authorize an exact finite computation only on the proved domain.",
    },
    {
        "id": "T-005",
        "bridge": "candidate_certificate",
        "requirement": (
            "A concrete integer candidate is accompanied by complete exponent-"
            "pair obstructions and passes two independent exact verifiers built from source."
        ),
        "payoff": "Reopen solely for counterexample certificate adjudication.",
    },
]

REPOSITORY_SNAPSHOT_PATTERNS = [
    re.compile(
        r"^analysis/(p2_core|k4_survivor_incidence|p4_maximizer_census|"
        r"p4_weighted_transferability|p4_mod8_live_landscape|"
        r"p5_sparse_panel_feasibility|p5_family_u_census)/"
    ),
    re.compile(r"^output/tn_pilot_20260713/"),
    re.compile(
        r"^docs/(tn_pilot_results|tn_low_tail_analysis|"
        r"p2_persistent_core_audit|k4_survivor_incidence_audit|"
        r"p4_maximizer_class_census|weighted_fixed_p4_transferability|"
        r"exact_p4_mod8_live_coverage_landscape|"
        r"p5_sparse_cross_class_panel_feasibility|"
        r"p5_family_u_unbalanced_full_sparse_census|"
        r"p4_gate_v2_route2_closure|current_state|audit_gap_register)\.md$"
    ),
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8", newline="\n")


def write_json(path: Path, value) -> None:
    write_text(
        path,
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2),
    )


def git(repo: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        capture_output=True,
        check=True,
    )
    return completed.stdout.strip()


def locate_source(downloads: Path, record: dict) -> Path:
    direct = downloads / record["source_name"]
    if direct.is_file() and sha256(direct) == record["sha256"]:
        return direct
    matches = []
    for candidate in downloads.glob("*.zip"):
        if candidate.is_file() and sha256(candidate) == record["sha256"]:
            matches.append(candidate)
    if len(matches) != 1:
        raise RuntimeError(
            f"{record['id']}: expected exactly one source by hash, found {matches}"
        )
    return matches[0]


def validate_inner_manifest(archive_path: Path) -> tuple[str, int]:
    with zipfile.ZipFile(archive_path) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"CRC failure in {archive_path}: {bad}")
        infos = archive.infolist()
        for info in infos:
            member = Path(info.filename)
            if member.is_absolute() or ".." in member.parts:
                raise RuntimeError(f"unsafe member in {archive_path}: {info.filename}")
        names = {info.filename for info in infos if not info.is_dir()}
        manifests = sorted(
            (
                name
                for name in names
                if Path(name).name
                in {"SHA256SUMS", "SHA256SUMS.txt", "MANIFEST.sha256"}
            ),
            key=lambda name: (len(Path(name).parts), name),
        )
        if not manifests:
            return "NOT_PRESENT", 0
        manifest = manifests[0]
        base = Path(manifest).parent
        checked = 0
        for line in archive.read(manifest).decode("utf-8").splitlines():
            if not line.strip():
                continue
            match = re.match(r"^([0-9a-f]{64})\s{1,2}(.+)$", line)
            if not match:
                raise RuntimeError(f"bad manifest line in {archive_path}: {line!r}")
            expected, relative = match.groups()
            candidates = [
                (base / relative).as_posix(),
                Path(relative).as_posix(),
            ]
            member_name = next((name for name in candidates if name in names), None)
            if member_name is None:
                raise RuntimeError(
                    f"manifest member missing in {archive_path}: {relative}"
                )
            actual = hashlib.sha256(archive.read(member_name)).hexdigest()
            if actual != expected:
                raise RuntimeError(
                    f"inner manifest mismatch in {archive_path}: {member_name}"
                )
            checked += 1
        return "PASS", checked


def snapshot_repository(repo: Path, output: Path) -> list[dict]:
    raw = subprocess.check_output(
        ["git", "ls-tree", "-r", "-l", "-z", "HEAD"],
        cwd=repo,
    )
    records = []
    for item in raw.split(b"\0"):
        if not item:
            continue
        meta, path_bytes = item.split(b"\t", 1)
        mode, object_type, oid, size = meta.decode("ascii").split()
        path = path_bytes.decode("utf-8")
        if not any(pattern.search(path) for pattern in REPOSITORY_SNAPSHOT_PATTERNS):
            continue
        if object_type != "blob":
            raise RuntimeError(f"non-blob selected for snapshot: {path}")
        content = subprocess.check_output(
            ["git", "cat-file", "blob", oid],
            cwd=repo,
        )
        if len(content) != int(size):
            raise RuntimeError(f"git object size mismatch: {path}")
        destination = output / "repository_snapshot" / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
        records.append(
            {
                "path": path,
                "git_mode": mode,
                "git_blob_oid": oid,
                "size_bytes": len(content),
                "sha256": hashlib.sha256(content).hexdigest(),
            }
        )
    if not records:
        raise RuntimeError("repository authority snapshot is empty")
    return records


def markdown_table(rows: list[dict], columns: list[tuple[str, str]]) -> str:
    header = "| " + " | ".join(label for _, label in columns) + " |"
    rule = "|" + "|".join("---" for _ in columns) + "|"
    body = []
    for row in rows:
        values = []
        for key, _ in columns:
            value = str(row.get(key, "")).replace("\n", " ").replace("|", "\\|")
            values.append(value)
        body.append("| " + " | ".join(values) + " |")
    return "\n".join([header, rule, *body])


def build_package(repo: Path, downloads: Path, output: Path, freeze_utc: str) -> None:
    if output.exists():
        raise RuntimeError(f"refusing to overwrite existing output: {output}")
    if git(repo, "rev-parse", "HEAD") != EXPECTED_HEAD:
        raise RuntimeError("repository HEAD drifted from the frozen closeout head")

    baseline_names = [
        "README.md",
        "REPORT_zh.md",
        "output/formal_results_audit.json",
        "output/final_packaging_audit.json",
        "cert/NO_COUNTEREXAMPLE_CERTIFICATE.txt",
    ]
    baseline_hashes = {name: sha256(repo / name) for name in baseline_names}

    output.mkdir(parents=True)
    source_dir = output / "source_archives"
    source_dir.mkdir()
    archive_inventory = []
    for record in SOURCE_ARCHIVES:
        source = locate_source(downloads, record)
        if sha256(source) != record["sha256"]:
            raise RuntimeError(f"source hash drift: {source}")
        inner_status, inner_count = validate_inner_manifest(source)
        destination = source_dir / record["canonical_name"]
        shutil.copyfile(source, destination)
        archive_inventory.append(
            {
                **record,
                "source_path_at_freeze": str(source),
                "package_path": destination.relative_to(output).as_posix(),
                "size_bytes": destination.stat().st_size,
                "outer_zip_crc": "PASS",
                "inner_manifest_status": inner_status,
                "inner_manifest_record_count": inner_count,
            }
        )

    baseline_dir = output / "baseline_snapshot"
    for relative in baseline_names:
        destination = baseline_dir / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / relative, destination)

    repository_snapshot = snapshot_repository(repo, output)
    write_json(
        output / "REPOSITORY_AUTHORITY_SNAPSHOT.json",
        {
            "schema": "a303656-repository-authority-snapshot-v1",
            "freeze_utc": freeze_utc,
            "repository_head": EXPECTED_HEAD,
            "selection": [
                "tracked compact T(n) pilot authority",
                "tracked compact P2/K4/P4/P5 finite authority",
                "tracked exact reports and Gate V2 closure",
            ],
            "file_count": len(repository_snapshot),
            "total_bytes": sum(row["size_bytes"] for row in repository_snapshot),
            "files": repository_snapshot,
        },
    )

    package_scripts = output / "scripts"
    package_scripts.mkdir()
    for script_name in [
        "build_master_authority.py",
        "verify_master_authority.py",
        "build_deterministic_authority_zip.py",
    ]:
        shutil.copyfile(repo / "scripts" / script_name, package_scripts / script_name)
        os.chmod(package_scripts / script_name, 0o755)

    machine_verdict = {
        "schema": "a303656-post-trigger-master-verdict-v1",
        "freeze_utc": freeze_utc,
        "a303656_status": "UNRESOLVED",
        "project_status": "PAUSED",
        "active_promoted_route": None,
        "general_proof_obtained": False,
        "certified_counterexample_found": False,
        "master_package_verdict": "PASS_WITH_DISCLOSED_CUSTODY_EXCEPTION",
        "custody_complete": False,
        "missing_historical_input_sha256": MISSING_POSITIVE_DENSITY_SHA256,
        "project_decision": {
            "positive_authority": "FREEZE",
            "closed_routes": "STOP",
            "unresolved_bridges": "SPECULATIVE_WATCH",
            "new_execution": "NOT_AUTHORIZED",
        },
    }
    write_json(output / "MACHINE_VERDICT.json", machine_verdict)

    write_json(
        output / "THEOREM_LEDGER.json",
        {
            "schema": "a303656-master-theorem-ledger-v1",
            "freeze_utc": freeze_utc,
            "entries": THEOREMS,
        },
    )
    write_json(
        output / "FINITE_COMPUTATION_LEDGER.json",
        {
            "schema": "a303656-master-finite-computation-ledger-v1",
            "freeze_utc": freeze_utc,
            "entries": FINITE_COMPUTATIONS,
        },
    )
    write_text(
        output / "THEOREM_LEDGER.md",
        "# Theorem Ledger\n\n"
        + markdown_table(
            THEOREMS,
            [
                ("id", "ID"),
                ("group", "Authority group"),
                ("name", "Result"),
                ("classification", "Class"),
                ("adjudication", "Adjudication"),
                ("scope_limit", "Scope limit"),
            ],
        ),
    )
    write_text(
        output / "FINITE_COMPUTATION_LEDGER.md",
        "# Exact Finite Computation Ledger\n\n"
        + markdown_table(
            FINITE_COMPUTATIONS,
            [
                ("id", "ID"),
                ("name", "Computation"),
                ("classification", "Class"),
                ("interval_or_domain", "Explicit interval or domain"),
                ("result", "Result"),
                ("scope_limit", "Scope limit"),
            ],
        ),
    )
    write_json(
        output / "ROUTE_MATRIX.json",
        {
            "schema": "a303656-master-route-matrix-v1",
            "freeze_utc": freeze_utc,
            "routes": ROUTES,
        },
    )
    with (output / "ROUTE_MATRIX.csv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        fieldnames = [
            "id",
            "route",
            "state",
            "authority",
            "reason",
            "exact_restart_trigger",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(ROUTES)
    write_text(
        output / "ROUTE_MATRIX.md",
        "# Complete Route Matrix\n\n"
        + markdown_table(
            ROUTES,
            [
                ("id", "ID"),
                ("route", "Route"),
                ("state", "State"),
                ("authority", "Authority"),
                ("reason", "Adjudication"),
                ("exact_restart_trigger", "Exact restart trigger"),
            ],
        ),
    )

    write_json(
        output / "ARTIFACT_DEFECT_LEDGER.json",
        {
            "schema": "a303656-master-artifact-defect-ledger-v1",
            "freeze_utc": freeze_utc,
            "defects": DEFECTS,
        },
    )
    write_json(
        output / "RESTART_GATE.json",
        {
            "schema": "a303656-restart-gate-v1",
            "freeze_utc": freeze_utc,
            "current_decision": "PAUSE",
            "automatic_restart_authorized": False,
            "exact_triggers": RESTART_TRIGGERS,
            "mandatory_admission_checks": [
                "exact primary theorem statement or exact finite certificate",
                "source version and raw-byte custody",
                "hypothesis and quantifier crosswalk to A303656",
                "effectivity, boundary, and uniformity audit",
                "independent adversarial proof or certificate review",
                "narrow scope authorization before any computation",
            ],
            "forbidden_without_trigger": [
                "linear interval extension",
                "broad CRT or adaptive panel search",
                "Gate V2 or Design A execution",
                "promotion from timeout, UNKNOWN, heuristic failure, or uncertified UNSAT",
            ],
        },
    )
    write_json(
        output / "SOURCE_ARCHIVE_INVENTORY.json",
        {
            "schema": "a303656-master-source-archive-inventory-v1",
            "freeze_utc": freeze_utc,
            "archives": archive_inventory,
            "missing_historical_inputs": [
                {
                    "filename_as_recorded": "A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(6).zip",
                    "size_bytes": 268781,
                    "sha256": MISSING_POSITIVE_DENSITY_SHA256,
                    "status": "MISSING_NOT_RECONSTRUCTED",
                    "active_replacement": "SRC-004",
                }
            ],
        },
    )
    with (output / "SOURCE_ARCHIVE_INVENTORY.tsv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(
            [
                "id",
                "canonical_name",
                "size_bytes",
                "sha256",
                "adjudication",
                "inner_manifest_status",
                "authority_role",
            ]
        )
        for row in archive_inventory:
            writer.writerow(
                [
                    row["id"],
                    row["canonical_name"],
                    row["size_bytes"],
                    row["sha256"],
                    row["adjudication"],
                    row["inner_manifest_status"],
                    row["authority_role"],
                ]
            )

    hierarchy = {
        "schema": "a303656-master-authority-hierarchy-v1",
        "freeze_utc": freeze_utc,
        "positive_authority": [
            "P-001 direct dyadic positive-density theorem",
            "P-002 distinct-shift positive-density variant",
            "P-003 bounded multiplicity, additive energy, and singular-factor support",
            "P-004 nu_tau exact-support bounded minorant and correct mean scale",
            "P-006 HC-A aggregate high-cutoff bad-tail bound",
            "F-001 through F-008 exact finite computations within explicit bounds",
        ],
        "negative_structural_authority": [
            "N-001 random CRT L2 versus adversarial L-infinity barrier",
            "N-002 private-witness positive-density obstruction",
            "N-003 mod-6 nu_tau variance obstruction",
            "N-004 theta/minor-arc critical-scale and phase barrier",
            "N-005 Gaussian single-branch sparsity obstruction",
            "N-006 affine S-unit axis-fiber classification",
            "N-007 entropy-sparsity finite-state affine descent no-go",
            "N-008 canonical-record critical saturation",
            "N-009 actual-mask Helly and profinite obstruction",
        ],
        "unresolved_bridges": [
            "indicator_level_lower_tail_or_signed_covariance",
            "effective_exceptional_set_elimination",
            "representation_independent_non_affine_unconditional_descent",
        ],
        "governance": {
            "project": "PAUSED",
            "active_promoted_route": None,
            "new_execution": "NOT_AUTHORIZED",
            "a303656": "UNRESOLVED",
        },
    }
    write_json(output / "AUTHORITY_HIERARCHY.json", hierarchy)

    package_manifest = {
        "schema": "a303656-post-trigger-master-package-manifest-v1",
        "package_name": PACKAGE_NAME,
        "freeze_utc": freeze_utc,
        "repository_head": EXPECTED_HEAD,
        "generator": "scripts/build_master_authority.py",
        "source_archive_count": len(archive_inventory),
        "source_archive_unique_sha256_count": len(
            {row["sha256"] for row in archive_inventory}
        ),
        "missing_historical_input_count": 1,
        "theorem_entry_count": len(THEOREMS),
        "finite_computation_entry_count": len(FINITE_COMPUTATIONS),
        "route_count": len(ROUTES),
        "defect_count": len(DEFECTS),
        "repository_snapshot_file_count": len(repository_snapshot),
        "repository_snapshot_total_bytes": sum(
            row["size_bytes"] for row in repository_snapshot
        ),
        "baseline_snapshot": baseline_hashes,
        "scope_guards": {
            "new_T_evaluations": 0,
            "new_interval_scans": 0,
            "new_CRT_searches": 0,
            "certified_baseline_overwrites": 0,
            "source_archive_reconstructions": 0,
        },
    }
    write_json(output / "PACKAGE_MANIFEST.json", package_manifest)

    write_json(
        output / "environment.json",
        {
            "schema": "a303656-master-authority-environment-v1",
            "freeze_utc": freeze_utc,
            "python": sys.version,
            "platform": platform.platform(),
            "repository_head": EXPECTED_HEAD,
            "generator_sha256": sha256(repo / "scripts/build_master_authority.py"),
            "verifier_sha256": sha256(repo / "scripts/verify_master_authority.py"),
            "zip_builder_sha256": sha256(
                repo / "scripts/build_deterministic_authority_zip.py"
            ),
        },
    )

    write_text(
        output / "README.md",
        f"""# A303656 POST-TRIGGER MASTER AUTHORITY AND RESTART-GATE REVIEW

Freeze: `{freeze_utc}`

This is the single project-level authority package for the post-trigger
closeout. It preserves accepted positive authority, accepted negative
structural authority, exact finite computations with explicit bounds, route
closures, speculative watches, artifact defects, and exact restart gates.

## Final status

- A303656: **UNRESOLVED**
- General proof: **NONE**
- Certified counterexample: **NONE**
- Project: **PAUSED**
- Active promoted route: **NONE**
- New computation or Gate V2 execution: **NOT AUTHORIZED**
- Package verdict: **PASS WITH DISCLOSED CUSTODY EXCEPTION**

The missing historical archive with SHA256
`{MISSING_POSITIVE_DENSITY_SHA256}` was not reconstructed. The repaired,
independently verified `aa0392...` positive-density package is the active
authority.

Run:

```bash
python3 scripts/verify_master_authority.py --root .
```

The verifier checks all package hashes, source archive CRCs and outer hashes,
classification vocabularies, explicit finite bounds, route/restart invariants,
the custody exception, and frozen baseline snapshots.
""",
    )

    write_text(
        output / "EXECUTIVE_VERDICT.md",
        f"""# Executive Verdict

## Project decision

```text
A303656: UNRESOLVED
GENERAL PROOF: NONE
CERTIFIED COUNTEREXAMPLE: NONE
PROJECT: PAUSED
ACTIVE PROMOTED ROUTE: NONE
NEW EXECUTION: NOT AUTHORIZED
MASTER PACKAGE: PASS WITH DISCLOSED CUSTODY EXCEPTION
```

The project has accumulated genuine positive theorems, genuine negative
structural theorems, and substantial exact finite computations. None closes
the universal statement. The accepted positive result remains positive density;
the accepted negative results close multiple natural method classes without
proving the conjecture false.

The exact missing historical input
`{MISSING_POSITIVE_DENSITY_SHA256}` is recorded, not fabricated. Its absence
does not invalidate the active repaired positive-density authority, but it
prevents a claim of complete historical byte custody.

Future work is limited to the exact triggers in `RESTART_GATE.md`. In their
absence, all active campaigns remain paused.
""",
    )

    positive_rows = [row for row in THEOREMS if row["group"] == "POSITIVE_AUTHORITY"]
    negative_rows = [
        row for row in THEOREMS if row["group"] == "NEGATIVE_STRUCTURAL_AUTHORITY"
    ]
    write_text(
        output / "AUTHORITY_HIERARCHY.md",
        """# Authority Hierarchy

## Positive authority

"""
        + markdown_table(
            positive_rows,
            [
                ("id", "ID"),
                ("name", "Authority"),
                ("classification", "Class"),
                ("adjudication", "Adjudication"),
                ("scope_limit", "Scope limit"),
            ],
        )
        + """

## Negative structural authority

"""
        + markdown_table(
            negative_rows,
            [
                ("id", "ID"),
                ("name", "Authority"),
                ("classification", "Class"),
                ("adjudication", "Adjudication"),
                ("scope_limit", "Scope limit"),
            ],
        )
        + """

## Unresolved bridges

1. Indicator-level lower-tail or signed covariance.
2. Effective elimination of the exceptional set.
3. Representation-independent non-affine unconditional descent.

No conditional implication is promoted as an unconditional theorem.
""",
    )

    write_text(
        output / "ARTIFACT_DEFECT_LEDGER.md",
        "# Artifact Defect Ledger\n\n"
        + markdown_table(
            DEFECTS,
            [
                ("id", "ID"),
                ("artifact", "Artifact"),
                ("status", "Status"),
                ("severity", "Class"),
                ("disposition", "Disposition"),
            ],
        )
        + "\n\nDefects are preserved and adjudicated; evidence is not deleted.",
    )

    write_text(
        output / "RESTART_GATE.md",
        """# Exact Restart Gate

Current decision: **PAUSE**. No trigger causes automatic restart.

"""
        + markdown_table(
            RESTART_TRIGGERS,
            [
                ("id", "ID"),
                ("bridge", "Bridge"),
                ("requirement", "Exact trigger"),
                ("payoff", "Authorized review scope"),
            ],
        )
        + """

## Admission protocol

Every proposed restart must provide exact source/version custody, a theorem or
certificate statement, a quantifier and hypothesis crosswalk, an effectivity
and boundary audit, and an independent adversarial review. Only then may a
narrow execution scope be authorized.

Without admission, do not extend intervals, launch broad CRT/adaptive searches,
reopen Gate V2, or infer a theorem from UNKNOWN, timeout, heuristic failure, or
uncertified solver UNSAT.
""",
    )

    write_text(
        output / "CUSTODY_EXCEPTION.md",
        f"""# Custody Exception

## Missing historical bytes

- Recorded filename:
  `A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(6).zip`
- Recorded size: `268781` bytes
- Recorded SHA256:
  `{MISSING_POSITIVE_DENSITY_SHA256}`
- Search result: **NOT FOUND**
- Reconstruction: **FORBIDDEN AND NOT ATTEMPTED**

## Adjudication

The missing archive was a historical direct input to the canonical-compression
and finite-state-multibranch packages. Both downstream packages preserve their
own complete output bytes and pass their package validators. Their inherited
positive-density premise is independently available in the repaired active
authority `SRC-004`, SHA256
`aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2`.

Therefore:

- positive-density authority: **ACCEPTED from SRC-004**;
- SRC-001 and SRC-006: **ACCEPTED WITH CUSTODY EXCEPTION**;
- complete historical byte custody: **NOT CLAIMED**;
- mathematical proof or counterexample status: **UNCHANGED**.
""",
    )

    write_text(
        output / "MASTER_AUTHORITY_REPORT.md",
        """# Master Authority Report

## 1. Mandate

This closeout replaces fragmented project-level governance with one
fail-closed authority hierarchy. It does not overwrite any certified baseline,
does not run a new search, and does not claim a proof or counterexample.

## 2. Accepted positive authority

The frozen dyadic theorem proves positive density, including its
distinct-shift form and supporting collision/energy structure. The exact
bounded support weight nu_tau has the correct support and mean scale. HC-A
gives a genuine aggregate high-cutoff tail bound. These statements remain
strictly below an almost-all or universal theorem.

## 3. Accepted negative structural authority

The package accepts route-specific obstructions for random CRT second moments,
private witnesses, the literal globally centered nu_tau trigger, the
theta/minor-arc scale, fixed-affine Gaussian descent, affine S-unit fibers,
finite-state affine multibranch descent, canonical record charging, and
finite-Helly/profinite simultaneous selection.

Each negative theorem is scoped to its hypotheses. None is a proof that the
conjecture is false.

## 4. Exact finite computations

All accepted finite computations appear in `FINITE_COMPUTATION_LEDGER.json`
with explicit bounds. The strongest continuous verified interval is
`[240000000001,241600000000]`; the baseline audit covers 1,853,000,000
distinct tested integers in its declared datasets. The p2-cover result, T(n)
pilot, P4 landscapes, fixed panels, P5 Family-U census, and finite analytic
anti-cover results remain bounded evidence only.

## 5. Supersession and rejection

Original P4 freshness and promotion claims are rejected while the exact core
landscape is retained. Gate V2, registry_v2, and its semantic authorization
verifier are closed FAIL. Duplicate downloads contribute no independent proof
weight. The 2026-07-13 packaging audit remains authority for its finite results
but is superseded as project-wide governance.

## 6. Remaining bridges

Only three project-level bridges remain:

1. indicator-level lower-tail or signed covariance;
2. effective exceptional-set elimination;
3. representation-independent non-affine unconditional descent.

They are speculative watches with exact triggers, not active tasks.

## 7. Final decision

The correct project decision is PAUSE. Completed or refuted routes are STOP.
Gate V2 execution is NOT AUTHORIZED. The conjecture remains UNRESOLVED.
""",
    )
    write_text(
        output / "MASTER_AUTHORITY_REPORT_zh.md",
        """# 项目级 Master Authority 收口报告

## 一、裁定范围

本包把 post-trigger 阶段的定理、精确有限计算、路线状态、artifact
缺陷与重启门统一为一个 fail-closed 权威层级。它不覆盖既有 certified
baseline，不启动新搜索，也不声称已经证明或否定猜想。

## 二、已接受的正面权威

正密度定理及其 distinct-shift 形式被接受；精确支撑权重 nu_tau
及正确均值尺度被接受；HC-A 高 cutoff 聚合尾界被接受。它们都严格弱于
almost-all 或 universal 结论。

## 三、已接受的负面结构权威

本包接受以下方法类内的障碍：随机 CRT 的 L2 对抗 adversarial L-infinity、
private witness、字面全局中心化 nu_tau 的 mod-6 方差障碍、
theta/minor-arc 尺度障碍、固定仿射高斯单分支、仿射 S-unit 轴纤维、
有限状态仿射多分支熵稀疏障碍、canonical charging 饱和障碍，以及
finite-Helly/profinite simultaneous-selection 障碍。

每项负面结论只在其明确假设内有效；没有任何一项构成猜想为假的证明。

## 四、精确有限计算

所有接受的有限计算均在 `FINITE_COMPUTATION_LEDGER.md` 和 JSON
版本中列出明确边界。最强连续验证区间为
`[240000000001,241600000000]`；baseline audit 在其声明的数据集中
覆盖 1,853,000,000 个不同整数。p2-cover、T(n) pilot、P4 landscape、
固定面板、P5 Family-U census 与有限 analytic anti-cover 仍然只是
有界证据。

## 五、缺陷、降级与 supersession

P4 原 freshness/promotion 主张被拒绝，但精确核心景观保留。
Gate V2、registry_v2 及其 semantic authorization verifier 均为
CLOSED/FAIL。重复下载按原始 SHA-256 去重，不增加证明权重。p2-cover
包内预编译二进制只作 custody 保存，不被信任；权威来自源码重建记录。
2026-07-13 packaging audit 的有限结果继续有效，但其项目级治理地位
已被本包取代。

缺失的历史正密度压缩包没有被伪造或重建。该缺口以 custody exception
保留；活动正密度权威来自独立验证过的 repaired 包。

## 六、未解决桥梁

仅保留三项项目级 watch：

1. indicator-level lower-tail 或 signed covariance；
2. exceptional set 的 effective elimination；
3. representation-independent、non-affine、unconditional descent。

它们只有满足 `RESTART_GATE.md` 的精确触发条件后才能进入窄范围复核，
目前不是已授权任务。

## 七、最终结论

项目结论为 **PAUSE**；已完成或已被结构性否定的路线为 **STOP**；
未解决桥梁仅为 **SPECULATIVE WATCH**；Gate V2 与新的执行均
**NOT AUTHORIZED**。A303656 仍为 **UNRESOLVED**。
""",
    )

    all_files_before_lists = sorted(
        path.relative_to(output).as_posix()
        for path in output.rglob("*")
        if path.is_file() and path.name not in {"PACKAGE_FILE_LIST.txt", "SHA256SUMS.txt"}
    )
    write_text(
        output / "PACKAGE_FILE_LIST.txt",
        "\n".join([*all_files_before_lists, "PACKAGE_FILE_LIST.txt"]),
    )
    manifest_files = sorted(
        (path for path in output.rglob("*") if path.is_file() and path.name != "SHA256SUMS.txt"),
        key=lambda path: path.relative_to(output).as_posix().encode("utf-8"),
    )
    manifest_lines = [
        f"{sha256(path)}  {path.relative_to(output).as_posix()}"
        for path in manifest_files
    ]
    write_text(output / "SHA256SUMS.txt", "\n".join(manifest_lines))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--downloads", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--freeze-utc", required=True)
    args = parser.parse_args()

    build_package(
        args.repo.resolve(),
        args.downloads.resolve(),
        args.output.resolve(),
        args.freeze_utc,
    )
    print(
        json.dumps(
            {
                "status": "PASS",
                "package": str(args.output.resolve()),
                "source_archive_count": len(SOURCE_ARCHIVES),
                "theorem_count": len(THEOREMS),
                "finite_computation_count": len(FINITE_COMPUTATIONS),
                "route_count": len(ROUTES),
                "defect_count": len(DEFECTS),
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
