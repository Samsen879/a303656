# Fail-closed restart gate

Restart is allowed only after one enumerated trigger is independently admitted. New ideas, compute, models, quota, or heuristics are not triggers.

| Allowed trigger |
|---|
| Indicator-level signed covariance theorem sufficient for the exact structured shift family. |
| HC-LT class lower-tail theorem. |
| Effective exceptional-set elimination. |
| Genuine representation-independent nonlinear descent. |
| Explicit finite reduction. |
| Credible independently certified counterexample candidate. |
| New primary literature theorem directly matching an A303656 blocker. |
