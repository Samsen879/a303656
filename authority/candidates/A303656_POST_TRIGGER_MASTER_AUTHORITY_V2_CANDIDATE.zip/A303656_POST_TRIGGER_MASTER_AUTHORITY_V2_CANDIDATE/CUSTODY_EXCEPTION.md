# Custody Exception

## Missing historical bytes

- Recorded filename:
  `A303656_DIRECT_TWO_SQUARE_POSITIVE_DENSITY_FROZEN(6).zip`
- Recorded size: `268781` bytes
- Recorded SHA256:
  `1d8bb9b45cb556d4693b568d42b10af386de88e734094d1af5f0396c9c243ff8`
- Search result: **NOT FOUND**
- Reconstruction: **FORBIDDEN AND NOT ATTEMPTED**

## Adjudication

The missing archive was a historical direct input to the canonical-compression
and finite-state-multibranch packages. Both downstream packages preserve their
own complete output bytes and pass their package validators. Their inherited
positive-density premise is independently available in the repaired active
authority `SRC-004`, SHA256
`aa0392a5ea1ddb0d4bb7f6c42b839d91dc054fab252deb07dae074cb889005b2`.

Therefore:

- positive-density authority: **ACCEPTED from SRC-004**;
- SRC-001 and SRC-006: **ACCEPTED WITH CUSTODY EXCEPTION**;
- complete historical byte custody: **NOT CLAIMED**;
- mathematical proof or counterexample status: **UNCHANGED**.
