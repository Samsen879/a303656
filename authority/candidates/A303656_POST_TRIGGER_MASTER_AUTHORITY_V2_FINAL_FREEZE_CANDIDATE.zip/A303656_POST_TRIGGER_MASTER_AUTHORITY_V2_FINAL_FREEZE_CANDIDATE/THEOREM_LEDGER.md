# Theorem and conditional-authority ledger

| ID | Classification | Name | Scope |
|---|---|---|---|
| P-001 | PROVED | Direct dyadic positive-density theorem | Positive density only; substantially subsumed by Radomskii v6; does not imply almost-all or universal representability. |
| P-002 | PROVED | Distinct-shift positive-density variant | Same positive-density-only limit as P-001. |
| P-003 | PROVED | Shift multiplicity, Sidon-scale energy, and singular-factor support | Supporting structure only; novelty is not established and the lemmas do not supply indicator covariance cancellation. |
| P-004 | PROVED | nu_tau exact-support bounded minorant and correct mean scale | No applicable growing parallel-shift covariance theorem is known; the finite sanity computation is non-evidentiary. |
| P-005 | ACCEPTED CONDITIONAL IMPLICATION | Weighted concentration-to-support implication | The required variance/covariance hypothesis is UNPROVED. |
| P-006 | PROVED | HC-A aggregate high-cutoff bad-tail bound | Does not bound the exceptional set without the unproved complete-survivor lower-tail theorem HC-LT. |
| P-007 | ACCEPTED CONDITIONAL IMPLICATION | HC-A plus HC-LT almost-all implication | HC-LT is UNKNOWN and close to the indicator-covariance barrier. |
| N-001 | PROVED NEGATIVE STRUCTURAL THEOREM | Random CRT L2 versus adversarial L-infinity barrier | Does not exclude a genuinely new generator-specific centered theorem. |
| N-002 | PROVED NEGATIVE STRUCTURAL THEOREM | Private-witness positive-density obstruction | Stops uniform private-witness suppression, not every witness method. |
| N-003 | PROVED NEGATIVE STRUCTURAL THEOREM | Mod-6 nu_tau between-class variance obstruction | A classwise W-trick removes this local bias but leaves an unproved parallel covariance theorem. |
| N-004 | PROVED NEGATIVE STRUCTURAL THEOREM | Exceptional-set spectral critical-scale and phase barrier | The O(sqrt(X) log X) threshold is specific to the SRC-005 absolute-minor-spectrum / F3 localization mechanism. It is not asserted as a universal necessary threshold for all future exceptional-set inverse methods, and a future arithmetic bipartite expansion theorem is not excluded. |
| N-005 | PROVED NEGATIVE STRUCTURAL THEOREM | Gaussian single-branch sparsity obstruction | Does not exclude genuinely nonlinear, representation-independent maps. |
| N-006 | PROVED NEGATIVE STRUCTURAL THEOREM | Affine S-unit axis-fiber classification | Uses the cited Evertse-Schlickewei-Schmidt finite-rank unit-equation theorem. |
| N-007 | PROVED NEGATIVE STRUCTURAL THEOREM | Entropy-sparsity finite-state affine descent no-go | Only the stated finite exact affine state framework is ruled out. |
| N-008 | PROVED NEGATIVE STRUCTURAL THEOREM | Canonical-record critical saturation | A different compressed record or a proved HC-LT theorem is not excluded. |
| N-009 | PROVED NEGATIVE STRUCTURAL THEOREM | Actual-mask Helly and profinite compactness obstruction | This proves arbitrarily large Helly obstruction on arbitrary finite active-shift restrictions. It does not prove that the complete D(n) actual-mask family itself has unbounded Helly number, and it does not exclude a theorem using the full arithmetic witness graph. |
| N-010 | PROVED NEGATIVE STRUCTURAL THEOREM | Theta-series divisor-switching, modular-cusp and pointwise minor-arc route closure | Stops the audited theta-series trigger only; it is not a theorem that all analytic approaches are impossible. |
| C-001 | ACCEPTED CONDITIONAL IMPLICATION | CRW fixed-parameter finite-reduction implication | No explicit fixed (Q,E) is known to satisfy CRW. CRW itself is NOT ESTABLISHED; route is INACTIVE / CONDITIONAL WATCH ONLY. |
