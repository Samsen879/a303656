# Exact Restart Gate

Current decision: **PAUSE**. No trigger causes automatic restart.

| ID | Bridge | Exact trigger | Authorized review scope |
|---|---|---|---|
| T-001 | indicator_level_lower_tail_or_signed_covariance | A precise primary theorem proves the exact growing-shift signed indicator covariance, classwise exact-support weight covariance, or HC-LT with uniform summable error and dyadic-boundary control. | Reopen a bounded proof audit for an almost-all theorem. |
| T-002 | effective_exceptional_set_elimination | A theorem gives eventual emptiness, an explicit finite threshold, or certified descent from every exception above an explicit bound. | Reopen only the all-sufficiently-large and finite-closeout bridge. |
| T-003 | representation_independent_non_affine_unconditional_descent | An explicit non-affine representation-independent transformation has exact forward closure, strict descent, complete tail coverage, and terminal soundness via a decoder or state-specific certificate. | Reopen a theorem-only descent audit outside the affine no-go scope. |
| T-004 | finite_counterexample_reduction | A proved theorem reduces existence of a counterexample to an explicit finite interval or finite certified state space. | Authorize an exact finite computation only on the proved domain. |
| T-005 | candidate_certificate | A concrete integer candidate is accompanied by complete exponent-pair obstructions and passes two independent exact verifiers built from source. | Reopen solely for counterexample certificate adjudication. |

## Admission protocol

Every proposed restart must provide exact source/version custody, a theorem or
certificate statement, a quantifier and hypothesis crosswalk, an effectivity
and boundary audit, and an independent adversarial review. Only then may a
narrow execution scope be authorized.

Without admission, do not extend intervals, launch broad CRT/adaptive searches,
reopen Gate V2, or infer a theorem from UNKNOWN, timeout, heuristic failure, or
uncertified solver UNSAT.
