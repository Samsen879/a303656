# Artifact Defect Ledger

| ID | Artifact | Status | Class | Disposition |
|---|---|---|---|---|
| D-001 | historical positive-density input to SRC-001 and SRC-006 | OPEN_DISCLOSED_CUSTODY_EXCEPTION | CUSTODY | Do not reconstruct or impersonate the bytes. Use SRC-004 aa0392... as active positive authority; accept SRC-001/SRC-006 with custody exception. |
| D-002 | legacy positive-density input variant 1d8bb9... | SUPERSEDED_FOR_ACTIVE_AUTHORITY | TYPOGRAPHY_AND_GENERATOR | SRC-004 aa0392... is the active repaired positive-density authority. |
| D-003 | SRC-012 simultaneous-selection replay | ACCEPTED_WITH_REPRODUCIBILITY_DEFECT | REPRODUCIBILITY | Mathematical fields retained; byte-determinism claim downgraded. |
| D-004 | SRC-007 Gaussian exact-check replay | ACCEPTED_WITH_REPRODUCIBILITY_DEFECT | REPRODUCIBILITY | Keep proofs and exact identities; do not claim cross-environment byte replay. |
| D-005 | SRC-013 weighted-minorant sanity replay | ACCEPTED_WITH_NON_EVIDENTIARY_NUMERIC_DRIFT | REPRODUCIBILITY | Sanity output remains non-evidentiary; exact theorem statements do not depend on it. |
| D-006 | SRC-017 p2-cover legacy report | ACCEPTED_WITH_TYPOGRAPHY_DEFECT | TYPOGRAPHY | Certificate, rebuilt source verifier, and exact numeric conclusions remain authoritative. |
| D-007 | Windows duplicate downloads | RESOLVED_BY_HASH_DEDUPLICATION | CUSTODY | One canonical copy per SHA256 is included; duplicates add no proof weight. |
| D-008 | original P4 mod-8-live freshness and promotion claims | SUPERSEDED_AND_REJECTED | SCOPE_OVERSTATEMENT | Retain the exact core landscape only; reject freshness/panel promotion authority. |
| D-009 | Gate V2 registry_v2 and semantic verifier | REJECTED_ROUTE_CLOSED | AUTHORITY_AND_SOUNDNESS | Gate V2=CLOSED/FAIL; new T(n)=NOT AUTHORIZED. |
| D-010 | Gate V2 audit source bundle | ACCEPTED_WITH_CONDITIONS_AS_NEGATIVE_AUTHORITY | PROVENANCE | Use the audit for its fail-closed rejection and protected exact core only. |
| D-011 | 2026-07-13 final packaging audit | SCOPE_SUPERSEDED_PROJECT_WIDE | SCOPE | Retain as authority for its exact finite computations, not current project governance. |
| D-012 | NEXT_TASK.md near-counterexample continuation | SUPERSEDED_FOR_EXECUTION_AUTHORIZATION | GOVERNANCE | Do not execute unless a restart trigger in this master package is independently admitted. |
| D-013 | SRC-017 bundled precompiled verify_pruning binary | PRESERVED_FOR_CUSTODY_NOT_TRUSTED | EXECUTABLE_PROVENANCE | Never use the bundled binary as authority. The accepted computation relies on the recorded clean rebuild from src/verify_pruning.cpp and exact replay. |

Defects are preserved and adjudicated; evidence is not deleted.
