# Theorem Ledger

| ID | Authority group | Result | Class | Adjudication | Scope limit |
|---|---|---|---|---|---|
| P-001 | POSITIVE_AUTHORITY | Direct dyadic positive-density theorem | PROVED | ACCEPTED | Positive density only; substantially subsumed by Radomskii v6; does not imply almost-all or universal representability. |
| P-002 | POSITIVE_AUTHORITY | Distinct-shift positive-density variant | PROVED | ACCEPTED | Same positive-density-only limit as P-001. |
| P-003 | POSITIVE_AUTHORITY | Shift multiplicity, Sidon-scale energy, and singular-factor support | PROVED | ACCEPTED_WITH_CONDITIONS | Supporting structure only; novelty is not established and the lemmas do not supply indicator covariance cancellation. |
| P-004 | POSITIVE_AUTHORITY | nu_tau exact-support bounded minorant and correct mean scale | PROVED | ACCEPTED_WITH_CONDITIONS | No applicable growing parallel-shift covariance theorem is known; the finite sanity computation is non-evidentiary. |
| P-005 | POSITIVE_AUTHORITY | Weighted concentration-to-support implication | CONDITIONAL | ACCEPTED_AS_CONDITIONAL_ONLY | The required variance/covariance hypothesis is UNPROVED. |
| P-006 | POSITIVE_AUTHORITY | HC-A aggregate high-cutoff bad-tail bound | PROVED | ACCEPTED_WITH_CUSTODY_EXCEPTION | Does not bound the exceptional set without the unproved complete-survivor lower-tail theorem HC-LT. |
| P-007 | POSITIVE_AUTHORITY | HC-A plus HC-LT almost-all implication | CONDITIONAL | ACCEPTED_AS_CONDITIONAL_ONLY | HC-LT is UNKNOWN and close to the indicator-covariance barrier. |
| N-001 | NEGATIVE_STRUCTURAL_AUTHORITY | Random CRT L2 versus adversarial L-infinity barrier | PROVED | ACCEPTED_AS_NEGATIVE_AUTHORITY | Does not exclude a genuinely new generator-specific centered theorem. |
| N-002 | NEGATIVE_STRUCTURAL_AUTHORITY | Private-witness positive-density obstruction | PROVED | ACCEPTED_AS_NEGATIVE_AUTHORITY | Stops uniform private-witness suppression, not every witness method. |
| N-003 | NEGATIVE_STRUCTURAL_AUTHORITY | Mod-6 nu_tau between-class variance obstruction | PROVED | ACCEPTED_AS_NEGATIVE_AUTHORITY | A classwise W-trick removes this local bias but leaves an unproved parallel covariance theorem. |
| N-004 | NEGATIVE_STRUCTURAL_AUTHORITY | Theta/minor-arc critical-scale and phase barrier | PROVED | ACCEPTED_AS_NEGATIVE_AUTHORITY | A future arithmetic bipartite expansion theorem is not excluded. |
| N-005 | NEGATIVE_STRUCTURAL_AUTHORITY | Gaussian single-branch sparsity obstruction | PROVED | ACCEPTED_AS_NEGATIVE_AUTHORITY | Does not exclude genuinely nonlinear, representation-independent maps. |
| N-006 | NEGATIVE_STRUCTURAL_AUTHORITY | Affine S-unit axis-fiber classification | PROVED_CONDITIONAL_ON_STANDARD_CITED_THEOREM | ACCEPTED_WITH_CONDITIONS | Uses the cited Evertse-Schlickewei-Schmidt finite-rank unit-equation theorem. |
| N-007 | NEGATIVE_STRUCTURAL_AUTHORITY | Entropy-sparsity finite-state affine descent no-go | PROVED | ACCEPTED_AS_NEGATIVE_AUTHORITY | Only the stated finite exact affine state framework is ruled out. |
| N-008 | NEGATIVE_STRUCTURAL_AUTHORITY | Canonical-record critical saturation | PROVED | ACCEPTED_AS_NEGATIVE_AUTHORITY | A different compressed record or a proved HC-LT theorem is not excluded. |
| N-009 | NEGATIVE_STRUCTURAL_AUTHORITY | Actual-mask Helly and profinite compactness obstruction | PROVED | ACCEPTED_AS_NEGATIVE_AUTHORITY | Does not exclude a theorem using the full arithmetic witness graph. |
