# Master Authority Report

## 1. Mandate

This closeout replaces fragmented project-level governance with one
fail-closed authority hierarchy. It does not overwrite any certified baseline,
does not run a new search, and does not claim a proof or counterexample.

## 2. Accepted positive authority

The frozen dyadic theorem proves positive density, including its
distinct-shift form and supporting collision/energy structure. The exact
bounded support weight nu_tau has the correct support and mean scale. HC-A
gives a genuine aggregate high-cutoff tail bound. These statements remain
strictly below an almost-all or universal theorem.

## 3. Accepted negative structural authority

The package accepts route-specific obstructions for random CRT second moments,
private witnesses, the literal globally centered nu_tau trigger, the
theta/minor-arc scale, fixed-affine Gaussian descent, affine S-unit fibers,
finite-state affine multibranch descent, canonical record charging, and
finite-Helly/profinite simultaneous selection.

Each negative theorem is scoped to its hypotheses. None is a proof that the
conjecture is false.

## 4. Exact finite computations

All accepted finite computations appear in `FINITE_COMPUTATION_LEDGER.json`
with explicit bounds. The strongest continuous verified interval is
`[240000000001,241600000000]`; the baseline audit covers 1,853,000,000
distinct tested integers in its declared datasets. The p2-cover result, T(n)
pilot, P4 landscapes, fixed panels, P5 Family-U census, and finite analytic
anti-cover results remain bounded evidence only.

## 5. Supersession and rejection

Original P4 freshness and promotion claims are rejected while the exact core
landscape is retained. Gate V2, registry_v2, and its semantic authorization
verifier are closed FAIL. Duplicate downloads contribute no independent proof
weight. The 2026-07-13 packaging audit remains authority for its finite results
but is superseded as project-wide governance.

## 6. Remaining bridges

Only three project-level bridges remain:

1. indicator-level lower-tail or signed covariance;
2. effective exceptional-set elimination;
3. representation-independent non-affine unconditional descent.

They are speculative watches with exact triggers, not active tasks.

## 7. Final decision

The correct project decision is PAUSE. Completed or refuted routes are STOP.
Gate V2 execution is NOT AUTHORIZED. The conjecture remains UNRESOLVED.
