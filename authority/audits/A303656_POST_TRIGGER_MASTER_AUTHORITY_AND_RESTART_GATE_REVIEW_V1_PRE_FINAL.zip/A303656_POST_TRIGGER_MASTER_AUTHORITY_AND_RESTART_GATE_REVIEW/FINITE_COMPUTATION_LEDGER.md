# Exact Finite Computation Ledger

| ID | Computation | Class | Explicit interval or domain | Result | Scope limit |
|---|---|---|---|---|---|
| F-001 | Certified baseline direct original-representation scan | EXACT_FINITE_COMPUTATION |  | candidate_count=0; every tested integer was represented | No theorem links the tested region to all integers. |
| F-002 | Bounded-order p2-cover obstruction | EXACT_FINITE_COMPUTATION |  | 527 primes cannot cover; any such finite cover needs at least 598 primes and at least 135 primes beyond the order bound. | Does not prove nonexistence of a larger finite cover. |
| F-003 | Validated T(n) pilot | EXACT_FINITE_COMPUTATION |  | PILOT-A minimum T=1 at 2,3,5,25; PILOT-B minimum T=16 at 240000005594; no T=0. | Only 300000 predeclared integers; no broad campaign authority. |
| F-004 | Fixed-P4 maximizer-class census | EXACT_FINITE_COMPUTATION |  | No T=0; unique G=231 minimum T=15 at n=196653638594. | Finite fixed-P4 panel only. |
| F-005 | Exact fixed-P4 mod-8-live landscape core | EXACT_FINITE_COMPUTATION |  | H8 min/max=32/201, 468 argmax tuples, lex-first (2,13,50,5), 21 maximizing full masks. | Exact landscape accepted; original strict freshness and promotion claims are rejected. |
| F-006 | Weighted fixed-P4 transferability audit | EXACT_FINITE_COMPUTATION |  | Weighted optimum G=219 at lex-first (1,9,21,21); t3=2 weighted optimum G=222 at lex-first (2,13,32,13); 12 deduplicated masks. | Empirical panel weights are not theorem evidence. |
| F-007 | P5 Family-U unbalanced sparse census | EXACT_FINITE_COMPUTATION |  | No T=0; minimum T=16 at 187808590514; exact mean 7762/227. | Family U only; no Family R/Q and no adaptive continuation. |
| F-008 | Analytic bad-prime finite anti-cover family | EXACT_FINITE_COMPUTATION |  | Certified finite-family survivor lower density at least 0.3855312313183401933866...; route does not scale under added primes. | Fixed finite prime family only. |
