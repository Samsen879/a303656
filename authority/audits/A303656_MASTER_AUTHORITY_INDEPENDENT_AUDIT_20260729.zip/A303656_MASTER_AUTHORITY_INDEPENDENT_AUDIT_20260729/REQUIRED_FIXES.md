# Required Fixes

## Blocking fixes before final freeze

1. Add the theta-series Phase A ZIP and the second-three-trigger comparative
   audit ZIP to the source inventory and custody set.
2. Split or rename `N-004` so the exceptional-set spectral barrier and the
   theta-series pointwise route closure are not conflated.
3. Add the two unrecorded source-artifact control-character defects to the
   defect ledger:
   - `A303656_EXCEPTIONAL_SET_INVERSE_PHASE_A.zip`:
     `FOURIER_AND_SPECTRAL_ANALYSIS.md`, byte `0x08` in `L_\Gamma=\beta^{-1}`;
   - `analytic_bad_prime_phaseA.zip`:
     eight `0x0C` bytes replacing the leading `f` in `\frac` expressions.
4. Extend the verifier with a recursive text scan of nested source ZIPs, while
   excluding genuine binary members.
5. Fix the finite-ledger Markdown generator to use `explicit_bounds` and add a
   JSON/Markdown semantic parity check.
6. Preserve the accepted CRW conditional theorem explicitly, or record a
   reasoned supersession mapping to `T-004`.

## Nonblocking clarification

Add a prominent statement that verifier `PASS` means artifact and governance
consistency, not independent validation of every mathematical proof.

## Status after repair

If these fixes are made without changing the substantive ledgers, the package
can reasonably be reissued as:

```text
PASS WITH DISCLOSED HISTORICAL CUSTODY EXCEPTION
```

Until then, the correct artifact status is:

```text
FIX REQUIRED — PRE-FINAL AUTHORITY DRAFT
```
