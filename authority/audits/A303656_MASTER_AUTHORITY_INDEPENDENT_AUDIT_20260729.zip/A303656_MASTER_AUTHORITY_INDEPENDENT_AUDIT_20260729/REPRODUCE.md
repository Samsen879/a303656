# Reproduction Notes

The independent audit performed these checks against the uploaded master ZIP:

```bash
sha256sum A303656_POST_TRIGGER_MASTER_AUTHORITY_AND_RESTART_GATE_REVIEW.zip
unzip -t A303656_POST_TRIGGER_MASTER_AUTHORITY_AND_RESTART_GATE_REVIEW.zip
python3 scripts/verify_master_authority.py --root .
python3 scripts/build_deterministic_authority_zip.py --root . --output rebuilt.zip
cmp original.zip rebuilt.zip
```

A separate recursive scanner opened every ZIP under `source_archives/`, tested
its CRC, and scanned text-like members for forbidden C0/DEL bytes. Binary files
were excluded by extension. This recursive check is not implemented by the
bundled verifier.
