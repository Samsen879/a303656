# Artifact Audit

## Passed checks

- Outer SHA256 independently recomputed.
- ZIP CRC/integrity: PASS.
- 265 entries under one safe top-level directory.
- No duplicate or unsafe outer members found.
- Internal verifier returned `PASS` with zero reported errors.
- All top-level textual files scanned clean for forbidden C0/DEL bytes.
- Deterministic rebuild was byte-identical to the uploaded ZIP.

## Rebuild result

```text
ORIGINAL SHA256:
904c9c0d0ed6b1a496f1e25591b4ce6f9b1401200c18f40263c899c337ce08b2

REBUILT SHA256:
904c9c0d0ed6b1a496f1e25591b4ce6f9b1401200c18f40263c899c337ce08b2

BYTE IDENTICAL:
YES
```

## Validator limitation

The bundled verifier checks hashes, JSON structure, route vocabulary,
repository-snapshot invariants, ZIP CRCs, and unsafe archive paths. It does not
recursively scan textual members inside nested source ZIPs for control-character
defects, and it does not prove the mathematical claims in the ledgers.
